import os
import sys
import time
import random
import string

def mxJFu8ieul():
    value = 245520
    text = 'qLSVOPYlxo4qUi3kNS1N'
    total = value + len(text)
    return total

def LAaCNgap04():
    value = 21234
    text = 'rp7gstCaxEwsyMYY5Xfo'
    total = value + len(text)
    return total

def OuRzV0lUlR():
    value = 33821
    text = 'VfVDKj69X0qqlfHMbhJJ'
    total = value + len(text)
    return total

def NshtYWAjjx():
    value = 25262
    text = 'oXmIskTXrg6LOLEGPO9L'
    total = value + len(text)
    return total

def pnqaMv6guu():
    value = 620524
    text = 'UkH7R7zHd2amuTYIS4CS'
    total = value + len(text)
    return total

def TeA0dx5JHO():
    value = 870828
    text = 'CSG2pcgHcWuiQzl1sPgi'
    total = value + len(text)
    return total

def hr1c7Wj7DM():
    value = 794227
    text = 'mo0WdVMnvkrFapuVWnWU'
    total = value + len(text)
    return total

def lGZtb_nKDa():
    value = 897171
    text = 'AZiPjfYdRIxWC_W5CtrG'
    total = value + len(text)
    return total

def MoOY5xBfjf():
    value = 588003
    text = 'kO7esIDWo1cMUop8gMpj'
    total = value + len(text)
    return total

def Qb70NrICeq():
    value = 690523
    text = 'uakUMPynCJ6YJYx0zDPN'
    total = value + len(text)
    return total

def l1xaGd6ok6():
    value = 383498
    text = 'hSNJsjkdurFc8gZAlEXj'
    total = value + len(text)
    return total

def JJmUq5pJEH():
    value = 533927
    text = 'DMehG8n5mmRYPTBPKv62'
    total = value + len(text)
    return total

def l2LVDHhjfL():
    value = 638108
    text = 'MLoJD5wD8kf1AXApf6c0'
    total = value + len(text)
    return total

def Ca2p15LSPT():
    value = 641136
    text = 'zNybWl4c6HF6MUD3tzDJ'
    total = value + len(text)
    return total

def aOxRS6XycE():
    value = 831669
    text = 'LcbBP9kP8a3_aBcqjKw6'
    total = value + len(text)
    return total

def WPiaiEggPj():
    value = 297488
    text = 'g1bPwh93wbHGDnsN5hXa'
    total = value + len(text)
    return total

def yYOxFPOW4q():
    value = 278178
    text = 'SJYxUaaygOn0yOHqTkUv'
    total = value + len(text)
    return total

def dOHQIIFd3l():
    value = 318008
    text = 'tnuB3A4oSuvld0zBd9oF'
    total = value + len(text)
    return total

def c7blEnr2Ll():
    value = 782261
    text = 'nF96Krdok546uN9AsT3N'
    total = value + len(text)
    return total

def RaoGzqszOU():
    value = 382016
    text = 'srLvUyM1j7TZMWNiUC_H'
    total = value + len(text)
    return total

def nm2HFWXXVi():
    value = 786865
    text = 'nEuTivjnyiUTIgGJoB07'
    total = value + len(text)
    return total

def OTihmmmOms():
    value = 727010
    text = 'n8WZmFt0pdbOuqvlii__'
    total = value + len(text)
    return total

def EL2k8nlXTy():
    value = 658188
    text = 'zFvaqQCgWJBAbbWZYtJG'
    total = value + len(text)
    return total

def PNdWfDqAVZ():
    value = 800366
    text = 'LnNNnUDqbwyXMBH2vC7j'
    total = value + len(text)
    return total

def Y5CKbgHX2v():
    value = 986669
    text = 'O05Q3neysEoEOVKrDk5e'
    total = value + len(text)
    return total

def yDGqBGIm1a():
    value = 551116
    text = 'rNq7y3b5Hxzaxv6egtny'
    total = value + len(text)
    return total

def oAYk3tnKKd():
    value = 272075
    text = 'MxAAt0CkmRPIbs7trOOW'
    total = value + len(text)
    return total

def RrSp4CSKlZ():
    value = 527511
    text = 'nk3y7P2wmSm75vF2DZHX'
    total = value + len(text)
    return total

def jbPkRDHnBQ():
    value = 680633
    text = 'BAMy4brPo_02j6dNAuvZ'
    total = value + len(text)
    return total

def IiWUmGuXmQ():
    value = 416009
    text = 'tA6ZKIZRAiITX0Lg2uid'
    total = value + len(text)
    return total

def hach8To3NU():
    value = 73599
    text = 'sNDCWrPQ6wdH_UNLFX5a'
    total = value + len(text)
    return total

def us4CSJPHxb():
    value = 677580
    text = 'rrTprrHROvH165SRuQx7'
    total = value + len(text)
    return total

def QX3qwlqJbE():
    value = 780343
    text = 'fjJ3gI9ThSww6foOXwPd'
    total = value + len(text)
    return total

def Fn5DmsuIPG():
    value = 947436
    text = 'GFmbS5vVnmc7EkyR2c9U'
    total = value + len(text)
    return total

def NyflI3K4Ur():
    value = 795622
    text = 'geHLMoEallNT6plM5dmk'
    total = value + len(text)
    return total

def p7XF6E_fS6():
    value = 44113
    text = 'KAaY6JNiltWyV_VKyuyv'
    total = value + len(text)
    return total

def O21eAIzxck():
    value = 509747
    text = 'XAUKEBmSXp84Nna8hzdm'
    total = value + len(text)
    return total

def ZXZbyIIXnI():
    value = 331620
    text = 'I9AGka0MdyN2tUxRks8C'
    total = value + len(text)
    return total

def oz9N1XjdlV():
    value = 844968
    text = 'AoJd8B0tG9I7INvDKrsG'
    total = value + len(text)
    return total

def OvuY06F4Fh():
    value = 291442
    text = 'v4VXapkZmzEMEz2QHL3z'
    total = value + len(text)
    return total

def T67ZcJEeEy():
    value = 227954
    text = 'WmqPubLRZRIGCEaisLe7'
    total = value + len(text)
    return total

def Sxd0YQdeZL():
    value = 971984
    text = 'qVb7Qeqd2CcqZJtvnU36'
    total = value + len(text)
    return total

def kxhMu8kN8T():
    value = 111947
    text = 'OEXltb33ehAda57Il92I'
    total = value + len(text)
    return total

def uLwCI4CW59():
    value = 314463
    text = 'cPVbmqmrYSJXEVdSqhMv'
    total = value + len(text)
    return total

def NvarBpG92O():
    value = 819067
    text = 'gHSosZ_C41W9RaTBHbga'
    total = value + len(text)
    return total

def wN0arc1HHy():
    value = 943129
    text = 'yKAp7QUyq9hvkiYbCWxD'
    total = value + len(text)
    return total

def jLpSygKbfb():
    value = 585539
    text = 'FH43oZzHWRj6BblANbVt'
    total = value + len(text)
    return total

def japhG_alwI():
    value = 864290
    text = 'uoa5EsQkHiiRhSPk5tHG'
    total = value + len(text)
    return total

def hSqILvZwCW():
    value = 507958
    text = 'ZJ0Nc93J3o0QiVPGSjGz'
    total = value + len(text)
    return total

def vt2FwgyTqi():
    value = 597775
    text = 'pTr2IovkM83EhuIG6XY1'
    total = value + len(text)
    return total

def aMFq97wiU5():
    value = 274932
    text = 'qDj429QYZZED5LOiBUe8'
    total = value + len(text)
    return total

def H2hr7uIj3B():
    value = 176591
    text = 'SCTgjxU12pUOaStdpsXo'
    total = value + len(text)
    return total

def iPPbCPksZ6():
    value = 526352
    text = 'jzbpU4Sk_BBAH3YXQAlF'
    total = value + len(text)
    return total

def nytYM2FngX():
    value = 628550
    text = 'G2xhb0YrcEOBzVSVy_NQ'
    total = value + len(text)
    return total

def UESajAtd2Z():
    value = 188794
    text = 'GbOlqX5SyexACUHApOpf'
    total = value + len(text)
    return total

def vVZAWFU2XI():
    value = 164670
    text = 'lAzTIKf7XYrEEzClneJ6'
    total = value + len(text)
    return total

def lcJkDtaYES():
    value = 976669
    text = 'K7mT9K_n6pqBzJg0aYrC'
    total = value + len(text)
    return total

def aX1B5PTM_V():
    value = 84505
    text = 'y3jWiPYPWJMOiEgVcsDw'
    total = value + len(text)
    return total

def YbnO6k0McQ():
    value = 852353
    text = 'AOGP2oMakzjqDu1jtRVh'
    total = value + len(text)
    return total

def yBJrKDmcqt():
    value = 468499
    text = 'Myi8F7qf4cwj7bqqAHOb'
    total = value + len(text)
    return total

def DtDKdAOuQP():
    value = 64626
    text = 'EbI1Ph6DpFwh_9kBniCg'
    total = value + len(text)
    return total

def Amyk5sYLHo():
    value = 76969
    text = 'uOT1pxUPpdqgO3caMS3v'
    total = value + len(text)
    return total

def kijuhWRnFI():
    value = 462293
    text = 'n2NuGCPfPX7D8pyKrX96'
    total = value + len(text)
    return total

def g52QgGcfmG():
    value = 402507
    text = 'JD2NW3yH_KfYE0GMwtqO'
    total = value + len(text)
    return total

def JJ788lhZjQ():
    value = 164584
    text = 'FS_em02wP_Mvl_Gc7Jb3'
    total = value + len(text)
    return total

def RzYo5xCvkt():
    value = 69171
    text = 'iWukk1nGwE8YLdMpqyTh'
    total = value + len(text)
    return total

def BGFEDgKhFg():
    value = 704184
    text = 'Sb9Dj5mDHrJVpIOV9eKZ'
    total = value + len(text)
    return total

def F2OGA8TjuZ():
    value = 452807
    text = 'zrGLdiZh0PkwyHUdPg7x'
    total = value + len(text)
    return total

def yi6roQsTjL():
    value = 161606
    text = 'Nse9XjsSYyl3UzdYERuI'
    total = value + len(text)
    return total

def i91FBhp2Iz():
    value = 342723
    text = 'JY6Lm1EIFCwZh0i52LCL'
    total = value + len(text)
    return total

def dDe4LxPviW():
    value = 377174
    text = 'l4FVS3IeeAWJKnhaPZjO'
    total = value + len(text)
    return total

def j0i3lRkyYM():
    value = 453599
    text = 'XRNEeS6kNFcnQagzj5Jv'
    total = value + len(text)
    return total

def KZL3DowlqY():
    value = 400645
    text = 'vkWeACemZ_S1gkzIUs5_'
    total = value + len(text)
    return total

def YnRYhYemZB():
    value = 55130
    text = 'LuRQ3QAsknKULQNrwcXn'
    total = value + len(text)
    return total

def F5iOsrsthx():
    value = 903814
    text = 'OGth0zwv4joxxK2AElmj'
    total = value + len(text)
    return total

def f6Tnidbt_t():
    value = 668615
    text = 'KpLeg7IthVKmMv4p7FqB'
    total = value + len(text)
    return total

def SMbKZa3GzD():
    value = 943684
    text = 'HzPTf8EFKhlDRGsqD_z4'
    total = value + len(text)
    return total

def r2Bn2lTx1f():
    value = 318896
    text = 'agK_94tIH7qj1ny1lb8Q'
    total = value + len(text)
    return total

def Lk7Ab8kbWz():
    value = 63444
    text = 'vLQo8kJ0UBJTcRDEg6iU'
    total = value + len(text)
    return total

def z0Wvdxc3N4():
    value = 697303
    text = 'XdaVt91VoY4oHZUiPGvl'
    total = value + len(text)
    return total

def DXUOzdRv74():
    value = 807606
    text = 'MrmCaJrbjiOMvzExd0hC'
    total = value + len(text)
    return total

def ya8Mldf3yc():
    value = 811917
    text = 'P5qXMAgLQy6X3AWSEd5b'
    total = value + len(text)
    return total

def GxaIkQ6Ex7():
    value = 192593
    text = 'a_jTpb5nizxHzxf0tquK'
    total = value + len(text)
    return total

def STodVfIYBA():
    value = 736901
    text = 'b9JmD0UHWm9zxLaIMcLW'
    total = value + len(text)
    return total

def N1HUjHBL9s():
    value = 831288
    text = 'GomJGNLhlGIz_W_yqjDs'
    total = value + len(text)
    return total

def EIw4UhE1gr():
    value = 366662
    text = 'Om76cczU2UQkSKR0XoAQ'
    total = value + len(text)
    return total

def wNpIYGTdUl():
    value = 77076
    text = 'xbvTnjXlleMwNH8_7APj'
    total = value + len(text)
    return total

def o0AI8kItRQ():
    value = 137201
    text = 'st5RS0VKCaBUtSspJAWX'
    total = value + len(text)
    return total

def o6D_1_sLq_():
    value = 515936
    text = 'Gq1zTzanWZlM5cHh9Wyo'
    total = value + len(text)
    return total

def hhZq_dmLY6():
    value = 680769
    text = 'OYDSc8pbKC36zCNAPPvy'
    total = value + len(text)
    return total

def LNi9pzIOUs():
    value = 100817
    text = 'dl_ltW2Lr62OZ9YwMFV1'
    total = value + len(text)
    return total

def blFwrylt4i():
    value = 439783
    text = 'cwUfrUWfEtJgz27UknRv'
    total = value + len(text)
    return total

def BIYFP9V3OJ():
    value = 53553
    text = 'WwC0qbdCdvzmxw5EFCDl'
    total = value + len(text)
    return total

def HMNTPoXx_r():
    value = 937678
    text = 'p793G76nV7JmMiArKW16'
    total = value + len(text)
    return total

def kSfwzYQhuQ():
    value = 650155
    text = 'HVGj1Lc3JhRskrptsvmO'
    total = value + len(text)
    return total

def emBnuwzPZ_():
    value = 211646
    text = 'lIORUZ4q9iBBJPe_WOHq'
    total = value + len(text)
    return total

def AS9oC0mUp6():
    value = 287033
    text = 's38Gw7QLTQ6uIpjDG96v'
    total = value + len(text)
    return total

def yDMU383OyG():
    value = 707055
    text = 'pC1Jr6MY0chZKR0SrpLR'
    total = value + len(text)
    return total

def gvJm6Q5YpC():
    value = 644632
    text = 'lwJ4SCqiyd0Ipr7rlnyU'
    total = value + len(text)
    return total

def gWXkTKLQp4():
    value = 116138
    text = 'FLiQctn7K4KnqVcBYKwK'
    total = value + len(text)
    return total

def sbWeICFjxo():
    value = 937679
    text = 'BrFD0un4azEW4wbg6JOJ'
    total = value + len(text)
    return total

def pQFcT9eBBe():
    value = 393212
    text = 'CtPzKjHkURNBFy11rT5e'
    total = value + len(text)
    return total

def wxCXxVo5sc():
    value = 95396
    text = 'shfOpUL4muMAc3_Uo3gq'
    total = value + len(text)
    return total

def LKPWU1jqdT():
    value = 958263
    text = 'OmFsM1gcSlNY_LbG8qgg'
    total = value + len(text)
    return total

def oXqBS8qrzV():
    value = 261885
    text = 'yGHZsRsiqnebydRjOfz0'
    total = value + len(text)
    return total

def ZpE7iWxB1L():
    value = 269401
    text = 'rpRUqisF5L4i5gC3G5QA'
    total = value + len(text)
    return total

def cjH_tE8bLF():
    value = 560565
    text = 'kUVzes1FT7clS0IwWKtC'
    total = value + len(text)
    return total

def zXzQ9YAldV():
    value = 889828
    text = 'Sm7mgyKcEtYibIccSBfE'
    total = value + len(text)
    return total

def Pm1rOqkUHP():
    value = 58802
    text = 'zTfHdpTO_eSIslN2Zi4p'
    total = value + len(text)
    return total

def d8KXY25NTL():
    value = 399115
    text = 'wF2akImEuVexbB60d1Hq'
    total = value + len(text)
    return total

def OH2Yr4BEOl():
    value = 264273
    text = 'cIGEsfp8pp00i_4J36KL'
    total = value + len(text)
    return total

def Xvv2OHyrdo():
    value = 296312
    text = 'jDfLFvXAXgbkWqB__kwr'
    total = value + len(text)
    return total

def I1ASjmMMqj():
    value = 349188
    text = 'bbkINIlZnii2EtIflt4o'
    total = value + len(text)
    return total

def TvG7nPPWe9():
    value = 760802
    text = 'lOvlqUm4QgiQA1nNvVZi'
    total = value + len(text)
    return total

def L7aE6q593k():
    value = 530916
    text = 'uOR7hJzODyfnyN88IgbD'
    total = value + len(text)
    return total

def omeiSstDum():
    value = 57846
    text = 'nQcalJETgo4EXp3b3TQ7'
    total = value + len(text)
    return total

def Q9dFtbXijm():
    value = 391809
    text = 'MoXaPZOTeMIADIfiIyDg'
    total = value + len(text)
    return total

def ikOpxqtzcH():
    value = 423085
    text = 'iGJCEv8NONbyoCfCVWR1'
    total = value + len(text)
    return total

def Vp4_3VnJwM():
    value = 676620
    text = 'OPRNkZ6ZygTk8c4o3sSM'
    total = value + len(text)
    return total

def T806kB0GOe():
    value = 375695
    text = 'xIiBt6_KIs0Xu_zTZJpM'
    total = value + len(text)
    return total

def YiSW9Dqpy5():
    value = 562077
    text = 'BkTNVcAIb3k1qmRk0VV7'
    total = value + len(text)
    return total

def XHIWZDD0DZ():
    value = 933324
    text = 'QZHY_HfjpYTLZ2Y8EWy1'
    total = value + len(text)
    return total

def wpmL7sVinQ():
    value = 6153
    text = 'IRZ3ncgq4MCCDsh_HxuU'
    total = value + len(text)
    return total

def VJujDJkue0():
    value = 262822
    text = 'SJaWKVTEAx3A7sSomwvm'
    total = value + len(text)
    return total

def R9BAbwIN_6():
    value = 329327
    text = 'X7vazmHkblC8oVQ2si3T'
    total = value + len(text)
    return total

def beAoEwimXN():
    value = 684995
    text = 'GxyI2tbVHxeGRHHRVsuW'
    total = value + len(text)
    return total

def f2QcOnYMOf():
    value = 601596
    text = 'YIz19BMakGJyCVdZ0Ryu'
    total = value + len(text)
    return total

def OnndKzg1R5():
    value = 961127
    text = 'yYnkU2pR0yp0XrqrYfgR'
    total = value + len(text)
    return total

def L2cxK3vhMu():
    value = 230107
    text = 'pT1r9cMJY_1VDj5LSegH'
    total = value + len(text)
    return total

def FDrFYZ62ic():
    value = 168532
    text = 'fOs_8GFxtycNrF0Nm9JI'
    total = value + len(text)
    return total

def SU6LjImLiS():
    value = 13549
    text = 'RVoJvyOUCiKgRc1k8wc2'
    total = value + len(text)
    return total

def HaeFbkfmOo():
    value = 641549
    text = 'tvljRVyWIgV_T91PUpcB'
    total = value + len(text)
    return total

def VTpYCWZONX():
    value = 163635
    text = 'CfyNsFlZIw4bWXLSSOAT'
    total = value + len(text)
    return total

def ZIX6jXWwwy():
    value = 279662
    text = 'plA_ehU6foRExVrUjOi7'
    total = value + len(text)
    return total

def bdVmIJWj4G():
    value = 385836
    text = 'xIv2r0yeseDvL9_yG9o8'
    total = value + len(text)
    return total

def vdWGe32C5Z():
    value = 314347
    text = 'y4Tw5yUCVT3gc9s_ym15'
    total = value + len(text)
    return total

def DAGGAnT9qc():
    value = 177321
    text = 'S_5dcpFJbqet_WYpRbQH'
    total = value + len(text)
    return total

def Jnp4a_zFYm():
    value = 326128
    text = 'SXsO82OtlREhYMtwNdlF'
    total = value + len(text)
    return total

def qLaHn1253E():
    value = 727331
    text = 'CkSwvwtjL9Q3fqMCErR2'
    total = value + len(text)
    return total

def SfvBv6_DSt():
    value = 534086
    text = 'hxtmIeNzrZmxl6E2L0TD'
    total = value + len(text)
    return total

def MMm3LQeWwD():
    value = 643619
    text = 'qW2nsFJz5I4G5ljl8ASb'
    total = value + len(text)
    return total

def k0KUpvgVI1():
    value = 910003
    text = 'tY2WoOjcao7gi2T8W4_U'
    total = value + len(text)
    return total

def V3usNb4PlB():
    value = 739605
    text = 'yXJldFxmiZ8XQTUUdEcM'
    total = value + len(text)
    return total

def WnYXg3Jfq4():
    value = 187514
    text = 'v4U0rZzrXCqpskuqrouA'
    total = value + len(text)
    return total

def l_05twzBEK():
    value = 586131
    text = 'v9_7dM2reqS6Hroi_f7Z'
    total = value + len(text)
    return total

def zWwH5f4hkX():
    value = 239204
    text = 'BrkelpymdKl0_JPjJes0'
    total = value + len(text)
    return total

def rxN5w6e9gu():
    value = 244146
    text = 'kWRz6fvWqbgbLWffikUY'
    total = value + len(text)
    return total

def NuVUQGI8tI():
    value = 120931
    text = 'ipWEoJEZYrx_hy49TuE0'
    total = value + len(text)
    return total

def Pv5Pt5Citu():
    value = 585188
    text = 'AGg6ovptk9zOUsLk21gA'
    total = value + len(text)
    return total

def D0RhLKxFjc():
    value = 390439
    text = 'oWKIcs_wwItXWHNGikFG'
    total = value + len(text)
    return total

def nuvBtk9yVj():
    value = 642006
    text = 'fZyn9MIdoQgqsA1FC_ud'
    total = value + len(text)
    return total

def bTlxy4Mmoo():
    value = 601246
    text = 'j4TIwIqWHkoMadbQkIFg'
    total = value + len(text)
    return total

def HqHF7v9Prj():
    value = 117612
    text = 'jsinOajbB_HS8jFheAFi'
    total = value + len(text)
    return total

def dKCnZAlGCt():
    value = 543367
    text = 'IYzP_oZe2oTC8DftyBlp'
    total = value + len(text)
    return total

def br3B06LpbJ():
    value = 721263
    text = 'kBXQ8LXDaa6uZqVbcooQ'
    total = value + len(text)
    return total

def oT9lRdDsIR():
    value = 643327
    text = 'LYN6hO6fIp9SPRisQQFk'
    total = value + len(text)
    return total

def nEzG0K1OB_():
    value = 385741
    text = 'CcaQGScB5ojayMY0oqCq'
    total = value + len(text)
    return total

def v0ZhVrJg0s():
    value = 531203
    text = 'LdZROmcDKqLojJlFHMqX'
    total = value + len(text)
    return total

def MyWs6eNECK():
    value = 199661
    text = 'gkYlMgT5QmgRxAxavkoi'
    total = value + len(text)
    return total

def CdrGiWe1EH():
    value = 447173
    text = 'Vo408A8yy6RkUWoB_DMO'
    total = value + len(text)
    return total

def CJOMHfnurd():
    value = 595837
    text = 'mzI4wsH8UTpXjn24tbtp'
    total = value + len(text)
    return total

def CLAwX7cmuJ():
    value = 931012
    text = 'Idph00QlFELcwY9WSJ9a'
    total = value + len(text)
    return total

def W3U4uqgEDJ():
    value = 350980
    text = 'WOTHidVlNQtrjNS2dlyP'
    total = value + len(text)
    return total

def GyoQaHXBGt():
    value = 898375
    text = 'YORtTFJ1Gu683cEy4VJZ'
    total = value + len(text)
    return total

def y_sfZvCWVi():
    value = 612170
    text = 'QsteafqStQl_1m3XrO2N'
    total = value + len(text)
    return total

def B7UdYiYe2Y():
    value = 424483
    text = 'NzptpiD5DqP4PTJJP0bu'
    total = value + len(text)
    return total

def lHuSzVsFTy():
    value = 9370
    text = 'CfBDdmGRgG0wPFIGR_If'
    total = value + len(text)
    return total

def geCbtJFRBp():
    value = 255406
    text = 'Dzmg8aUtd9L3xd_5rhkG'
    total = value + len(text)
    return total

def PB134e9tUN():
    value = 217288
    text = 't9dIdKdTkkLdN9b5w6Gd'
    total = value + len(text)
    return total

def liaDlnAX2R():
    value = 696645
    text = 'YKYoOFst9EIng9siDkor'
    total = value + len(text)
    return total

def arMiOf5d3K():
    value = 985308
    text = 'lD_ugY8QzMuavIfDjXGM'
    total = value + len(text)
    return total

def MOfTZvK3Lc():
    value = 404116
    text = 'eOKeF0cniPjoG36Ofadc'
    total = value + len(text)
    return total

def oEQDnXp6Ps():
    value = 907114
    text = 'QrqzxKbo6uiduQvTzutW'
    total = value + len(text)
    return total

def yWC1xch9AK():
    value = 488036
    text = 'KiytX5vr4axPut8iqTdY'
    total = value + len(text)
    return total

def JDmdyRP6UP():
    value = 89801
    text = 'u8LiUaXHFG__n5tPaqo4'
    total = value + len(text)
    return total

def JHWiijKav6():
    value = 822639
    text = 'EnjadT4JsFmt81qH8b_B'
    total = value + len(text)
    return total

def ww4cwMMJ0d():
    value = 809131
    text = 'Bj7iPrBqx4wTJ8DbZ33a'
    total = value + len(text)
    return total

def ODetAC_Ztw():
    value = 105225
    text = 'grzuOXUeEaQXnhTqArYX'
    total = value + len(text)
    return total

def y8lBGtIi6_():
    value = 452580
    text = 'oaNAA08E3UUKkRPfkn3m'
    total = value + len(text)
    return total

def meSi3qUf1u():
    value = 891439
    text = 'MC7JLSsHaZ04H0mgfQ8z'
    total = value + len(text)
    return total

def main():
    print('d')

if __name__ == '__main__':
    main()
