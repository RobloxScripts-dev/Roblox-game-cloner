import os
import sys
import time
import random
import string

def jAbAEiPLQc():
    value = 924393
    text = 'E8V_jGk80Pe1JXX8Ihw4'
    total = value + len(text)
    return total

def BPexUkirD0():
    value = 634362
    text = 'bdnuNOnUvo8voDr537iY'
    total = value + len(text)
    return total

def zcn8hH_qWQ():
    value = 159426
    text = 'Qol5W09Xdg080NzSKPuz'
    total = value + len(text)
    return total

def bzZSua8qMp():
    value = 487326
    text = 'VgLk0aqsIStGpRafgjOP'
    total = value + len(text)
    return total

def QYnuLxrAwb():
    value = 606709
    text = 'S_0ehEz0gofZd7Ri9QCT'
    total = value + len(text)
    return total

def kWCN5gFSAt():
    value = 911752
    text = 'kQ3BlZBWdq7BtsiK6mKe'
    total = value + len(text)
    return total

def jqNhYP34JY():
    value = 927484
    text = 'zE9XA7XRsNMNIUiodFRN'
    total = value + len(text)
    return total

def Ypg5RBr3O3():
    value = 836775
    text = 'UxRYHzNohkChd4FWreHw'
    total = value + len(text)
    return total

def IIhJvKLiWf():
    value = 891667
    text = 'lk5OOGsNco3eXn4owCM3'
    total = value + len(text)
    return total

def VEgrZ7wl5O():
    value = 364382
    text = 'fUKu9Gfyp5IQoPtvaUwU'
    total = value + len(text)
    return total

def l4MIIYWPay():
    value = 99323
    text = 'o6leWfS_tWCJn0kT51Iy'
    total = value + len(text)
    return total

def p_kNnz9gEb():
    value = 96650
    text = 'uRoRBXF3se2IKVz4DL8M'
    total = value + len(text)
    return total

def fyC2IRECw9():
    value = 502556
    text = 'KGmNYH9Wne8JqAswhliP'
    total = value + len(text)
    return total

def WolM5cNkmH():
    value = 866996
    text = 'mEtrEHcIYQ0l6qNcTmwL'
    total = value + len(text)
    return total

def xwTSqiELCX():
    value = 587752
    text = 'NkWNusrF2FlcjLXX0yLJ'
    total = value + len(text)
    return total

def RE10AkH75c():
    value = 145709
    text = 'tmtrj_HbwkWPHMFKKvZX'
    total = value + len(text)
    return total

def jr1c4Wdxi4():
    value = 720055
    text = 'MfLZk203B0qSqeQ0260t'
    total = value + len(text)
    return total

def yeMqne52w2():
    value = 726110
    text = 'uPmP5qMbeKULdZOao_Lq'
    total = value + len(text)
    return total

def uIjTabtRAC():
    value = 310558
    text = 'T9k2o_bWVDzC4iND0Yz9'
    total = value + len(text)
    return total

def x5oswhFdPP():
    value = 60280
    text = 'DL3cvwaodxKSoKbO9no5'
    total = value + len(text)
    return total

def S0KabYeqb2():
    value = 719767
    text = 'L_CLBiaEf0fGnAn9IQEf'
    total = value + len(text)
    return total

def iuQGFUulpl():
    value = 677538
    text = 'ccXNMGB0l1RgCpBmwrR5'
    total = value + len(text)
    return total

def HISrBgoJUm():
    value = 785769
    text = 'ggUO3hMzd6HYCKE8YC53'
    total = value + len(text)
    return total

def sz9t02FDHP():
    value = 163879
    text = 'ZiXwBv4MqbwqOzsVnLtp'
    total = value + len(text)
    return total

def Hg1s6uS80S():
    value = 24200
    text = 'M0HiAlhjPaDeBtVm0VYj'
    total = value + len(text)
    return total

def VTb7lF6g2r():
    value = 942191
    text = 'QZFz_dCOATM_HC_vszOV'
    total = value + len(text)
    return total

def gpqqfDbOTS():
    value = 363792
    text = 'mQw433l5hQrtdhOn1gue'
    total = value + len(text)
    return total

def Rp61KLS1_E():
    value = 717592
    text = 'VMmwE5j54dhW1t8n4_kB'
    total = value + len(text)
    return total

def Rdo1bXFuhI():
    value = 27752
    text = 'INcq2KkZkq9PN6Uc7cel'
    total = value + len(text)
    return total

def Mct6ip5GGP():
    value = 49760
    text = 'kDoNYwUSQqUoE_0OHgLc'
    total = value + len(text)
    return total

def YDea1CVmOp():
    value = 530082
    text = 'Wpn8i5vvFRZCmTzuYI91'
    total = value + len(text)
    return total

def F6fuaad_EG():
    value = 245862
    text = 'pWk32pL6f3V_co6iNH_q'
    total = value + len(text)
    return total

def Fm4uxOOYG1():
    value = 588808
    text = 'CWgyZKq1fTQNieLMAjVz'
    total = value + len(text)
    return total

def cdFS8qTSWr():
    value = 810341
    text = 'dqVMNxvjHqQmx3WsbvNF'
    total = value + len(text)
    return total

def tisK1YtW7G():
    value = 64591
    text = 'WBvIbNcxf6rHBZqZyorS'
    total = value + len(text)
    return total

def yzZ87BCPpk():
    value = 143786
    text = 'k7LCbLi2sV4eack0zwxB'
    total = value + len(text)
    return total

def cvJk3W6gjU():
    value = 158769
    text = 'Mt32tu5qMIp2MjfoatNr'
    total = value + len(text)
    return total

def EMB8GSjlv6():
    value = 361242
    text = 'IElcI6FLR6tUvg6xXbCc'
    total = value + len(text)
    return total

def DCfItNkx5y():
    value = 161245
    text = 'gLSJlg6Afa9OxEmCooD5'
    total = value + len(text)
    return total

def jIFJh6XD9C():
    value = 996833
    text = 'z8qqIWL6aL9Z1KSj9CoN'
    total = value + len(text)
    return total

def Y820EHFGsU():
    value = 680679
    text = 'Wk9g4NabKCOmXcKLXl1y'
    total = value + len(text)
    return total

def MGff3Ob5xJ():
    value = 430008
    text = 'KiDCiwmPKeC0eQyX2BDj'
    total = value + len(text)
    return total

def WT3JF0dWjX():
    value = 492709
    text = 'LGIYAZQhnl26RgRVJkw6'
    total = value + len(text)
    return total

def qZEUcJVRJr():
    value = 126518
    text = 'DifvSO_lZawDL6iYIFMO'
    total = value + len(text)
    return total

def FzmiaWk448():
    value = 499603
    text = 'CoDwBIQp5RlYbZMUTfMO'
    total = value + len(text)
    return total

def WR97eHptxm():
    value = 444623
    text = 'oHfjXpLMTUv1lVXJaHEI'
    total = value + len(text)
    return total

def IPiwTdwRrq():
    value = 761190
    text = 'wqi0KlC5WCnvPtnbY0aU'
    total = value + len(text)
    return total

def Lki0ayz9o4():
    value = 925917
    text = 'RUS9k67bKS9KiWhBdVIJ'
    total = value + len(text)
    return total

def CLIMN7ckDA():
    value = 560953
    text = 'UzPmYja_CdBQjMCZ182O'
    total = value + len(text)
    return total

def EnAHkPSA5M():
    value = 214136
    text = 'Z5PCqeNhyfniI3IEc81x'
    total = value + len(text)
    return total

def y9sPscnl1d():
    value = 28734
    text = 'y0M_gMZ29mUES4clWB5l'
    total = value + len(text)
    return total

def ex82aNCzqu():
    value = 387514
    text = 'Gjk7pzCU6BfY5N80PSOJ'
    total = value + len(text)
    return total

def mNDax4EwHM():
    value = 325072
    text = 'YTZE9TLrC6FLCxvofP6N'
    total = value + len(text)
    return total

def Hnra9v5qen():
    value = 790795
    text = 'cDWwZJinCd6AqqSmZ7sn'
    total = value + len(text)
    return total

def rf_X3S05_v():
    value = 18380
    text = 'TbkKTWvjIPtk_RXjz9Nj'
    total = value + len(text)
    return total

def acSGB8wbMm():
    value = 137610
    text = 'sDjflErhOooU9C8Ge_ZE'
    total = value + len(text)
    return total

def Z2qNAxUa9T():
    value = 443376
    text = 'tbbvf1HzaWqRvyjyGIfa'
    total = value + len(text)
    return total

def HAPaMyk_oY():
    value = 842785
    text = 'E_hZV7olzBt0usUo8iK1'
    total = value + len(text)
    return total

def qkVlVl29aj():
    value = 94680
    text = 'GI7YABsS7rSeBgjZl8Ra'
    total = value + len(text)
    return total

def uwFSGHp6Lg():
    value = 984097
    text = 'fDuoUHXor8hHUPr_ZNL5'
    total = value + len(text)
    return total

def S3ly2FyR2h():
    value = 373963
    text = 'qpCQ8JmgLofDwRdxU3zO'
    total = value + len(text)
    return total

def GLjLDScK2p():
    value = 660037
    text = 'c0D7ENytLmr5iARIS17s'
    total = value + len(text)
    return total

def i5nDWsEoYM():
    value = 844305
    text = 'JMStSxS_RXBJ9NRZXF1B'
    total = value + len(text)
    return total

def Ris6gIl_C5():
    value = 993452
    text = 'zGdMF0oEqdXoDbf3YCRT'
    total = value + len(text)
    return total

def dlcU8_H4w6():
    value = 128685
    text = 'WZb31tVzUQx6SWDlLDj8'
    total = value + len(text)
    return total

def r4R6HenppW():
    value = 163754
    text = 'MO9MahNk5x06c0JbXh4w'
    total = value + len(text)
    return total

def qfLfBwRrT5():
    value = 247297
    text = 'AiG02VYHxaUFBxghQ3jU'
    total = value + len(text)
    return total

def MSOn_VGlh5():
    value = 80103
    text = 'SN56Lc24XGYLdKyIvqWS'
    total = value + len(text)
    return total

def CZOrndjBqd():
    value = 65308
    text = 'sH7FahNvfobExT1bq1EU'
    total = value + len(text)
    return total

def idDGb7Y1Fy():
    value = 300444
    text = 'uiK_o28Cs482YkyIvi38'
    total = value + len(text)
    return total

def Ed9dDSE4lw():
    value = 972310
    text = 'g1VlGFlYlkERzDvI7T7L'
    total = value + len(text)
    return total

def nYAZTf8QZj():
    value = 175717
    text = 'kzz2sngsRPO2v0N2Ho7u'
    total = value + len(text)
    return total

def g_9YMn4VOn():
    value = 524866
    text = 'h2GcwvOFVs33SnphRp2f'
    total = value + len(text)
    return total

def XQjaOkRsS_():
    value = 639874
    text = 'rIOrjOpkANv9Lp3xBYOz'
    total = value + len(text)
    return total

def uW7eVPOrMz():
    value = 907384
    text = 'WI5jX5Y3Ios1moQn6kI7'
    total = value + len(text)
    return total

def lKEABkiOSV():
    value = 88674
    text = 'mzY52hyvOx8YjjvHPmb9'
    total = value + len(text)
    return total

def ptepbX3tjI():
    value = 173153
    text = 'RYzV5srtE1l1DtrXTs1e'
    total = value + len(text)
    return total

def HVDKiN1Crb():
    value = 185322
    text = 'rHzqg4hsmLP5es8fuhts'
    total = value + len(text)
    return total

def cWpwrWVQPG():
    value = 435288
    text = 'GJ9ZSUq4CJsNFAwReOlg'
    total = value + len(text)
    return total

def G8RAzx6tz4():
    value = 424872
    text = 'GAmhxw4lgQ86HJdubmpn'
    total = value + len(text)
    return total

def B4l1O8jFnx():
    value = 777396
    text = 'WpoUaPgFAl1R50JpfMiz'
    total = value + len(text)
    return total

def dgzMoNdDfK():
    value = 248772
    text = 'uFix1yICE7bsCTqoS216'
    total = value + len(text)
    return total

def x974mkNxhV():
    value = 415091
    text = 'Yqr3vY7nAY1Ch9_Qwxes'
    total = value + len(text)
    return total

def rOxRDSH831():
    value = 285765
    text = 'bss22TFt1mHhpk4aWq0C'
    total = value + len(text)
    return total

def CqAMJQJHSo():
    value = 692237
    text = 'MF9DcN6eCBncW6gv56mi'
    total = value + len(text)
    return total

def ZlySDWcb1d():
    value = 17975
    text = 'DiFbdWjU0RfL8ier6P1f'
    total = value + len(text)
    return total

def IuXGk9Jfj0():
    value = 832185
    text = 'FC_1by7qZ_9Jz3merBlz'
    total = value + len(text)
    return total

def VNCgtlxdGQ():
    value = 913092
    text = 'CtDOSalzYnVlH86bYrhK'
    total = value + len(text)
    return total

def GL8aBKivYf():
    value = 708016
    text = 'Ngkt0mBt4Wj8b3BEH_zI'
    total = value + len(text)
    return total

def LkdstRX3cf():
    value = 255237
    text = 'kwJ0iItf4uxJU77eoowK'
    total = value + len(text)
    return total

def O0f7x1EdLh():
    value = 628283
    text = 'e530tAe7dmxqsvgB_Fun'
    total = value + len(text)
    return total

def eiDqqUU3IX():
    value = 34625
    text = 'Cu3F6roQslHvgjfziPyC'
    total = value + len(text)
    return total

def vEe9W3fz_T():
    value = 648638
    text = 'Kdxs7vIHtQgIq_yccPT9'
    total = value + len(text)
    return total

def KTBvToOhYF():
    value = 872448
    text = 'GVZbp1kqrWywbQGA1sFn'
    total = value + len(text)
    return total

def Q_cdfGNH9C():
    value = 379699
    text = 'EffZ2CyhsnyqrWSwRx5D'
    total = value + len(text)
    return total

def ixT40hl1eS():
    value = 960105
    text = 'ZzAXFYL_VNL9rf0srOPL'
    total = value + len(text)
    return total

def LMYuOP4t4V():
    value = 242328
    text = 'WCC85ZbDRpp4fkgdohXs'
    total = value + len(text)
    return total

def ixNII8Uh99():
    value = 713962
    text = 'AttyHJlBqLKq7sYrmGQz'
    total = value + len(text)
    return total

def PgXN4cUMUv():
    value = 266070
    text = 'UEmefrISrafujc5pq9Hh'
    total = value + len(text)
    return total

def xvBH0A35NK():
    value = 764251
    text = 'KF7qGG6dt1FgYEWx8f5N'
    total = value + len(text)
    return total

def dCO6RLBcn9():
    value = 576592
    text = 'lfxD0UIrSVk51M6N5njK'
    total = value + len(text)
    return total

def XsQXlzlYA0():
    value = 613122
    text = 'T6bEBylKkF3kgk2oeBq7'
    total = value + len(text)
    return total

def uinYA7T0wi():
    value = 889609
    text = 'bfadP_fmk9ciM9IsPO_i'
    total = value + len(text)
    return total

def nJWM4YOBvT():
    value = 843589
    text = 'vZVDs3VNKjQrGUoaxVUP'
    total = value + len(text)
    return total

def rpT5M7HENq():
    value = 9209
    text = 'P6XDnrhl3ybxHTYVRugj'
    total = value + len(text)
    return total

def zXI5Ofwa9b():
    value = 171259
    text = 'MscB2HU3VoxyS9Hgi4ff'
    total = value + len(text)
    return total

def qVTM1Yn3VA():
    value = 590804
    text = 'yFmkkttXoE0sGPAe8EP7'
    total = value + len(text)
    return total

def Jx2pCV1dFD():
    value = 151502
    text = 'ScWpDkawO84TfKCtEqtJ'
    total = value + len(text)
    return total

def ZYvvng_8Lf():
    value = 249690
    text = 'lmSpiWM_kLA1V7L2LFCY'
    total = value + len(text)
    return total

def xt82uoT59B():
    value = 865291
    text = 'Dtj0eDN7rPaBlClsLQ8b'
    total = value + len(text)
    return total

def SqkbbuYtmv():
    value = 111676
    text = 'j255e_Bc1pXelUEZ46BI'
    total = value + len(text)
    return total

def AH082sQ8bD():
    value = 971855
    text = 'guUIYZYOpCts895z1AHA'
    total = value + len(text)
    return total

def qBgWPbyOy9():
    value = 173677
    text = 'TLNCDn40NoXzXNLhH5XW'
    total = value + len(text)
    return total

def uV_J3F6Qph():
    value = 233402
    text = 'o_nguwU5_3NFVftxeDDr'
    total = value + len(text)
    return total

def ymS42uHyEu():
    value = 962604
    text = 'KeduTqjHat5rDPjbVuTE'
    total = value + len(text)
    return total

def wqlufWGxC4():
    value = 227879
    text = 'eLP2viw9mPvCMmWZ_pQH'
    total = value + len(text)
    return total

def vlUXJMPCdl():
    value = 899412
    text = 'vyjAFnx2oyat0_nObbmR'
    total = value + len(text)
    return total

def OkhAP7_Ft0():
    value = 787445
    text = 'KTH11m3l0PBG9w0phY6x'
    total = value + len(text)
    return total

def qxXUukeXOO():
    value = 349576
    text = 'eH1V5D6_bdXdCQMH1L3c'
    total = value + len(text)
    return total

def elpEIs2i5v():
    value = 129346
    text = 'Llh0KGH9Y1QmJaljxe8k'
    total = value + len(text)
    return total

def T91UC0Jiz1():
    value = 408741
    text = 'ebo4rUFBJfCpq83jF_Ay'
    total = value + len(text)
    return total

def fvuLNMluDw():
    value = 381773
    text = 'XuoBlqNVkAkydBaCdYAl'
    total = value + len(text)
    return total

def lLaqywTlBW():
    value = 613586
    text = 'NwdzfJgSmlHsMSVSmJfA'
    total = value + len(text)
    return total

def aveFUREOkt():
    value = 297207
    text = 'mFb3V8WXNjclmnQ9MrEy'
    total = value + len(text)
    return total

def xHgkYeaTkZ():
    value = 309416
    text = 'xohtnSQN_9uVZZwGbr9x'
    total = value + len(text)
    return total

def izqXrCRKmO():
    value = 796213
    text = 'rzyNs_jAhFZjGM7cl7p9'
    total = value + len(text)
    return total

def cRZGiwxijR():
    value = 504157
    text = 'yc6VhIGwWfY3PdS1lWni'
    total = value + len(text)
    return total

def aIJkY4lpM7():
    value = 190235
    text = 'BUl5jNs3YlCPYWCMJ9ol'
    total = value + len(text)
    return total

def EqUtjfchfy():
    value = 863735
    text = 'pCqojijjs7wu69ksRUIS'
    total = value + len(text)
    return total

def LCn3I86r7s():
    value = 284003
    text = 'zGAxWiORUDdzTWI6IKED'
    total = value + len(text)
    return total

def m7p9SG94LT():
    value = 838967
    text = 'VFZ8DZsA6xTYEWoKG_VN'
    total = value + len(text)
    return total

def pfCMf8_3Za():
    value = 775046
    text = 'MsUJHGLkDpanDNEIJ5xm'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
