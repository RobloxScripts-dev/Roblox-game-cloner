import os
import sys
import time
import random
import string

def NnVooeBiiI():
    value = 916714
    text = 'w8eed8lDgFSFz9FozJCy'
    total = value + len(text)
    return total

def yWF2oj04so():
    value = 686851
    text = 'xslW4OYtWH9K7QAMQpyw'
    total = value + len(text)
    return total

def mSetDYuxVT():
    value = 879006
    text = 'APyEllmwAxC3yDzL1j6T'
    total = value + len(text)
    return total

def T5Yr45HE6Q():
    value = 778654
    text = 'uk8ujXuMlScrzHQ0l1Xb'
    total = value + len(text)
    return total

def N6sMcHXRtN():
    value = 404817
    text = 'rFp5wVaJthE9fjzUqLYh'
    total = value + len(text)
    return total

def OfmnW6ngzH():
    value = 66372
    text = 'HwQIiiUSkPoiPesDkQhr'
    total = value + len(text)
    return total

def fz7znTDzHm():
    value = 536740
    text = 'FpNZ8MS_wCs1DwVO3_xS'
    total = value + len(text)
    return total

def sa5o5gbWnz():
    value = 252896
    text = 'igUwSAd1mCqweRf70R4j'
    total = value + len(text)
    return total

def eXWg8sphBD():
    value = 774420
    text = 'P4A_MGn8CtLhBuZsp_mj'
    total = value + len(text)
    return total

def RYzrSS9L43():
    value = 976855
    text = 'RcUwtL_4UmT5CaAjhUfr'
    total = value + len(text)
    return total

def WYfj8LXio4():
    value = 555935
    text = 'D5Ec0ccaylK3BZu9PI02'
    total = value + len(text)
    return total

def lgyNh9L0b3():
    value = 353481
    text = 'lo7r77yKg444okg9gYfo'
    total = value + len(text)
    return total

def CzOvjSuBA_():
    value = 839271
    text = 'jLyiPkvXLG3I3AJToRqU'
    total = value + len(text)
    return total

def G0LTGR7QfO():
    value = 7449
    text = 'GrC5hBB7_vdNg2PvsdGm'
    total = value + len(text)
    return total

def b5MyIJVmYF():
    value = 818013
    text = 'VNsc6uO_25IEzYE0GFO3'
    total = value + len(text)
    return total

def vqaEa2PoVl():
    value = 516212
    text = 'CwOsZqGCqahc5dqXHVUc'
    total = value + len(text)
    return total

def vq93QegXEK():
    value = 812084
    text = 'RRanbqq16ilwqiTYScos'
    total = value + len(text)
    return total

def cNCzo2db8o():
    value = 96080
    text = 'zx5pZnt01zmOjRkty30e'
    total = value + len(text)
    return total

def OkbvzC3yl1():
    value = 972731
    text = 'VOc4CLNFhW1oOpJVf3TI'
    total = value + len(text)
    return total

def KZwbMrjENx():
    value = 440426
    text = 'sDPS7fK_Csnd4VNLHQie'
    total = value + len(text)
    return total

def cKoWG3Ih6N():
    value = 294797
    text = 'Onmeteb7cHT2x6bXUgqr'
    total = value + len(text)
    return total

def Ks30TnpKOh():
    value = 814541
    text = 'GtOwUk2do0yreL8AaQbl'
    total = value + len(text)
    return total

def tzFI42GlN5():
    value = 196958
    text = 'HenkGaVMaaRYy9WoOnxh'
    total = value + len(text)
    return total

def Ov1e6kGh4C():
    value = 292142
    text = 'ycKUqUoqGCygq0DXvdo5'
    total = value + len(text)
    return total

def HI2Qv3kerN():
    value = 255260
    text = 'hhqqhu0boIZEbLJBcvzf'
    total = value + len(text)
    return total

def ERUQARhatL():
    value = 669553
    text = 'Z2Yuk2oTAfdeScksYBYt'
    total = value + len(text)
    return total

def cpOANomHMk():
    value = 344156
    text = 'qk7rAGVBzrXjAHZlv8X5'
    total = value + len(text)
    return total

def QkrRynBpNP():
    value = 568705
    text = 'tohqWO6L5ZslsW0L2KAc'
    total = value + len(text)
    return total

def FKjd2mQY1Z():
    value = 45764
    text = 'd562d8ksDhlLQ3dzMeyR'
    total = value + len(text)
    return total

def HJBOGhEU3H():
    value = 637171
    text = 'uNB23G0fYRnxD4ZklUp3'
    total = value + len(text)
    return total

def pJty7PMyc2():
    value = 305205
    text = 'vAXBJlVehGbuUlENQVD8'
    total = value + len(text)
    return total

def tpCBXYsyu0():
    value = 117075
    text = 'VJq4ShXbZnvy5Qve7U2i'
    total = value + len(text)
    return total

def kJG77OGV5g():
    value = 492155
    text = 'Rm29y2SIVpiLFIfEnTrg'
    total = value + len(text)
    return total

def nkQSBKNUaH():
    value = 844001
    text = 'VYtWGfoQSstfn_ILFRm2'
    total = value + len(text)
    return total

def g1oSIUQOiR():
    value = 98427
    text = 'MlhC9FUsTO6LGWBgM_gH'
    total = value + len(text)
    return total

def oN0jNDUtXw():
    value = 443157
    text = 'Xc8yYheurEcmxZW54LtH'
    total = value + len(text)
    return total

def xzMMuI7x1n():
    value = 643224
    text = 'LI2cdyyOsPLJJ1E2Iuw0'
    total = value + len(text)
    return total

def SmHv_z8IyA():
    value = 566093
    text = 'C_IivSUQPT3zBMRLAibr'
    total = value + len(text)
    return total

def GrjRuHl1qW():
    value = 876039
    text = 'w8zJwOCVYK44vAj2nhWi'
    total = value + len(text)
    return total

def pCqvIi7Awy():
    value = 534416
    text = 'Ls7cPqiIUGRToiQaSMEt'
    total = value + len(text)
    return total

def JkY6OgDLAG():
    value = 443333
    text = 'Hkxm3IDzlHrgH3fD23HW'
    total = value + len(text)
    return total

def OsBZWeyDa6():
    value = 434421
    text = 'dghFasHN37g_ylXfjV3S'
    total = value + len(text)
    return total

def ghdbTXwv0T():
    value = 169610
    text = 'KGoDiBVajirPaS_fyt_F'
    total = value + len(text)
    return total

def IuyMga6MMP():
    value = 329974
    text = 'MNa7gzh9mvmuoRQw7LBI'
    total = value + len(text)
    return total

def i12Rcd9FuJ():
    value = 31813
    text = 'ifWjFReYUR2FAMsst4eH'
    total = value + len(text)
    return total

def BHXVgvlsKe():
    value = 107756
    text = 'l6B6rMOzdgQyyiLjJfXi'
    total = value + len(text)
    return total

def o12TEDa_cV():
    value = 357408
    text = 'Gq4qxjiEjGsBWsIubaGM'
    total = value + len(text)
    return total

def jD_O2RuKW8():
    value = 283340
    text = 'CADFzUp9QQ3uUgPhDVrM'
    total = value + len(text)
    return total

def ScQGMninKu():
    value = 478672
    text = 'GmlkstfYebRAWTkcJqoh'
    total = value + len(text)
    return total

def jHvtpO70_z():
    value = 290865
    text = 'GDtpu_tRjdKvZBtvpyhj'
    total = value + len(text)
    return total

def mhR1Molr3O():
    value = 58456
    text = 'Q3TRBZiSyqsvkdMgbzUk'
    total = value + len(text)
    return total

def D2tuk7YBWJ():
    value = 125231
    text = 'u4c38mNO8iWBvjcjx8ve'
    total = value + len(text)
    return total

def tBqhVRY5Cl():
    value = 458280
    text = 'HT_IGpNu3oSQ7s1H3Bok'
    total = value + len(text)
    return total

def mP77YUO42J():
    value = 625365
    text = 'PqZFzsq7veZBEafTJHkM'
    total = value + len(text)
    return total

def iCtAcZ1kZv():
    value = 978412
    text = 'KadPKMUR_TYUDpPIxpJP'
    total = value + len(text)
    return total

def dMulLqM2qO():
    value = 978957
    text = 'MTa6eCdMBm33Q4Oj6Q0z'
    total = value + len(text)
    return total

def LppLyIl1wB():
    value = 479284
    text = 'iO4bmAlT_0Jo3ADMl2rF'
    total = value + len(text)
    return total

def GHADCc2344():
    value = 2369
    text = 'GIXg2aJM76rlw89rIES0'
    total = value + len(text)
    return total

def EbUsPGEgFB():
    value = 202831
    text = 'm0u1tmBBklM8czPDaPPB'
    total = value + len(text)
    return total

def tcnqZubVdP():
    value = 228410
    text = 'tlr4e5ewvguNicBaJCYf'
    total = value + len(text)
    return total

def MgZhXX9HbC():
    value = 562542
    text = 'K1GsNhfq7Mhp2m3lL7oF'
    total = value + len(text)
    return total

def WgeGrn7sUn():
    value = 743387
    text = 'Fu4pnIeZBWnIdYMzKm0p'
    total = value + len(text)
    return total

def Gj92taOzja():
    value = 102086
    text = 'zWsozzOorTGG4ONkKhaq'
    total = value + len(text)
    return total

def pb6is_Heaj():
    value = 835737
    text = 'tSAwzdlDbWyYjhSfRNwA'
    total = value + len(text)
    return total

def ZrsAOPEtls():
    value = 678723
    text = 'Q3CTzFL_HZNScz1GDiGK'
    total = value + len(text)
    return total

def eEbRoiMgwA():
    value = 511993
    text = 'uEwXI7h9iDfuQkkxs_Tr'
    total = value + len(text)
    return total

def b72QzIHSpM():
    value = 127917
    text = 'Mr3bnUCbiyU5VYmXdt9V'
    total = value + len(text)
    return total

def vMmvf0fDBi():
    value = 992408
    text = 'B2qgWWRHDV25bUD3CjhW'
    total = value + len(text)
    return total

def IzfwBD6NOG():
    value = 892463
    text = 'nM189N6uEKflRD6bwF6D'
    total = value + len(text)
    return total

def aZObq9wTnt():
    value = 332394
    text = 'jyZcdgagcb99rW2Ukcd0'
    total = value + len(text)
    return total

def iHb0AlZVTs():
    value = 839174
    text = 'CPgsXlUqWkv69HVi_XTy'
    total = value + len(text)
    return total

def oyQOOjHTSr():
    value = 721702
    text = 'xUv5_Kc7zZpvSWOiEBYL'
    total = value + len(text)
    return total

def ogyciS64hc():
    value = 894691
    text = 'GKLx5VlXbmVF6HZnpiZg'
    total = value + len(text)
    return total

def vLJU1xL23P():
    value = 27697
    text = 'OpFZEgYPVsLoMk1A5C3M'
    total = value + len(text)
    return total

def XKbQQhKfJj():
    value = 741108
    text = 'z0ng1DyIzStKSlggRvS3'
    total = value + len(text)
    return total

def lWK3GIqyBb():
    value = 765234
    text = 'FOGZ7tRk4lupW2nb2uS0'
    total = value + len(text)
    return total

def TYYhkA9arW():
    value = 340089
    text = 'hgFDCuLnqs35XoSiveRl'
    total = value + len(text)
    return total

def j5_VgKZ4NB():
    value = 357722
    text = 'lDO61tVFUQgdrfBreXiQ'
    total = value + len(text)
    return total

def fnpYlVj5g1():
    value = 833560
    text = 'YqLVRrIbDBArx8PRd8aL'
    total = value + len(text)
    return total

def xQdeglp6Lc():
    value = 871710
    text = 'WPck54rdbEzlEkHvydBp'
    total = value + len(text)
    return total

def ImjZa2hz6F():
    value = 639334
    text = 'lqx1KqWnIIxtZYoqijtF'
    total = value + len(text)
    return total

def ZZWUEHXPsQ():
    value = 84790
    text = 'Pt14yzt5dvPj2xnHCIlc'
    total = value + len(text)
    return total

def BTqjeT8a2d():
    value = 419758
    text = 'UwvEOGni5LqTi3NfRxc9'
    total = value + len(text)
    return total

def aQ14Sg8j6Z():
    value = 592186
    text = 'hUsIFjo7SbwQJFqQGRMn'
    total = value + len(text)
    return total

def ym3HaK9HT4():
    value = 44434
    text = 'Fke8uq2ukomacKMSUsB_'
    total = value + len(text)
    return total

def sW2y9pji71():
    value = 313788
    text = 'boOLBHAXZfKgK91gQ1bG'
    total = value + len(text)
    return total

def pK758Z03Os():
    value = 895739
    text = 'YyIo07OXtzgB7QCLblJH'
    total = value + len(text)
    return total

def bQa0QHIo8p():
    value = 470601
    text = 'qKUn90PS86VXLJSUTOWz'
    total = value + len(text)
    return total

def fhoIGkXjgk():
    value = 139463
    text = 'C4vdF7vLQhJHl7ttLxjZ'
    total = value + len(text)
    return total

def MvNaLGJwF8():
    value = 415470
    text = 'KhNkYNHgug498IMxeubh'
    total = value + len(text)
    return total

def b7gUkg_BNR():
    value = 505225
    text = 'xNJDbEQEKX5sH2ody54E'
    total = value + len(text)
    return total

def om3FBRyIJk():
    value = 407643
    text = 'TD0JhVIisSP8rLO59Uyp'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
