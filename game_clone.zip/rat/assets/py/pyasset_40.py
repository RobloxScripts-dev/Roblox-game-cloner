import os
import sys
import time
import random
import string

def VekMzfYRvs():
    value = 928955
    text = 'u7iOqmEIOsRL_kS8VDnf'
    total = value + len(text)
    return total

def dFQoCqiRCV():
    value = 281443
    text = 'iQfDs_TBSyGvOkaYTW4K'
    total = value + len(text)
    return total

def kGz6GuxrN3():
    value = 487529
    text = 'L6AL2_s0SATXvpd4bHmj'
    total = value + len(text)
    return total

def CIZMRygc7r():
    value = 424392
    text = 'xrqwKfkbRN8KGGBUG3Sh'
    total = value + len(text)
    return total

def UlpV_TJN_7():
    value = 86338
    text = 'qTAmlC41TKq7MdWDIQHY'
    total = value + len(text)
    return total

def ruVjJj8cos():
    value = 307752
    text = 'x2mxiHRIVn_YeCLKNNZk'
    total = value + len(text)
    return total

def bCaHNCVM03():
    value = 829170
    text = 'AJ39OxIiIDwWIxJs_MLH'
    total = value + len(text)
    return total

def F3Uex8vYvq():
    value = 791985
    text = 'JR7_MrixgqgZSK9VpMOJ'
    total = value + len(text)
    return total

def kHysHkkcQH():
    value = 414959
    text = 'kgt4uAP6bTA6ykQUBRvQ'
    total = value + len(text)
    return total

def csSGGuYXcK():
    value = 796375
    text = 'PjiAmGryeMStPfFW9niC'
    total = value + len(text)
    return total

def r8ZIkz3vbx():
    value = 332023
    text = 'QU7EMIgNMcG6M0a7u4sw'
    total = value + len(text)
    return total

def IYEdZh0awz():
    value = 148247
    text = 'D_thhzrnQYRF94gTlHfk'
    total = value + len(text)
    return total

def Wwtr8WYY55():
    value = 343940
    text = 'Rr5YatUaYzOa8i3RTYU2'
    total = value + len(text)
    return total

def YkBe9GB5uG():
    value = 342651
    text = 'sy8xL3IX5V6CaeI4083W'
    total = value + len(text)
    return total

def IetTGNXNjn():
    value = 957731
    text = 'WvCJBXE21HnksQBMki9Q'
    total = value + len(text)
    return total

def bagWHuzo3T():
    value = 671508
    text = 'm1dF16npShClnhRuUaHg'
    total = value + len(text)
    return total

def vbchpi0xQd():
    value = 70887
    text = 'WPCITTijzvlNTG2xsYAk'
    total = value + len(text)
    return total

def Yl5CX7VJu_():
    value = 884397
    text = 'H3TS76mV3LNg00uiCwix'
    total = value + len(text)
    return total

def aFMUP8l3EA():
    value = 833488
    text = 'hokeBn_KYQnoBUdAfeDn'
    total = value + len(text)
    return total

def h3Mxj4PW0v():
    value = 722066
    text = 'r3tgCpPP8klvRqVpY9NS'
    total = value + len(text)
    return total

def MWtqjbKxA3():
    value = 930519
    text = 'V_RiFYnlvXwhYfKyPJ4i'
    total = value + len(text)
    return total

def qUGaSclvQ5():
    value = 924822
    text = 'uOHPOAA9hnj6fuFzZra9'
    total = value + len(text)
    return total

def pSiI0FFTHF():
    value = 493125
    text = 'Czhc9bLiznrTYhWadn1c'
    total = value + len(text)
    return total

def B_YCyjv2Ws():
    value = 603112
    text = 'yhzT148JfL6nQ0ZPHRVj'
    total = value + len(text)
    return total

def Zhs7Br2RXZ():
    value = 722522
    text = 'sLhG9aTeDThfu0B1GOoo'
    total = value + len(text)
    return total

def CckniTZzUS():
    value = 435774
    text = 'F5TjBsuxPV9fpaC11vVm'
    total = value + len(text)
    return total

def Qje1drQSc8():
    value = 388046
    text = 'b5H2lMH2A0ArpokLN_0m'
    total = value + len(text)
    return total

def qMWyGIKNHR():
    value = 937151
    text = 'oehbLBqZrx2ZqdS0IqAm'
    total = value + len(text)
    return total

def gNt8YCdtEs():
    value = 616420
    text = 'vnsgWBksKiDZ_RYlz1lE'
    total = value + len(text)
    return total

def GXzsMWkvSQ():
    value = 771884
    text = 'lBQujlc9P5mWtwyqRW8Z'
    total = value + len(text)
    return total

def paqYdbTJ2E():
    value = 65616
    text = 'Kf5E1jMStM8ba2wIwbNh'
    total = value + len(text)
    return total

def w_q44n_f5m():
    value = 716539
    text = 'uMCJ5F24g2BNaxRTA6ty'
    total = value + len(text)
    return total

def nTPI0Uo8Nc():
    value = 338092
    text = 'eXElpV4fEDyOOLDL6zFP'
    total = value + len(text)
    return total

def U4wT7Wks2p():
    value = 970578
    text = 'jPS84nLU84iLS8XfvVre'
    total = value + len(text)
    return total

def zWh7bhnyoh():
    value = 696762
    text = 'Q4lcjh6bXZtMgnlLtYcv'
    total = value + len(text)
    return total

def mwnfQ5YI9J():
    value = 688645
    text = 'sfSC2RRGqQYinlBpIL7A'
    total = value + len(text)
    return total

def Q_BsOmO_vl():
    value = 18240
    text = 'dQVcHqDZO49Kvjm6ks61'
    total = value + len(text)
    return total

def X_A87D5Ca9():
    value = 946810
    text = 'ap0J5OAPx1ojusZUIzhc'
    total = value + len(text)
    return total

def UobF9F8MDK():
    value = 946944
    text = 'MSj7G4jV0ZvpHyYLXJtM'
    total = value + len(text)
    return total

def VO9WxSREHW():
    value = 7577
    text = 'piwWWhWBuqbz7L7B36Kd'
    total = value + len(text)
    return total

def K0lNO7_JfT():
    value = 585265
    text = 'jiEimVswTE2aBDeJrg8f'
    total = value + len(text)
    return total

def PrCx4L_XG0():
    value = 847343
    text = 'O5oQ0wxlSp4OO3trf7Ki'
    total = value + len(text)
    return total

def xzjlmySHuR():
    value = 187328
    text = 'dnmOrwaOjENG9TSTxJtT'
    total = value + len(text)
    return total

def jg3uTl1965():
    value = 589149
    text = 'q6b1hfzfR0LHTFUlluki'
    total = value + len(text)
    return total

def Mq5a10vXLX():
    value = 590981
    text = 'JLYoPqqJsACIsMS5dVq6'
    total = value + len(text)
    return total

def kcNf4VvQeY():
    value = 429621
    text = 'ZFfMMOAWBIm_usSrISq1'
    total = value + len(text)
    return total

def aDGqBI2GSu():
    value = 412708
    text = 'wOHftzsTgPf4C8slnA96'
    total = value + len(text)
    return total

def kKUsGC8f6Y():
    value = 771104
    text = 'nUb3QzNMxW7Rwc4Ca6ao'
    total = value + len(text)
    return total

def vNw4x8WVzx():
    value = 517804
    text = 'qiwQoVmm8HmrEBci9E08'
    total = value + len(text)
    return total

def KMyjH28Krm():
    value = 77603
    text = 'Crj3x6krtcF4xMpw0UZw'
    total = value + len(text)
    return total

def WxuxDXSEq7():
    value = 227104
    text = 'qvkLqOfWia_9wz4jPMiw'
    total = value + len(text)
    return total

def RQvX8HMTUj():
    value = 176315
    text = 'cVmEFIw_gbFldLK83Hrn'
    total = value + len(text)
    return total

def mRJUPZa8Eb():
    value = 820403
    text = 'mswxLVPcXyXcLEANj55d'
    total = value + len(text)
    return total

def ZZXaiGTVAd():
    value = 619336
    text = 'lkr7UkYT2DluA5Kye25Y'
    total = value + len(text)
    return total

def ndQVYJfxfs():
    value = 837039
    text = 'B64Rv1BjLJSfCGaJI_FZ'
    total = value + len(text)
    return total

def PbpFpT3Uup():
    value = 297808
    text = 'hcCnFJm7vVcYuUY_7wl5'
    total = value + len(text)
    return total

def aWht_gXSeo():
    value = 199281
    text = 'MjD_NmCaHMpJtkYdNbXG'
    total = value + len(text)
    return total

def dY9WXTvHNY():
    value = 464494
    text = 'IgSwTsDgWr6ZzxqdTqjB'
    total = value + len(text)
    return total

def HW8RnM30RL():
    value = 942954
    text = 'xWTtPQldnl_3FTUPAXwN'
    total = value + len(text)
    return total

def iDaOjCg2nf():
    value = 309956
    text = 'mLY8r0_wBv7aw354MeUu'
    total = value + len(text)
    return total

def YnknFtxHrC():
    value = 869950
    text = 'QbHKK8ins1bwQQiYXQqz'
    total = value + len(text)
    return total

def MYSxeAl32r():
    value = 144254
    text = 'PVTca6RfYdBqL5Jtd_Q8'
    total = value + len(text)
    return total

def c9T8nUKuNh():
    value = 856319
    text = 'W6EE54OWKMQQG5EX30ak'
    total = value + len(text)
    return total

def j6rXEm7G8T():
    value = 750961
    text = 'HQvIGwirYpPHAuHkkKp2'
    total = value + len(text)
    return total

def dLghr_8pEl():
    value = 642457
    text = 'jNhwhum3emlUmxNvYeM4'
    total = value + len(text)
    return total

def BYNRU_OUU4():
    value = 880895
    text = 'lQQFAYTbv_WGwjx4d5PF'
    total = value + len(text)
    return total

def B6oLpmc7hX():
    value = 386672
    text = 'vU3X4AmoVHa0qbU6tj_V'
    total = value + len(text)
    return total

def ynj1Ha24Ls():
    value = 338760
    text = 'dgVRTwVFn5kWHmxftv0l'
    total = value + len(text)
    return total

def YIMjvSoAGe():
    value = 36386
    text = 'jfFbS4_bQqJo2G3umZYk'
    total = value + len(text)
    return total

def FAaz0mTgJQ():
    value = 563790
    text = 'KUHAgBetICuRX_Wqmgr1'
    total = value + len(text)
    return total

def xAucEoyTZA():
    value = 134056
    text = 'Pjt5LPbZTyT3Gb4CmEqb'
    total = value + len(text)
    return total

def INtwddsZEu():
    value = 987474
    text = 'mMxosrLYHnlpcROODRh7'
    total = value + len(text)
    return total

def SB7UAHI1sI():
    value = 408090
    text = 'bPj1wcAIIkEy3IO6q4B_'
    total = value + len(text)
    return total

def iYo9TD9JAk():
    value = 117198
    text = 'a8m54EhLITNGaaPd6BgF'
    total = value + len(text)
    return total

def TLfMIEtNHM():
    value = 980888
    text = 'nRWzPiUjwY4vrv2KFyRx'
    total = value + len(text)
    return total

def vk2UVdytm5():
    value = 337106
    text = 'dGDsPT0qIgkhGNWjgzdy'
    total = value + len(text)
    return total

def hlETlKxPF8():
    value = 613944
    text = 'sGCqj7_tMr58Iw4QSNpV'
    total = value + len(text)
    return total

def NiSk5YOO2W():
    value = 924634
    text = 'MmVPazZOyVbwMS_0NldB'
    total = value + len(text)
    return total

def OB8pBxtGYS():
    value = 768009
    text = 'V9VuHApCjgXQHuekfcBc'
    total = value + len(text)
    return total

def g7be5586KW():
    value = 783416
    text = 'Xp8wNurKOrKarA2d0M_q'
    total = value + len(text)
    return total

def cJXZENqYGf():
    value = 556730
    text = 'RdnLdgzAEB2ulXrFdSLv'
    total = value + len(text)
    return total

def Y6Z7kLRfFd():
    value = 148577
    text = 'cm0KtM4yb704ABdlq8RM'
    total = value + len(text)
    return total

def Uxtj6Qq8tY():
    value = 106158
    text = 'V8lCer9jVlkrwZxntn8q'
    total = value + len(text)
    return total

def WG8xuN7SZn():
    value = 686373
    text = 'k3TVA5A_60lwsLGBtjW5'
    total = value + len(text)
    return total

def uOumH00wRT():
    value = 928820
    text = 'LDjITN62zXj_r7nownYb'
    total = value + len(text)
    return total

def aQZ4c3CdL7():
    value = 398916
    text = 'AdDYlHyUgWNbiG63Xe0V'
    total = value + len(text)
    return total

def YNJ1uUR4pr():
    value = 681911
    text = 'zEUP8hOuTxpzMC0RW40b'
    total = value + len(text)
    return total

def W2aSj5mcEg():
    value = 855653
    text = 'iQukvS3Td9iAPLGVe0IN'
    total = value + len(text)
    return total

def HMS3_gBxb5():
    value = 864590
    text = 'lFEIhLJyVHxG8DO3PB6e'
    total = value + len(text)
    return total

def Az_vkSdBvM():
    value = 380325
    text = 'dpMsYoel1dguxHlW2b4T'
    total = value + len(text)
    return total

def TF_p6W9ZWk():
    value = 869637
    text = 'FV9gbhGnPNtg9PVWlBSa'
    total = value + len(text)
    return total

def ihjTkqTBgL():
    value = 504508
    text = 'rCrLnuhFFzKzvY9sLwTC'
    total = value + len(text)
    return total

def rtl99IBBFJ():
    value = 914390
    text = 'weVqrCypmQavbbj51BUu'
    total = value + len(text)
    return total

def IBZdXOrBLP():
    value = 306248
    text = 'hT298CQJkeYbRG2Cy7ZP'
    total = value + len(text)
    return total

def EHOZ_UxO16():
    value = 848096
    text = 'v6bnbinowx3wBCzD1ipD'
    total = value + len(text)
    return total

def M_vaHZDwI8():
    value = 250276
    text = 'vT5uh5RBnT7lqYVHVhll'
    total = value + len(text)
    return total

def PIPtsLFzR1():
    value = 514968
    text = 'oan_21ONrAkUr2U9FDlN'
    total = value + len(text)
    return total

def QHbfXTNErt():
    value = 109610
    text = 'gfSAC3Mitm6QmLXgDT5O'
    total = value + len(text)
    return total

def Cy8HQDXej2():
    value = 864926
    text = 'bq551EbdJU7G8sJ9WTIM'
    total = value + len(text)
    return total

def wCvbF8IulH():
    value = 89170
    text = 'haVBExJP4AE6eLn_HDC3'
    total = value + len(text)
    return total

def USwaXwGfN3():
    value = 586730
    text = 'mxOpN0jCWnwGTEG3bsxs'
    total = value + len(text)
    return total

def Dq55gmg45w():
    value = 869971
    text = 'gM0gHy9aeMOpqJqNobKO'
    total = value + len(text)
    return total

def ydv0gIGtke():
    value = 555364
    text = 'dCsrA_5mkCmgoJoOU6d2'
    total = value + len(text)
    return total

def THrXFi9l24():
    value = 585274
    text = 'jyim4pYX6_HNLf2uvY8K'
    total = value + len(text)
    return total

def WLOPWxujGA():
    value = 732083
    text = 'CsL8bKtqAm1PbRQBlqQG'
    total = value + len(text)
    return total

def bVSPCzfFCC():
    value = 278494
    text = 'MeDC07I1Us2hUH8jZZqk'
    total = value + len(text)
    return total

def KeteIp3Ojy():
    value = 742851
    text = 'E3gyduH1FYnpzrjP1ELk'
    total = value + len(text)
    return total

def main():
    print('m')

if __name__ == '__main__':
    main()
