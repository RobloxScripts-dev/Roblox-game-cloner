import os
import sys
import time
import random
import string

def DnXz2qK9iz():
    value = 217452
    text = 'G7XnEDSA72N4Vcvt_nBT'
    total = value + len(text)
    return total

def V3CiwBs4Kq():
    value = 105867
    text = 'pjAAuxZ9b4aELSsdNyDj'
    total = value + len(text)
    return total

def Co1OnFVhzr():
    value = 487743
    text = 'UGG4AqYrO9jjPydI3DZY'
    total = value + len(text)
    return total

def yU9ur756bK():
    value = 985841
    text = 'w2WwEVunZakLLqp_TUWW'
    total = value + len(text)
    return total

def a7IJu7z31l():
    value = 221892
    text = 'qYRBb96aAcSBgYl_uEUl'
    total = value + len(text)
    return total

def h96cpYr7mG():
    value = 836040
    text = 'qb5hITcXPN2qzTob_B5J'
    total = value + len(text)
    return total

def CoCxOb_mOJ():
    value = 223116
    text = 'TSi0CZtDvJnFTL2OkwJ7'
    total = value + len(text)
    return total

def qXTYc3XWf6():
    value = 266807
    text = 'rY3KxGXG5f7Oe9vVLgX3'
    total = value + len(text)
    return total

def k149ZIyGgY():
    value = 649997
    text = 'yvwmIcRz4KRdu3CTc11s'
    total = value + len(text)
    return total

def yDnK_CA2bC():
    value = 163259
    text = 'g7vbk_MEq6FGbzdqYWwz'
    total = value + len(text)
    return total

def M0VgQZGrxp():
    value = 272469
    text = 'pLmt3_TYvXGBJ1JwStTp'
    total = value + len(text)
    return total

def O0hpiLtHEO():
    value = 912724
    text = 'wgnMrPZInFizJDbYQwiv'
    total = value + len(text)
    return total

def L3gxnazDRB():
    value = 112810
    text = 'CiJ8b8ecHxjpWFOR7_wX'
    total = value + len(text)
    return total

def dj4nuQs8e0():
    value = 259122
    text = 'Hrdm5IHsgx8xvA1jYuhE'
    total = value + len(text)
    return total

def zRzqdfTNAS():
    value = 129479
    text = 'ZecYWQqbvsvXVsx5kVFm'
    total = value + len(text)
    return total

def cVfxJPjdG5():
    value = 509484
    text = 'o8rDhzqr3y6C2YA9jjZo'
    total = value + len(text)
    return total

def MUeJM5xVip():
    value = 645291
    text = 'tWPx5c30oVz1CDRRyUyQ'
    total = value + len(text)
    return total

def hdBjv6rwdq():
    value = 814439
    text = 'hU4uq1h7NNpD0nrVxj11'
    total = value + len(text)
    return total

def zWWrAy39hP():
    value = 206703
    text = 'T9enEIg2R36bI7Slbv1H'
    total = value + len(text)
    return total

def CyddSN6Qba():
    value = 116741
    text = 'FGhRvJnb8RFWvOPX8Shp'
    total = value + len(text)
    return total

def LMrQFuke3L():
    value = 96777
    text = 've_VKrmI2WnmKDn2xG7Z'
    total = value + len(text)
    return total

def la1iuqYWTt():
    value = 521060
    text = 'SzvVTiRAgkOf5LqIPXQo'
    total = value + len(text)
    return total

def n45GHslDfL():
    value = 104489
    text = 'HuPJAUGcI5JFlgTCCTXh'
    total = value + len(text)
    return total

def mt_rgz1lSR():
    value = 781598
    text = 'pDz3VdqH3bykuut8CqCD'
    total = value + len(text)
    return total

def AiaeBdAIlp():
    value = 845345
    text = 'NepWZsFWWQ0jDrxzWkpz'
    total = value + len(text)
    return total

def OaBDmZROoA():
    value = 200168
    text = 'YtSfy3rN4Ki6RCSR951g'
    total = value + len(text)
    return total

def ZXWveHejwA():
    value = 446474
    text = 'seI1fzaubJARkUUQrGOd'
    total = value + len(text)
    return total

def ybx31A9IPU():
    value = 482570
    text = 'NbQ6cYZnXbLtqiN9ea4g'
    total = value + len(text)
    return total

def o3MXMhu5kN():
    value = 765171
    text = 'AyA3Yj4yPxIjLq1hHlO9'
    total = value + len(text)
    return total

def tSXp51BwjS():
    value = 510990
    text = 'f3ldkCxQ3ajxUzae9b_R'
    total = value + len(text)
    return total

def DNuYTomVQk():
    value = 302869
    text = 'PQeqp50FYEvIbIjoxcJy'
    total = value + len(text)
    return total

def liDuBhqj4u():
    value = 412853
    text = 'QN6HcHn6YNo3HopVAXTm'
    total = value + len(text)
    return total

def hfaKqxdZQK():
    value = 798843
    text = 'z63zEZyEVNyrF0uhrJAe'
    total = value + len(text)
    return total

def R84dS68ip4():
    value = 891613
    text = 'eL_KNNps4UFAxHpqrFFR'
    total = value + len(text)
    return total

def OJ9JdSyXWO():
    value = 737362
    text = 'IwlAkOee40sQZ1mKqHRJ'
    total = value + len(text)
    return total

def koEQKCiH1T():
    value = 587225
    text = 'fGVdsgRBY2KcQ8IU1XXH'
    total = value + len(text)
    return total

def F0VzvKoNjw():
    value = 786441
    text = 'pe9KIHUUooUSJIxmheL_'
    total = value + len(text)
    return total

def owPCILIINf():
    value = 997867
    text = 'S9N5kNy7GS_QV66e_q0Q'
    total = value + len(text)
    return total

def oZiCuEHzdx():
    value = 301366
    text = 'xXSlERaCA_hxCqyG5BvG'
    total = value + len(text)
    return total

def GISeW9inzN():
    value = 712875
    text = 'Z_Phv_tfX5w3BpYfyGBc'
    total = value + len(text)
    return total

def m0NLkHQSOK():
    value = 420332
    text = 'jA_2htBH1mGYyvkNJ5W8'
    total = value + len(text)
    return total

def TQH9kUrnGl():
    value = 210393
    text = 'iG6wz5fsjVUhWsLVeuJp'
    total = value + len(text)
    return total

def sJdOo8zSji():
    value = 935060
    text = 'fPJq0pVoH9mIvCgHcEod'
    total = value + len(text)
    return total

def SnvL1rbKQ3():
    value = 963475
    text = 'aXAtVdkR7XJKPX1wyL5l'
    total = value + len(text)
    return total

def GpO2kACUwa():
    value = 560635
    text = 'Xm3yXxy4Ruy0Sym33Oy4'
    total = value + len(text)
    return total

def YBBYyZru9C():
    value = 544457
    text = 'Mx7pM8UiGSqiVxN9D5pD'
    total = value + len(text)
    return total

def Ygc0tBdm2R():
    value = 853841
    text = 'UpkljoH60fGy1qFRLQOL'
    total = value + len(text)
    return total

def Hvf4MoSG5r():
    value = 797069
    text = 'WPk_JvFBDFezosRRqPsE'
    total = value + len(text)
    return total

def eYzuz8z7Bn():
    value = 239482
    text = 'Z75zsN9q0uijzJGmGt4H'
    total = value + len(text)
    return total

def oBUBLw8X13():
    value = 19133
    text = 'qqyuSOzoCuhzh6FVTjh8'
    total = value + len(text)
    return total

def kTSQCfJQrA():
    value = 397322
    text = 'dgntJOvIum7BEwoREwuU'
    total = value + len(text)
    return total

def QcSTQw5jST():
    value = 102740
    text = 'uXocEkML_xvWcSzU8nEf'
    total = value + len(text)
    return total

def iucjU3wfuD():
    value = 300977
    text = 'epD133_KXgMHbn1OCV9L'
    total = value + len(text)
    return total

def FLClmZdQAR():
    value = 765244
    text = 'hxcxvaVL0TO6ZvaIpUic'
    total = value + len(text)
    return total

def vzhj0RipJ0():
    value = 79619
    text = 'sszB57Gshqzqvr4vFn7O'
    total = value + len(text)
    return total

def p3ooAPhRcY():
    value = 153474
    text = 'i3G2wRp4ZLr_W5FWBa5Y'
    total = value + len(text)
    return total

def lJ0elCxR_Q():
    value = 892213
    text = 'lhaPglKkEFIurUbBj1gD'
    total = value + len(text)
    return total

def IOh20WZxsT():
    value = 924233
    text = 'NrK0RhABVJIwHcPCwPCG'
    total = value + len(text)
    return total

def oqFxTzCD1_():
    value = 870164
    text = 'RO9G7L6HCf0RL23EVucM'
    total = value + len(text)
    return total

def CaAhyz0GeH():
    value = 709702
    text = 'rsZXUt69azexCYVpEuDw'
    total = value + len(text)
    return total

def sPcbxYSlHx():
    value = 780024
    text = 'NsSWQKGI_VWB4VocenWM'
    total = value + len(text)
    return total

def cuZKGLzJfL():
    value = 212592
    text = 'GcdTEaMq0ODX1A_AZ0qG'
    total = value + len(text)
    return total

def tO0kaodAp8():
    value = 486556
    text = 'zd2FM27pE7EfJoXR9cED'
    total = value + len(text)
    return total

def GFgohyr5IT():
    value = 36201
    text = 'm0IvU7ay5YVD7_OD7a7X'
    total = value + len(text)
    return total

def OsEdGym8Nv():
    value = 82629
    text = 'KFXvgkNbfo_GHBhV7cVR'
    total = value + len(text)
    return total

def PLcCkRcTRv():
    value = 493623
    text = 'CEj46H8r8gwlKcFrwXj2'
    total = value + len(text)
    return total

def kDIy_ArDz4():
    value = 640484
    text = 'WfuwcuX0wj7k_giV5mzS'
    total = value + len(text)
    return total

def ngzLCtUMk0():
    value = 302919
    text = 'zsSLq2OV9jdhZ9hyPxiR'
    total = value + len(text)
    return total

def L7w12VXOaU():
    value = 553968
    text = 'Mwn0ZJdF3OuBA4dcOQgc'
    total = value + len(text)
    return total

def UYFes9bPzU():
    value = 671453
    text = 'WhcgCBjkxRXKXyIF_uR8'
    total = value + len(text)
    return total

def WcCTxYiIbl():
    value = 570607
    text = 'Sp8fq5ODzwn0d2LVoiZ4'
    total = value + len(text)
    return total

def E9CnzR2jg7():
    value = 854299
    text = 'Xk4nTXzISIeuZwRw2rg7'
    total = value + len(text)
    return total

def BnQmtgayNZ():
    value = 623154
    text = 'YlNhuwL2RCE0twCMzZ8I'
    total = value + len(text)
    return total

def q9JYp7Q18z():
    value = 812911
    text = 'LEKjFtbT0dPWB5LkoS0n'
    total = value + len(text)
    return total

def YBW7y_I1pS():
    value = 28063
    text = 'bVepLOVhBqKk1xKB5IiA'
    total = value + len(text)
    return total

def iCeoNPM9Aq():
    value = 898912
    text = 'mIGbJfRPcCyca9ozuMLU'
    total = value + len(text)
    return total

def CdiaCipC2Z():
    value = 307325
    text = 'ExDI1Nqfvly7G6H4PZ3l'
    total = value + len(text)
    return total

def VNzYSFX4l9():
    value = 726155
    text = 'y5eC69denQKGoLDWk_GE'
    total = value + len(text)
    return total

def T8Rfu73WwA():
    value = 793758
    text = 'cmUsC5JyNOLwedrrMoDp'
    total = value + len(text)
    return total

def YGD1F5YBh0():
    value = 605151
    text = 'onu84jrmCekSuxhiQe8K'
    total = value + len(text)
    return total

def MaqAGGXOdB():
    value = 310419
    text = 'wR7YOTB19f5f_z_bVf_L'
    total = value + len(text)
    return total

def x42pdpXGMt():
    value = 307846
    text = 'ztVwHyNUi27nkDwW_OUc'
    total = value + len(text)
    return total

def PxpcAqXJ7O():
    value = 790381
    text = 'wCcz9UyAO2rXB7Dwd2N4'
    total = value + len(text)
    return total

def WBYLRIH13a():
    value = 928129
    text = 'wJ6Cqx_KDko2SIFsVlj0'
    total = value + len(text)
    return total

def FXiVIv83oo():
    value = 146587
    text = 'FRucTLO8y21mFWJqg1ef'
    total = value + len(text)
    return total

def Zz0P_Di5vS():
    value = 340232
    text = 'Nav07C7_MeLYG7pncVan'
    total = value + len(text)
    return total

def sXgz7X3I4i():
    value = 350624
    text = 'soGiEf5TAc0Mppo54U02'
    total = value + len(text)
    return total

def cBnY5NEI37():
    value = 59571
    text = 'jnM2VMlpHtewFVVbURDT'
    total = value + len(text)
    return total

def u2oyaaAfM6():
    value = 90193
    text = 'OHL8SZT1wP04x58pjaWS'
    total = value + len(text)
    return total

def iSaiMR5Tgx():
    value = 683557
    text = 'UjZWREqKI9kUqUn04za_'
    total = value + len(text)
    return total

def Kqr2JkrC0q():
    value = 919627
    text = 'TWLe3JADersdxFMRStDS'
    total = value + len(text)
    return total

def wLGVblra6P():
    value = 858754
    text = 'gcLb9w0XBWkarVcsbpmM'
    total = value + len(text)
    return total

def Z4KovJHzGL():
    value = 92004
    text = 'H5AL8_H8rYwr5djRMKn_'
    total = value + len(text)
    return total

def SvIQqxs5HF():
    value = 649024
    text = 'qe9o2eBvpNfCQ1D5Edjt'
    total = value + len(text)
    return total

def V5Rowi0WHI():
    value = 474798
    text = 'X97w8fsNkbLPjacxFvRQ'
    total = value + len(text)
    return total

def VFrszQIlrP():
    value = 781865
    text = 'kwtZ403jn45JSTl6Oqm7'
    total = value + len(text)
    return total

def oYROPKuNko():
    value = 889361
    text = 'UrOdoxMFvimpiAubg4d5'
    total = value + len(text)
    return total

def xMWJyEWBIy():
    value = 464360
    text = 'KG67Wp0Cd8ygTtknaKcI'
    total = value + len(text)
    return total

def qw9bDVlLvf():
    value = 909260
    text = 'YkB2S39_wfmqxMVUMEOZ'
    total = value + len(text)
    return total

def UpHk6MtjiO():
    value = 623604
    text = 'acmD_N3V_380_4IiCkuo'
    total = value + len(text)
    return total

def qU1Y3besCb():
    value = 965407
    text = 'l9Dw5vAIiYNN7zgZdUKo'
    total = value + len(text)
    return total

def miRugdwpYV():
    value = 240871
    text = 'h5ObeEXg0cNJWDJ0NhAq'
    total = value + len(text)
    return total

def toaTlsRFUh():
    value = 384925
    text = 'fDiO3P4Z8loArJDrCWMe'
    total = value + len(text)
    return total

def pDNCb_5C95():
    value = 577712
    text = 'Z7KIySho41ptFmP6QQq1'
    total = value + len(text)
    return total

def AbCD4nb_JH():
    value = 637771
    text = 'rnsj6lRI0BSJx15aJDC_'
    total = value + len(text)
    return total

def main():
    print('d')

if __name__ == '__main__':
    main()
