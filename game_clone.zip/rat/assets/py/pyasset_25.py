import os
import sys
import time
import random
import string

def duGXAZImdn():
    value = 356444
    text = 'kMCYymtioJexKHIP9tBv'
    total = value + len(text)
    return total

def eJZzExyFgK():
    value = 922393
    text = 'zQBiOFLYhFgOc79AVqMl'
    total = value + len(text)
    return total

def uU23GzgVvw():
    value = 781348
    text = 'lE5Zqhpa102KPo7LUEQ1'
    total = value + len(text)
    return total

def jzc9e_ifdt():
    value = 732528
    text = 'nyZ5gVwFpwMa3sY_Om3l'
    total = value + len(text)
    return total

def lymH9c2uMe():
    value = 306335
    text = 'xOAVaCtD34F5P9IPpVS7'
    total = value + len(text)
    return total

def n7HqHlEUWq():
    value = 366765
    text = 'MRrEHxK14WDDlmeCyAy1'
    total = value + len(text)
    return total

def B3uEgkIJVx():
    value = 393739
    text = 'OssAsfrtsZDAaq6XYgF3'
    total = value + len(text)
    return total

def UKQHsYQy8d():
    value = 88559
    text = 'AXadUmdDbOouDLeY2Irw'
    total = value + len(text)
    return total

def JgNn9b20pM():
    value = 695365
    text = 'OJZnmk5eoR6fDqqS3U1A'
    total = value + len(text)
    return total

def YOVt9mdgRo():
    value = 345920
    text = 'xqrQ5NkOd8XndoUzWuEy'
    total = value + len(text)
    return total

def RjbI61ozBq():
    value = 774853
    text = 'wkqeKYZKtqzX7CbOrWVV'
    total = value + len(text)
    return total

def iYnPsAf0cV():
    value = 563894
    text = 'IxkIdl4Y6XKJlNqvqowl'
    total = value + len(text)
    return total

def kCONkMn6Wd():
    value = 621485
    text = 'P9DPDbVBApQyEblvClCi'
    total = value + len(text)
    return total

def anBO0FucLQ():
    value = 398219
    text = 'yCgm7UyNFLaILmUoNzDx'
    total = value + len(text)
    return total

def kr2YztSxF1():
    value = 638059
    text = 'YXBbMbOEpjpaHy8Ht9ne'
    total = value + len(text)
    return total

def XJtGzmTrVr():
    value = 358155
    text = 'NELEgSLvBogTXnFEDyJN'
    total = value + len(text)
    return total

def UI7UIcVlh_():
    value = 142240
    text = 'Povi5h3Yd4igwlQDUlOd'
    total = value + len(text)
    return total

def BH6ovQfgKk():
    value = 298747
    text = 'VyN4feuMzuLjc15PtEQd'
    total = value + len(text)
    return total

def LyOtrTVOrJ():
    value = 39049
    text = 'Mo0oQQhgpbv7EPQhUajs'
    total = value + len(text)
    return total

def tzveVzrKJ1():
    value = 366342
    text = 'sOhSjv8wNdDSy8vAqnCr'
    total = value + len(text)
    return total

def DYO_lZY0DM():
    value = 262782
    text = 'ZALa1QXyWksKg7dayawR'
    total = value + len(text)
    return total

def f7ImID0G3R():
    value = 293883
    text = 'BGoYX9aTORd_C52EwMnI'
    total = value + len(text)
    return total

def YH2q0AbhEy():
    value = 65203
    text = 'wQsX9hGkVAyGmV66MFFK'
    total = value + len(text)
    return total

def fhxsc_qAgf():
    value = 606290
    text = 'ixm4imJ3QD1glhwPWLq0'
    total = value + len(text)
    return total

def d2iqjnZqjQ():
    value = 942249
    text = 'p0nr9dPfQYqeA39WfDbp'
    total = value + len(text)
    return total

def evBAHqyLOB():
    value = 807456
    text = 'cOpP4CR1SKvzTQf7UExW'
    total = value + len(text)
    return total

def qgjROk3307():
    value = 777213
    text = 'rIJ2kvI3sXR4R3ETA29E'
    total = value + len(text)
    return total

def NduXf_B1ZO():
    value = 834192
    text = 'sNoS_A0Q0HrdaY3636Xg'
    total = value + len(text)
    return total

def f4UkfPLl9d():
    value = 424661
    text = 'nugL9RAHmWG46flCl5YJ'
    total = value + len(text)
    return total

def kqGnDAS__u():
    value = 887166
    text = 'N4fD2OdxIOK7sIuvZKd9'
    total = value + len(text)
    return total

def Osxv_j7PoR():
    value = 21584
    text = 'gIOs44YfEuhhJUN8fmpK'
    total = value + len(text)
    return total

def jnPR2IseQH():
    value = 275766
    text = 'A1XerB5NxrWjqSrDRDwf'
    total = value + len(text)
    return total

def fWPW9IA0Nl():
    value = 621497
    text = 't0xnOzLLzfhbqVJX0G0e'
    total = value + len(text)
    return total

def yAkBacJR3x():
    value = 949389
    text = 'BTY7OUJ6JZnVL0i7uwxL'
    total = value + len(text)
    return total

def AZ71phJ0Qw():
    value = 119622
    text = 'iNsG27R2sRG4epQY0TQm'
    total = value + len(text)
    return total

def vNlL9ZEjj1():
    value = 402250
    text = 'r44s0ELz5QvdCxxtbGtJ'
    total = value + len(text)
    return total

def qXNPDZBAMn():
    value = 477506
    text = 'IrbfSUhkTLyMy0rpGhVS'
    total = value + len(text)
    return total

def y383uqSqoT():
    value = 729517
    text = 'Ji19ARTVhKzdhZKq0Aqk'
    total = value + len(text)
    return total

def Fa6jUbYsFw():
    value = 594371
    text = 'RjTXwAJ6bOisFIK8Nox0'
    total = value + len(text)
    return total

def I21tf0OB7h():
    value = 172402
    text = 'xtIY5IXTdgjDBlf5zLFz'
    total = value + len(text)
    return total

def t29xANdHoy():
    value = 773557
    text = 'qjj3kZqYrl04trkHX0Jh'
    total = value + len(text)
    return total

def JxcMRtq88B():
    value = 897590
    text = 'M9Q27f2iLcn0DK8eSa3E'
    total = value + len(text)
    return total

def IltHXDscx6():
    value = 88053
    text = 'ukFiKQGrVVtIg5dX6RgA'
    total = value + len(text)
    return total

def NUB_S4muTw():
    value = 535818
    text = 'kJZKdFuXkW4LjpS49ArW'
    total = value + len(text)
    return total

def m8ABY9QFNj():
    value = 855643
    text = 'lZ0Xr9gx4yKcz2_tBsYY'
    total = value + len(text)
    return total

def FT4KC2hN54():
    value = 678457
    text = 'hybcSYxwD0lsj2qlQ8vi'
    total = value + len(text)
    return total

def oodw3VBBD5():
    value = 963703
    text = 'yEZnua2LDLLImzcq4h3T'
    total = value + len(text)
    return total

def cv1w36PgOD():
    value = 622700
    text = 'h6_wvWwsdwpRrQ6slfDK'
    total = value + len(text)
    return total

def UoUecw6Esh():
    value = 711053
    text = 'X_5BXo4c8ZcGdDulNO9c'
    total = value + len(text)
    return total

def yP3S5BDlNT():
    value = 72389
    text = 'CLEWR_DBzOHOQ6aZNTcj'
    total = value + len(text)
    return total

def ie7jl2InYR():
    value = 202070
    text = 'rmNVgw5R_VsE8YxJ0nzX'
    total = value + len(text)
    return total

def JWqUGY5nsF():
    value = 994351
    text = 'X3WVnV_O8i5MkNbOg_Bi'
    total = value + len(text)
    return total

def CqPW1UnqWc():
    value = 596131
    text = 'Ue2Gk0QGHXc0aWd3p4h4'
    total = value + len(text)
    return total

def kyIjsmQQh5():
    value = 245635
    text = 'A42ChzrroMH8Ztpunpjv'
    total = value + len(text)
    return total

def qIIUxstY87():
    value = 118295
    text = 'ZJoYfOI1GsIviXgTM6bb'
    total = value + len(text)
    return total

def imdv7n2Kjs():
    value = 402001
    text = 'UcGwawH22Ojv0y4rzwg4'
    total = value + len(text)
    return total

def MGneuHEqja():
    value = 949417
    text = 'Qjzvc2Nos_T2UH6JY6ea'
    total = value + len(text)
    return total

def vaqWUVTbtv():
    value = 237107
    text = 'qBFCjohMbmnBXlxuWNzs'
    total = value + len(text)
    return total

def VLXxlpLVK0():
    value = 400261
    text = 'QyeUJ6iNM2N4Z_3S0QgC'
    total = value + len(text)
    return total

def UIw9lGFhEy():
    value = 534040
    text = 'nckCPvMZmb6AwXtApdPU'
    total = value + len(text)
    return total

def qgHBNN77zc():
    value = 59556
    text = 'FHyL3855aOiRpkC0qV_r'
    total = value + len(text)
    return total

def G_8KBjsP54():
    value = 732907
    text = 'lfQeHMDh9akfC6vCfq8S'
    total = value + len(text)
    return total

def p1mBjy4BoS():
    value = 150395
    text = 'xe1AKaIXQauzG7vS21RE'
    total = value + len(text)
    return total

def xPmLTIhGAM():
    value = 539701
    text = 'lXH2qiXMRUl5b8UrX4V0'
    total = value + len(text)
    return total

def V7Ip_mgpxz():
    value = 936589
    text = 'ZkYUPYcvBriyhVe26G5A'
    total = value + len(text)
    return total

def hSgcChn8bP():
    value = 596673
    text = 'Npa7EqbaQl7gow6l8ANY'
    total = value + len(text)
    return total

def bYJiO8wlCe():
    value = 618609
    text = 'pzMWG9h_hilScNwQ8HKC'
    total = value + len(text)
    return total

def M2nGPCjHoT():
    value = 546322
    text = 'bF7ubzAtp5IHlGZyx1s0'
    total = value + len(text)
    return total

def oAtRV5ke9A():
    value = 673128
    text = 'PH1AMlyykCOpsBOJ0VIq'
    total = value + len(text)
    return total

def zqSzNmQeVy():
    value = 133670
    text = 'VOP4cunlMgmgYsXQcGoB'
    total = value + len(text)
    return total

def yt38rVIwvg():
    value = 790889
    text = 'zPnnAWCLioBQ4lzEfDpz'
    total = value + len(text)
    return total

def xkhrQzGsab():
    value = 309929
    text = 'SRsz5w_Yf7ORxy6rlnJ_'
    total = value + len(text)
    return total

def l01hhYlkbM():
    value = 244236
    text = 'NpRGTT3wXrLl60Ylr5ej'
    total = value + len(text)
    return total

def E6Z83PFcMg():
    value = 992876
    text = 'M6Zw0KKZd4W39wY3lpL3'
    total = value + len(text)
    return total

def xC7UN8c05c():
    value = 216092
    text = 'zE4XTQI82dTXO38uC_pC'
    total = value + len(text)
    return total

def J6lDbGeZjg():
    value = 293311
    text = 'FbUoF9II8Z_JxL9H2y6G'
    total = value + len(text)
    return total

def UDtH5hZdF4():
    value = 324093
    text = 'fgPRCimyLoap7PoSgcl9'
    total = value + len(text)
    return total

def sbtPh_mp7m():
    value = 817757
    text = 'ku31wP1Qjp68D7F0kscV'
    total = value + len(text)
    return total

def cY0LfiyzQZ():
    value = 96259
    text = 'ddgm2bASk2cfJiKb0fNb'
    total = value + len(text)
    return total

def Ab4ro_LAk2():
    value = 71038
    text = 'TOXgbWZoagIAQURRnobt'
    total = value + len(text)
    return total

def ypQMxG2iyB():
    value = 919072
    text = 'TRRwNcGmc74n1ies6lDR'
    total = value + len(text)
    return total

def UyiZ8oRy0O():
    value = 416680
    text = 'FHnb6PTHfqhDOAPFum2T'
    total = value + len(text)
    return total

def utL56hMyrX():
    value = 34251
    text = 'Vic9EZlPtVOxmsEkEswz'
    total = value + len(text)
    return total

def JgT63IzsN2():
    value = 469307
    text = 'Jq51LKNUSbZgqunWkebk'
    total = value + len(text)
    return total

def xyjDZwlDF8():
    value = 193057
    text = 'NDf2BlpCDH75xhSaR3is'
    total = value + len(text)
    return total

def B327e1xOwA():
    value = 360280
    text = 'jHW5Vt_xh7zIS6H1CI8R'
    total = value + len(text)
    return total

def vyeX74MJZx():
    value = 550072
    text = 'jAuBt1WYu3T5KzL9Y44l'
    total = value + len(text)
    return total

def T8NbvaoWda():
    value = 958585
    text = 'eilawQfPogmpo7kmqg9E'
    total = value + len(text)
    return total

def XJOXc2MnIz():
    value = 447684
    text = 'PicEO16mZXMv2s7xvTRd'
    total = value + len(text)
    return total

def UiZY31YeSI():
    value = 492071
    text = 'OeM_bpUGsoxZCdSubJ54'
    total = value + len(text)
    return total

def OJaXucMaIx():
    value = 672556
    text = 'CYU51B1ZneUcuaV6lRTi'
    total = value + len(text)
    return total

def yn5MqoLyJY():
    value = 690454
    text = 'F9dyWcWUCIw9KuY9mAET'
    total = value + len(text)
    return total

def eLjTnHoBTV():
    value = 781338
    text = 'ySQ5Q587iQD0rmpTFLw1'
    total = value + len(text)
    return total

def o3HgOxcWUp():
    value = 126598
    text = 'JkG5gyu265k5pLIatJTI'
    total = value + len(text)
    return total

def fgFRf2_gcf():
    value = 469212
    text = 'FZUDK4yMCMS2qUJllo3F'
    total = value + len(text)
    return total

def jQbDGABeEM():
    value = 906763
    text = 'yUnPjGk7B0VpXuN5IcfC'
    total = value + len(text)
    return total

def pnPzezg4Uj():
    value = 717628
    text = 'jtpQPCn4TpYA9xedB4lG'
    total = value + len(text)
    return total

def D8lly5VeZI():
    value = 493276
    text = 'ni5phohgcI6lxIbAOl0V'
    total = value + len(text)
    return total

def Hf8gHQPm1G():
    value = 859703
    text = 'aCXOS1pYVKkBX03pflkb'
    total = value + len(text)
    return total

def xBpdjSTYML():
    value = 717633
    text = 'hGO1xRmm83_JbsLgGwdh'
    total = value + len(text)
    return total

def xmn1HYmHf3():
    value = 394120
    text = 'WAofgKsxTx2UKwS355nU'
    total = value + len(text)
    return total

def vBytuWLtWG():
    value = 200840
    text = 'VaYrW8rSX1i8Mq5U8qqw'
    total = value + len(text)
    return total

def XvGivMq3Rz():
    value = 740279
    text = 'lwsov1vHl5K1EyrZZ_sm'
    total = value + len(text)
    return total

def Y4jhiCRdbx():
    value = 748859
    text = 'RceaKjeJyt2Dr84Nzxo3'
    total = value + len(text)
    return total

def nwxtPmCbgl():
    value = 130339
    text = 'Sc30bzAWsRUfgYnewR9Z'
    total = value + len(text)
    return total

def lkEnYaBm0S():
    value = 423171
    text = 'ku7HVeTpjE9PeVLBIdgv'
    total = value + len(text)
    return total

def DrtK1SGKMz():
    value = 209304
    text = 'NsfXi7uillos2nxRcq_d'
    total = value + len(text)
    return total

def cPSz7l1P_a():
    value = 589398
    text = 'viGQGGHKtmKqdsdy03dq'
    total = value + len(text)
    return total

def iOWQSzhFPo():
    value = 143848
    text = 'ZhWvlemy0ZUWkUl06K2N'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
