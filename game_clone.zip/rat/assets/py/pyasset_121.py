import os
import sys
import time
import random
import string

def UBvgtMiFXC():
    value = 794325
    text = 'cnMyAqaKkYuhUReRlOL6'
    total = value + len(text)
    return total

def xDHaXxJuQF():
    value = 169466
    text = 'hcJwPPfXSimWxUQmNjsK'
    total = value + len(text)
    return total

def p11w0IyIyM():
    value = 298898
    text = 'w6fUVYuLh_sXsZ0KmctX'
    total = value + len(text)
    return total

def aLjyguIFPU():
    value = 455394
    text = 'KdE6UMzxHTnbHV8z4qDW'
    total = value + len(text)
    return total

def e5qLAudy7W():
    value = 224286
    text = 'LMHvUCKwkKwLvVJLsXve'
    total = value + len(text)
    return total

def UOE0u8Ucc9():
    value = 49088
    text = 'CqK5pqZGrwz9xzGQZNRt'
    total = value + len(text)
    return total

def WkYlVw5D8d():
    value = 824275
    text = 'PsRNPcRtyvRq5zjrFNdi'
    total = value + len(text)
    return total

def ptB50ArROL():
    value = 412811
    text = 'svFX0CPHvCzf4QwWhZvZ'
    total = value + len(text)
    return total

def z_PC0RkzIP():
    value = 134350
    text = 'vbZRAyhVSJkjpsrdz7kd'
    total = value + len(text)
    return total

def c3Lk0vPveu():
    value = 364616
    text = 'U2rxfm2YREiZLb0GZWSN'
    total = value + len(text)
    return total

def YgmqkrVPob():
    value = 893507
    text = 'Si8RUBFhuUZMAdJspMJq'
    total = value + len(text)
    return total

def zi_rs3BpxZ():
    value = 736036
    text = 'IAf6TMUxmGQvgV2WngyQ'
    total = value + len(text)
    return total

def IVJHgFkiIz():
    value = 249776
    text = 'tkaUs2E_jZABerxk3VgF'
    total = value + len(text)
    return total

def adC1xvtsun():
    value = 947316
    text = 'QLiqjjJb1YeNlmo3wOOw'
    total = value + len(text)
    return total

def dxBy2_jWLr():
    value = 389773
    text = 'NL84ctWv8oADzPyow92i'
    total = value + len(text)
    return total

def wguLmWZSML():
    value = 176529
    text = 'zSYNqRBnZKfZO39UkYTQ'
    total = value + len(text)
    return total

def Dqnhksk61o():
    value = 417033
    text = 'jfy3Ev18zT8Nuh2WTekh'
    total = value + len(text)
    return total

def ke8QDKqXMu():
    value = 336570
    text = 'em26cXzAPIl0VSmxX8vY'
    total = value + len(text)
    return total

def TcNFduXXOE():
    value = 513603
    text = 'aX8BkCrY96aFpCfa_oYo'
    total = value + len(text)
    return total

def wuGBtrg5Ny():
    value = 267711
    text = 'u7KRrGXNdpePm9Hauopu'
    total = value + len(text)
    return total

def i1rf6VZLwG():
    value = 512814
    text = 'tzR2f0XCSs5DWIJNoDiE'
    total = value + len(text)
    return total

def kDba8mN7j4():
    value = 487077
    text = 'tcMmfo_HJjGuY1V1T9_S'
    total = value + len(text)
    return total

def xVxWZVVzxa():
    value = 298234
    text = 'wlK4Ebd8mHc3JtC9vvHz'
    total = value + len(text)
    return total

def uACW8EpoJt():
    value = 542864
    text = 'ZRjb6MfwXBwUdMbIArLt'
    total = value + len(text)
    return total

def zzUdV_3ZmE():
    value = 633032
    text = 'sYBttqsnnB48BZFLHxfR'
    total = value + len(text)
    return total

def Cj72eJK9sY():
    value = 855702
    text = 'PK8daZFwqUOESxRuUVpv'
    total = value + len(text)
    return total

def aeFzp39ViH():
    value = 187504
    text = 'cWb4k14LjywpPOYjxVYa'
    total = value + len(text)
    return total

def wgVWBdLNXC():
    value = 189497
    text = 'rmHh_giMKyS9RhAWfGKl'
    total = value + len(text)
    return total

def xk99sa8sN6():
    value = 345077
    text = 'iwXB9WbtAKCoWRhUsKbj'
    total = value + len(text)
    return total

def UCW14Itx51():
    value = 738991
    text = 'Is8ifHB3ZGrgRFYnH2PJ'
    total = value + len(text)
    return total

def WOcks9emNC():
    value = 369729
    text = 'rnYAQh10HHbfWTFNkOU2'
    total = value + len(text)
    return total

def mlH2EcvGdj():
    value = 895118
    text = 'wyHr8UaSUwONpTNh6kQo'
    total = value + len(text)
    return total

def RTRYbGh2am():
    value = 473819
    text = 'zOjE89mwAHRHsensFYcv'
    total = value + len(text)
    return total

def YcJG_wD5HG():
    value = 811888
    text = 'zBV9x1k_eOkDSCc_inT_'
    total = value + len(text)
    return total

def aBLofoiYDV():
    value = 468556
    text = 'Df1z8rSqzXZgHvWYSl2i'
    total = value + len(text)
    return total

def eUjrWQHJyq():
    value = 727521
    text = 'qxVpOX8joARDti4b4tA8'
    total = value + len(text)
    return total

def IDdPwMGLtF():
    value = 375675
    text = 'HfeUeOVBxA4GqZQ3mbtV'
    total = value + len(text)
    return total

def sXCsWSyLWx():
    value = 137755
    text = 'HfE95LImiMMXDagLIqu8'
    total = value + len(text)
    return total

def t1M4TPhMZu():
    value = 665850
    text = 'pDqmHjQuXsfQ0ELgHNMo'
    total = value + len(text)
    return total

def nmZYDGJ1Bt():
    value = 181581
    text = 'wIN0hy3L9NyBBkGGuP1S'
    total = value + len(text)
    return total

def m7MdCX2FU4():
    value = 309470
    text = 'IFsmr0xMbpiKEZXKt6kJ'
    total = value + len(text)
    return total

def Mt16kZKNTE():
    value = 133221
    text = 'ZQaiXJJqevHgiqJ6VvoF'
    total = value + len(text)
    return total

def GmFwqLIE0G():
    value = 330949
    text = 'MTqyjEXX3W1GrmG8sHoN'
    total = value + len(text)
    return total

def uy5YMegk_Q():
    value = 504070
    text = 'FaMhALEpFVplrAxsDLTC'
    total = value + len(text)
    return total

def kxUeHVFGkJ():
    value = 450798
    text = 'QHJOXntnOeF21BUq3NzQ'
    total = value + len(text)
    return total

def asVeWV_iUB():
    value = 83065
    text = 'VsfMaXgm5nqQ1tq252ee'
    total = value + len(text)
    return total

def zFDQLP3XxJ():
    value = 19221
    text = 'vEpk6MMzK01B17b7Ph9W'
    total = value + len(text)
    return total

def TuLb2yTTsw():
    value = 598346
    text = 'ZarjTq9KB6ZAXOQrGVqE'
    total = value + len(text)
    return total

def xETreQR3oH():
    value = 380731
    text = 'GSxDt93FlmB2hUoG29zO'
    total = value + len(text)
    return total

def utIiaSQfG4():
    value = 220551
    text = 'x5LuvkF6xSZHeQARD98Q'
    total = value + len(text)
    return total

def xqBDXaoseU():
    value = 26673
    text = 'NgDwL53zos4LWSm3Zvo1'
    total = value + len(text)
    return total

def JqK0PB9U7R():
    value = 292135
    text = 'iplnevckvImr9duv1k5R'
    total = value + len(text)
    return total

def A3ob5rOxeO():
    value = 607025
    text = 'ujE4M3JMSaXkxq8zwyjF'
    total = value + len(text)
    return total

def i_8XAZI2Ou():
    value = 39026
    text = 'JpOo6M_P9dAonoekLK48'
    total = value + len(text)
    return total

def YLIuX8zrcW():
    value = 861092
    text = 'Sk_GDNRjT4elOjFgbnyH'
    total = value + len(text)
    return total

def I8YxjdBANQ():
    value = 690936
    text = 'WecovOgJ7ren6c7Svlmv'
    total = value + len(text)
    return total

def Bp7QtKYk52():
    value = 462861
    text = 'oMOIyakGHIbqM1V9vu1B'
    total = value + len(text)
    return total

def NSFcjdQK7d():
    value = 42756
    text = 'sf7XcS9v3o5p0spmWsNh'
    total = value + len(text)
    return total

def O1mWQ0K4wc():
    value = 56599
    text = 'NmcEULPMkVAA_3fpiGRn'
    total = value + len(text)
    return total

def s0UHUeOFmZ():
    value = 826555
    text = 'SCXKPoFZKj9xosSg2Kmc'
    total = value + len(text)
    return total

def kixNdBHWq2():
    value = 55463
    text = 'XVHVwt4MLblZSLCoiU9L'
    total = value + len(text)
    return total

def nLoJV5qsKH():
    value = 847048
    text = 'YwHl6b1kEvpt04s_tMuK'
    total = value + len(text)
    return total

def IZHIa5qSLi():
    value = 946867
    text = 'u31jIZPlBR7jdcW6Sui0'
    total = value + len(text)
    return total

def OyRz3veQyr():
    value = 153194
    text = 'lk6D3f3DaRe9GKh5bwSY'
    total = value + len(text)
    return total

def M3JbZPirKn():
    value = 651782
    text = 'dgwyYD0w4ZpSu0ROmXwk'
    total = value + len(text)
    return total

def FVEOtmPadk():
    value = 214894
    text = 'twDdrTXhmBUaEYfyJAyV'
    total = value + len(text)
    return total

def GdybkhyaCm():
    value = 726093
    text = 'N2LXYvr4LXM9Wax5wK7T'
    total = value + len(text)
    return total

def yivH9R5vot():
    value = 985415
    text = 'pJeQWzi0UkXgJ3OedXwN'
    total = value + len(text)
    return total

def L1bx95vHDB():
    value = 814231
    text = 'm65cG1cKUNaInqrGyPwm'
    total = value + len(text)
    return total

def JM6NexPTKe():
    value = 447955
    text = 'xbhEcLCaj24vHg7yyk8J'
    total = value + len(text)
    return total

def WgcqU0uQJE():
    value = 417681
    text = 'tVfwJjyTmwDTe_zmLuaS'
    total = value + len(text)
    return total

def mrUYhZENAT():
    value = 827139
    text = 'o5nVtvz87OtIhtGppWts'
    total = value + len(text)
    return total

def Wte_99ljXf():
    value = 270303
    text = 'RLrqNstvIdWcSEadQtAz'
    total = value + len(text)
    return total

def N5IXSIuSc1():
    value = 679704
    text = 'R4AIdXOoSbYOxwxcLfOI'
    total = value + len(text)
    return total

def hfybRq918W():
    value = 879104
    text = 'vv0_6aHEtH0wKT4wo_VP'
    total = value + len(text)
    return total

def yiGW2c5Zhw():
    value = 510287
    text = 'RfMv9JvUshA24teoBRLM'
    total = value + len(text)
    return total

def vMoqUB3D3j():
    value = 897055
    text = 'vQkfamhODIZRc1qQyEKM'
    total = value + len(text)
    return total

def YbpElrjumo():
    value = 788774
    text = 'ulje4lSQ2QOdeecLdlTb'
    total = value + len(text)
    return total

def bF4kjZ9TE5():
    value = 784381
    text = 'jcmzKherdlCKXrc0Mxyt'
    total = value + len(text)
    return total

def ld4J_ukXpy():
    value = 120333
    text = 'VyesQdZ5ITEBDKrRTzrI'
    total = value + len(text)
    return total

def zW6cQGcoHM():
    value = 996678
    text = 'dVZqRhTGyAYUrmeODw_H'
    total = value + len(text)
    return total

def BOwk_JzjqD():
    value = 476052
    text = 'YaEmIpTfcY4tq9ICQ9le'
    total = value + len(text)
    return total

def XzES0trFj4():
    value = 70884
    text = 'bYoPZ1OQQrSE05QBli2u'
    total = value + len(text)
    return total

def eREkgRUKse():
    value = 28332
    text = 'a6OFLF6Xxppi6zUMorIj'
    total = value + len(text)
    return total

def Q6sH5puv87():
    value = 551816
    text = 'p0UkCMbvcQEYKf9ty2tx'
    total = value + len(text)
    return total

def V6AcSY5VF9():
    value = 778215
    text = 'A_RbjwZMCqxOo5UTuN3b'
    total = value + len(text)
    return total

def AaA7lp3Mgl():
    value = 287931
    text = 'ZKk_SSg2JSaIxt8extCi'
    total = value + len(text)
    return total

def xZvrxdXT7C():
    value = 642431
    text = 'dRUyKr9kGPxKiAnd1GcB'
    total = value + len(text)
    return total

def MkrWTWHwtE():
    value = 691314
    text = 'lQMeHWgbV1b8deKI8001'
    total = value + len(text)
    return total

def uQDZthLujg():
    value = 661406
    text = 'ptSxF5rbQrabSN0yQgvo'
    total = value + len(text)
    return total

def jKCKiFv1NF():
    value = 778805
    text = 'RD0oO34O6q226cQGfdLA'
    total = value + len(text)
    return total

def V_smNVyMuN():
    value = 935578
    text = 'IXGvHx3LE1VMU_ljgzId'
    total = value + len(text)
    return total

def TfpV71m_zj():
    value = 974806
    text = 'JhxVCaBsWdpBpRHShm6V'
    total = value + len(text)
    return total

def jdnmmwxzxY():
    value = 239077
    text = 'dlbOHiR4NaLOwm0oFNOz'
    total = value + len(text)
    return total

def eWjsY_Zert():
    value = 509783
    text = 'R5wApM0BNaqeJjYoIRLy'
    total = value + len(text)
    return total

def m3BEIglQZ8():
    value = 590499
    text = 'P4VLwM5iWTIcG4aedVmD'
    total = value + len(text)
    return total

def fltPmFKl7I():
    value = 695927
    text = 'zitLxPzjwLOXLdSptGBi'
    total = value + len(text)
    return total

def pRdFHd8mEN():
    value = 509346
    text = 'LN4wgjaJ1QuvOokI7GB_'
    total = value + len(text)
    return total

def k5LpMbYoF_():
    value = 428902
    text = 'XH1A1kcIyark6wgLmBP1'
    total = value + len(text)
    return total

def bNUS7BJ4D1():
    value = 593899
    text = 'gll6W7G5YshRAPyZDdme'
    total = value + len(text)
    return total

def TVv6K_P2dQ():
    value = 475467
    text = 'cKgREcAab8DOwyoPcgIJ'
    total = value + len(text)
    return total

def O2JMB_hkre():
    value = 877225
    text = 'bBWJbPrOIE49y0bVLP2k'
    total = value + len(text)
    return total

def TDwLkKqOjE():
    value = 337258
    text = 'y8OgVD42qoeaepgfKTkm'
    total = value + len(text)
    return total

def yWYRhQ2q5w():
    value = 317381
    text = 'JV9b3jDS9CsxDyezWcYG'
    total = value + len(text)
    return total

def ROwV9KBoi7():
    value = 363982
    text = 'WK65VyXgLYRsturTlgQR'
    total = value + len(text)
    return total

def DNwXotYUZj():
    value = 757619
    text = 'UCyyeQdVdTgVAgB2Fj_f'
    total = value + len(text)
    return total

def q1_Avchal7():
    value = 184564
    text = 'ISsm9fzsrjmBlK9LNk0b'
    total = value + len(text)
    return total

def oLpH_HW6h5():
    value = 214366
    text = 'cqjngNSo0obRxQtb1TCI'
    total = value + len(text)
    return total

def HvtjahMz4V():
    value = 181714
    text = 'Fuzu53FVyO_0oVlWyGv8'
    total = value + len(text)
    return total

def r52v64MEVn():
    value = 426728
    text = 'pGd5sAC2l5CC306tHout'
    total = value + len(text)
    return total

def eLIktOaenT():
    value = 156619
    text = 'CVx_qhObFvz1edVRCYYW'
    total = value + len(text)
    return total

def G26PlPrPsc():
    value = 182799
    text = 'wBm6PUX6zRQ5bfgqCvBn'
    total = value + len(text)
    return total

def flQqbOrrUj():
    value = 827791
    text = 'OcUHiW3IQFofXtUwk4Ka'
    total = value + len(text)
    return total

def cJdFjzb5sX():
    value = 812408
    text = 'GwKd4KvJ2qpyAxNGoyDp'
    total = value + len(text)
    return total

def mAT1y4wNtj():
    value = 433462
    text = 'VkygzKErWITjJeVYRjsq'
    total = value + len(text)
    return total

def Z6NhSeDGDQ():
    value = 704958
    text = 'sswiHTCuNsKpvqEwB6lr'
    total = value + len(text)
    return total

def mPVPvqM9j5():
    value = 246698
    text = 'HO_trtSop5w6Kyh8g9FR'
    total = value + len(text)
    return total

def Wpw586whaH():
    value = 464061
    text = 'KJCFQGjWI8kecY1ex_f1'
    total = value + len(text)
    return total

def z_9Qm9mzad():
    value = 709904
    text = 'yewf5QGHyRaT7Z1LKg0h'
    total = value + len(text)
    return total

def VBoPBAnVOe():
    value = 845892
    text = 'SRDMBH69YXcqPrxESFLx'
    total = value + len(text)
    return total

def oHGhRZCM5w():
    value = 373623
    text = 'G98F8BChjimU328ezNrB'
    total = value + len(text)
    return total

def iNKe2Q_B1f():
    value = 287495
    text = 'WYetlsEYBMzZGK2yIjLs'
    total = value + len(text)
    return total

def vJK9RGCs1Y():
    value = 864487
    text = 'DhEgP5261fLLm0K3b2St'
    total = value + len(text)
    return total

def pO7QvdTXs_():
    value = 968440
    text = 'pzf0oAhTKFTy9MQ8eX9_'
    total = value + len(text)
    return total

def MIsbspjEhn():
    value = 386245
    text = 'rxoMQST76aKJMH2nbS7L'
    total = value + len(text)
    return total

def UZfbzZw5Ad():
    value = 930734
    text = 'HT6wH2VJiukOAMQyBaVm'
    total = value + len(text)
    return total

def XNFtpIXWkz():
    value = 216548
    text = 'VWeMq7_tsvVXL_ydzx7w'
    total = value + len(text)
    return total

def b2yvL4dmAy():
    value = 532888
    text = 'ZNKIzPNrVkmdoM_BUMOq'
    total = value + len(text)
    return total

def pFD48177aa():
    value = 580627
    text = 'kg3lD_J3NtaayrXkMHsw'
    total = value + len(text)
    return total

def k8ueijnrkb():
    value = 855321
    text = 'KqMwP2rQ1uFqtEyzSD37'
    total = value + len(text)
    return total

def BVjnFvcUUW():
    value = 576598
    text = 'dKahHAjlgGmahoQWaC22'
    total = value + len(text)
    return total

def Dv6mqX_geH():
    value = 517629
    text = 'qkqO61CTnSmNCUyIR_o4'
    total = value + len(text)
    return total

def PgYcNO8_aJ():
    value = 301287
    text = 'CHUzVOfx57IAS3z_t2Ib'
    total = value + len(text)
    return total

def t9meaqkLdL():
    value = 779267
    text = 'v_NINeSBYvgUBFoxltQB'
    total = value + len(text)
    return total

def nPfkl3OAeo():
    value = 409331
    text = 'bwopLFao8HhJVT8M9NTe'
    total = value + len(text)
    return total

def D4QyNr03Q5():
    value = 376887
    text = 'ddi1iMGr17D821o3mmHk'
    total = value + len(text)
    return total

def cNqynq9zkI():
    value = 932539
    text = 'FFzyVwJHGGGRocAyajrv'
    total = value + len(text)
    return total

def SlwVO9ZEec():
    value = 361977
    text = 'zL7yQz_v1Jolj0i_Fsln'
    total = value + len(text)
    return total

def MS_L3Ua1sK():
    value = 163985
    text = 'I3OixKyMMbkzDIq_mMhA'
    total = value + len(text)
    return total

def DhXTiwzprD():
    value = 404797
    text = 'tiNIt8PXyn4Gi2mdjGW_'
    total = value + len(text)
    return total

def Pqpby1YxJI():
    value = 392640
    text = 'kaLTRowExiDoZXMXo5s0'
    total = value + len(text)
    return total

def B7dYhzMai8():
    value = 430352
    text = 'sByrlVdCAh2GSIm435NU'
    total = value + len(text)
    return total

def t13GziGKms():
    value = 268824
    text = 'nzzgc8QpTczKLzJa1D9n'
    total = value + len(text)
    return total

def K1mA34kvyx():
    value = 112693
    text = 'gR0oGRFru5n9CTaNfVhe'
    total = value + len(text)
    return total

def FH0g_jCZjd():
    value = 838540
    text = 'ZJltUuXZPyaI4kducMSR'
    total = value + len(text)
    return total

def wHWUvVFcU1():
    value = 350968
    text = 'Kl8Et0Tr2487fT1urKtV'
    total = value + len(text)
    return total

def YjOzeV_wQq():
    value = 804485
    text = 'aabM8fwnN1K2AxQYmllF'
    total = value + len(text)
    return total

def v0_rOd1M50():
    value = 77238
    text = 'DLtQcDvGlo9KCyQ6Nnym'
    total = value + len(text)
    return total

def M6g8gtfLio():
    value = 838183
    text = 'NIVObrNwjeFG8D8XhQiq'
    total = value + len(text)
    return total

def kKuVga4wyh():
    value = 948955
    text = 'UXjUWFld4k_ov9wdG4Rq'
    total = value + len(text)
    return total

def Cnia_KOaZU():
    value = 825182
    text = 'Rehz7JybV0QASWTdY5E7'
    total = value + len(text)
    return total

def Vbgpm7dryN():
    value = 639270
    text = 'YZ2jT1nbfyNgznkzYrJ2'
    total = value + len(text)
    return total

def h6rzO7llvA():
    value = 844187
    text = 'HRHZ_DOhxO2hK8h3afKI'
    total = value + len(text)
    return total

def YF7obZ_ATO():
    value = 200137
    text = 'XUEP8vV3jJeniyd5Kke5'
    total = value + len(text)
    return total

def n121oUQSu5():
    value = 814924
    text = 'tO7otELyJVoZxNTbwuY6'
    total = value + len(text)
    return total

def phIjYBM9Q1():
    value = 151664
    text = 'hOXzvew41t0kedNrhKI3'
    total = value + len(text)
    return total

def Xo2Nu7Luyr():
    value = 235374
    text = 'kh2Wej7Vs_dPWRKAudmO'
    total = value + len(text)
    return total

def th780QvefE():
    value = 365092
    text = 'vVFXIcELYXxNqjCACElj'
    total = value + len(text)
    return total

def sR8ldbWhA6():
    value = 938609
    text = 'FDbj3UG0u_hr2Sxa9esV'
    total = value + len(text)
    return total

def I_i1ot_t1a():
    value = 897793
    text = 'UJp4QW2ItwikIT4TVJer'
    total = value + len(text)
    return total

def ltqMQH74u_():
    value = 482116
    text = 'hehz8GWvz8fCkabBTIsa'
    total = value + len(text)
    return total

def czsvE3x6dg():
    value = 710850
    text = 'RynWzRS2W_h4LyjBA2Gb'
    total = value + len(text)
    return total

def FEWsRlnwjm():
    value = 785074
    text = 'EWU7T1tBkUoxxvwSffey'
    total = value + len(text)
    return total

def bCFubji4Bf():
    value = 870206
    text = 'ysljvv3Z0vm6CrNHCStg'
    total = value + len(text)
    return total

def FNKRaRNZP6():
    value = 173979
    text = 'XzB2rvCsQFPeF7vI23jo'
    total = value + len(text)
    return total

def TfWSo0rwOe():
    value = 952533
    text = 'EaKXutThB6318aeMKkfT'
    total = value + len(text)
    return total

def TCsjTO8Kum():
    value = 415918
    text = 'yhmtZWCFjLF7eK2hMjC7'
    total = value + len(text)
    return total

def JMbSvkuXCB():
    value = 634296
    text = 'BmAL9RkVc88G5Ea_XnuL'
    total = value + len(text)
    return total

def k__9r1epNe():
    value = 999083
    text = 'XMqr5MSzgeC3WFNbYcBk'
    total = value + len(text)
    return total

def EqHNzFQbZB():
    value = 824342
    text = 'zCfMQNjQUAiOCpegdxYy'
    total = value + len(text)
    return total

def tEShO3qN0C():
    value = 427822
    text = 'WUqjUIbf7FOsEgfaV9Jm'
    total = value + len(text)
    return total

def LoEMj1zbfW():
    value = 874732
    text = 'kXUwU0UTMtQf7KKOKCPH'
    total = value + len(text)
    return total

def AOfDJSMfux():
    value = 112339
    text = 'A1PQJAn_VY4cv1IU5EMc'
    total = value + len(text)
    return total

def Xy7kQ9zTTP():
    value = 401387
    text = 'ztZ0J9a6WPr2FDoW1Ezi'
    total = value + len(text)
    return total

def M3QTO2OHJZ():
    value = 713877
    text = 'cLbEx_cRYRi2yYroSYTF'
    total = value + len(text)
    return total

def NgMOi68HyI():
    value = 978797
    text = 'GNfqDi5cIhbE9vTBRJyw'
    total = value + len(text)
    return total

def opWC99oCNT():
    value = 238614
    text = 'OAwLnraGlPO8p_aMqrak'
    total = value + len(text)
    return total

def JqFZVHTXFm():
    value = 386927
    text = 'zpob854mu1yYCDF86HY0'
    total = value + len(text)
    return total

def IJu1guGgil():
    value = 293377
    text = 'GlCIpXJBS0a2R9Sf8CZB'
    total = value + len(text)
    return total

def cQZxX5vYK9():
    value = 938497
    text = 'fFS9uJObNOBwdbaDAbHu'
    total = value + len(text)
    return total

def wTC6fjSraM():
    value = 825542
    text = 'ZegqjLDVbpnYoruZGt1e'
    total = value + len(text)
    return total

def PLg4Qxamyd():
    value = 254395
    text = 'dzNzVItILdBqQCROQUhy'
    total = value + len(text)
    return total

def DfyInt6HOM():
    value = 695737
    text = 'pf5jxvTWawajwdbEzo8P'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
