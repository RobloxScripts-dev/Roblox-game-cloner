import os
import sys
import time
import random
import string

def qcp8QjjijV():
    value = 446627
    text = 'LDMRirUT8FPevlg7RzNb'
    total = value + len(text)
    return total

def Bc2VkoYnX8():
    value = 69640
    text = 'JSvJQDcoy8qJ6R9v9kc6'
    total = value + len(text)
    return total

def BtFsefhpwJ():
    value = 494044
    text = 'oVS77VwCZ3Hs8v4PkUN7'
    total = value + len(text)
    return total

def y6L0_M9wwt():
    value = 223279
    text = 'JL3xGbF_UpMh3KzEH5DN'
    total = value + len(text)
    return total

def V5ifC5rNnP():
    value = 372603
    text = 'urhOgw9RDWsQCd1Z14gw'
    total = value + len(text)
    return total

def SbruBEizLB():
    value = 626282
    text = 'RbMbLYwJEnztukUMY65u'
    total = value + len(text)
    return total

def I4rVNEAvsV():
    value = 689938
    text = 'roBPyOf4gys9WkWJZy23'
    total = value + len(text)
    return total

def p60t594zD_():
    value = 662874
    text = 'RVHZwBs4CApzP62E2KAy'
    total = value + len(text)
    return total

def stvmGOqRbQ():
    value = 842291
    text = 'UfrVMsa1LdzdZFlpFbfg'
    total = value + len(text)
    return total

def PJAWm9Bd0Y():
    value = 975872
    text = 'BHaVtkqYSC4pQgJYceIE'
    total = value + len(text)
    return total

def g6XQTp_4uJ():
    value = 478855
    text = 'pM9u735qeDE8kS4v978o'
    total = value + len(text)
    return total

def gHM4WgiJHX():
    value = 79434
    text = 'ST_MmHFaPrQwckUDljke'
    total = value + len(text)
    return total

def zTC6CsFpyX():
    value = 805390
    text = 'OAgSF5G3Vdu1aMngLbo0'
    total = value + len(text)
    return total

def pBAWJHLAXK():
    value = 18346
    text = 'PeflJazQVn_j7KfvzvhZ'
    total = value + len(text)
    return total

def K0ZB4QHqFZ():
    value = 689071
    text = 'zgR1xhX0LxD6nqhHM1db'
    total = value + len(text)
    return total

def MzLG6E0wYn():
    value = 68431
    text = 'iQ77Zx_yyFhIzw2sFjvZ'
    total = value + len(text)
    return total

def swTtdLO0F7():
    value = 362163
    text = 'maQEGHuDRHqN_S662XUU'
    total = value + len(text)
    return total

def bZGhO1MGgq():
    value = 130695
    text = 'MdzJpJLpUWWG_b2rxwOY'
    total = value + len(text)
    return total

def kOpau0jxyX():
    value = 517138
    text = 'yMfdpkDJNPiMuHHuV2ge'
    total = value + len(text)
    return total

def numMVpqjbb():
    value = 796292
    text = 'VmOUd2xz6c6PuMclHLcb'
    total = value + len(text)
    return total

def UaKozpg1FZ():
    value = 973905
    text = 'mzQCOhUasSw4KD4C76Kr'
    total = value + len(text)
    return total

def T7yK5zvOg2():
    value = 475628
    text = 'TcdtT77dKiQ4_eWTVkQP'
    total = value + len(text)
    return total

def GUZaKZYDWZ():
    value = 272739
    text = 'Kk0Ei637lXc9MymLHCZD'
    total = value + len(text)
    return total

def EjpZBMlMXH():
    value = 399238
    text = 'nui5emGrDtiPArABrApE'
    total = value + len(text)
    return total

def iVVa855um8():
    value = 793009
    text = 'evddcMt6GS_FeFpx834G'
    total = value + len(text)
    return total

def a9wb5B1Lxe():
    value = 413614
    text = 'lnJgYwSu8EUIigp9_Hq5'
    total = value + len(text)
    return total

def nWyGD2Eq8j():
    value = 343573
    text = 'GhLThFkTk_EOPstAsKKS'
    total = value + len(text)
    return total

def kuP7xLHfKh():
    value = 198572
    text = 'Jm5O5P0pMC_rAP_YZcWQ'
    total = value + len(text)
    return total

def EkibO48nZV():
    value = 108087
    text = 'CbbOtHUj2IBqxlZ8Udfx'
    total = value + len(text)
    return total

def ye5oJoAds_():
    value = 345885
    text = 'PFtBA4k9qUPj0ZqnqAoX'
    total = value + len(text)
    return total

def yCnjXJXKPS():
    value = 870556
    text = 'cb7z8pOInbYS3gfTEHtb'
    total = value + len(text)
    return total

def aTPQyzZVy6():
    value = 9156
    text = 'Kx7sTfRpvQcuN7suq2Qg'
    total = value + len(text)
    return total

def LtY99V8yEp():
    value = 292304
    text = 'T81E_5kvIU9gZ9p620n1'
    total = value + len(text)
    return total

def OKs1f2rXU3():
    value = 634260
    text = 'RtuMmiGHjGgs_ph6ZRsP'
    total = value + len(text)
    return total

def TMsumZu6qS():
    value = 135222
    text = 'D8E8IGFskgW6U1iCNJdJ'
    total = value + len(text)
    return total

def tobmhhQo0Q():
    value = 359454
    text = 'tdsLSfB2qUkgHss83dz1'
    total = value + len(text)
    return total

def zRH_KjsGGM():
    value = 200315
    text = 'RGWvjSDk5DPFv7Y5ly3E'
    total = value + len(text)
    return total

def RMJkMobMv6():
    value = 87398
    text = 'J2Qsp29GW7tLoEEsZCsE'
    total = value + len(text)
    return total

def MKllWJU5yF():
    value = 448246
    text = 'mQEgfZ_wdfwCEfwQe697'
    total = value + len(text)
    return total

def tLhCcTcatO():
    value = 21824
    text = 'R3eYIldzA1ckOtpRHmmz'
    total = value + len(text)
    return total

def FgUV2wQgGL():
    value = 551783
    text = 'OV7ufXAZYlvn1CaIEvYh'
    total = value + len(text)
    return total

def ahQrXBA1wR():
    value = 177825
    text = 'etZaZ3Emp1qIoKQ4EAuo'
    total = value + len(text)
    return total

def Jekboc2XYF():
    value = 825173
    text = 'eMndPX1Z4WAlSNwTzeGB'
    total = value + len(text)
    return total

def DvOtAV4Mlp():
    value = 55019
    text = 'SoIvaNIi8b592wXYYfWA'
    total = value + len(text)
    return total

def LTMHERMHO3():
    value = 512911
    text = 'oMnU8E74ohlyqguE3d6s'
    total = value + len(text)
    return total

def X7qgkQsRVr():
    value = 624965
    text = 'ASPowppCn85jO6gVX54o'
    total = value + len(text)
    return total

def DX8UFP0_ET():
    value = 527574
    text = 't65XJISQ0Ot4yWJqzcD6'
    total = value + len(text)
    return total

def M_qSrqDTXi():
    value = 426326
    text = 'W1kJueVifvMVzxIOUjea'
    total = value + len(text)
    return total

def hviZ8ClKUp():
    value = 258946
    text = 'FgiyeaZhaEKtHKsdt59n'
    total = value + len(text)
    return total

def oTNZPph5HS():
    value = 985720
    text = 'gUTXyjYX3EDOwgc8rnsm'
    total = value + len(text)
    return total

def KQpsBjq4HA():
    value = 296811
    text = 'A1QArqIFvb0wRbpSprIB'
    total = value + len(text)
    return total

def Dr5uFIV2uI():
    value = 165618
    text = 'wuUP6_hOZRbq4IuQCS6n'
    total = value + len(text)
    return total

def RqCaxcLzn3():
    value = 667222
    text = 'bhxrOY1n655fatAbV9Kw'
    total = value + len(text)
    return total

def iB_hfqVaag():
    value = 13910
    text = 'sr_YJIncONTfASTTkWCR'
    total = value + len(text)
    return total

def YVQJEJK1w4():
    value = 138583
    text = 'pYk0QEDcWf6I_FEAEaxO'
    total = value + len(text)
    return total

def kgtKBbQr9t():
    value = 687468
    text = 'EC18CZV4NSW6IEhShfWc'
    total = value + len(text)
    return total

def n2CJjKQrOl():
    value = 326394
    text = 'XViz8KXxzfQRepOQbtUY'
    total = value + len(text)
    return total

def pc0su7tA6F():
    value = 685701
    text = 'qeJtFuF10B1tFfZe4vdd'
    total = value + len(text)
    return total

def HHnc7T0UGY():
    value = 701971
    text = 'emfIbmXB8nGrE9C6qUTE'
    total = value + len(text)
    return total

def UQFt3ZjWV_():
    value = 693269
    text = 'pqQ8_eGFJGZXtFhjp99g'
    total = value + len(text)
    return total

def oU33dop3Up():
    value = 887377
    text = 'iHpyLjWrSoy8gYa7oIIl'
    total = value + len(text)
    return total

def pZZEpH1Tzx():
    value = 198399
    text = 'Vm0ZFPvBMENWieRztRDb'
    total = value + len(text)
    return total

def DXjQoYZ6Pp():
    value = 197858
    text = 'whxuNPlNOmqSTPenBdjj'
    total = value + len(text)
    return total

def SjK6EnLpxw():
    value = 136404
    text = 'OcMwv6FhBhd3QHkNMgrp'
    total = value + len(text)
    return total

def weow9C12yK():
    value = 968425
    text = 'br3JU9eo4Oi9eC7jdbzb'
    total = value + len(text)
    return total

def QxaFRg0MYs():
    value = 839188
    text = 'R8On4aT8VucKFbtOabA4'
    total = value + len(text)
    return total

def bJKCYzpX5X():
    value = 809020
    text = 'sY0tFssKeojr81IHv8oY'
    total = value + len(text)
    return total

def QMdM5IMQBp():
    value = 573898
    text = 'DUBoq5NSSyuYq1AWCL4X'
    total = value + len(text)
    return total

def Uvv_9xv8X1():
    value = 55332
    text = 'J97XybTg7MHFFGrliSoz'
    total = value + len(text)
    return total

def ovg7MnWBej():
    value = 563006
    text = 'Pua7nbETDv5yrdqMRCiv'
    total = value + len(text)
    return total

def hDr3v34xLy():
    value = 633688
    text = 'Kqu387ZLsyEnvDVr9nNJ'
    total = value + len(text)
    return total

def YMnow37nO_():
    value = 500071
    text = 'KcA9injB4k5d2j97qxzF'
    total = value + len(text)
    return total

def I_rjjPWP__():
    value = 294372
    text = 'n7en5DaBO3iWcC0sInFI'
    total = value + len(text)
    return total

def zqJITbQq74():
    value = 342228
    text = 'YzmYfIijWQgCN_PYz6kc'
    total = value + len(text)
    return total

def arjweJcmeY():
    value = 358525
    text = 'LDqG21JUqg2OmSp5oG4V'
    total = value + len(text)
    return total

def j5zvI8fuh8():
    value = 419818
    text = 'JOjoagb08rxBuVjUezsZ'
    total = value + len(text)
    return total

def DNp3OX6yyg():
    value = 823423
    text = 'kU8ABetXQOlRuI2mRntT'
    total = value + len(text)
    return total

def YZYpFF5TnU():
    value = 913655
    text = 'GNMsAqSVvGPlSYYEuCG7'
    total = value + len(text)
    return total

def H5cTkbDnwA():
    value = 696209
    text = 'ylC6kHOSmKu6rGn18fM0'
    total = value + len(text)
    return total

def Q9ZORRXg8y():
    value = 249575
    text = 'XlD1GKR7C6SCgFXcy0g4'
    total = value + len(text)
    return total

def LZWyot4yrR():
    value = 570176
    text = 'TPNNQhKH9IUdUqGHhPFt'
    total = value + len(text)
    return total

def VBs9rAjj3X():
    value = 543586
    text = 'ctRXLESwxNKIcoBMbGw_'
    total = value + len(text)
    return total

def d2l9aIZ66Q():
    value = 723750
    text = 'SuurFp8ZDcRiR_J3FSHE'
    total = value + len(text)
    return total

def uPw5x55QrA():
    value = 843324
    text = 'P0WW64DWP2CpSzYdB4ie'
    total = value + len(text)
    return total

def RwzEwawOxI():
    value = 258865
    text = 'z3F7G_e50Gil2wmHafaG'
    total = value + len(text)
    return total

def Qdo1OmyLjZ():
    value = 963413
    text = 'q9wLEUVcZze3QZ8i6EuV'
    total = value + len(text)
    return total

def qeCXgMOk65():
    value = 92338
    text = 'mby5lZ_W6kfAUHCSjgbV'
    total = value + len(text)
    return total

def L8V6nU08vJ():
    value = 597925
    text = 'r_rWYqrb8zD94BjaTPXB'
    total = value + len(text)
    return total

def oOUAkdABsv():
    value = 690774
    text = 'agp1Y5ajIkbb_HLWX2ky'
    total = value + len(text)
    return total

def QcYAiFre7G():
    value = 211344
    text = 'kf_bxvHFIHf5TsuFVO67'
    total = value + len(text)
    return total

def TVPh1l6b1O():
    value = 532572
    text = 'tzGEQB_YNvlph_7QBxWq'
    total = value + len(text)
    return total

def Ltd1NC3Vzs():
    value = 208744
    text = 'ni5aEEfOD_e8ZF3GZu19'
    total = value + len(text)
    return total

def sJGvMdCzZ3():
    value = 242191
    text = 'MwW02vzG8Wq2BkYqcIdU'
    total = value + len(text)
    return total

def UdOuRT2J98():
    value = 514423
    text = 'HdJxSKh0EB6XLDjEggot'
    total = value + len(text)
    return total

def RPLfu7FB0a():
    value = 309272
    text = 'dIj8TqX9UuHcMyRDCQof'
    total = value + len(text)
    return total

def IY3bEJfSzC():
    value = 210798
    text = 'icagbBRiG9gMZrWvtf1V'
    total = value + len(text)
    return total

def Ks8tt_3dXI():
    value = 81828
    text = 'zi_ZPij3ndZpOFkqTf8S'
    total = value + len(text)
    return total

def VIXOmdPOD3():
    value = 912562
    text = 'xToMX9xp9BXAiQFy5d3I'
    total = value + len(text)
    return total

def ENoGZCu6zo():
    value = 343222
    text = 'J1HkBTOF2TE8cEoIJ46n'
    total = value + len(text)
    return total

def DEkBEVTMD0():
    value = 710531
    text = 'D9UqDcLPXCEpk3ESzmbI'
    total = value + len(text)
    return total

def ii0oqg1iEN():
    value = 521785
    text = 'liIQZhLNVot1bHdEAQ6n'
    total = value + len(text)
    return total

def XgeQ27HG3M():
    value = 920118
    text = 'EhmncLCXhbyJYyQcny6H'
    total = value + len(text)
    return total

def N1zXIo2_Cf():
    value = 426720
    text = 'jo6f78GcHd8J9YXPDiid'
    total = value + len(text)
    return total

def BbTsy1f6sm():
    value = 511151
    text = 'Hb9FmtvQilIEUDSYrB18'
    total = value + len(text)
    return total

def puqoc6IWm1():
    value = 78697
    text = 'T0YK88dH8sNfG8vN8M8Y'
    total = value + len(text)
    return total

def BTCeDk6KIC():
    value = 481392
    text = 'PT4ldtUq_fbck5Fv0Fqh'
    total = value + len(text)
    return total

def T76AjCED77():
    value = 96513
    text = 'KOrGl1RUdVNatzrkCC75'
    total = value + len(text)
    return total

def oVSgjqs4DS():
    value = 561240
    text = 'RsbC16Dd7LiOpEn0RE1N'
    total = value + len(text)
    return total

def fWJ8eKmiT4():
    value = 856623
    text = 'slsNVpGPIOxdi3qaifzK'
    total = value + len(text)
    return total

def xhFO291ffM():
    value = 328095
    text = 'cZW3yusVqsDaKycYCjhc'
    total = value + len(text)
    return total

def aHjUsO6ZfF():
    value = 194180
    text = 'DjnZRnOwUia34f51eNWr'
    total = value + len(text)
    return total

def ds4pe0XpO4():
    value = 579366
    text = 'SmgpcnY7auOdggM3NYnO'
    total = value + len(text)
    return total

def vjC9dUPP8f():
    value = 454022
    text = 'lTN152P09GDbdbD47njh'
    total = value + len(text)
    return total

def DRpv3UKzl5():
    value = 507746
    text = 'iPuCt_Eb04ggLTRM40e_'
    total = value + len(text)
    return total

def d_LpVrkhqT():
    value = 21655
    text = 'dyi6OemRLCnMLAAkAIK4'
    total = value + len(text)
    return total

def EFZ9H5ZChL():
    value = 123295
    text = 'jA2lGLnqmTD6_RR8I1mi'
    total = value + len(text)
    return total

def OdTATpS3AS():
    value = 997013
    text = 'GXFBPtPTqM_nD6YfzgD0'
    total = value + len(text)
    return total

def vEuMbZyjnJ():
    value = 521897
    text = 'qAefSwaxFxgBqXIgbq68'
    total = value + len(text)
    return total

def Cl9yLnYdeM():
    value = 225781
    text = 'WTzivaMqgcIsDPrN6F1a'
    total = value + len(text)
    return total

def iQonquFS6S():
    value = 596447
    text = 'dVQ26bj9dGRUV2WjKgBf'
    total = value + len(text)
    return total

def M3s9oUZVmI():
    value = 77764
    text = 'oRcPqJ2LUKNrAoUA1rfm'
    total = value + len(text)
    return total

def eBmCrLnEyj():
    value = 680096
    text = 'rpKc27KL3DsUIiBKjfj8'
    total = value + len(text)
    return total

def ce6uvvDi45():
    value = 288372
    text = 'RkTeUaKpjDFCG1fR99b8'
    total = value + len(text)
    return total

def KFSsYBMTB9():
    value = 413261
    text = 'cZJkkX3zhcOWNadsXxEJ'
    total = value + len(text)
    return total

def hqz0Ngw4y8():
    value = 317033
    text = 'u3B1jirYkGTI3mukU5Px'
    total = value + len(text)
    return total

def NPHP42UbZ4():
    value = 736752
    text = 'a8135F9VzV3NknXMnOyI'
    total = value + len(text)
    return total

def TWvmFZAQ7L():
    value = 672691
    text = 'y6PQkfi0yFqcCl3hWH0i'
    total = value + len(text)
    return total

def XC8mHquRVS():
    value = 461952
    text = 'Xyp9_07R9j6P2JmpOZta'
    total = value + len(text)
    return total

def RBk8HqH1Wr():
    value = 296617
    text = 'CSwiHRUMbx96NSSjsoeK'
    total = value + len(text)
    return total

def wpoqZCpgyG():
    value = 417310
    text = 'OaKuu4vx2ehTUzWdgUHV'
    total = value + len(text)
    return total

def R0cQgsrviH():
    value = 148859
    text = 'DTw0tWlwAj2GnuNSndzy'
    total = value + len(text)
    return total

def k9VSV_S2nO():
    value = 320132
    text = 'JzQ_aF00Lmobt_Kzwezt'
    total = value + len(text)
    return total

def GwrpmeNQ1O():
    value = 482427
    text = 'cxdpmuA_WJKsiWE4Ml_c'
    total = value + len(text)
    return total

def tpCSvcVUS4():
    value = 868941
    text = 'H0bepusDoMSzzgS10K6E'
    total = value + len(text)
    return total

def Jglb6LGiU2():
    value = 781762
    text = 'ygqK_pQG1d48Ap2CLjMQ'
    total = value + len(text)
    return total

def H8D3u75jm7():
    value = 232923
    text = 'rA_jOZH2adukzIBLjNGT'
    total = value + len(text)
    return total

def jrTdedXxoq():
    value = 500616
    text = 'rTchmhxC5xBp5qJJwqg5'
    total = value + len(text)
    return total

def zHUZKs7mqn():
    value = 851017
    text = 'FAQ9Hl1IJgTQzvcDT6aS'
    total = value + len(text)
    return total

def esV3GyfhqQ():
    value = 433884
    text = 'nfpmKvGU4n8ZXM6HL30z'
    total = value + len(text)
    return total

def ExPE7ZXAYJ():
    value = 286863
    text = 'cbwUaL5BNySkmQjeowFr'
    total = value + len(text)
    return total

def ah_pudypAt():
    value = 353996
    text = 'Ztpi06suaVnHyQxseN4T'
    total = value + len(text)
    return total

def dB8T4A1hmj():
    value = 745353
    text = 'yS_iAUxhfNea4Hd1Py3p'
    total = value + len(text)
    return total

def UGlUyP2b9W():
    value = 245293
    text = 'vgi7NjgO2Hah4Y1xUZMR'
    total = value + len(text)
    return total

def RCLiED3gIg():
    value = 557383
    text = 'AcEriEmPMq9Msx_z53rb'
    total = value + len(text)
    return total

def iJt45M97Mf():
    value = 737534
    text = 'AYyKcWp0TkzKBbP_Izhn'
    total = value + len(text)
    return total

def XcVmRhaAN8():
    value = 22099
    text = 'yvl32fwAo3LNpRVfjLu9'
    total = value + len(text)
    return total

def YQHyvjos1d():
    value = 732245
    text = 'qqVJQru65A2AMp_btWuM'
    total = value + len(text)
    return total

def qGl7uAlmGB():
    value = 138781
    text = 'TdiMVUqHlBGZW_ukusZj'
    total = value + len(text)
    return total

def ubiKEEw1CR():
    value = 606639
    text = 'K_gzy_KTIIO08lx9h9wu'
    total = value + len(text)
    return total

def dWToM9b_c8():
    value = 506538
    text = 'PYcMyzvPw0Rz_9AuCK6M'
    total = value + len(text)
    return total

def CWPNeBLReP():
    value = 113270
    text = 'yEqRmccMOYoDYi7X7rxn'
    total = value + len(text)
    return total

def FSUUEVYbJo():
    value = 979506
    text = 'gei1h9W1W5oy5BS5suXm'
    total = value + len(text)
    return total

def pi8TykFomL():
    value = 67400
    text = 'FZDA4cAXANdoDvLwq5_y'
    total = value + len(text)
    return total

def emZkLCMKpn():
    value = 472640
    text = 'CUESM7HFpx0Qb5hz5T7S'
    total = value + len(text)
    return total

def DxXdRHAYgo():
    value = 166645
    text = 'sMZa3nbgxVUfwB4WiRjx'
    total = value + len(text)
    return total

def beqUaCnVKf():
    value = 357877
    text = 'dZaGibimfZVevVl1mEsE'
    total = value + len(text)
    return total

def OsMJkRB80d():
    value = 107652
    text = 'VaImK4wBVf7NcQp2SlxV'
    total = value + len(text)
    return total

def qV_qSOfO4w():
    value = 829797
    text = 'Jk9jA0cwLyZhO9S3YYCR'
    total = value + len(text)
    return total

def AKOfUc2bCn():
    value = 470313
    text = 'p7QiqIaTuMhQuV9qm465'
    total = value + len(text)
    return total

def URCf_IsnfQ():
    value = 99202
    text = 'Daf4FkWXxCGurWkX1gIy'
    total = value + len(text)
    return total

def KYMadTSsAM():
    value = 743917
    text = 'npozjvKlLhiZvTeeMRHk'
    total = value + len(text)
    return total

def B68uHBMatP():
    value = 573691
    text = 'x7AJn5J2Xo1Qqgu03PGY'
    total = value + len(text)
    return total

def JkeIBWeNpD():
    value = 169392
    text = 'Yg7GiopifY3xKbhnwQGf'
    total = value + len(text)
    return total

def Z97Q34DJYZ():
    value = 225795
    text = 'EcDG8AgF_C3FdSv67sdQ'
    total = value + len(text)
    return total

def iWPSaJtyXN():
    value = 460665
    text = 'Z2OSPjPTvnLSwlIVO2eg'
    total = value + len(text)
    return total

def wMcewxdhIj():
    value = 960113
    text = 'Zmhbr9Ed5DtoFfavOd_l'
    total = value + len(text)
    return total

def Ik4t_l53Bc():
    value = 59182
    text = 'wAHdbzqiHCChB2R9GsD8'
    total = value + len(text)
    return total

def hr4JAhYDQO():
    value = 749777
    text = 'nkStrpTsjZCkb_PtAG_d'
    total = value + len(text)
    return total

def FwcSEG7id0():
    value = 200804
    text = 'xOAuMMk5YujIybqYFkLt'
    total = value + len(text)
    return total

def j3yxw56U1C():
    value = 798750
    text = 'bc9_2U8KU83xPwleRanl'
    total = value + len(text)
    return total

def saC5PCouiZ():
    value = 564270
    text = 'vM9eYJyZfy6_E579Zis3'
    total = value + len(text)
    return total

def YJJA48WI13():
    value = 471530
    text = 'TAMwIW4ffqndDas37e3s'
    total = value + len(text)
    return total

def KwJ63uOZQ1():
    value = 610571
    text = 'KYGG28hysBt1izMyiAvL'
    total = value + len(text)
    return total

def BDjJuu1SCj():
    value = 196014
    text = 'OZIBbQCKKBeVu_7CMfwI'
    total = value + len(text)
    return total

def hlRv7jxNMa():
    value = 548497
    text = 'JABNh_1WODAprCwTkNsh'
    total = value + len(text)
    return total

def r24tQFyb1U():
    value = 23467
    text = 'sfC6EO8TwenzbSNDNW5U'
    total = value + len(text)
    return total

def c0XYLZ00Rs():
    value = 192014
    text = 'tWrJbYc04vno2qCrvibK'
    total = value + len(text)
    return total

def I9b6vQIE33():
    value = 164557
    text = 'YhYrT5a8Cv7EhO1CH2BM'
    total = value + len(text)
    return total

def fcUg43a2Ky():
    value = 967981
    text = 'SzHOnAN7MKLevCoy8sXw'
    total = value + len(text)
    return total

def main():
    print('e')

if __name__ == '__main__':
    main()
