import os
import sys
import time
import random
import string

def zmYBX9XQUF():
    value = 73946
    text = 's4Wrq1x3stIZX76ntrjd'
    total = value + len(text)
    return total

def lGdFC9tQhC():
    value = 441575
    text = 'PCQEIBlrrTdEw40kn5hd'
    total = value + len(text)
    return total

def jFrsZ8RmNN():
    value = 453076
    text = 'CHOC7hqUAInYpbE_W7vr'
    total = value + len(text)
    return total

def fT5DmniFE9():
    value = 96141
    text = 'IdHullZ77zJVTKWPMZQT'
    total = value + len(text)
    return total

def sUlUGiZCah():
    value = 829873
    text = 'xGLQ18fGE7ODWM7Hmj6A'
    total = value + len(text)
    return total

def op6LtrsNsT():
    value = 789480
    text = 'nWodvXvvuRDBtLegiDUi'
    total = value + len(text)
    return total

def rin6JZMz49():
    value = 367290
    text = 'cm9iiQwj28HnMf7xRycD'
    total = value + len(text)
    return total

def R6EZVBMpjd():
    value = 95642
    text = 'sRozrmLFBPKXB755erlg'
    total = value + len(text)
    return total

def VowiBYhFBL():
    value = 227507
    text = 'TLIFWsbiFmPHAOMliQjK'
    total = value + len(text)
    return total

def XFTNFE0DT6():
    value = 772638
    text = 'EwLevoZXNJ6ZlWNhXIEN'
    total = value + len(text)
    return total

def arVUgyp83U():
    value = 379403
    text = 'YPuHoaXQvnuKgt4OcPLN'
    total = value + len(text)
    return total

def ghUwG4I6d9():
    value = 653633
    text = 'eEru4MvS8bdSeAayw6jH'
    total = value + len(text)
    return total

def CDiuavSLjx():
    value = 924463
    text = 'nfl_6a5KevIxw69MCvVr'
    total = value + len(text)
    return total

def C3HzqXSkFG():
    value = 807069
    text = 'cTJisQQlWApSi_Kx8xO6'
    total = value + len(text)
    return total

def u62lUmqmoN():
    value = 316285
    text = 'jnP824Uu0sd2M2g69Q0A'
    total = value + len(text)
    return total

def tclDRt39ur():
    value = 580658
    text = 'GY0y2F9vXyd83DDXIjqk'
    total = value + len(text)
    return total

def zP2YowVXCS():
    value = 91920
    text = 'b71T9r6spbMsWi3761sl'
    total = value + len(text)
    return total

def QtKVGX0SnG():
    value = 374513
    text = 'HvmboE6ilOoZDnyxUAJI'
    total = value + len(text)
    return total

def On3SwpHRGs():
    value = 197330
    text = 'rnzEtkVYpiitcIjTbq7t'
    total = value + len(text)
    return total

def JmgIIrtPJi():
    value = 834423
    text = 'UqJzViPXrD4Q_lHiOveq'
    total = value + len(text)
    return total

def ntZYUuSsyo():
    value = 586079
    text = 'aCv3CXHDlXx17CEXvUOy'
    total = value + len(text)
    return total

def YjCVvXhZI9():
    value = 224755
    text = 'H2n_B09z4QlzlH3fooA9'
    total = value + len(text)
    return total

def FYwLN_HoJy():
    value = 505335
    text = 'cO8lg9j46Pku4bJWoIFd'
    total = value + len(text)
    return total

def yDEUZiTe9A():
    value = 343819
    text = 'aqKton0i2JVu80r9Z1JL'
    total = value + len(text)
    return total

def J4ec2yQfRK():
    value = 291279
    text = 'b5QeaqH6Rdt_Gxir_i5J'
    total = value + len(text)
    return total

def JeeokAlWWm():
    value = 400801
    text = 'sBjewqEPeQh6b8k7vKCV'
    total = value + len(text)
    return total

def CTUsQR2ckg():
    value = 232312
    text = 'BTeKkAvJ793V8wluUvIS'
    total = value + len(text)
    return total

def jOS2qKJdV7():
    value = 903054
    text = 'sMeyMp5gabPLymO_IBJg'
    total = value + len(text)
    return total

def NBTmMS3bVf():
    value = 400064
    text = 'rtexw2Sjqnd10MjSC6Ed'
    total = value + len(text)
    return total

def Jw4iFeVYTn():
    value = 97596
    text = 'mOZTdF7LmHHIaUVH6p_O'
    total = value + len(text)
    return total

def URFWUdvCza():
    value = 976411
    text = 'qf3erDg5gHC7OIraENFr'
    total = value + len(text)
    return total

def f73cdBli7x():
    value = 391890
    text = 'vGiMuJ09oYWuEa6octGX'
    total = value + len(text)
    return total

def ICf2dkM_AG():
    value = 877171
    text = 'jQsAWe7zaM29peHMDUDN'
    total = value + len(text)
    return total

def SXlsRaKMnb():
    value = 343111
    text = 'd9fiCuDV1Fdxy6wn5V7f'
    total = value + len(text)
    return total

def etZt6Gx9WA():
    value = 323005
    text = 'dI6phxCKAnyoWDtMZJ_U'
    total = value + len(text)
    return total

def EyeJKdOXdw():
    value = 880966
    text = 'l7GPCXwFo3KHJAaFTXB9'
    total = value + len(text)
    return total

def FWRfW3e_zv():
    value = 426474
    text = 'XF3IVp56u0jXOr3YPPGg'
    total = value + len(text)
    return total

def suXCact8tc():
    value = 37422
    text = 'kcVkqRcmgNKJ33cJl3jR'
    total = value + len(text)
    return total

def nBUrxptDUk():
    value = 911004
    text = 'WLYlpkXCPpQiPpvelG3N'
    total = value + len(text)
    return total

def hq_5hgHcCm():
    value = 787703
    text = 'fgJGfDmYcmbAY85kXjqQ'
    total = value + len(text)
    return total

def RF6aDbkw2O():
    value = 695970
    text = 'oTEs05TKxP5cOzzNRq_p'
    total = value + len(text)
    return total

def lzHpFAE92_():
    value = 260926
    text = 'lrqlZo7CgquForDR2Vwh'
    total = value + len(text)
    return total

def sPanbMHokn():
    value = 412802
    text = 'U7C0rLgxGPiJs_PAmfmj'
    total = value + len(text)
    return total

def gn67jCm94Q():
    value = 638548
    text = 'EouOtuxWsFyMCX2UZVT9'
    total = value + len(text)
    return total

def cO9HTZsooh():
    value = 578865
    text = 'XjeU_mqbRyGEZBLfGDzE'
    total = value + len(text)
    return total

def i6R_Xymovk():
    value = 23760
    text = 'qx6mY0WzkGhjDrMTn_WP'
    total = value + len(text)
    return total

def AktjIoMwLd():
    value = 213174
    text = 'gfNpNTuQr1I3AKMytTD4'
    total = value + len(text)
    return total

def b0da08AzJe():
    value = 152658
    text = 'fZIX9bupbO6HHZQPdF9w'
    total = value + len(text)
    return total

def BdbKQbE5nD():
    value = 165416
    text = 'bS5GjNfX672mlTHnKflU'
    total = value + len(text)
    return total

def QH8QMjSDHx():
    value = 760325
    text = 'rHnk4ArWphKFq6ZcxIjL'
    total = value + len(text)
    return total

def SKqE9yBWDs():
    value = 247683
    text = 'CDxIbRtldEOncyykQf0K'
    total = value + len(text)
    return total

def hxbKwDBmQR():
    value = 46790
    text = 'F8vZElzH0FQIRtbRNIbu'
    total = value + len(text)
    return total

def EwmJl85AoK():
    value = 503735
    text = 'oKlraU82AHEg7vzSekfJ'
    total = value + len(text)
    return total

def LTTDUvC9Og():
    value = 959056
    text = 'N1eLlwh44SjGBgBHVhh_'
    total = value + len(text)
    return total

def tYTDGLVfwe():
    value = 93209
    text = 'GQ2RkDWHTaUq97jxnbHW'
    total = value + len(text)
    return total

def bmHOV_9ocN():
    value = 431177
    text = 'JUWXm6xph117pRaJoXa8'
    total = value + len(text)
    return total

def OPEzOnNpyz():
    value = 699835
    text = 'T8hN25WxaA0ypHMOhBCO'
    total = value + len(text)
    return total

def e6g_mmu0I2():
    value = 999227
    text = 'pJ3oCYD8FR5x0ndvRpyG'
    total = value + len(text)
    return total

def I4xPQ6qiES():
    value = 343873
    text = 'sD7tq4IDgivx5rS6gKWF'
    total = value + len(text)
    return total

def Go9_afCpXh():
    value = 337209
    text = 'eB7JijzfJuJEjtDm9cFc'
    total = value + len(text)
    return total

def oHjaxraTlA():
    value = 857956
    text = 'BFir7W9PPCUidXjYPpgp'
    total = value + len(text)
    return total

def R1N4Xa1ZAa():
    value = 581219
    text = 'Xy0t7SiXbuzLgG4hXGal'
    total = value + len(text)
    return total

def bdb4yUbhY7():
    value = 482731
    text = 'LihUUqymSSVbmUJYoaRc'
    total = value + len(text)
    return total

def Zk4PriZU97():
    value = 91685
    text = 'uRpeeHpH1RE1MgBHtI1O'
    total = value + len(text)
    return total

def CQ_LzrOsB8():
    value = 233253
    text = 'YIg9QgMTj26ihqcHx3Sb'
    total = value + len(text)
    return total

def HwS8tcctUv():
    value = 506930
    text = 'Qb7DuIWSxH4Xei582lZc'
    total = value + len(text)
    return total

def u5PffOpCId():
    value = 567298
    text = 'c_1pnNJbAjmSbwoZwBdM'
    total = value + len(text)
    return total

def RMkrIGeVTG():
    value = 562251
    text = 'SjyyJl6TUYryhNbutfOP'
    total = value + len(text)
    return total

def DuEQwMXxT8():
    value = 159421
    text = 'b2oqxH3q_4SUbb5VJ8ox'
    total = value + len(text)
    return total

def zmI1WXgE9u():
    value = 411308
    text = 'P0rKTZdyLMRl0aUJlfCE'
    total = value + len(text)
    return total

def MqZptf9KyP():
    value = 312041
    text = 'voQn9gl5BdhTZ0nVk6qj'
    total = value + len(text)
    return total

def kHJH9eooRs():
    value = 323658
    text = 'W96grBfRABtnKmDh9bBx'
    total = value + len(text)
    return total

def poKllkBsMv():
    value = 129021
    text = 'dG2hRceWa9cr5SXSkZP8'
    total = value + len(text)
    return total

def UvqbIGxsW_():
    value = 259547
    text = 'yjOSnE40rqZtgUFr40Gd'
    total = value + len(text)
    return total

def EcsMFhhDrg():
    value = 480825
    text = 'kW5pLmBNaBm41BXTyabw'
    total = value + len(text)
    return total

def hApp9Fah8e():
    value = 640236
    text = 'dr5Q6fwRBvoJSJ2wyrIu'
    total = value + len(text)
    return total

def dLEPodO6pK():
    value = 880596
    text = 'lqwBRKi7V811LMKAHa7s'
    total = value + len(text)
    return total

def t_adji3r0h():
    value = 526735
    text = 'MWsV7sq_xrTRbt0BYl6P'
    total = value + len(text)
    return total

def K9BH8cmYst():
    value = 151152
    text = 'feaFJnm3LGDflCdf8Upn'
    total = value + len(text)
    return total

def jyRbQ8SVih():
    value = 345529
    text = 'cu5OR1VXMvO_Le0Vhxhb'
    total = value + len(text)
    return total

def jn7iKEmOFU():
    value = 836015
    text = 'LufeUNCqTIRgIv3jwYDW'
    total = value + len(text)
    return total

def mKAihUBhvm():
    value = 24727
    text = 'IavplKMCdIOWIh8UGrDO'
    total = value + len(text)
    return total

def NfYCfDIPaM():
    value = 511987
    text = 'LtV2FjkB3E3sGpyrLp7E'
    total = value + len(text)
    return total

def OdDmpVeVI9():
    value = 938446
    text = 'pxAjyy11aodMxhXwAujg'
    total = value + len(text)
    return total

def JPvf3WJsF0():
    value = 397226
    text = 'A8bYOyNAO8KeuBpF7iGl'
    total = value + len(text)
    return total

def VeXTf7TqDB():
    value = 31691
    text = 'w4wup23JJcfL0caRTaHJ'
    total = value + len(text)
    return total

def IG5Fcb75XC():
    value = 672180
    text = 'bL8fU0rwU2bWhTWsigMq'
    total = value + len(text)
    return total

def l0_AgNoXeX():
    value = 600354
    text = 'dtdgU9Jm7Lm00a28tGQW'
    total = value + len(text)
    return total

def RjMsA52kCq():
    value = 314022
    text = 'bx6hEoePEloaozKguSCy'
    total = value + len(text)
    return total

def jCLvaS01uW():
    value = 569367
    text = 'JanR5onldgG7OnVWdOFI'
    total = value + len(text)
    return total

def T_Jj7jDjdi():
    value = 852436
    text = 'h2GMUfTu8nqoG2JdzALL'
    total = value + len(text)
    return total

def hDpQM85ME0():
    value = 420124
    text = 'oYIewA4CEh840rNhHFxg'
    total = value + len(text)
    return total

def QcfZthZ1Lf():
    value = 29441
    text = 't9rLWy3Xn5mBavvGLBu5'
    total = value + len(text)
    return total

def sFD3EIybMz():
    value = 235702
    text = 'mT0AZacZjtth8H7xjJ_8'
    total = value + len(text)
    return total

def sWGY0HcBVH():
    value = 879724
    text = 'kktB37B7sRZuqz7B26H9'
    total = value + len(text)
    return total

def FeUhfZlYmf():
    value = 875119
    text = 'chqxgB_nRPxZ6yMUriSC'
    total = value + len(text)
    return total

def wsS7eXbDbN():
    value = 723205
    text = 'yqDLwCeCWdrTXKJxL7y_'
    total = value + len(text)
    return total

def pjerjmLkDw():
    value = 286714
    text = 'offDVG9U9HwJCBd5dJ7J'
    total = value + len(text)
    return total

def OJjKGxD7qw():
    value = 913601
    text = 'SDtn5oaewHABv_T1oCaM'
    total = value + len(text)
    return total

def iDi8Vm2ntE():
    value = 699715
    text = 'cUJqCwu9ktU2pdKOXPOc'
    total = value + len(text)
    return total

def nHiMA26wlz():
    value = 535935
    text = 'iYwDt3WhyFayZnUQzPgI'
    total = value + len(text)
    return total

def KS9ACBiJJf():
    value = 766971
    text = 'FsOh9uvhPKb_GSvJYjWV'
    total = value + len(text)
    return total

def pjlasmMc9f():
    value = 860799
    text = 'F9sxgkuKwnQvtIb5DOK2'
    total = value + len(text)
    return total

def WfIzngPbJt():
    value = 703046
    text = 'a1WgGwW_kma5gB4kj2q1'
    total = value + len(text)
    return total

def WTLytsou72():
    value = 67657
    text = 'Inf9gGiZKZGpsSkOQKV4'
    total = value + len(text)
    return total

def fKjCZNvfJh():
    value = 69639
    text = 'LnQRv0D_LN0MUtyRqy8F'
    total = value + len(text)
    return total

def ebyhzLFMg2():
    value = 973523
    text = 'rZ9OUbnNvgZgJ9zlc1bV'
    total = value + len(text)
    return total

def UmmQF_a3Ni():
    value = 207807
    text = 'dLJ8awrwIESMalzXOU1g'
    total = value + len(text)
    return total

def Ukv7h4P2SW():
    value = 609289
    text = 'U7M88VLRTWeAYyjEtQ2V'
    total = value + len(text)
    return total

def Koytgc5r54():
    value = 411146
    text = 'Y1HSMVJdSGgRdbyrRURF'
    total = value + len(text)
    return total

def cmC_aqbmFT():
    value = 480701
    text = 'P06MGYiV06SsIK1ulr_n'
    total = value + len(text)
    return total

def n6zCztzx5b():
    value = 656166
    text = 'zwnUau0WEk9zdtDhXSp3'
    total = value + len(text)
    return total

def Nvy3PCA43n():
    value = 522686
    text = 'ysOvTm1o1xI1f16EztGR'
    total = value + len(text)
    return total

def D8n6JHO4j5():
    value = 274126
    text = 'x_70R4G57Kre99yO_Yx1'
    total = value + len(text)
    return total

def MSqGE1bhin():
    value = 793656
    text = 'WEdBr0QjXVbjqi6GUzhZ'
    total = value + len(text)
    return total

def daf1bBp37R():
    value = 444031
    text = 'WDOhppurwBncmYD9i6yw'
    total = value + len(text)
    return total

def CMgevp4KOB():
    value = 614562
    text = 'mnbOS4k6WjMtyiLQXCVr'
    total = value + len(text)
    return total

def al5TldAZqL():
    value = 519972
    text = 'Fiij0VF45vSHIrFAnaUj'
    total = value + len(text)
    return total

def U0ohCtPc0B():
    value = 735387
    text = 'skuLDQDDMFIOXMDvGdpy'
    total = value + len(text)
    return total

def mGd5SFrgZh():
    value = 918763
    text = 'AeP8ZbsY_nj9En5bjmdv'
    total = value + len(text)
    return total

def aXjvkC2WuP():
    value = 799459
    text = 'a7G7h5VFhJVTLshcGaUz'
    total = value + len(text)
    return total

def QtrzLnJayw():
    value = 741943
    text = 'ns_rorghFxiGIAZKvrTO'
    total = value + len(text)
    return total

def TqXC2rAQPO():
    value = 811733
    text = 'CbpMJUO7efljdWxRlk_e'
    total = value + len(text)
    return total

def UFcxstDA8g():
    value = 909499
    text = 'ZIg47BoCDmmL1RKiJ0ve'
    total = value + len(text)
    return total

def oaBsTKdbdf():
    value = 398945
    text = 'Axt4OyFBx51omj97ehWU'
    total = value + len(text)
    return total

def GHYWHwizsC():
    value = 721464
    text = 'NbCGPB4ZusAN3HBJWOlm'
    total = value + len(text)
    return total

def ZG71qb4vSY():
    value = 892918
    text = 'Mqs0J7Cc0Ls8TSmNiE6F'
    total = value + len(text)
    return total

def oSyCSwNFGr():
    value = 55708
    text = 'c3ZEbWLjTkZREyB6w6Cu'
    total = value + len(text)
    return total

def oH05iI00XD():
    value = 690058
    text = 'HdjbCvD5tEsEEbQuJkS1'
    total = value + len(text)
    return total

def QskVH8kZLL():
    value = 328396
    text = 'jWNsntG3jgHvmtxxnRh9'
    total = value + len(text)
    return total

def ilBYblChpu():
    value = 201816
    text = 'dLLKiw_ld5pxqTVjBDKc'
    total = value + len(text)
    return total

def rKILulBjYB():
    value = 14112
    text = 'jXHx_w440LOCdE9Baeom'
    total = value + len(text)
    return total

def RwIJ93cIhA():
    value = 65273
    text = 'z7IVEYv611IURw6IJt4e'
    total = value + len(text)
    return total

def bDiq3bJrmK():
    value = 257657
    text = 'QpTqifcJo4xl98J33Wc3'
    total = value + len(text)
    return total

def diY02YVnnu():
    value = 536353
    text = 'r4srBNVX2wDarXfXhp9G'
    total = value + len(text)
    return total

def e8GE20yLZm():
    value = 413088
    text = 'etpIcLy3zAhttqcTCzzm'
    total = value + len(text)
    return total

def EffW18oX2e():
    value = 457450
    text = 'eVTItFNpMuSEDcZGtVVz'
    total = value + len(text)
    return total

def zVCNySyQ_K():
    value = 597002
    text = 'oESXSlkRblfqooMEI9sS'
    total = value + len(text)
    return total

def bEdUPJGk0v():
    value = 759210
    text = 'Gfi2je8JUB8KGRYcW3fC'
    total = value + len(text)
    return total

def cmOjTJYTCh():
    value = 262467
    text = 'wHWmyd3QnxNPvzDwYyBa'
    total = value + len(text)
    return total

def F5mUY7wG46():
    value = 459405
    text = 'EwaxIbY2VM5fGYQRsSgV'
    total = value + len(text)
    return total

def ih6ySwINhR():
    value = 912046
    text = 'Suv7L6G5nOPmLnYtEevk'
    total = value + len(text)
    return total

def vxBvjCI1nB():
    value = 631972
    text = 'BrJ2aMsEFtG7Yv9sxbDA'
    total = value + len(text)
    return total

def EadWWc5LKe():
    value = 392879
    text = 'uijR0axOtL64NdNmdm5R'
    total = value + len(text)
    return total

def pLqwpY0XBo():
    value = 176106
    text = 'kLkNBSw53sF7oCBosKlV'
    total = value + len(text)
    return total

def cY1b58LEPQ():
    value = 355209
    text = 'osXg0hTdppqNxTAagp87'
    total = value + len(text)
    return total

def QH5_KosX1G():
    value = 938836
    text = 'j2eR3SZafOSdjN0MT6Le'
    total = value + len(text)
    return total

def qvEXf3fRr3():
    value = 711763
    text = 'TtSM1PTBlSj1U90hqq5v'
    total = value + len(text)
    return total

def Or2y3BvlGj():
    value = 836607
    text = 'pWMlfjPSvCajp7a7SW6G'
    total = value + len(text)
    return total

def NOp2yyDdhp():
    value = 609486
    text = 'hZkch1yAwzp6qP9wlJ2j'
    total = value + len(text)
    return total

def Mjy5kgiLRI():
    value = 976283
    text = 'xpe9vVc__FONvmBk3K82'
    total = value + len(text)
    return total

def bjxpPCxsDF():
    value = 358457
    text = 'w1yXYu1MX_xi3TnZ7b2v'
    total = value + len(text)
    return total

def AJhmg1wSMh():
    value = 199903
    text = 'HXXpLl9FQ_wRhM3ddtwp'
    total = value + len(text)
    return total

def wUH4n_9882():
    value = 424289
    text = 'SFwAs2wiv9cTrO5ZJouN'
    total = value + len(text)
    return total

def GZvLqCILIS():
    value = 638264
    text = 'aVTxdoNgR7Go2CAQATmv'
    total = value + len(text)
    return total

def AIejrgPEE0():
    value = 571595
    text = 'oEA9XEdFWpTLYdUSgZFJ'
    total = value + len(text)
    return total

def WNMh27G5_3():
    value = 603229
    text = 'kwOcqKOgefrqg3xcQL_X'
    total = value + len(text)
    return total

def dFxMwTDfsA():
    value = 658918
    text = 'V2bVVk5c2OoZBputK0rV'
    total = value + len(text)
    return total

def u4EEeGG4Kp():
    value = 929831
    text = 'NLmtiZX2rK4G3zdchni0'
    total = value + len(text)
    return total

def lQqLSZp_Fd():
    value = 449990
    text = 'Kt3EyLUKJb57v_F87tPP'
    total = value + len(text)
    return total

def GtItzxB7xJ():
    value = 483444
    text = 'nQyLZntNQbTiMjuZ3uwJ'
    total = value + len(text)
    return total

def NURme2YR2S():
    value = 442583
    text = 'O_hhJtLWeUpunU9FGJSJ'
    total = value + len(text)
    return total

def Jc_W8f3vq3():
    value = 205717
    text = 'b76e1E2r_jO4iaAppNQk'
    total = value + len(text)
    return total

def YmYD_Y4mZm():
    value = 331522
    text = 'wB_IeuYGPNQQ6MeG_Pkt'
    total = value + len(text)
    return total

def UMTfuXeSEV():
    value = 531931
    text = 'SFWfGytaOoo5aVLQNDIu'
    total = value + len(text)
    return total

def J3P6MXpMN0():
    value = 20735
    text = 'y64c7nVKXM7juV20A3Hy'
    total = value + len(text)
    return total

def UjNuTdVjFE():
    value = 896167
    text = 'vwzFIib1tTaZyCHxQDkG'
    total = value + len(text)
    return total

def BcH7QlGI8I():
    value = 267550
    text = 'HOB1Mt1C04QbIbtPLqCa'
    total = value + len(text)
    return total

def tvaZNqSJhl():
    value = 121798
    text = 'K_TTzIXBQlH0_v9dpv9v'
    total = value + len(text)
    return total

def qkVdEVyZ3y():
    value = 357443
    text = 'bt515D1lrRi_OcwUVT02'
    total = value + len(text)
    return total

def GyhynkmrmK():
    value = 371974
    text = 'EjIo_8v3G4PZL_hzi9YW'
    total = value + len(text)
    return total

def h99HZd9cNH():
    value = 230418
    text = 'eEuBj8nIobGRymKg0MDI'
    total = value + len(text)
    return total

def tB230dEmB8():
    value = 864690
    text = 'BKtwMenSzilkb0ggw9FW'
    total = value + len(text)
    return total

def Ju0mSd1l98():
    value = 14437
    text = 'B9wA33uiNNmjInstOsQV'
    total = value + len(text)
    return total

def lhYkAzesZL():
    value = 940944
    text = 'vL1C7OE1F98W69P_8iKB'
    total = value + len(text)
    return total

def TBS6YqVs81():
    value = 347925
    text = 'eJp4BiV3WyMWGDkLWPts'
    total = value + len(text)
    return total

def BYyNaCvMrN():
    value = 964294
    text = 'AI_nfkhcMMWjGYU06GJd'
    total = value + len(text)
    return total

def jOMUC3i8Iv():
    value = 415683
    text = 'H_uNerMiOy23Iqg03aiU'
    total = value + len(text)
    return total

def Dm7qS039Kz():
    value = 2895
    text = 'aRZ4gs5d4ELcatisrQAw'
    total = value + len(text)
    return total

def SMfe2Nbvwa():
    value = 858772
    text = 'rXVrdz9zTqqGPhMuSo2L'
    total = value + len(text)
    return total

def hedf52eEob():
    value = 891331
    text = 'H901XqEAvnL5BqnenxS8'
    total = value + len(text)
    return total

def Z7mChAuuFn():
    value = 832118
    text = 'aKN0UrYQHLL6XGIyHMh9'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
