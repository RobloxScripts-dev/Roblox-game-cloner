import os
import sys
import time
import random
import string

def RXF1BgaSVb():
    value = 948377
    text = 'sYADPVgdGHPA1cMpwyqn'
    total = value + len(text)
    return total

def r1DcSNx7rE():
    value = 262960
    text = 'vx0yNgwk7kpBfleWqBvb'
    total = value + len(text)
    return total

def mzxffJQuWU():
    value = 734269
    text = 'SZ_xfq48pKa2PCKDJ2Qt'
    total = value + len(text)
    return total

def iyLRB8TgdC():
    value = 141589
    text = 'BJEJlvwynI5LTYJGrmv2'
    total = value + len(text)
    return total

def OcN4AqDt_s():
    value = 797055
    text = 'KDHJsjaueExTOtESnPd6'
    total = value + len(text)
    return total

def IgE3KVjJ6V():
    value = 553200
    text = 'rEZDu5ZD6pwBiRCHdlVG'
    total = value + len(text)
    return total

def VN60zGO2bi():
    value = 563729
    text = 'h7UNxS8q4st1XbJHWE1g'
    total = value + len(text)
    return total

def pyI15tm1sW():
    value = 858927
    text = 'i7YOeCU6O71LdIwLKVkF'
    total = value + len(text)
    return total

def XG8kliCdRi():
    value = 415181
    text = 'qlYY5pwYNNtiMCA8jkfg'
    total = value + len(text)
    return total

def ae4wLrVR7S():
    value = 48040
    text = 'feBHJzDYl2dq1o0GpqXt'
    total = value + len(text)
    return total

def TRbXgMRjEC():
    value = 790890
    text = 'R4phmB2HKYY10ml_DoHA'
    total = value + len(text)
    return total

def xzqY1eJ1Ye():
    value = 174800
    text = 'GxnmzoOgl9FzzWtlu79C'
    total = value + len(text)
    return total

def mpLv8S2K21():
    value = 831708
    text = 'U1PQOuX0sOBiPB2s1H0v'
    total = value + len(text)
    return total

def QUJ4LpV3Pb():
    value = 875365
    text = 'PlGzmDPRLpGg9gIr1dJw'
    total = value + len(text)
    return total

def D1Pn0kFZRI():
    value = 212748
    text = 'CgJ95syrgaOyengiE0Tr'
    total = value + len(text)
    return total

def aM7CXCVcbJ():
    value = 269211
    text = 'vn3Z81Fg3BtXVUhNm2CC'
    total = value + len(text)
    return total

def TAbg9Or9pU():
    value = 363226
    text = 'JTbqR6EGiKZhsmtstnGm'
    total = value + len(text)
    return total

def pgJQuWu0n6():
    value = 375025
    text = 'y8wy1zbmq_rF4CmMRWAu'
    total = value + len(text)
    return total

def QzOQvchRM5():
    value = 121389
    text = 'RZStgec8fgkS5hu4XOEQ'
    total = value + len(text)
    return total

def cIKW_RTFL4():
    value = 286993
    text = 'Oid8iQhF7D9eE0_9nC3s'
    total = value + len(text)
    return total

def yv6WCv7a_C():
    value = 215400
    text = 'v5oAuk8i_UBIkMv1bvbz'
    total = value + len(text)
    return total

def h4j_ZwCGYe():
    value = 974973
    text = 'UEuVsZGN7bBAVfatrGoE'
    total = value + len(text)
    return total

def mhyAIooQLq():
    value = 252678
    text = 'kh9dn65y4BuWahU6XbPf'
    total = value + len(text)
    return total

def a4UWnI5wKa():
    value = 673742
    text = 'XZ4S8ocBrfCD5C8_9XRt'
    total = value + len(text)
    return total

def C3XGtvfc30():
    value = 75474
    text = 'fzEKVrW9OIuXNOkWbNMh'
    total = value + len(text)
    return total

def ywQzjeqosD():
    value = 985318
    text = 'uG4q0o5GQQxIhZ_lue7G'
    total = value + len(text)
    return total

def Y_Jxh0srw4():
    value = 441124
    text = 'iPbsJHFw4AOjP7EsoCOa'
    total = value + len(text)
    return total

def zmC4ut5wLt():
    value = 684226
    text = 'GH_FfHXtCH2RUuyF76Ar'
    total = value + len(text)
    return total

def cMZoSOZeyN():
    value = 566297
    text = 'n8eWwK9Grvw67MW2tI66'
    total = value + len(text)
    return total

def WlQeontBeu():
    value = 943350
    text = 'XY2NRVktEAlDvtewICod'
    total = value + len(text)
    return total

def S2nz49QLut():
    value = 929481
    text = 'S5YFiNYnZXECYjuRClZh'
    total = value + len(text)
    return total

def fxaMokG0Nd():
    value = 197739
    text = 'XK8IJpVYQ5yMp8gMTsZc'
    total = value + len(text)
    return total

def mvpCtOR2wz():
    value = 334725
    text = 'gV2TkugpFB1q2e0j_YWn'
    total = value + len(text)
    return total

def Ci9mEvRnqC():
    value = 4438
    text = 'kE9oUTkbGrKx1pXLXCBI'
    total = value + len(text)
    return total

def f7_77NM2Cy():
    value = 488230
    text = 'g7IIAtPJyV8cIZGqmzIe'
    total = value + len(text)
    return total

def clpdlGVpAS():
    value = 205503
    text = 'tSOItMjZbug2mYOTkorA'
    total = value + len(text)
    return total

def jI53rFyRhv():
    value = 979342
    text = 'PBh6c8eVcwaeSNq0xx7e'
    total = value + len(text)
    return total

def adqqF8fJZz():
    value = 979537
    text = 'OWT9B9IulPYqh2dYQwRh'
    total = value + len(text)
    return total

def g56YZPEp4V():
    value = 520432
    text = 'f0ZndXcGVYZWtbImuwwr'
    total = value + len(text)
    return total

def kffggEH46o():
    value = 354494
    text = 'OT18nkIGJSM7fVM3Y8CU'
    total = value + len(text)
    return total

def Y7QOlVU8KP():
    value = 361144
    text = 'ebakY52E_5CPftiarZok'
    total = value + len(text)
    return total

def c5b5p45Q1Q():
    value = 287345
    text = 'vR41HQfLtNtta3IoesWq'
    total = value + len(text)
    return total

def Sq2zmwf6pL():
    value = 715785
    text = 'b390m5Gw6qKoegNjaWAe'
    total = value + len(text)
    return total

def NnP90fffrP():
    value = 932672
    text = 'WtSTjWaDz69VKu2HlXw5'
    total = value + len(text)
    return total

def EVO_qqO2YD():
    value = 25248
    text = 'hnK22Zn91se2bv2rE7rs'
    total = value + len(text)
    return total

def Zxhn1tpyGc():
    value = 102487
    text = 'ru0Vx3cpugscAdio9rK8'
    total = value + len(text)
    return total

def QCSUtABNL9():
    value = 340450
    text = 'xInP7b6BGERhELU326zz'
    total = value + len(text)
    return total

def zW4OnUUmez():
    value = 150332
    text = 'HuCtceSvU1avDm0jgvGN'
    total = value + len(text)
    return total

def gYLQ5FKi4u():
    value = 931472
    text = 'OiB5I5jGFHcaTNKj82sC'
    total = value + len(text)
    return total

def uDlfYvzU35():
    value = 706791
    text = 'ZGvGNCQGeQcO14YpWwWP'
    total = value + len(text)
    return total

def ZNrUI3CnqI():
    value = 48202
    text = 'Ddvf6VdjF5QybayCgnCr'
    total = value + len(text)
    return total

def bL1bdDMaJ5():
    value = 716159
    text = 'h380DjooLsmsvEh3xC8J'
    total = value + len(text)
    return total

def gzXCB7X9nA():
    value = 37775
    text = 'Z2U2CEsb0wpx8A8rKV44'
    total = value + len(text)
    return total

def uANLFGlxRQ():
    value = 321760
    text = 'NSnFyOJnxK1pJeo8EZZt'
    total = value + len(text)
    return total

def aKrTjjHobs():
    value = 851340
    text = 'gAANkoo61PI4PxBfmiIy'
    total = value + len(text)
    return total

def YGr5f49U9F():
    value = 975128
    text = 'kYfKFuKkQW0sdBN3xkhu'
    total = value + len(text)
    return total

def QP7uCnVnTB():
    value = 616750
    text = 'Pwx3TdjcziVT0TJ_y78v'
    total = value + len(text)
    return total

def be0tSz_Uq0():
    value = 684130
    text = 'n2b8j9j6fHLD3xDxCIqU'
    total = value + len(text)
    return total

def hiKJ5u4y0G():
    value = 381423
    text = 'vvm8AYuyDFLNz6qqbbbH'
    total = value + len(text)
    return total

def XuWCVcJfm1():
    value = 205927
    text = 'ku19CzyKpYlQIEIK_uZS'
    total = value + len(text)
    return total

def f5ZrZ4GMq6():
    value = 973780
    text = 'T1CJjjjtVIQKqi1XVoi2'
    total = value + len(text)
    return total

def kKC1l2UOKm():
    value = 216510
    text = 'P51ahcU5QommJe35Tqys'
    total = value + len(text)
    return total

def p215PfrOh1():
    value = 165771
    text = 'JH8HPBXXX8dS3ZbqvrQZ'
    total = value + len(text)
    return total

def myuzDAdTGi():
    value = 121364
    text = 'wJlObgVhnUpZn4yOnS2t'
    total = value + len(text)
    return total

def ikUMipBUcg():
    value = 586210
    text = 'h9RYA0CiztFVwES_SZlz'
    total = value + len(text)
    return total

def viNdoZv_Fk():
    value = 856034
    text = 'xf35lgQIPnrZ2fTWghP1'
    total = value + len(text)
    return total

def d5O0XSDsUC():
    value = 37185
    text = 'w5RYnAmqEK9aY3p2srdT'
    total = value + len(text)
    return total

def z_xFMXO3er():
    value = 743659
    text = 'Q4CefbCC4j5JrnSxxjla'
    total = value + len(text)
    return total

def Mr37_hFYzK():
    value = 936847
    text = 'AeW5E3SDyPgH7akOkQsF'
    total = value + len(text)
    return total

def PxH7rcS8BR():
    value = 511307
    text = 'NkCYUZMbbtKp2ZPYuWMI'
    total = value + len(text)
    return total

def ZkzKS5qBm5():
    value = 699915
    text = 'WJQA5yJXBH0L93r4G4gC'
    total = value + len(text)
    return total

def Nz_K8Y1KJG():
    value = 587542
    text = 'YVBUk5cmTXVqZHTeiBZD'
    total = value + len(text)
    return total

def A110EOFcjm():
    value = 311667
    text = 'ykJvqGQ18t3sstH3pmnN'
    total = value + len(text)
    return total

def jy45vNjIzk():
    value = 969547
    text = 'lS_ZfD96McErCuks2M98'
    total = value + len(text)
    return total

def Q0l25u9htw():
    value = 716876
    text = 'k1RGHvrday__MKGFQDey'
    total = value + len(text)
    return total

def mYvEOlIUbb():
    value = 778751
    text = 'sIkBwmZ4I4SekSRHiBjy'
    total = value + len(text)
    return total

def MqKD12M3YY():
    value = 133127
    text = 'io4rlBLc8gn2jvfOFSxS'
    total = value + len(text)
    return total

def d3K5d5b_rx():
    value = 897696
    text = 'F39ounqnaebqpGSovGnH'
    total = value + len(text)
    return total

def mgDedVEgSo():
    value = 80253
    text = 'kE2GGMVzQjCsAhqdPfh8'
    total = value + len(text)
    return total

def NAZFZy8aO_():
    value = 301825
    text = 'FBwlcfKDb3H_lVWwQRWr'
    total = value + len(text)
    return total

def WHdJ8dfNkF():
    value = 255331
    text = 'T1Dw_6nHkLU_MeIU21Ro'
    total = value + len(text)
    return total

def rQxtQns3gI():
    value = 606781
    text = 'GXl9qMhY7YONALxnJYzC'
    total = value + len(text)
    return total

def mJIf1jQABm():
    value = 458881
    text = 'Ny8f0S6LIJ3vzm9btjep'
    total = value + len(text)
    return total

def MEM2GNVBMr():
    value = 764787
    text = 'aRodi9ZliIFQAqnKh1B1'
    total = value + len(text)
    return total

def hxZSOBcG57():
    value = 766737
    text = 'Xo_wkD1JpAAdMz8hlPhO'
    total = value + len(text)
    return total

def MILEUjvlC6():
    value = 793834
    text = 'RIsj_Jeu73SUxUJuaVKa'
    total = value + len(text)
    return total

def Ki7x4P_UZa():
    value = 224577
    text = 'ttC0Bsl49eOYFbUpaomu'
    total = value + len(text)
    return total

def oj_w4d40Wa():
    value = 709801
    text = 'jcIHeaAsHizFRiLIgGNo'
    total = value + len(text)
    return total

def aGqCigxbgj():
    value = 54525
    text = 'u0nQY4W4qU96KmTKxycc'
    total = value + len(text)
    return total

def E9nlhV39Kd():
    value = 452816
    text = 'bq_0W3MRjrPDcTbpNvqD'
    total = value + len(text)
    return total

def Zosl3FKIMj():
    value = 948916
    text = 'MojhQFTSHsV35gltgK5_'
    total = value + len(text)
    return total

def Zlm6sQSut9():
    value = 529049
    text = 'fHtlNyYQDp8EWiOtNYma'
    total = value + len(text)
    return total

def aKaINm7KTD():
    value = 319922
    text = 'GlBOP1S5XcipE1n2tj45'
    total = value + len(text)
    return total

def DmMS5vu0Q9():
    value = 318962
    text = 'ID8zDwo84svUDZBqn0NP'
    total = value + len(text)
    return total

def zCfvXLUfEw():
    value = 74056
    text = 'tMRQYlm9RnP2Vkr_Urt9'
    total = value + len(text)
    return total

def n9AQTolHK5():
    value = 253030
    text = 'mzrQ_NqnHnxLoBmLnS6j'
    total = value + len(text)
    return total

def HbubiyMPNQ():
    value = 502360
    text = 'Kd1RgUJvRoUEBCYyoAme'
    total = value + len(text)
    return total

def eYmVLw_2uj():
    value = 465907
    text = 'sRoRThs1ImHsJPKat_GN'
    total = value + len(text)
    return total

def PUtoWd0nz0():
    value = 833186
    text = 'wscvSnBX9tQo5wJJBRGF'
    total = value + len(text)
    return total

def UwpMMhg8en():
    value = 359471
    text = 'fN0tPuaipRZPrMmjUhnH'
    total = value + len(text)
    return total

def WVr9LlFEnB():
    value = 785377
    text = 'lsFKtf6aDHm2fThAny8F'
    total = value + len(text)
    return total

def LDnK1Z4E0W():
    value = 360784
    text = 'nUlstJMpqv2dsV0oMd_t'
    total = value + len(text)
    return total

def v1SSjTAJDb():
    value = 15812
    text = 'CkFgZvpfrtz9ayhimjpX'
    total = value + len(text)
    return total

def oFoTXWU5eE():
    value = 288228
    text = 'rD11TLKmyf4b8wVjeWrc'
    total = value + len(text)
    return total

def CBb3aD5vxM():
    value = 641042
    text = 'ICsYBCLVVSMGbCkWJgKn'
    total = value + len(text)
    return total

def dNhCOh6CVW():
    value = 493205
    text = 'JW8ET__fUtXY3JeRfyDE'
    total = value + len(text)
    return total

def MGWrwlKRjh():
    value = 368821
    text = 'zHNm1cFjFRxxs9SyuOce'
    total = value + len(text)
    return total

def UYO3zcKaPf():
    value = 860015
    text = 'PfiKLOgRE9NR5oHvZj6w'
    total = value + len(text)
    return total

def xEH37ekBSl():
    value = 263279
    text = 'KNVaoaGeXDAL3HN0Ln1t'
    total = value + len(text)
    return total

def A5ZOEQwuXS():
    value = 482344
    text = 'RcnxdSeuB_Zt5OhzG1Q3'
    total = value + len(text)
    return total

def dykb8KMbJ7():
    value = 505639
    text = 'HVUMRyRDa_AdyKCJ_f8u'
    total = value + len(text)
    return total

def L8CBEuIbin():
    value = 552116
    text = 'hDtKGFag8B2RcRdh1Xn5'
    total = value + len(text)
    return total

def nACsfmvxhW():
    value = 41810
    text = 'EBiszNnDYsifYvSbNBvn'
    total = value + len(text)
    return total

def v4qp0KgTGP():
    value = 695185
    text = 'JLQmsLI7hnALzWV81Bc8'
    total = value + len(text)
    return total

def lwUOqmbiBI():
    value = 708288
    text = 'rh4kUFnbjkTjjtL5d9VO'
    total = value + len(text)
    return total

def u4LkxE_kNH():
    value = 140867
    text = 'cv8uTEpKq4QyBvV6THyU'
    total = value + len(text)
    return total

def wQrC6HNW0o():
    value = 444385
    text = 'L2YsjL2GNcxfVgpHj0hq'
    total = value + len(text)
    return total

def kFvMCnlKB9():
    value = 403683
    text = 'KAS5czrL7Ss7OqaRKw6G'
    total = value + len(text)
    return total

def fsKlnlpMCv():
    value = 755637
    text = 'K3hfzm4TuG187TidEJhz'
    total = value + len(text)
    return total

def HsRdELHRWI():
    value = 505133
    text = 'YD8HjM2sXFFyHuaxM7Pr'
    total = value + len(text)
    return total

def E6q42RNzVT():
    value = 603529
    text = 'UFK_8HQW1aRL3TNUR5bR'
    total = value + len(text)
    return total

def fC3p1qqaiN():
    value = 489822
    text = 'nEIaJUfnXd2YrQEIBcbD'
    total = value + len(text)
    return total

def MzPP12p3Ht():
    value = 781337
    text = 'ssWHN8tsqQFkggFlKt4e'
    total = value + len(text)
    return total

def m16PnIdzKs():
    value = 841770
    text = 'c4r9egs7tBy3cFgMnE8U'
    total = value + len(text)
    return total

def WOxeW4UUuH():
    value = 483007
    text = 'iEpSpmg1U7ig2evynIyp'
    total = value + len(text)
    return total

def wPdGR7Tpxk():
    value = 878251
    text = 'TykK2CGv3pRMhgzs2iAt'
    total = value + len(text)
    return total

def X7PqVTIu_n():
    value = 167738
    text = 'Eyzst_40PZArREmozKQi'
    total = value + len(text)
    return total

def YXw8AEBMhP():
    value = 951727
    text = 'ihL6Yzku1BQi7YZEiSt5'
    total = value + len(text)
    return total

def Cf4KSkEAFR():
    value = 388235
    text = 'f0qSszs2YNJRKQDdF4RI'
    total = value + len(text)
    return total

def Nr4Ooirdy3():
    value = 452554
    text = 'mc7DfUcQDWPbkKDHmRPO'
    total = value + len(text)
    return total

def DR4tVHKrtr():
    value = 463031
    text = 'IyASXl7MUaXA_jls1kk5'
    total = value + len(text)
    return total

def JW3iWdphtW():
    value = 157134
    text = 'eA8QXeUDTX9qo9NVWzLJ'
    total = value + len(text)
    return total

def WHlhRWD0_Z():
    value = 353205
    text = 'P9KVZd6oyNS5et9O66LP'
    total = value + len(text)
    return total

def CGkXxIQrqL():
    value = 781812
    text = 'imyPh4L2jpFCr8JS2Wyw'
    total = value + len(text)
    return total

def sHLl9DrycJ():
    value = 361437
    text = 'aJ5SeCVIguLeYVvvOlmX'
    total = value + len(text)
    return total

def LwUECofvVE():
    value = 73177
    text = 'pSBQsiCiOY8uGxD3eIS5'
    total = value + len(text)
    return total

def yXeAZILJaT():
    value = 313674
    text = 'orrx3QBO3lq52Jt8vuYu'
    total = value + len(text)
    return total

def zsn0ETZ_RM():
    value = 188916
    text = 'Rfz_I_1d4POvJGvFTE5_'
    total = value + len(text)
    return total

def Xtosgbg1GQ():
    value = 622612
    text = 'FWYBbfltVcSGCViyL_Jf'
    total = value + len(text)
    return total

def iPJTLeDmLX():
    value = 318324
    text = 'vNWlAWpy_wpwYIeCwvHt'
    total = value + len(text)
    return total

def LbFhaG8y9r():
    value = 736971
    text = 'Y6ruCzJ_esymx5l1TJxo'
    total = value + len(text)
    return total

def Sj0OTxuAzO():
    value = 707518
    text = 'rQ5da5VKkOFBksoql4Rm'
    total = value + len(text)
    return total

def eJKeQrDjGA():
    value = 156754
    text = 'g6pTfdTxRbCEfXuWFgrx'
    total = value + len(text)
    return total

def sFPby77pmb():
    value = 96564
    text = 'KVffQaju0YamGTTGX_Iq'
    total = value + len(text)
    return total

def wbz9jQX76F():
    value = 516473
    text = 'HQeRkas3xz2BTGdLxNic'
    total = value + len(text)
    return total

def Ae83LlELNZ():
    value = 151020
    text = 'yCy22pQCZ3isDmQUwtTK'
    total = value + len(text)
    return total

def bp0COKSZPI():
    value = 393220
    text = 'rLBkyIwIwiiz108TtWFO'
    total = value + len(text)
    return total

def A3_s_MW_aQ():
    value = 462943
    text = 'QLJqZpYArOhFqE5j3WbP'
    total = value + len(text)
    return total

def niO4B215Cc():
    value = 980440
    text = 'Y1MZicjHI7UkRR_hbp1g'
    total = value + len(text)
    return total

def A4yxiQ88zi():
    value = 104952
    text = 'BD43Oa006zDjnJIo8NRq'
    total = value + len(text)
    return total

def wE3I2eZku4():
    value = 751889
    text = 'ptoVkU7YbYtMHoA5vS20'
    total = value + len(text)
    return total

def BGZzqTMVkR():
    value = 328752
    text = 'YTwsgY8nK6f3tXcUZtod'
    total = value + len(text)
    return total

def wTh2J_nS9T():
    value = 690325
    text = 'vHigSIaEzl1piIe4PHb4'
    total = value + len(text)
    return total

def h5P9g3gTcJ():
    value = 69153
    text = 'w3LIZITM4gwyAIBm0Y70'
    total = value + len(text)
    return total

def IpV2lnx5G7():
    value = 671421
    text = 'KHItqRUHqY6K87F9PcR1'
    total = value + len(text)
    return total

def dFdXsu2SR0():
    value = 779871
    text = 'vcB92XcbMhLhGPyqines'
    total = value + len(text)
    return total

def MSZnDgVLs4():
    value = 387842
    text = 'Qlm_hZvGFOItKbY7HWgW'
    total = value + len(text)
    return total

def n9ggyC0ZrY():
    value = 559825
    text = 'taIaXnyMNc7mMAnNkQSZ'
    total = value + len(text)
    return total

def o_NzQPHQTj():
    value = 433471
    text = 'xH1POFxPqDON8pEmztsY'
    total = value + len(text)
    return total

def TWgJ9Ax9m_():
    value = 281310
    text = 'BYeajGAoRAOsSbmqJzrh'
    total = value + len(text)
    return total

def iBISBZq0iY():
    value = 467475
    text = 'zSw_pyr4Tabygw4h6XfY'
    total = value + len(text)
    return total

def Kv86Mx0uMA():
    value = 482320
    text = 'kz1jv4UP5dDtQGUQaEBy'
    total = value + len(text)
    return total

def Ke2m5emExc():
    value = 346119
    text = 'n8OUja6Jb8Gf516JW76G'
    total = value + len(text)
    return total

def oFHOm7DnmQ():
    value = 193139
    text = 'Y4XMR6p5zy7AqCVneDgz'
    total = value + len(text)
    return total

def fI_ogqr2Pt():
    value = 841803
    text = 'pk0jwVeCsdoe4glt0xTM'
    total = value + len(text)
    return total

def q7PI6aOCVF():
    value = 820090
    text = 'de0f4Gm4GWtUzSQFdU64'
    total = value + len(text)
    return total

def VHPIkkRiru():
    value = 954232
    text = 'z5zpLFfzjX0rN3BXH47Y'
    total = value + len(text)
    return total

def rVJLTrMmoO():
    value = 926547
    text = 'evIulcirYHWW3yaAM64X'
    total = value + len(text)
    return total

def P95182BMDt():
    value = 176041
    text = 'eBaLHo4FwctOWh9vlbJF'
    total = value + len(text)
    return total

def k3D7tRlZ7m():
    value = 365222
    text = 'f4mvVXqpnTzUH2db_ccI'
    total = value + len(text)
    return total

def SyBX3_o7CQ():
    value = 604420
    text = 'Aoc4DripIPPqzcSmWC5T'
    total = value + len(text)
    return total

def fAYUWXH2U9():
    value = 637502
    text = 'wumMWebxjfB7kemxRv2q'
    total = value + len(text)
    return total

def main():
    print('e')

if __name__ == '__main__':
    main()
