import os
import sys
import time
import random
import string

def yGBjotI4JM():
    value = 598669
    text = 'SH8zfPWrgth0MYhJYAIe'
    total = value + len(text)
    return total

def JvB5A6J1Kx():
    value = 874897
    text = 'cJpw7PA7dzwMFqCgjd9h'
    total = value + len(text)
    return total

def nZCJGW8n5v():
    value = 384335
    text = 'mj5b_Ut9bI6NffuhLcsT'
    total = value + len(text)
    return total

def j2dW3rvGBA():
    value = 901998
    text = 'kz2j4t4N4q8ve0ExDLbY'
    total = value + len(text)
    return total

def wfzD_e9tb1():
    value = 416072
    text = 'bKnZwyyvBirT1QvNxDMT'
    total = value + len(text)
    return total

def s2cJO9LxmU():
    value = 292177
    text = 'o4PZB5DJJXU9DcS0alJN'
    total = value + len(text)
    return total

def h6Os156A3c():
    value = 221003
    text = 'KEvdnq3wc_QmIKanXCuk'
    total = value + len(text)
    return total

def mEuHxo8kIQ():
    value = 987963
    text = 'HGdRiIFq5itdQagAM0q0'
    total = value + len(text)
    return total

def zAf4nv0Odr():
    value = 378746
    text = 'exMfTJO0hcwgcj6hNXBh'
    total = value + len(text)
    return total

def u3n3v9wZP6():
    value = 975987
    text = 'DKcghCmsugF03g0FdXCw'
    total = value + len(text)
    return total

def TXul0Owwyy():
    value = 968742
    text = 'noiliCnU0ASlFyc79QMV'
    total = value + len(text)
    return total

def EoYa9quP2M():
    value = 189223
    text = 'AHzQL6NTVt2jcAaVkZsV'
    total = value + len(text)
    return total

def rxoGCwSzDC():
    value = 274721
    text = 'e54r_s0hy8zvjCYW7Qb5'
    total = value + len(text)
    return total

def FXsr9LfwcN():
    value = 698227
    text = 'ptRsuuEF6PUMYBQmpjI8'
    total = value + len(text)
    return total

def knrApm86J1():
    value = 908220
    text = 'mazQY_ZSBZP0U9n57K9L'
    total = value + len(text)
    return total

def DEO7eKoly3():
    value = 391566
    text = 'Nj1Clz8SUktBhLVILSYw'
    total = value + len(text)
    return total

def S6Qmms1WT4():
    value = 674679
    text = 'xIwdeLv56X4HS6IcRP0S'
    total = value + len(text)
    return total

def PBqmvQoHv8():
    value = 514223
    text = 'HTnKD_6oNWWMV0HmDDWv'
    total = value + len(text)
    return total

def K7q2J9x0rG():
    value = 279171
    text = 'w30HyFtBZUs0P9cx_8I0'
    total = value + len(text)
    return total

def OpC45vdKPQ():
    value = 667632
    text = 'oa55eJEOaMt2vNl1PEEM'
    total = value + len(text)
    return total

def odCHcx3wZY():
    value = 512883
    text = 'THno5dyqdQScUvYOGQss'
    total = value + len(text)
    return total

def Gp8F7us7vd():
    value = 220054
    text = 'aK9UYPxJcjIR2bA9ouEQ'
    total = value + len(text)
    return total

def pba6g3k_nw():
    value = 218619
    text = 'xSYAcW8GY2DaVehwlChv'
    total = value + len(text)
    return total

def BA97bs3pVw():
    value = 178177
    text = 'ErVh8h51AUMFJPupFZ5b'
    total = value + len(text)
    return total

def xUDBbjcdnH():
    value = 209697
    text = 'U1IwuI2UejqqogOZYi7W'
    total = value + len(text)
    return total

def XxA6a6bXKO():
    value = 29629
    text = 'l7t9R19m4XLHx9b_6k0K'
    total = value + len(text)
    return total

def vRgzcZLS8M():
    value = 889435
    text = 'GGq4PyWr3nUGJ62f_nrJ'
    total = value + len(text)
    return total

def BdtodqmUyQ():
    value = 443498
    text = 'Dm46GdSbnhTGKl8thxvU'
    total = value + len(text)
    return total

def Ti3zYV1o_9():
    value = 301256
    text = 'QeBMv4tsP8XgL1LiJEZC'
    total = value + len(text)
    return total

def p0exmLFe3x():
    value = 613987
    text = 'PbNZ_esu2zz2cODGH9yd'
    total = value + len(text)
    return total

def ebKvELOC9L():
    value = 28053
    text = 'xUen78RLtIRqOk_7RwvM'
    total = value + len(text)
    return total

def WXsBcQhLy7():
    value = 760445
    text = 'PEjLTEAms4yECd_M3Foh'
    total = value + len(text)
    return total

def qgYRJ82xWp():
    value = 711736
    text = 'GVghL57JMttuaTgsFUKS'
    total = value + len(text)
    return total

def IJ7NI5dp_u():
    value = 485751
    text = 'N16KbWL6GKqSCO14A5kf'
    total = value + len(text)
    return total

def cg53g1Cnb2():
    value = 979168
    text = 'MHYbBBZ_wAjCGJT9PSAr'
    total = value + len(text)
    return total

def sL4SvCrrfv():
    value = 367416
    text = 'NS4k4eavCU2zh4DmAwa9'
    total = value + len(text)
    return total

def JMQnsYAact():
    value = 352068
    text = 'PKeHpMtzeFSamXfVqZxh'
    total = value + len(text)
    return total

def yz6LlFyHpN():
    value = 443349
    text = 'j1sM3EW7iZtcDddAR122'
    total = value + len(text)
    return total

def fydmRjwls7():
    value = 697061
    text = 'Vtl0WaiA_l0ejrZd6XSo'
    total = value + len(text)
    return total

def nK8zCpPyPK():
    value = 678374
    text = 'd90vCGXbDa7FcRlTCsUe'
    total = value + len(text)
    return total

def Ykos3EWlZh():
    value = 894308
    text = 'gwcJUetNhdai_11RywyL'
    total = value + len(text)
    return total

def UocoGa8xLZ():
    value = 123951
    text = 'hvB_v7sMuvryi28nc8JD'
    total = value + len(text)
    return total

def AZSebvuNsv():
    value = 251865
    text = 'yCx7inBZPy8OraMBrL94'
    total = value + len(text)
    return total

def beQcIDLZsY():
    value = 514551
    text = 'ODpZwcCkl8OQn5BkRsZn'
    total = value + len(text)
    return total

def ufCkD002Md():
    value = 558725
    text = 'PpW6CJ2TJ5qKSYM0QkPk'
    total = value + len(text)
    return total

def BQqOc_jxxP():
    value = 710556
    text = 'X1MoJtXK5NlU5Sw01vfh'
    total = value + len(text)
    return total

def HlQ1b0b3Ty():
    value = 517094
    text = 'tzX8R6cNnsOkFLG_yO16'
    total = value + len(text)
    return total

def VAfjH5fD3a():
    value = 842731
    text = 'Qf2tPNCqy0UVi42Grv3a'
    total = value + len(text)
    return total

def ItRUsvV8zm():
    value = 799343
    text = 'mslMmCiC_EbCbp1zdoJO'
    total = value + len(text)
    return total

def wqVWTmleed():
    value = 642453
    text = 't5hrEBBWBZt4M0NxGS6c'
    total = value + len(text)
    return total

def N4cwVnKj7u():
    value = 200443
    text = 'GLFsZO63nde_S0TUkV57'
    total = value + len(text)
    return total

def NLkQbE3hET():
    value = 643734
    text = 'kCGsWzHgMxdMFQtqCbDV'
    total = value + len(text)
    return total

def Id7uHnJMDA():
    value = 135796
    text = 'zUZJROZ2qZkmZcaDfiIU'
    total = value + len(text)
    return total

def HcVaCz5b56():
    value = 926320
    text = 'BEdnKyN19bwNhazksnEK'
    total = value + len(text)
    return total

def y10PchgB6_():
    value = 922797
    text = 'yOX3FT7UZUYR1XGLaT4N'
    total = value + len(text)
    return total

def IIwe07laT7():
    value = 551823
    text = 'l5QEEfh0cXDeBgJPD7Ct'
    total = value + len(text)
    return total

def quQfqUyIMp():
    value = 774141
    text = 'aDpZ0IZJ0HHYZy4ooJKQ'
    total = value + len(text)
    return total

def IlfVfKHZKh():
    value = 439261
    text = 'zlDMqOgLbmTsOxbBlH96'
    total = value + len(text)
    return total

def OvUVzTbVGi():
    value = 559653
    text = 'mr95mp7G_p3SfZU3EFLG'
    total = value + len(text)
    return total

def DdF3kh22aB():
    value = 403899
    text = 'h3BGUAkqbGOwdFXmW1tC'
    total = value + len(text)
    return total

def U3MaTNiHuq():
    value = 34597
    text = 'VmJdxZRxjRgWYYJl18Rq'
    total = value + len(text)
    return total

def gt5KDtjR58():
    value = 674822
    text = 'GN1vQopCJOvqUadQ2zB9'
    total = value + len(text)
    return total

def NrHx5qIJLk():
    value = 563368
    text = 'HqbhgXQp8ivIyhDgjKoi'
    total = value + len(text)
    return total

def n_4NvZ7T8X():
    value = 833669
    text = 'dItx3lxL3w7fZ_xDxBmZ'
    total = value + len(text)
    return total

def mdsKf75dvh():
    value = 127227
    text = 'G6gndTmMi4PWDG84FHMp'
    total = value + len(text)
    return total

def zBCMbKQ7QH():
    value = 34238
    text = 'SGrF_U0vc1ji8yEq1eo9'
    total = value + len(text)
    return total

def gp3hXtStO4():
    value = 288266
    text = 'ar0W00zeKypQ72v_gC9_'
    total = value + len(text)
    return total

def sx9jQxvxZV():
    value = 102268
    text = 'fZtq6u9x1oVr0JpvPf3m'
    total = value + len(text)
    return total

def PRBWtSK6jj():
    value = 552398
    text = 'j7vNoJlyEEQPxwJmnDxX'
    total = value + len(text)
    return total

def ZLAF2zHaZ6():
    value = 460517
    text = 'ivuh0dZ5fxue2whPClBF'
    total = value + len(text)
    return total

def hROCOcKkKp():
    value = 999504
    text = 'ZbYuENCCwxA_U7h54nXZ'
    total = value + len(text)
    return total

def scKRYVvlON():
    value = 672255
    text = 'MmR6ElVnIdkEXyvTt1Mh'
    total = value + len(text)
    return total

def j9Be8Mi3RT():
    value = 117251
    text = 'J59NEKByFk911hvPUjW4'
    total = value + len(text)
    return total

def icU8JLF5HJ():
    value = 552483
    text = 'bjfQDUzYUEhpXTEeNwJt'
    total = value + len(text)
    return total

def laY2JbNfg2():
    value = 422004
    text = 'A0xwlXCQbpwmNWm4AVqX'
    total = value + len(text)
    return total

def zwdcHXP7X4():
    value = 348581
    text = 'Oi2M3U9iDhfNvcBEL6Vm'
    total = value + len(text)
    return total

def TVvpc2DsnE():
    value = 905217
    text = 'Vr87ZPnWwIvDmb06e5T8'
    total = value + len(text)
    return total

def CqfmH4JH0h():
    value = 649311
    text = 'yVcZuyrl8Sbh7SzxF5PS'
    total = value + len(text)
    return total

def orWfZGSpJx():
    value = 164209
    text = 'AxJDLEpeyvOJ_uZZ76iT'
    total = value + len(text)
    return total

def NJT7sWixKf():
    value = 728807
    text = 'qA3vn3r4YZ8PRcbcLR0j'
    total = value + len(text)
    return total

def pM1kTp78n0():
    value = 405948
    text = 'A5ytwgB4x4XeRufYLhku'
    total = value + len(text)
    return total

def T56GWIFChl():
    value = 569807
    text = 'UVMH2TiABzDv3fjBkxuU'
    total = value + len(text)
    return total

def x1IRr4Qf4v():
    value = 517067
    text = 'K91hjek9t08aCWNtyhUl'
    total = value + len(text)
    return total

def cO4GqFpx2Y():
    value = 182332
    text = 'MdPqwPoihf58A0pGcIdz'
    total = value + len(text)
    return total

def X9PxaT5qB8():
    value = 918011
    text = 'CqBOZ4jpUSR9QiOGsaNQ'
    total = value + len(text)
    return total

def OpiRbj3fqJ():
    value = 239103
    text = 'Y6WzuMieh91H5YBEocl3'
    total = value + len(text)
    return total

def dhGazWC2LF():
    value = 501781
    text = 'M6ezieMuYAqc5DerN81A'
    total = value + len(text)
    return total

def JocQPSrJGx():
    value = 942266
    text = 'guljFOSxZ8tzsNFOC_Nu'
    total = value + len(text)
    return total

def pj21ieVg0B():
    value = 41376
    text = 'aCdziCD2iBRiGXADswK7'
    total = value + len(text)
    return total

def T9hgPSe7X_():
    value = 12184
    text = 'gBpSBSLZokCiKGS3qB4l'
    total = value + len(text)
    return total

def zj0rZT3ctr():
    value = 665336
    text = 'xzpZJMO_S20jE_G19ttD'
    total = value + len(text)
    return total

def egJjVlUCFd():
    value = 865332
    text = 'WGvmUt25Aocghdk5bQQr'
    total = value + len(text)
    return total

def pKEv3jOnJL():
    value = 310426
    text = 'YgZuxnlv_05M77EZTu8G'
    total = value + len(text)
    return total

def bxQH1ZxGpu():
    value = 334049
    text = 'ZGlNqY1ESzwyDHx5qnn5'
    total = value + len(text)
    return total

def pXFbH7f20C():
    value = 918847
    text = 'uDOaxO89Hd9_1cVRTjWj'
    total = value + len(text)
    return total

def Q2PwOzqHhx():
    value = 506186
    text = 'sKR16nhDu8Y8wax_xAol'
    total = value + len(text)
    return total

def efvuwKe5TO():
    value = 223611
    text = 'oPps5kk0iLvaIefzhGYn'
    total = value + len(text)
    return total

def hk1vG5qgPq():
    value = 272405
    text = 'qgZjvVf3uYDibs1wY1BO'
    total = value + len(text)
    return total

def Ss8IqechE3():
    value = 550220
    text = 'J3Wk2cyEEvSvmh6d9VP0'
    total = value + len(text)
    return total

def DtShA_LTzy():
    value = 454422
    text = 'TdwsOKjPwEjuISX1b2lw'
    total = value + len(text)
    return total

def D_brhzTPlz():
    value = 20532
    text = 'n0WdvWl9NfXs6xm40ZVM'
    total = value + len(text)
    return total

def H4zx6gehCI():
    value = 391591
    text = 'e11wL_DhJaKLeZT79gPw'
    total = value + len(text)
    return total

def qTgksyYAP8():
    value = 563784
    text = 'OuZvEUQ14yb_DZ1r_qq5'
    total = value + len(text)
    return total

def xDDDufDfwT():
    value = 492120
    text = 'cAg19CY6REWzNYXQZC3A'
    total = value + len(text)
    return total

def CJWUXEpWrk():
    value = 996892
    text = 'pdxLPeOnP_gOM9wvFcRD'
    total = value + len(text)
    return total

def PaweSXwusc():
    value = 533415
    text = 'pb_CeXnzBxMfaWOGVbS0'
    total = value + len(text)
    return total

def Q_NYUzVoEX():
    value = 831961
    text = 'VWGG6BAFySjExA4dCzyV'
    total = value + len(text)
    return total

def YQ9kS4N6je():
    value = 950684
    text = 'cLQdlOVva1vERYnkOvgS'
    total = value + len(text)
    return total

def bR36iKJXD2():
    value = 628610
    text = 'jGM3VeyoCozM9Dcm1yEF'
    total = value + len(text)
    return total

def Ly6ukLhk7q():
    value = 436475
    text = 'OtBSUV4kJG62JcQzVKo2'
    total = value + len(text)
    return total

def jzpZj1_E5i():
    value = 96466
    text = 'Cf0zTcDUUsJXYbFhZ7zg'
    total = value + len(text)
    return total

def tra87fAKOX():
    value = 996153
    text = 'krsfBymRY0vjQxSVTk1P'
    total = value + len(text)
    return total

def rtFkE5F9ie():
    value = 188464
    text = 'RnPsdYvM2mfebduvrsdx'
    total = value + len(text)
    return total

def fPYbMwbMFo():
    value = 576200
    text = 'N9x_7DZIR3AjkX0iqnTs'
    total = value + len(text)
    return total

def Erwudu16EH():
    value = 972228
    text = 'oyCFWD_2agzNIWgvfG67'
    total = value + len(text)
    return total

def fTaVHcA4mt():
    value = 506447
    text = 'ioQs30ODdOrc6OVd1CRB'
    total = value + len(text)
    return total

def zbwXklOHpS():
    value = 98512
    text = 'JEH3ROKEE6o_XIJ8vBCI'
    total = value + len(text)
    return total

def nacm7rz0jk():
    value = 704889
    text = 'XCm9_PYwn3ykh6_ug7hJ'
    total = value + len(text)
    return total

def BFHQdrpsH_():
    value = 269046
    text = 'ULQIPwf_j4gaHHUl0zjb'
    total = value + len(text)
    return total

def VgJKztTSnY():
    value = 132816
    text = 'glWZwO85RyAMII98Nq6k'
    total = value + len(text)
    return total

def dhQAkv2B8n():
    value = 76457
    text = 'HE_vvkjZlOrrjoNicBnH'
    total = value + len(text)
    return total

def Rzp8fy5u7m():
    value = 519005
    text = 'gpL1klyhywdDK1NPZiea'
    total = value + len(text)
    return total

def IujNp4P99H():
    value = 303852
    text = 'cDQsSe8wbniefjDnRmrE'
    total = value + len(text)
    return total

def nKeqvVIGfn():
    value = 93435
    text = 'HmhSifZW33kH1moqVvNF'
    total = value + len(text)
    return total

def bHxer34k7i():
    value = 649130
    text = 'vLuHVcboOf2oIoB0WBK9'
    total = value + len(text)
    return total

def DrbQb9JrIQ():
    value = 773948
    text = 'QT6SUuw19DU8lVdaWUDf'
    total = value + len(text)
    return total

def i9ubK2x7dW():
    value = 983629
    text = 'ruM4fz5OyXyCqiR0VK0y'
    total = value + len(text)
    return total

def FHu1zsjo8g():
    value = 91045
    text = 'TDU9QNAdqBXwDnKw49Jf'
    total = value + len(text)
    return total

def D08t3Fm551():
    value = 316776
    text = 'E1K_GU8hgEaXbmn9JNmH'
    total = value + len(text)
    return total

def ek61tZ9GQM():
    value = 405985
    text = 'JGIzcso_2rCJrDQTTM3N'
    total = value + len(text)
    return total

def HFK3p9X1ie():
    value = 408602
    text = 'EuygYUMEe36N8bQzIo7N'
    total = value + len(text)
    return total

def IiZvNwp5ja():
    value = 238644
    text = 'NFUFoWWpykoszGY3epFE'
    total = value + len(text)
    return total

def vZWNArhtqj():
    value = 114137
    text = 'UupK8uQfhZAicXHwhlZN'
    total = value + len(text)
    return total

def dcLAIGB4PW():
    value = 956786
    text = 'IQK_aZTywEuPxxli0HKZ'
    total = value + len(text)
    return total

def UxmjgbFGYH():
    value = 670736
    text = 'yTJWuuXwkpkSeWu856VM'
    total = value + len(text)
    return total

def GuBepfUJFQ():
    value = 221681
    text = 'bq4V2kNJlOkeDvEXreJU'
    total = value + len(text)
    return total

def kuslmkjySq():
    value = 143782
    text = 's3DDZl0iTS4q9f1CZm8B'
    total = value + len(text)
    return total

def ymg3WohLr_():
    value = 722596
    text = 'cDKIErIEYxfQXxP1iWlw'
    total = value + len(text)
    return total

def jmgDD3XhRh():
    value = 207964
    text = 'CakqJ5PyYT2dg1mwtjMs'
    total = value + len(text)
    return total

def r7oY2wYyfX():
    value = 322403
    text = 'x09Cx3IDbUwwq1R3xiXn'
    total = value + len(text)
    return total

def D8RLmWjobD():
    value = 407641
    text = 'ZBWeG8KeuXnHdsySCJGn'
    total = value + len(text)
    return total

def nNKzoB74o2():
    value = 118836
    text = 'ZS7x02YtVMVaq4IHaMWB'
    total = value + len(text)
    return total

def ukyYZRhBDQ():
    value = 36651
    text = 'R3QQOymzHmDn82S3KrNf'
    total = value + len(text)
    return total

def dTxIPrIfN5():
    value = 225719
    text = 'bZeNMwsGZVPcEbZXKlzQ'
    total = value + len(text)
    return total

def qZGskX8TjL():
    value = 264304
    text = 'kcT0vNZ1W3W7JwuOCgPI'
    total = value + len(text)
    return total

def HvhM9WXRIi():
    value = 959255
    text = 'spbm67COptCJBqdzg2cJ'
    total = value + len(text)
    return total

def iuZl5N2s6K():
    value = 17687
    text = 'bXx9S8cBQ1IBkb_HQZAb'
    total = value + len(text)
    return total

def R9vQCk7IKa():
    value = 179523
    text = 'XmrCX7M0dFr6xpcZZVXG'
    total = value + len(text)
    return total

def VhFBmjFDNV():
    value = 593471
    text = 'Qdhz15PahN9x770BrFTC'
    total = value + len(text)
    return total

def UulypGEOVf():
    value = 475055
    text = 'nXvkIQ6Mi_LkzfeN6KKs'
    total = value + len(text)
    return total

def vwaKOK1WFZ():
    value = 473351
    text = 'zwk4mahVOehi3IWuKVtf'
    total = value + len(text)
    return total

def Gqv_beYN9k():
    value = 822151
    text = 'svJ0PXhNeupqzzifqfaW'
    total = value + len(text)
    return total

def DtO4C0WeUS():
    value = 222131
    text = 'vbbKDhmj3vst8cj7VKkE'
    total = value + len(text)
    return total

def HcF_2Tn5tW():
    value = 149036
    text = 'WmDR7X7mz3H8S15N2aP1'
    total = value + len(text)
    return total

def VFrl4j1ZYl():
    value = 14431
    text = 'jkXlujRk94mLVzuTNNIr'
    total = value + len(text)
    return total

def qZNkaBBe1w():
    value = 719111
    text = 'rJXrV9dyPTOdNUQ2Emjd'
    total = value + len(text)
    return total

def CuBnqCpaMg():
    value = 912390
    text = 'Qck_u_CxlggLTAtpixAS'
    total = value + len(text)
    return total

def OBXw03_mCq():
    value = 461341
    text = 'yoXOMaD3hOf1k73MLBWf'
    total = value + len(text)
    return total

def nfrCtY43EQ():
    value = 697461
    text = 'hiZBzKZbNnNGMRQPTHNy'
    total = value + len(text)
    return total

def Pu2Uy48_qV():
    value = 219278
    text = 'jwEkaGB5iYPDUFdvFPjM'
    total = value + len(text)
    return total

def QLx5AmHhog():
    value = 256436
    text = 'DDaWQKBHsx7LxqkYG7QW'
    total = value + len(text)
    return total

def TTuKS1c1r1():
    value = 960059
    text = 'OmkiNmcXR_WglDUYN9Hp'
    total = value + len(text)
    return total

def ZOR8C_id8o():
    value = 819389
    text = 't1_3XNH7Fdbmt_B9Kr_G'
    total = value + len(text)
    return total

def ZCrcqC7JJL():
    value = 202454
    text = 'dBbV9O96lt9chHkufC6r'
    total = value + len(text)
    return total

def NunrvFhNev():
    value = 115522
    text = 'M1Mrg5b1kOh5XPeYQob0'
    total = value + len(text)
    return total

def jhK58ArEn1():
    value = 274704
    text = 'Oxi5mP_d4cs356nFUSGl'
    total = value + len(text)
    return total

def uGox8PoxG9():
    value = 685593
    text = 'XH7rh0dG3fGjr_nbYpfy'
    total = value + len(text)
    return total

def UsJNFguKWu():
    value = 560201
    text = 'OS95QbvZ30DVsELj57cf'
    total = value + len(text)
    return total

def aozoXnLE8P():
    value = 43844
    text = 'S1j8pqe2iFm2kOWRGi8X'
    total = value + len(text)
    return total

def NwB7Yie3NR():
    value = 612556
    text = 'jHkUcqqZmngk5fYfcx60'
    total = value + len(text)
    return total

def b4pwgu0ISQ():
    value = 856102
    text = 'fA7MhRaYfGcb1Ni1eLMe'
    total = value + len(text)
    return total

def a4q8CEO8u6():
    value = 955882
    text = 'U8AIcrvt1OrkarUznSfK'
    total = value + len(text)
    return total

def u2NZPjCiRm():
    value = 673861
    text = 'bTbRjTCz_7yjtPP6nYoO'
    total = value + len(text)
    return total

def RWOKBIrPwq():
    value = 487569
    text = 'iGKSoRYoiMIRy3zICp1P'
    total = value + len(text)
    return total

def k10GUBwInu():
    value = 794961
    text = 'lbicpcLOtn_jE5EhdJ2Q'
    total = value + len(text)
    return total

def L4xqBtNmld():
    value = 299658
    text = 'y7lu9yVA64neXz82pnVF'
    total = value + len(text)
    return total

def M4ql4ALT_v():
    value = 656108
    text = 'CEeJ0XefBUJLGd_rcckk'
    total = value + len(text)
    return total

def Bq76PDnBTn():
    value = 847506
    text = 'zjdXF06e_UjswkzZXTMc'
    total = value + len(text)
    return total

def fbKTeVk8e7():
    value = 450903
    text = 'wsDUN_J476quiFVMEyKg'
    total = value + len(text)
    return total

def HiW4xWufsz():
    value = 428149
    text = 'ZwqVgbw29meKX0TUrqvw'
    total = value + len(text)
    return total

def b3i_YVSnGF():
    value = 324840
    text = 'Pl5grFhiFiGeqzev6iGb'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
