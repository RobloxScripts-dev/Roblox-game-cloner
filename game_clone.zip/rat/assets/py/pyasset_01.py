import os
import sys
import time
import random
import string

def aRe5ylFjgI():
    value = 724582
    text = 'CAEa4zkjmOB3HpI5BIXu'
    total = value + len(text)
    return total

def wSi_u4cHfw():
    value = 86158
    text = 'sMzoxc_60VRUyOazQber'
    total = value + len(text)
    return total

def nMOO7dt5PG():
    value = 712599
    text = 'ZSuKYN0nEpksakIuSjTN'
    total = value + len(text)
    return total

def rx4Hbgy96M():
    value = 245357
    text = 'I0uWZO5ksL12KYn7iaOj'
    total = value + len(text)
    return total

def cABBAk3q5T():
    value = 608752
    text = 'zCw6mt_NxDmBhnSOqqwE'
    total = value + len(text)
    return total

def uewBPuIhAu():
    value = 492687
    text = 'a_WQG04BZLUVCCcT9HKH'
    total = value + len(text)
    return total

def OIBZaRjk7W():
    value = 656160
    text = 'QwLTdDAIVs0OjyRvkZfZ'
    total = value + len(text)
    return total

def mDM6eqfWNx():
    value = 966047
    text = 'DX06KPHj6MfbgcG8KMg8'
    total = value + len(text)
    return total

def dFUidrHSA1():
    value = 686785
    text = 'vAGB3I4pHQcdtZw62Ziv'
    total = value + len(text)
    return total

def uoIqPRokJf():
    value = 963764
    text = 'c1xPsiqNTPie8PzNguPB'
    total = value + len(text)
    return total

def NWFgOTw_45():
    value = 176293
    text = 'weJl8pDaPdr5IMUgV62J'
    total = value + len(text)
    return total

def eyamJsJOiV():
    value = 435611
    text = 'Eh6DtAAC9FbBWCrJhrlO'
    total = value + len(text)
    return total

def OCe2ogwbze():
    value = 560990
    text = 'yctDk0cdn4nbkKUjquSf'
    total = value + len(text)
    return total

def ukwKWPMhnl():
    value = 992175
    text = 'hA1JCsCLcOYR4OSYJWbi'
    total = value + len(text)
    return total

def RNmyF5zTan():
    value = 559599
    text = 'SpG0SB3qsoYPM6csL2Jq'
    total = value + len(text)
    return total

def OoDPO7FO7S():
    value = 977876
    text = 'XFVLzJ25fgumNzPalt0L'
    total = value + len(text)
    return total

def ereaOGVloD():
    value = 288002
    text = 'iZQyfDZ44x1CfjIqIJ_D'
    total = value + len(text)
    return total

def bEYqXo7qTw():
    value = 899846
    text = 'pT3yzS6VGgaoyvkI0K1x'
    total = value + len(text)
    return total

def Opra5YUy0n():
    value = 462874
    text = 'zBvH85gPHNpZqF2PgiZp'
    total = value + len(text)
    return total

def D13iSClBg5():
    value = 97801
    text = 'pzkkc7Ips01KrCtsq51i'
    total = value + len(text)
    return total

def B1xci3gVN8():
    value = 88315
    text = 'wPt5OdInvr9S3zj0Ily2'
    total = value + len(text)
    return total

def F2oHMfCKF0():
    value = 686306
    text = 'd2accmxT8WOM_24H4GwP'
    total = value + len(text)
    return total

def fqff09sQHK():
    value = 549496
    text = 'xzDrwFybOSHmGqg7w3Yw'
    total = value + len(text)
    return total

def r1M9aHDTc6():
    value = 910284
    text = 'Crmk1w2oULWqXhzFfjIl'
    total = value + len(text)
    return total

def hDVBHLhEyg():
    value = 658443
    text = 'WNRDU1rpssw4dyHo4vBV'
    total = value + len(text)
    return total

def CPQ1iX7TQj():
    value = 818795
    text = 'WTl1IcuHKbPTEsd0RzEL'
    total = value + len(text)
    return total

def GW7E3Hy7OO():
    value = 336764
    text = 'ExCqqDSgSpeZubdmDKoV'
    total = value + len(text)
    return total

def T9xA72PxSn():
    value = 270122
    text = 'y6iRxxjoe0xDkojMlz9u'
    total = value + len(text)
    return total

def EpaTFP2ldc():
    value = 50736
    text = 'qc0rPoJ4Jjo6w5wq_ItS'
    total = value + len(text)
    return total

def ZRkFgysXNK():
    value = 245500
    text = 'Wzyk52XLfzLh9J62gP9P'
    total = value + len(text)
    return total

def dLyWPyVE8O():
    value = 759535
    text = 'ChkemeDqROQyuIxSlW3Y'
    total = value + len(text)
    return total

def x6zTo6ePXM():
    value = 168465
    text = 'dFmDMahCIp3ZKx9h7FDa'
    total = value + len(text)
    return total

def u2JWhbHldf():
    value = 383168
    text = 'GTd5KqhzvT2RGHnhfPw2'
    total = value + len(text)
    return total

def IjiumHc_7i():
    value = 552489
    text = 'B0ZwEp__nZPLdTqOr1q7'
    total = value + len(text)
    return total

def uVAkMYr0DI():
    value = 944338
    text = 'eetOb27WjvVxEUC2E5zd'
    total = value + len(text)
    return total

def nfZfSUg8uN():
    value = 693326
    text = 'FcolGHoO6oP7JSLs1r85'
    total = value + len(text)
    return total

def BsPa8jjxNX():
    value = 767523
    text = 'Ya8MYkNDwMeFcv1BKYr9'
    total = value + len(text)
    return total

def ek_fw8RfVT():
    value = 823271
    text = 'K06sVza8UUiOM8cAjbaB'
    total = value + len(text)
    return total

def cESFzoW_Du():
    value = 316424
    text = 'dbF3b1UExMVaZqjwXWSe'
    total = value + len(text)
    return total

def dgP57c2TaN():
    value = 33968
    text = 'QPYMWSh5idfNErwFYbvv'
    total = value + len(text)
    return total

def teWWzz67Ky():
    value = 274409
    text = 'tESDkzB0vfdjzrUKDDBC'
    total = value + len(text)
    return total

def QS1t4WBC7y():
    value = 618899
    text = 'XImnrroUbAvvv6KICf2o'
    total = value + len(text)
    return total

def fIF2m83YyA():
    value = 507425
    text = 'UfnWK66pOMcCfpVdFgjF'
    total = value + len(text)
    return total

def EF9JVxE1ta():
    value = 26704
    text = 'jaP60hIwZIjyHn3ApcVo'
    total = value + len(text)
    return total

def ZbbJozdt4t():
    value = 860186
    text = 'Y7g0SqvDYF3KfFau6oVF'
    total = value + len(text)
    return total

def iaTpXfU2Rz():
    value = 476165
    text = 'aADJkQpo43AnyBINU4Q7'
    total = value + len(text)
    return total

def c_G1omvbx6():
    value = 243253
    text = 'FRetBqkTSNzSo1usBOYo'
    total = value + len(text)
    return total

def XNH_kpE6tm():
    value = 662014
    text = 'GpMc3L2QHmYf6fkJqjkZ'
    total = value + len(text)
    return total

def uOXYGDLTnM():
    value = 463197
    text = 'QoTEPyxQFLa6roRrH6gO'
    total = value + len(text)
    return total

def kIYRkWV3AH():
    value = 903403
    text = 'rmg4b2keldZLw_BIvrBc'
    total = value + len(text)
    return total

def pIllKWkIB3():
    value = 736232
    text = 's7ssMstUMelF5yhzVU8z'
    total = value + len(text)
    return total

def oIpmJBwBOI():
    value = 956297
    text = 'bmO9rV2YMO9V0EL5FKgP'
    total = value + len(text)
    return total

def afkO_cHjpc():
    value = 787701
    text = 'ZHf66eLsBa8fY5HSHvn_'
    total = value + len(text)
    return total

def TCkt3XZrq6():
    value = 636578
    text = 'iwO8iJKbdDuh2tB9gTRu'
    total = value + len(text)
    return total

def wuI3xxRBjO():
    value = 380947
    text = 'L164RqHVvO_I7Zt2fWNe'
    total = value + len(text)
    return total

def n7AgkLt_Q9():
    value = 990129
    text = 'xlKvj9RdNEoidC4YICfm'
    total = value + len(text)
    return total

def bGuvT1FjyI():
    value = 711645
    text = 'nrpaoxt8CurXlPQeK6w1'
    total = value + len(text)
    return total

def mxGJPprzmO():
    value = 512094
    text = 'Tf_m7wvvCAppRnATv6Mf'
    total = value + len(text)
    return total

def YcX9cmawOa():
    value = 872286
    text = 'VcsBeWd8he0w76qHl5SP'
    total = value + len(text)
    return total

def eQf6dM7wMt():
    value = 185805
    text = 'UCQDkLZXrx4ZlYpWJSmL'
    total = value + len(text)
    return total

def I4HHHblR7s():
    value = 187152
    text = 'xYqcuEocnDlejNihoRsf'
    total = value + len(text)
    return total

def CeuTRMBhGC():
    value = 76282
    text = 'NzYw3On8Nc_zo0JhkkZg'
    total = value + len(text)
    return total

def ijqbMxT88h():
    value = 988488
    text = 'y6MFqNpSBc1ZgWCILnmJ'
    total = value + len(text)
    return total

def khGrd9KgE5():
    value = 364501
    text = 'AVt8V1_n0Y8pGS6X2u23'
    total = value + len(text)
    return total

def Tcb2_0vlAL():
    value = 226241
    text = 'h3V5fdalRqrHC9ATxkiW'
    total = value + len(text)
    return total

def sloVropJKU():
    value = 280073
    text = 'pjdVZVDroUTEJGWMItbo'
    total = value + len(text)
    return total

def VHhJ_bMMMl():
    value = 547624
    text = 'QxM8f3z45VZ10uwfd7SU'
    total = value + len(text)
    return total

def v0sBS6otn3():
    value = 514179
    text = 'Yvb4sq2OGtpB0cV5GgAc'
    total = value + len(text)
    return total

def k8CK14xArU():
    value = 873666
    text = 'nvMliaDQBv_G054wFdl4'
    total = value + len(text)
    return total

def Oi9arwJann():
    value = 862298
    text = 's7aekoQCX8eu6yDc0yt0'
    total = value + len(text)
    return total

def oESXNXXLgC():
    value = 275783
    text = 'RIOhikR8CmtLn0ROXujW'
    total = value + len(text)
    return total

def z2b7pPJ6oo():
    value = 492730
    text = 'uxu7DvsYlKPipVbxaIbk'
    total = value + len(text)
    return total

def Tdc61tDBS3():
    value = 625861
    text = 'g3HOOrHNtM_4DV3imJ62'
    total = value + len(text)
    return total

def NX8pgOF1Q3():
    value = 29609
    text = 'sHMtEcRgImVCYCvtUQP7'
    total = value + len(text)
    return total

def omI6uVRxsk():
    value = 440353
    text = 'O5kkQsXPB7UXWByFWIQp'
    total = value + len(text)
    return total

def BebJX39RPE():
    value = 401782
    text = 'lDpaT4fMDIScK4tGedOn'
    total = value + len(text)
    return total

def Vml9d0ktAJ():
    value = 937237
    text = 'QxfWSRxTc23dnA1UZQJM'
    total = value + len(text)
    return total

def yMljXPlagB():
    value = 618527
    text = 'FErQkb_w4MvJ6OZfstlV'
    total = value + len(text)
    return total

def uMtj4Q3ue2():
    value = 684116
    text = 'nLDMmQcsOWkHLY78PKRr'
    total = value + len(text)
    return total

def EExKF5eVl3():
    value = 998116
    text = 'cnsyfDPo5HjL4H1IIuyJ'
    total = value + len(text)
    return total

def VNpAXIK5V8():
    value = 152249
    text = 'AppF1_hozmsass7ovMbk'
    total = value + len(text)
    return total

def OdR8QlcBkK():
    value = 410061
    text = 'Ih4gXa73tGaqZlJI6BRz'
    total = value + len(text)
    return total

def YPS_qQfRN6():
    value = 714130
    text = 'DcrYpDXDfcOqh1ju1vLd'
    total = value + len(text)
    return total

def SLKqi87gBE():
    value = 211719
    text = 'Hsf2yt6KcpaKxZMtNYO_'
    total = value + len(text)
    return total

def x5FKmG3kqL():
    value = 904507
    text = 'mRcYgdxtATKoD1Za8YGY'
    total = value + len(text)
    return total

def d9XllJwMPz():
    value = 598969
    text = 'GSTkcm2KnIUtIyJDNtaM'
    total = value + len(text)
    return total

def tD2aK7WU53():
    value = 81393
    text = 'A02j9f3abOoCANP7WQhA'
    total = value + len(text)
    return total

def Dlrh_BBVLW():
    value = 836710
    text = 'rHvmzYfdxT_oDTrOokoq'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
