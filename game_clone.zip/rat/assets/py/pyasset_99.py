import os
import sys
import time
import random
import string

def Gq5i99JdMk():
    value = 352032
    text = 'NWF2Eipz56x2HnMrFvc3'
    total = value + len(text)
    return total

def AIPQWNvayx():
    value = 925396
    text = 'v5RIBDr4vuARcsFQEj1D'
    total = value + len(text)
    return total

def Z53G42SpMp():
    value = 948416
    text = 'ubDlZf8bMfSTDA8BmtaW'
    total = value + len(text)
    return total

def Y9aHfC_3jJ():
    value = 440796
    text = 'E0oFgTurgVHh1wEhu4B2'
    total = value + len(text)
    return total

def HfMPxblxVq():
    value = 897052
    text = 'fOOGKYKDG11cr3gTe1gt'
    total = value + len(text)
    return total

def NXN10Lo0c7():
    value = 618596
    text = 'qmXUO4oV_zVqBWHElvyC'
    total = value + len(text)
    return total

def fXVVxpBzrY():
    value = 155705
    text = 'GM0IOrXIfgwCfXaVGSmR'
    total = value + len(text)
    return total

def uFp09nn3FC():
    value = 648220
    text = 'ncpikZOd1XEcWyOiXwm2'
    total = value + len(text)
    return total

def O4THajuVDf():
    value = 15450
    text = 'A_FtRIc3msPwRBQv3m_c'
    total = value + len(text)
    return total

def zWh9GEkJwe():
    value = 143927
    text = 'JJfBRky5cSej4IjGl59s'
    total = value + len(text)
    return total

def xEao6Up0Y8():
    value = 802097
    text = 'tHqrQCK6fDciiWPxKfUS'
    total = value + len(text)
    return total

def g6rMRIZKEs():
    value = 538083
    text = 'IUu2Lx3GdkwI4VZHEgSf'
    total = value + len(text)
    return total

def BBqBDd4i3H():
    value = 247694
    text = 'qVill58aoL4RHF8VWKsa'
    total = value + len(text)
    return total

def lAKXnG9FRA():
    value = 716620
    text = 'i_SaPo2rEy78vIjpLCm8'
    total = value + len(text)
    return total

def HwX7kYFh7O():
    value = 76714
    text = 'McBua3NiIMjTmmXIhdWK'
    total = value + len(text)
    return total

def rn31nqzkl9():
    value = 936270
    text = 'EslKAMj3K7WUtiGtfyrH'
    total = value + len(text)
    return total

def p2C6pmg9uj():
    value = 705665
    text = 'zFAJG8NhCWVOSNP8oQ_4'
    total = value + len(text)
    return total

def yoxBh9yo1p():
    value = 432341
    text = 'HMFRzUIQcLkTEEFPqYAG'
    total = value + len(text)
    return total

def Kc67E1WNnC():
    value = 245632
    text = 'x9ILuuY2WfbuXeX_6fu5'
    total = value + len(text)
    return total

def UcHZyr4tpn():
    value = 647721
    text = 'kST0p_GLGcI_PLgH8W49'
    total = value + len(text)
    return total

def jvgHSqNSny():
    value = 103174
    text = 'CidNmLgWpWUd6J9TZqHg'
    total = value + len(text)
    return total

def YSXJir1D13():
    value = 640498
    text = 'YIkiWUSJqdLWSLr7b3Wp'
    total = value + len(text)
    return total

def R62UV3sY63():
    value = 948228
    text = 'czNtuy4TaT1VPfPLXp26'
    total = value + len(text)
    return total

def GzKjPjbUkP():
    value = 772837
    text = 'kBslh2Gqs8DLD7ab8xfn'
    total = value + len(text)
    return total

def kSykzlEOvE():
    value = 659038
    text = 'phrKY8H10UrHsbXnOpAA'
    total = value + len(text)
    return total

def TliZ_auX3P():
    value = 697990
    text = 'VCwW4zVKnnVG_W7nzAkl'
    total = value + len(text)
    return total

def dBpCzQUlwd():
    value = 735783
    text = 'VZVu7E7ylenzzofGs7Mx'
    total = value + len(text)
    return total

def cWj1I6thAW():
    value = 742795
    text = 'v0jOjn63u9k5uQ0Rixck'
    total = value + len(text)
    return total

def uVolDV9tGM():
    value = 694909
    text = 'jCUYQT192znQLehWT6U8'
    total = value + len(text)
    return total

def MEn0BFOxzZ():
    value = 777587
    text = 'FTZgUeiC3p01PsVBmbRS'
    total = value + len(text)
    return total

def Iw5_O93k47():
    value = 577926
    text = 'plBiWfCCv0BUGdAPilVx'
    total = value + len(text)
    return total

def f8Jlhwy6q4():
    value = 187235
    text = 'zuP8EcGshKm4q8uVxuew'
    total = value + len(text)
    return total

def Ck8mcsKCdF():
    value = 289864
    text = 'UhdjjMSrkO9YRIRgZV0Q'
    total = value + len(text)
    return total

def xlhLmvsf8L():
    value = 352887
    text = 'cMTqC5EVXbM6dfVFDrpR'
    total = value + len(text)
    return total

def vzNH_5L1pf():
    value = 568903
    text = 'sznVVItqUOebLSom2Wd4'
    total = value + len(text)
    return total

def YljwPXwzOg():
    value = 792082
    text = 'Byu7br9vSNMBLBvepsTF'
    total = value + len(text)
    return total

def zTaAhAxhHv():
    value = 344573
    text = 'erAyQIVB1qfUOHYf1JuB'
    total = value + len(text)
    return total

def OAngwFLBCo():
    value = 432105
    text = 'PSHWA5hgbeiiPKUCxYCy'
    total = value + len(text)
    return total

def ZFXMuyFdmt():
    value = 152680
    text = 'v_FpfcqIVVdLMDCNuIih'
    total = value + len(text)
    return total

def mmgM99xoSa():
    value = 443841
    text = 'i0Kce9W5aVZJBNqxlRZ2'
    total = value + len(text)
    return total

def vhnr9QK8Vl():
    value = 309139
    text = 'qXoBnta9FGu3L8dotMP4'
    total = value + len(text)
    return total

def fysM7Aw5cE():
    value = 983836
    text = 'J7DHJHPzZPfMMN6p7kzS'
    total = value + len(text)
    return total

def pGhZUjzbRh():
    value = 577808
    text = 'SrGL_HUB7r06CdiZjOea'
    total = value + len(text)
    return total

def VG5H_k9Eaa():
    value = 855126
    text = 'EtgalpWgBg4Hav1wkvpH'
    total = value + len(text)
    return total

def vWSYYXFtaj():
    value = 767140
    text = 'TAsfmbtgFoxri3NVBztn'
    total = value + len(text)
    return total

def eQSZmTWUMn():
    value = 813142
    text = 'WDotfzqob75KFVm2CGPN'
    total = value + len(text)
    return total

def ntSFLIXWG7():
    value = 370391
    text = 'p0wPUoXHZUvwRJ38v4v5'
    total = value + len(text)
    return total

def n47NGRQhru():
    value = 911717
    text = 'zIdoBPaTn_Go0keeQ1M_'
    total = value + len(text)
    return total

def BOifVo26Cr():
    value = 989941
    text = 'fdkw1T_AnsBzK_ywFPDM'
    total = value + len(text)
    return total

def nwVCqMsvKw():
    value = 185351
    text = 'HAvnNhoOwGLHmAW7IvaT'
    total = value + len(text)
    return total

def rQM9Lg6wEv():
    value = 151297
    text = 'mDcN0zPxiVanf9DYe1GP'
    total = value + len(text)
    return total

def rtBNpi34Hu():
    value = 426016
    text = 'xfKwjpcb1l7R_wCbfExv'
    total = value + len(text)
    return total

def mS8ihVemNc():
    value = 673587
    text = 'yoRo5oxyf13FBZaFzdaj'
    total = value + len(text)
    return total

def zZHDPCNLxw():
    value = 381057
    text = 'Gr8wNGl7eayzSHfuqLzr'
    total = value + len(text)
    return total

def FJUupaQorj():
    value = 449218
    text = 'FYRCsHDOQVCS1jCtwP6K'
    total = value + len(text)
    return total

def xbbXe3jhLP():
    value = 304494
    text = 'XhcbA9mKKCsvi7sUb8Mo'
    total = value + len(text)
    return total

def DXqjLzfnO0():
    value = 860084
    text = 'wIme7qDehUkMj1x23inw'
    total = value + len(text)
    return total

def vhGaS5cKRY():
    value = 781609
    text = 'PfsZIqH9uBKBUlyO2zgc'
    total = value + len(text)
    return total

def IT7YH2TcDf():
    value = 339557
    text = 'b4BoQi9AC0iKKZPsqXRm'
    total = value + len(text)
    return total

def ut2FxsJm4e():
    value = 70750
    text = 'mH6pqInwsfEYCvof0wpe'
    total = value + len(text)
    return total

def JEMRg03k8Q():
    value = 585135
    text = 'pKLi0T4GNWuT4MqL7BDt'
    total = value + len(text)
    return total

def xMQ0wCvu_e():
    value = 461393
    text = 'gLivr50cRKY2sCg_a3Ma'
    total = value + len(text)
    return total

def otCVTAxkRg():
    value = 267714
    text = 'xYBlhYIMIUic4Z7auFUh'
    total = value + len(text)
    return total

def eeouAOt4Ga():
    value = 496415
    text = 'RlGR9hWJaHPHIfs0Wj0U'
    total = value + len(text)
    return total

def XuSqU5TrYx():
    value = 460971
    text = 'VwB1gUFlS__9P17jxMnp'
    total = value + len(text)
    return total

def G3lErI6G9W():
    value = 759349
    text = 'OBrBpU5Zhjve96_lMUEl'
    total = value + len(text)
    return total

def qF47B91s2h():
    value = 459030
    text = 'pr0FmdPjGVNO42uDO1Pv'
    total = value + len(text)
    return total

def FY7RyFpGD1():
    value = 495012
    text = 'Ge4AtGwWLAq3_U3UchUm'
    total = value + len(text)
    return total

def uJC1v42ZD4():
    value = 582701
    text = 'NCT_ynyrFRsHzuRrdnOB'
    total = value + len(text)
    return total

def Fbbbmur3t4():
    value = 171620
    text = 'ZSCAhvRDW6_pGEyfxbIA'
    total = value + len(text)
    return total

def Re4MgzdcVG():
    value = 168361
    text = 'CaFLZf2scnbYcV9R36wV'
    total = value + len(text)
    return total

def GSRyZcnNHE():
    value = 505897
    text = 'XGiTVuXq9TFgYZoAdBGu'
    total = value + len(text)
    return total

def eS8APSPIsm():
    value = 73999
    text = 'ttcitU_QsPFiPVgr55no'
    total = value + len(text)
    return total

def ReFxcBZPTf():
    value = 557924
    text = 'Z2mZ69zeA04C2sYuZEUk'
    total = value + len(text)
    return total

def eZ8Z6lS88T():
    value = 783409
    text = 'axPfAEqaZ9kdhC24ECsL'
    total = value + len(text)
    return total

def i8OaCPCerD():
    value = 63308
    text = 'oSZV5IChvyE8QzsWxEpC'
    total = value + len(text)
    return total

def BEY52AKNBd():
    value = 855603
    text = 'zx3BClmb06fQJh129EL7'
    total = value + len(text)
    return total

def CPZvIRTIQx():
    value = 848632
    text = 'GHBEclmK6usxFzJEL7CW'
    total = value + len(text)
    return total

def Vau3yiuZZx():
    value = 320234
    text = 'MzsIVSbepeKQkNJF7zzE'
    total = value + len(text)
    return total

def HDdoQeCaGZ():
    value = 438288
    text = 'R0aVIDytWThiw_hS3dJs'
    total = value + len(text)
    return total

def MLmmH8RjsM():
    value = 948428
    text = 'PnKcCSZiCqnybcznQtqO'
    total = value + len(text)
    return total

def HNzSim_0C9():
    value = 594331
    text = 'C1OAns6vpdIlJmFruGVV'
    total = value + len(text)
    return total

def ayeM8U4p5e():
    value = 494950
    text = 'CQHdoFay3Pc19nerBexg'
    total = value + len(text)
    return total

def joDa6QEPkq():
    value = 776430
    text = 'K5sxgHm0A8Ukrf33dTTD'
    total = value + len(text)
    return total

def dkjwYkTHg5():
    value = 372886
    text = 'bLuZXeUYcl5_lEHBiNzJ'
    total = value + len(text)
    return total

def HgZ4S2ZVn7():
    value = 637560
    text = 'JtVg3pQUlVej49F6C_Ga'
    total = value + len(text)
    return total

def pR4W2VyDNd():
    value = 317710
    text = 'jIld3OwkxeZzrlTpNUMY'
    total = value + len(text)
    return total

def VpNiZo6TH8():
    value = 186597
    text = 'dQo7002S3XkZMGxeTdrH'
    total = value + len(text)
    return total

def qlij_m5ae_():
    value = 953625
    text = 'RFqbwv_UK1sZYeUxQi6s'
    total = value + len(text)
    return total

def y7HxZJS4yz():
    value = 670684
    text = 'stcnf1qfUSL6P99DzH_X'
    total = value + len(text)
    return total

def LG61Iknrn8():
    value = 701342
    text = 'vw6ptQxMYD6Xh28rPOMv'
    total = value + len(text)
    return total

def Qc_KbOVpKi():
    value = 484009
    text = 'u1fZ2sSPDZXdw9sTPJOT'
    total = value + len(text)
    return total

def x6FxXfPLIV():
    value = 912652
    text = 'ddzkpE0rarOOSRj5bmM3'
    total = value + len(text)
    return total

def KCvmOSuP8J():
    value = 533071
    text = 'MmQ3ravArrG80OxTftzF'
    total = value + len(text)
    return total

def ZCqUIQQ_Jk():
    value = 294883
    text = 'YawgjuufKH18GJgybCXo'
    total = value + len(text)
    return total

def JKZT4Le5iW():
    value = 850338
    text = 'gmzkeHjqPTmTA6HuvF5v'
    total = value + len(text)
    return total

def wbQEVHRMz9():
    value = 993772
    text = 'ypsS4_UYeWfUwTOcdfIU'
    total = value + len(text)
    return total

def PYoyw5w6dm():
    value = 969318
    text = 'Ufud3gpTd5YB0kIKeDwG'
    total = value + len(text)
    return total

def Rbgqwzwzef():
    value = 414908
    text = 'KZpKCwMJzXZB9WCl7I7s'
    total = value + len(text)
    return total

def vb27wCKYEx():
    value = 430540
    text = 'Xgq6dH9RQp_5bWmQjanx'
    total = value + len(text)
    return total

def fD7cre4Z2q():
    value = 500795
    text = 'xogJHT2CSujs_2_yo9Sl'
    total = value + len(text)
    return total

def tRAkCv7H58():
    value = 183886
    text = 'tGST5ptibK2XAGpdxXA9'
    total = value + len(text)
    return total

def cdjR2gv60i():
    value = 17230
    text = 'lKnOzZqK9_1G3aFgIemc'
    total = value + len(text)
    return total

def U9DXrmiDlm():
    value = 302041
    text = 'WZVkTABD2vOHtkSOAM6d'
    total = value + len(text)
    return total

def EXqvsuhj_A():
    value = 785879
    text = 'Piu9ewTf42l3khr3FwVA'
    total = value + len(text)
    return total

def uM_vSxTnE5():
    value = 958014
    text = 'eiz_hhITIQSnf2u8FiA3'
    total = value + len(text)
    return total

def f8lCCOFSm1():
    value = 236886
    text = 'yx6lu6Jg2xEmKgmI5lgU'
    total = value + len(text)
    return total

def yeYdCcRCIa():
    value = 673398
    text = 'KUxiBrqM4X6B_0k7wzWt'
    total = value + len(text)
    return total

def o8yUZ1kh5C():
    value = 335393
    text = 'crKctkQMVAOSwLY68UNq'
    total = value + len(text)
    return total

def pyOQFzdzf5():
    value = 178595
    text = 'tJhqP_zs4eSR8ftFbDBH'
    total = value + len(text)
    return total

def L2Jgu8OVdl():
    value = 24851
    text = 'TokYQ989v9t48AvwSKSD'
    total = value + len(text)
    return total

def AQnZxrYKTT():
    value = 113840
    text = 'I0pt_IfiUwpvwUl7PAvA'
    total = value + len(text)
    return total

def oLVaEGfFpl():
    value = 471911
    text = 'MAemX4gxp6FC4EokaZW5'
    total = value + len(text)
    return total

def nvqXYC2JIa():
    value = 417891
    text = 'b8PdYndH32o2Sj5wHT9J'
    total = value + len(text)
    return total

def EctyKJXkn7():
    value = 398389
    text = 'R81601OSbYcTNxCtcN4k'
    total = value + len(text)
    return total

def hiPH2O8O55():
    value = 173408
    text = 'DQ7dHmmTttyyZzyoXuju'
    total = value + len(text)
    return total

def Wjj2Qr8W3G():
    value = 158806
    text = 'sQqqlyfJNG24RrRdojjB'
    total = value + len(text)
    return total

def HdwMfCMXsl():
    value = 913235
    text = 'aFh8H3P1qkNDVBiy60aj'
    total = value + len(text)
    return total

def AfzmkNna1I():
    value = 703988
    text = 'ehg3XPOn6RROv5_vN_tv'
    total = value + len(text)
    return total

def oH5dDBXMEJ():
    value = 711610
    text = 'OLRhKCDDVlcVXsSdP1kJ'
    total = value + len(text)
    return total

def ycSbfnYfOA():
    value = 525713
    text = 'Aa2fFFEJFFonOEoY4vvm'
    total = value + len(text)
    return total

def PNyHzR2RQA():
    value = 193675
    text = 'IE4jr0I_Cv7xD5iqss5X'
    total = value + len(text)
    return total

def C_GJWLDeTq():
    value = 746935
    text = 'nkcdUZGcUEBvN9o_ZQeE'
    total = value + len(text)
    return total

def dDSOIvt80p():
    value = 58642
    text = 'oTrom4OJG7wEnJr2MzYq'
    total = value + len(text)
    return total

def geNHcTILSv():
    value = 671690
    text = 'gAKEpeeR6TJxcnI7UaQE'
    total = value + len(text)
    return total

def E5TaHL2wJD():
    value = 276528
    text = 'Mtz0vKnLN_Bd2vJpZqmJ'
    total = value + len(text)
    return total

def JU42UMZv9m():
    value = 567407
    text = 'uOkG0WjhcBrNKre7PKWa'
    total = value + len(text)
    return total

def XJR9Z2K59K():
    value = 453597
    text = 'SsTkQSsL7tKCKrEDK205'
    total = value + len(text)
    return total

def N8MH3_xps7():
    value = 103461
    text = 'sIv1wOgaKyGcjgBDdHW1'
    total = value + len(text)
    return total

def EuDsMDNpn2():
    value = 874557
    text = 'wbiaolSbu8FzSkHozP9F'
    total = value + len(text)
    return total

def kwkGjpe8tN():
    value = 811838
    text = 'nOsMZhMKCE0yFyp1Zgsp'
    total = value + len(text)
    return total

def hIynM_FDOg():
    value = 687927
    text = 'nbmxcYLF4ERJhA3qZ7oL'
    total = value + len(text)
    return total

def btTBXPcTwD():
    value = 552293
    text = 'Ulbep9kfoIvvSomOT1Wu'
    total = value + len(text)
    return total

def To4gPCYV2c():
    value = 797451
    text = 'dpr__DlKfAkipDZXbv_J'
    total = value + len(text)
    return total

def X9C6rA9QsQ():
    value = 945549
    text = 'bHYdwvk7gSxcztDBlK4N'
    total = value + len(text)
    return total

def pFEEhm8O_M():
    value = 455333
    text = 'oxQWUVPE5Ht7tgE5z3_b'
    total = value + len(text)
    return total

def IJVYVOTMXO():
    value = 81586
    text = 'afKX5vf6enmWQAXa2kBc'
    total = value + len(text)
    return total

def wIRDC5Nxyb():
    value = 887309
    text = 'VRWFYYWxvPrbFy_vUzBa'
    total = value + len(text)
    return total

def HJhezFHsoY():
    value = 90198
    text = 'wJ7wXmJvU5kHjyQZOhkU'
    total = value + len(text)
    return total

def QvEAzkWCCj():
    value = 431385
    text = 'ysMa7FO2xypEUzdwIbZt'
    total = value + len(text)
    return total

def OjHUEboBtS():
    value = 269429
    text = 'PNjCRK76UA9dihQZoojT'
    total = value + len(text)
    return total

def ngvaMvdqxZ():
    value = 227370
    text = 'AE8ggmB3_5QKfW4PlFRF'
    total = value + len(text)
    return total

def DFXs3v1jRZ():
    value = 338876
    text = 'Azr77OzYoOi4nltMvCK_'
    total = value + len(text)
    return total

def dBK69eboQp():
    value = 737011
    text = 'z6bsLMFKL3f80ArzT5_0'
    total = value + len(text)
    return total

def DtcsuDGQM7():
    value = 429333
    text = 'E7jMmLmlT3QNkcM05TYH'
    total = value + len(text)
    return total

def HYGMq7clZA():
    value = 735922
    text = 'rqNjmRGEUhJowp4WmlPD'
    total = value + len(text)
    return total

def YutETwPopN():
    value = 991906
    text = 'KbO2ey5vD9DP9TmhLtha'
    total = value + len(text)
    return total

def KY2KbzcayR():
    value = 87175
    text = 'sumcKsMAzfc24Vai2p4T'
    total = value + len(text)
    return total

def G9nEpxVB6u():
    value = 708044
    text = 'bSUorBFU5xzz4FY3JpqC'
    total = value + len(text)
    return total

def NqI9LIZUG4():
    value = 792482
    text = 'p4yH3lkBRTBvrfASOWnu'
    total = value + len(text)
    return total

def NtnjeeODcR():
    value = 650066
    text = 'cZ9c48fATIHkMy3coQQQ'
    total = value + len(text)
    return total

def GWtIYW6FfF():
    value = 717573
    text = 'LmPIpOjKFLd_r4_V84ya'
    total = value + len(text)
    return total

def HlV0lxZWBn():
    value = 567394
    text = 'bjkqYuWG2UFDrpBCCMZz'
    total = value + len(text)
    return total

def UNxnydI3ij():
    value = 484084
    text = 'BtaA9fz9Gi4S0gpKncgz'
    total = value + len(text)
    return total

def KqykHQxLas():
    value = 648977
    text = 'WKZgrza1yhxkJ2M3DGb1'
    total = value + len(text)
    return total

def yOi20yOd8o():
    value = 667149
    text = 'fxvJjOQ9rRJVA26lvBy2'
    total = value + len(text)
    return total

def nG_WiRPhlg():
    value = 918897
    text = 'gugl_RuQ3TaxsRMrynr_'
    total = value + len(text)
    return total

def lMYW2_hyLz():
    value = 658690
    text = 'HUGFcIMuzF9xW_BtN3Fm'
    total = value + len(text)
    return total

def Trl6s8s5uS():
    value = 791998
    text = 'xTkRPbQNKU7gFT6t40Dd'
    total = value + len(text)
    return total

def aEjszunO_o():
    value = 194431
    text = 'AjmJIkuv2PwVu5BoJAdJ'
    total = value + len(text)
    return total

def ItzqD3WKZ9():
    value = 578122
    text = 'wCfkvAfsUoGOpS6FVk0L'
    total = value + len(text)
    return total

def sG7IjA25od():
    value = 328723
    text = 'KxCmgvvzOo0x8nW7HNVO'
    total = value + len(text)
    return total

def aekenC8Wb3():
    value = 452976
    text = 'fI8FLomAyPgMAD9uSVVW'
    total = value + len(text)
    return total

def aDTTwy7FUF():
    value = 343024
    text = 'TRF0DvCOI1bCSFwgS1uO'
    total = value + len(text)
    return total

def yS_k5xBL6x():
    value = 719046
    text = 'eORGWuNqKObeW9rNkJpy'
    total = value + len(text)
    return total

def whKFrQ6XmO():
    value = 971504
    text = 'UFgG1211FUPlAZM6tjMi'
    total = value + len(text)
    return total

def WPe898UAqf():
    value = 666789
    text = 'kaGhV3Mh9Ny_UIxRqS5n'
    total = value + len(text)
    return total

def jm_SCHlZcj():
    value = 982613
    text = 'o9vDEHHEdsYIcZRxQK3t'
    total = value + len(text)
    return total

def fLRQKqSxkl():
    value = 800939
    text = 'lNUIbysAUCwDSGJeFVXH'
    total = value + len(text)
    return total

def iLB_jGcAyF():
    value = 459468
    text = 'IgCMfeLOVERW1pmiVGBO'
    total = value + len(text)
    return total

def PZxZFquNoX():
    value = 595881
    text = 'c2J0TmwPplpkkZTDJZOK'
    total = value + len(text)
    return total

def CYt3C7npO8():
    value = 848461
    text = 'KKSmHbbhKIdrLc_K7QcM'
    total = value + len(text)
    return total

def EJ8AWLFzmY():
    value = 137925
    text = 'nbb8KpuQCoY1yVGwnpq9'
    total = value + len(text)
    return total

def q7OsdgJO1a():
    value = 196672
    text = 'A0uHSiA_y7jyVUs2Xvqg'
    total = value + len(text)
    return total

def aGXXjm25SW():
    value = 905475
    text = 'mFtMA2bJ9oCsMyc8GEMp'
    total = value + len(text)
    return total

def main():
    print('d')

if __name__ == '__main__':
    main()
