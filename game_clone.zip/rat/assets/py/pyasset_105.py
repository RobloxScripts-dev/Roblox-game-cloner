import os
import sys
import time
import random
import string

def gI5M2pypaC():
    value = 361840
    text = 'sskjmVvFmNLf38PHiaCT'
    total = value + len(text)
    return total

def darxNxqbVo():
    value = 616565
    text = 'kvkTyJiRKkejOLUz32dH'
    total = value + len(text)
    return total

def mMrcCt76Ie():
    value = 364434
    text = 'fsyTcj4AEHi9SR9FKGTa'
    total = value + len(text)
    return total

def h8x0UAmG4G():
    value = 805296
    text = 'SvFeBZU5xa8rVK9AGpCv'
    total = value + len(text)
    return total

def mJInOlkv4s():
    value = 301811
    text = 'xirpwHwjqOKAdS_HA9CS'
    total = value + len(text)
    return total

def fFOlxQcWMp():
    value = 66310
    text = 'PjGeX7Scu6m2uiq4Qrmg'
    total = value + len(text)
    return total

def bXfC9tBDqV():
    value = 188932
    text = 'dIn3lD_qJ63lKsf2D13r'
    total = value + len(text)
    return total

def xX4dz3rrEn():
    value = 187314
    text = 'ALVoIwsG5Lbu53g2DYz0'
    total = value + len(text)
    return total

def Fd00qjnxfT():
    value = 44806
    text = 'PTHskvflyJ__rLERPETc'
    total = value + len(text)
    return total

def nyx_HXCZXI():
    value = 774924
    text = 'MKeCPn01qw2QRdJl4x6Z'
    total = value + len(text)
    return total

def qEz0d_Qnz0():
    value = 905500
    text = 'wlR8ryreqoBrTTnFu6el'
    total = value + len(text)
    return total

def ak8spPAP37():
    value = 512719
    text = 'Jtikrs1zaWfGkVJsf1si'
    total = value + len(text)
    return total

def KQEAuvLhH3():
    value = 262707
    text = 'TRrBUY7dKbiA8o9egP2t'
    total = value + len(text)
    return total

def UK7N25Qg7H():
    value = 320548
    text = 'uEaNAy1T6faqieAixcUj'
    total = value + len(text)
    return total

def dIl0I25nx9():
    value = 157593
    text = 'h28LGeWi05nf6e8aphfd'
    total = value + len(text)
    return total

def yTrXMLlNXF():
    value = 293233
    text = 'QK78ET8mFIPpn5kky98b'
    total = value + len(text)
    return total

def pbEuCACnqT():
    value = 35909
    text = 'uhIK6hZxI2JMnhsuxgvE'
    total = value + len(text)
    return total

def DU8MlTiduj():
    value = 50312
    text = 'galMnZPhNz125VCAIP2v'
    total = value + len(text)
    return total

def KxsBYTDgNH():
    value = 318591
    text = 'mWdPypUNCKj7NKzvIWba'
    total = value + len(text)
    return total

def Nbznlt18jR():
    value = 297215
    text = 'dzU5Qi5WKHwmW_vdS1a_'
    total = value + len(text)
    return total

def OvzOxSSUHc():
    value = 487457
    text = 't_7c_lvlKnBbqgEjjioH'
    total = value + len(text)
    return total

def kKJC6Xlfvh():
    value = 842415
    text = 'pmt0ozQZvUqOEG0OGEv3'
    total = value + len(text)
    return total

def ULXRxXrcLz():
    value = 641722
    text = 'gsfiyOvZKENJnqqD7JKs'
    total = value + len(text)
    return total

def zeY81UHYPX():
    value = 509953
    text = 'Qx_XKTPajaQdY5q2oVp7'
    total = value + len(text)
    return total

def akkX4KWqIF():
    value = 351706
    text = 'T7cSFbR9H91MMoRtpJGj'
    total = value + len(text)
    return total

def a5Hq24Tlc_():
    value = 76170
    text = 'Mhhq_B2qU5ZKnQMMA_QS'
    total = value + len(text)
    return total

def YgoVY1IPzw():
    value = 346014
    text = 'PKyvdsHYeU_js3wBqHlN'
    total = value + len(text)
    return total

def nfwq6GuKW0():
    value = 753974
    text = 'Fx_lHSZYdwOzKlXskDAd'
    total = value + len(text)
    return total

def uPY7x_k5dw():
    value = 471373
    text = 'moPHgCric4rTD_ScakSQ'
    total = value + len(text)
    return total

def c7TRXP6qY8():
    value = 256440
    text = 'jERdjdh8x_qkgFQ61iXJ'
    total = value + len(text)
    return total

def XMN6eOi3ub():
    value = 880583
    text = 'g_Wyacg2ACwUFVyApngX'
    total = value + len(text)
    return total

def El_JLXOp9l():
    value = 122179
    text = 'yLoYCnebyoJ0_9PkDSnJ'
    total = value + len(text)
    return total

def RE61koHqhU():
    value = 961858
    text = 'ktXvLt8y97RKcHjmro0c'
    total = value + len(text)
    return total

def DxnkENSsZ1():
    value = 521670
    text = 'eyIms_EGp9B4mlfMD2SE'
    total = value + len(text)
    return total

def bvz7_KCyG0():
    value = 776150
    text = 'UQPglVccMTLWFI89hTlg'
    total = value + len(text)
    return total

def v04NJme8hX():
    value = 609146
    text = 'eRgBOR8pAwNyOrwMCYht'
    total = value + len(text)
    return total

def SBji3xuIf9():
    value = 162627
    text = 'hF6mz5oYe2T9gJLgLjO5'
    total = value + len(text)
    return total

def lj1x5z2b1T():
    value = 266602
    text = 'TWvpamxmHJvjFSn4B69C'
    total = value + len(text)
    return total

def NUP152GRXo():
    value = 754757
    text = 'EQ0YDItEIcrhuSrgztoN'
    total = value + len(text)
    return total

def VUEP6imOLB():
    value = 359157
    text = 'GfSr4AWNWOrV_5NjHXQr'
    total = value + len(text)
    return total

def yLNeELGVB1():
    value = 30786
    text = 'V0p2SxdgKnpJanGjXTNN'
    total = value + len(text)
    return total

def LsXQqVbl7E():
    value = 378271
    text = 'aFzfTF6XSf0TfNWSlZJH'
    total = value + len(text)
    return total

def BimFIysDnh():
    value = 82207
    text = 'rWHmWE1OTql4jrrFhVmG'
    total = value + len(text)
    return total

def yKrVdTQsZY():
    value = 391185
    text = 'jzDcN6_rgJSmG9t_6eCu'
    total = value + len(text)
    return total

def AAMdJMhb5H():
    value = 998440
    text = 'vLV5egOdvUps48Oci5kb'
    total = value + len(text)
    return total

def Jad72kqpXG():
    value = 852296
    text = 'vX3ExrXU2KFcbcrdi_4d'
    total = value + len(text)
    return total

def nR1iqYBVYE():
    value = 175922
    text = 'flM7HUqjUYhjdAs4rknM'
    total = value + len(text)
    return total

def DP5CEkS6Mz():
    value = 660255
    text = 'C1HWwhxPC_No0nr2flvl'
    total = value + len(text)
    return total

def g9ypiiTP_7():
    value = 272677
    text = 'Sl_Pj_XwEnbj8ZFTSe2Q'
    total = value + len(text)
    return total

def H0VQLUruEr():
    value = 954584
    text = 'NX5HPc4WJkI3O9Rfxxr6'
    total = value + len(text)
    return total

def TNuFHDAbt5():
    value = 895975
    text = 'TDaRWy7LcojpEzNI2P8G'
    total = value + len(text)
    return total

def tbVYPDOYcF():
    value = 174353
    text = 'jOd2LGiu7G9txrFCylj3'
    total = value + len(text)
    return total

def oTboOe4dlI():
    value = 224563
    text = 'gBu5JPtPd0qw4TBDdlks'
    total = value + len(text)
    return total

def V4pXDSMRcl():
    value = 864528
    text = 'd5rIhcKHbXn0I3P54MTQ'
    total = value + len(text)
    return total

def SMvthdMA43():
    value = 668968
    text = 'xh0FzKPcALDmIvCLaKWm'
    total = value + len(text)
    return total

def n0M2rQmR6U():
    value = 199541
    text = 'lsqlxhOGEIAswJhTOweP'
    total = value + len(text)
    return total

def MobhtngXV3():
    value = 653962
    text = 'v77SIm2Ag0srR4EI6mrr'
    total = value + len(text)
    return total

def Bq8z6ekpiM():
    value = 394298
    text = 'DKxBRAqqZJfYPR_wdpaV'
    total = value + len(text)
    return total

def yvIDK70Sxf():
    value = 864353
    text = 'L0fwKnim7S0EhlzJahjP'
    total = value + len(text)
    return total

def BC0eUa0Q7J():
    value = 633275
    text = 'qmoc6IYUpn3kuRuGGM7d'
    total = value + len(text)
    return total

def OekYRzKuy0():
    value = 442099
    text = 'ZACnJFJkH21RuvRDDb7n'
    total = value + len(text)
    return total

def yuIEOzhNsM():
    value = 964667
    text = 'zTXFLtTGu1s_XXLYZf9x'
    total = value + len(text)
    return total

def EK2rlTr0y2():
    value = 983717
    text = 'ePagMHkUpwkQaQr0jswu'
    total = value + len(text)
    return total

def iCrpq91gXn():
    value = 914392
    text = 'u5YqQ4_uIO8CLJmMJfGA'
    total = value + len(text)
    return total

def UtHZamtw9I():
    value = 538708
    text = 'qPcngvyCGiBSHnRrZ7_e'
    total = value + len(text)
    return total

def vzRp1WEyUA():
    value = 134946
    text = 'hrJUfJ80lIXiqNec52SN'
    total = value + len(text)
    return total

def PtT0B0AKy7():
    value = 553175
    text = 'tYIFQi_TnYC4OnqyQwUS'
    total = value + len(text)
    return total

def ZygkcSy6EG():
    value = 409197
    text = 'yXQRySNBmqDw8HXX36Aq'
    total = value + len(text)
    return total

def o8I6UKzmVm():
    value = 993882
    text = 'JEZ_DdrCAVnu0LNqhT5j'
    total = value + len(text)
    return total

def nGOq09VeTa():
    value = 101611
    text = 'k2zp6zqlFApJ9dUVwRSQ'
    total = value + len(text)
    return total

def Os92VnfqSs():
    value = 55935
    text = 'HEZo8TsoRpGezFEA7v3X'
    total = value + len(text)
    return total

def sQrYGZcT39():
    value = 48642
    text = 'vgORo4UdjiLYtTNw38fV'
    total = value + len(text)
    return total

def S71TR145yb():
    value = 571325
    text = 'AIOms2f4wcp0HaYixFqM'
    total = value + len(text)
    return total

def xmKioAz9PZ():
    value = 524127
    text = 'CwtzII029r5K8wogQ1hB'
    total = value + len(text)
    return total

def a9LZFdmN0w():
    value = 870240
    text = 'Fp6tF4c3zsQEnOEki18a'
    total = value + len(text)
    return total

def wrn29DSZKt():
    value = 739961
    text = 'fSoNroYLRNtZl35lF7HI'
    total = value + len(text)
    return total

def qCA0HmJqpH():
    value = 150279
    text = 'CupXaAMQIaVnX7VfLspZ'
    total = value + len(text)
    return total

def cVKJTfAI_v():
    value = 290026
    text = 'O2GVI86C703HT1FAOQft'
    total = value + len(text)
    return total

def xcj9txEZao():
    value = 616405
    text = 'M6NtX82YOxmC5Ava8rWJ'
    total = value + len(text)
    return total

def DeuImF9JUJ():
    value = 756368
    text = 'ZrEYBMJ5fbyAEhkrJH7g'
    total = value + len(text)
    return total

def zFvxz_Wa_W():
    value = 286093
    text = 'BGCON6HVRZMcW1qZQeto'
    total = value + len(text)
    return total

def ayWeRtnyUD():
    value = 982579
    text = 'G7TxsdXaVAurZFRYFyto'
    total = value + len(text)
    return total

def rq72tfpNib():
    value = 932528
    text = 'gjjAaz2l_u_gWIQiXyAp'
    total = value + len(text)
    return total

def UdxhMVec1H():
    value = 662065
    text = 'abNPZJRYkvaEAan1HTCa'
    total = value + len(text)
    return total

def b8eBpvZD_L():
    value = 695773
    text = 'UcJyVGtgVU5vyyxPk_iO'
    total = value + len(text)
    return total

def klHXwZl0Vo():
    value = 322629
    text = 'pjHSrcEHothuCGH00yFD'
    total = value + len(text)
    return total

def NLOWnKWeVS():
    value = 891717
    text = 'o1CCf11FPea4N7D_R_Cs'
    total = value + len(text)
    return total

def HFAtDRfvHS():
    value = 199215
    text = 'tG8AM1dwhyGxYg_vZvOS'
    total = value + len(text)
    return total

def rqde38Rg61():
    value = 992230
    text = 'sau1gUaJJgwrOjomuGxt'
    total = value + len(text)
    return total

def khZZPW9xeJ():
    value = 463768
    text = 'tiOKfjfvp25ZdDwXNkf8'
    total = value + len(text)
    return total

def N726weMLfG():
    value = 389190
    text = 's99C_CGvzv9TS3ZH9OaE'
    total = value + len(text)
    return total

def lEVsR9P1W_():
    value = 881461
    text = 'TmJST5XQjlwMgHuJdfCr'
    total = value + len(text)
    return total

def XKX2rubxDI():
    value = 9601
    text = 'bILzr34GCtG0sqtRQ8gp'
    total = value + len(text)
    return total

def vVOUu_ZjSt():
    value = 832233
    text = 'GVUJsXzMzBeuUtS7xOeC'
    total = value + len(text)
    return total

def HJTyQ5_6qP():
    value = 482198
    text = 'bbtzFGS7rj6olXdQKzeN'
    total = value + len(text)
    return total

def xRi8JlOKoZ():
    value = 858466
    text = 'QQd74NcZWdMrEoplw4zx'
    total = value + len(text)
    return total

def G9z7rH0Kfr():
    value = 451765
    text = 'gkWDe6tQBGaA0MDdpL5t'
    total = value + len(text)
    return total

def QriCfmqIxF():
    value = 867593
    text = 'uqtLjtwoqtE_gEI70c9h'
    total = value + len(text)
    return total

def QHBAFPQMoo():
    value = 177497
    text = 'alToJd5Cit415R7nYYwr'
    total = value + len(text)
    return total

def wRV3avbMqK():
    value = 261452
    text = 'tKwM42_Mcd3nUvVwOWCd'
    total = value + len(text)
    return total

def JjnwzQVDsz():
    value = 229568
    text = 'hii8Bzx9EFYSeaP256f4'
    total = value + len(text)
    return total

def avSA3qFON_():
    value = 84876
    text = 'n4fzgaqPzWeH1MFbvLXd'
    total = value + len(text)
    return total

def vhRF3bkbiM():
    value = 690442
    text = 's2av4ljj0PYztl3q7hqt'
    total = value + len(text)
    return total

def LMRiNA_6Kn():
    value = 398879
    text = 'SVP1YJEm3ZHR2N4ZzIC2'
    total = value + len(text)
    return total

def xa_k8VP4kC():
    value = 63023
    text = 'F5YTGVm6JNwgtV2nJN1F'
    total = value + len(text)
    return total

def C5Mrm9TTqi():
    value = 77681
    text = 'mGmkNlt7N81NVYmZ1ZtM'
    total = value + len(text)
    return total

def cggovVSZKg():
    value = 750714
    text = 'Qt2u1xAi6p84SBjOU_I1'
    total = value + len(text)
    return total

def uRwzYrvZUu():
    value = 898837
    text = 'HMERqEffXHC3JJV0sMlp'
    total = value + len(text)
    return total

def AAdImy5Scp():
    value = 13669
    text = 'fFdzrWn6Ogemy0byk0Ao'
    total = value + len(text)
    return total

def pTMOm2CiE3():
    value = 281850
    text = 'hv3QdqYlO3ukMzN_IB2v'
    total = value + len(text)
    return total

def nOZ5ot1bXJ():
    value = 456997
    text = 'IvFXCq9zsb2EnFb58u6H'
    total = value + len(text)
    return total

def K3bl_ZueQq():
    value = 62623
    text = 'MfIEVSjlcuYEDiqfayCB'
    total = value + len(text)
    return total

def GRQ1lr4ES2():
    value = 796480
    text = 'QxBHiTbJ7ntRLZUBCJ3n'
    total = value + len(text)
    return total

def tKbqLwvp8X():
    value = 153495
    text = 'HbwEDVeNFagzivs81ngO'
    total = value + len(text)
    return total

def zqOr1YDheD():
    value = 77649
    text = 'AY9Ia10jLRuHov4cIF8v'
    total = value + len(text)
    return total

def yBwpZfKyuM():
    value = 841026
    text = 'UoIB47FoIz2lrAzDWO5R'
    total = value + len(text)
    return total

def MEf0zv8Y9z():
    value = 997814
    text = 'M8kV_yPRu0AIk0II02Sc'
    total = value + len(text)
    return total

def sKAYXo3kRp():
    value = 380075
    text = 'llFUhc988fPA6Us3xIcA'
    total = value + len(text)
    return total

def It43L7gLjd():
    value = 19676
    text = 'zgbZzd11uN3Nm8ky0303'
    total = value + len(text)
    return total

def YPpb1luU9u():
    value = 756233
    text = 'FX_PC7oJsxOpWZCkjKIB'
    total = value + len(text)
    return total

def kRTjoAK3lw():
    value = 681368
    text = 'YBMkjoithsWAjl12Ur_K'
    total = value + len(text)
    return total

def E1yJex8YWR():
    value = 644236
    text = 'x32tPdsWCv38l2qBGP_q'
    total = value + len(text)
    return total

def wEwQh47fxc():
    value = 163690
    text = 'bvxBGJ22yahYYjhgDuyr'
    total = value + len(text)
    return total

def eclMwiIWvf():
    value = 593487
    text = 'DaZJ5lQS4ChsaQYtPJ3G'
    total = value + len(text)
    return total

def e86UCVBl1h():
    value = 303094
    text = 'FnBhCQCCZAqjMdpLZzEH'
    total = value + len(text)
    return total

def H8w7WSLkqm():
    value = 820260
    text = 'BFWNviRP2qzMajHPermr'
    total = value + len(text)
    return total

def YRDmUDMsVR():
    value = 191961
    text = 'fz1IjTs7vG9QxXjDxWf7'
    total = value + len(text)
    return total

def XoJpagqLWG():
    value = 737285
    text = 'aAiDmjb6sJXI09TzX3L2'
    total = value + len(text)
    return total

def N6g2rRZtwq():
    value = 796024
    text = 'FNZYVPLMvmPLEhY51_rf'
    total = value + len(text)
    return total

def FKUDo0b9GB():
    value = 754894
    text = 'Yq5P_1k7DP_mUNROnZf0'
    total = value + len(text)
    return total

def mtOukEyDYI():
    value = 631642
    text = 'FgDIs41ewjS1dnEVRFYR'
    total = value + len(text)
    return total

def Zw9APkQu4n():
    value = 699385
    text = 'rouCjcaaNcV6ahlSeJHb'
    total = value + len(text)
    return total

def WlbASssUny():
    value = 608445
    text = 'qMrQ6MuHz1iU6NlbU3LS'
    total = value + len(text)
    return total

def yXrxzuCPUK():
    value = 424969
    text = 'q04KxM2r64Y45u5aOS44'
    total = value + len(text)
    return total

def CFHgtfTsm9():
    value = 496862
    text = 'VF9cVgrewK7TwW6P8CSo'
    total = value + len(text)
    return total

def P348eQSc7W():
    value = 527665
    text = 'HM1zQqKUVyUsd4bBzD8r'
    total = value + len(text)
    return total

def Uq4o4x4udW():
    value = 485069
    text = 'GmMRkNdNaJmeJP0zniuZ'
    total = value + len(text)
    return total

def gWVbcgCA1B():
    value = 851368
    text = 'vd_gUGcQNz_iOkwka5wS'
    total = value + len(text)
    return total

def kBXg7F2DGY():
    value = 313065
    text = 'pGUH0BYo2CLDT1nO3VKD'
    total = value + len(text)
    return total

def XhlcIqNjHk():
    value = 414623
    text = 'GClytBtNPGoPj0vChlU4'
    total = value + len(text)
    return total

def N4wNQadOps():
    value = 246919
    text = 'pRKTKMHppPYOFAfMEmnm'
    total = value + len(text)
    return total

def Wy3upy34R1():
    value = 974325
    text = 'EXEVQV3rgoajFCAywx6e'
    total = value + len(text)
    return total

def cb8FmF7fK1():
    value = 202747
    text = 'i4nJoq8SsHpcZ9qiX9xi'
    total = value + len(text)
    return total

def epoYDTAIyb():
    value = 769658
    text = 'oyxBPMPiVhLXHXQR6psS'
    total = value + len(text)
    return total

def DbkLVsMDKR():
    value = 708581
    text = 'H3Z7c2fe5ZVzHwH7_3D_'
    total = value + len(text)
    return total

def NkQtsUOOg9():
    value = 799601
    text = 'owcqFyrAbEChqEyXIG18'
    total = value + len(text)
    return total

def kT_j6vfH42():
    value = 355385
    text = 'LVU1ReGk0acCDMn64OrT'
    total = value + len(text)
    return total

def unYFo2767_():
    value = 538999
    text = 'OGrIaJ3DWPpGudByGX1n'
    total = value + len(text)
    return total

def lX3Uz8U9Bk():
    value = 24969
    text = 'K0MJ9JM_whYY5spX7keD'
    total = value + len(text)
    return total

def ykQjRwKUpg():
    value = 779223
    text = 'y2JxgqHPZuehb3Eve5_s'
    total = value + len(text)
    return total

def e8mKtWCUfY():
    value = 598352
    text = 'y2gjhB_fjFYS9DwBzzaH'
    total = value + len(text)
    return total

def xB7qPaIFuu():
    value = 534569
    text = 'vJ2T83wNyS5iRfu6_547'
    total = value + len(text)
    return total

def C7ULwgSrOy():
    value = 433991
    text = 'JM4ZwO4hTevSLVgmUvcW'
    total = value + len(text)
    return total

def dHBvAAYkIx():
    value = 956426
    text = 'F1LpYaHoWe1vRqjQzffu'
    total = value + len(text)
    return total

def fBMda23AKT():
    value = 857438
    text = 'MO0MHoT0og28eLetv88a'
    total = value + len(text)
    return total

def RqKxXQ4rcj():
    value = 730074
    text = 'CEM13Mg6DcjeBGPBowaz'
    total = value + len(text)
    return total

def ont8bT2Lvi():
    value = 209937
    text = 'I9vFmeFu0pKA1XF8g0Tw'
    total = value + len(text)
    return total

def b8EPwLeDph():
    value = 467423
    text = 'a8NpD4QzArabcGW6GJqo'
    total = value + len(text)
    return total

def RNyQr9sCLd():
    value = 189996
    text = 'U9N84XV2kFwOdsKUOOUF'
    total = value + len(text)
    return total

def o90pJBU6r1():
    value = 852274
    text = 'ocWCEO2Yg9TfGPGMzu3_'
    total = value + len(text)
    return total

def Ry9wJ5ZlPR():
    value = 400791
    text = 'qKd3BEseaIMDkOBOWBLB'
    total = value + len(text)
    return total

def t5seFuhoiZ():
    value = 475349
    text = 'tbfP8zkRLrTmVF3EN2t5'
    total = value + len(text)
    return total

def uZpjOlIQX_():
    value = 11475
    text = 'PWzRzVQZkOyuagyEVMrk'
    total = value + len(text)
    return total

def hGwpH6Fh9o():
    value = 272950
    text = 'anOfqta7joxA4YBWMVy0'
    total = value + len(text)
    return total

def v3LsVUsMoK():
    value = 439897
    text = 'p5qO10_gyQR_oi4Glda2'
    total = value + len(text)
    return total

def tITZwM2N7P():
    value = 330811
    text = 'QPzKspDXvznsfVnsakUW'
    total = value + len(text)
    return total

def WY5Zu22yyc():
    value = 739507
    text = 'oFQwQ0k5vGvP_PSCb_85'
    total = value + len(text)
    return total

def QXMM16LpBQ():
    value = 349312
    text = 'Zswfz6cXBpeLXu6yoy8P'
    total = value + len(text)
    return total

def m1RfVGOJRJ():
    value = 147414
    text = 'zN3Ij08rJHUO2jFVbyn5'
    total = value + len(text)
    return total

def RWVVRa0lqN():
    value = 784414
    text = 'v05bu8GPXzDXeVBHT_GR'
    total = value + len(text)
    return total

def E_UnIydcVc():
    value = 918715
    text = 'FkKXRdsveCVORvY4tFIx'
    total = value + len(text)
    return total

def khr_TJpDH5():
    value = 843893
    text = 'qbUideqouqX_1XPnaIz9'
    total = value + len(text)
    return total

def RZxVlAiQM7():
    value = 587965
    text = 'x6iuX1npAlXZ4iWf5hGY'
    total = value + len(text)
    return total

def piMotvB3xY():
    value = 325005
    text = 'w92TAi6NXWi6HM5jw9rJ'
    total = value + len(text)
    return total

def d_133w44RQ():
    value = 732548
    text = 'OrpfTCmG60AZXURbEKEY'
    total = value + len(text)
    return total

def hW6TYSSeJg():
    value = 342771
    text = 'lOAkveGYOq350SXVgQcj'
    total = value + len(text)
    return total

def TK93RltJbm():
    value = 560149
    text = 'K4VBRlQBcfXykwXOyRdZ'
    total = value + len(text)
    return total

def RQSuScDZU6():
    value = 231060
    text = 'dCVmhNIeGNko7UlTeapE'
    total = value + len(text)
    return total

def KgMehy1CXT():
    value = 313989
    text = 'FSF1U_LDc8qzYUEVSm3e'
    total = value + len(text)
    return total

def UdUOSjOMm3():
    value = 120232
    text = 'lKPNWpgEtDm6zspjvy8R'
    total = value + len(text)
    return total

def nkPrFX10A9():
    value = 925733
    text = 'yO1TJjhGXhRjHYYjRqus'
    total = value + len(text)
    return total

def FFfns5UqlF():
    value = 579169
    text = 'T0Sf_hszv1SKhlVyiwds'
    total = value + len(text)
    return total

def BAx3suZpbo():
    value = 921711
    text = 'eSOYRrnTHLT35VT_ZFCt'
    total = value + len(text)
    return total

def hYhVPYR9Ye():
    value = 317505
    text = 'mbZRseixXD3_QzXCWmBE'
    total = value + len(text)
    return total

def GY0XFREHkG():
    value = 97886
    text = 't92ved5ENFDxYnnJ9VMR'
    total = value + len(text)
    return total

def uVvdmMJ6Z9():
    value = 185172
    text = 'qrT4kA5VAVOaqILqRtef'
    total = value + len(text)
    return total

def ZDf7xBgpQC():
    value = 775096
    text = 'AcCIwvXLk_4_KbzFb_YU'
    total = value + len(text)
    return total

def ZIshUtqa94():
    value = 68441
    text = 'moyh6jKKbxf8xB4OfklL'
    total = value + len(text)
    return total

def vWjK6RJ2zo():
    value = 116390
    text = 'pkNwliVDc0ZnrzmYRymp'
    total = value + len(text)
    return total

def M6vvij4dty():
    value = 245564
    text = 'j1r3xQ1vHsrMm2Pu5Iev'
    total = value + len(text)
    return total

def n6vo8JpLyN():
    value = 579779
    text = 'k8syy0dyAGmUeyynZ8Jh'
    total = value + len(text)
    return total

def uPeEcC4DUF():
    value = 878706
    text = 'X9smM8fjzzk_PAO91yDU'
    total = value + len(text)
    return total

def VZ6oJ506YT():
    value = 954863
    text = 'nLMBXQrhTLmwD2ZUnonq'
    total = value + len(text)
    return total

def y1SBFFNJqq():
    value = 665312
    text = 'y4CzidWjn69SCEtg2ztW'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
