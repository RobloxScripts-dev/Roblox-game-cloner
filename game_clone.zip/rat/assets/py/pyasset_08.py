import os
import sys
import time
import random
import string

def LsBUuXrFKB():
    value = 196751
    text = 'yDQX8Qys5_b1w3LDiRUM'
    total = value + len(text)
    return total

def VQWM2WciGe():
    value = 168027
    text = 'njLpzpt_yJnyW7m8L6s9'
    total = value + len(text)
    return total

def zUls2MSPRz():
    value = 377993
    text = 'iF0ZoI05HzrqxzJNWMaG'
    total = value + len(text)
    return total

def GW3urPTpuN():
    value = 934086
    text = 'eIhRDjPt63MOBKRyZdE1'
    total = value + len(text)
    return total

def lYHkyPDmjz():
    value = 389675
    text = 'OKOlArpHtwJTwutvv0pL'
    total = value + len(text)
    return total

def WdmjH0By4s():
    value = 641142
    text = 'Xjf5bUZSjzNyNuQMY6Jk'
    total = value + len(text)
    return total

def LMV_qrtzmX():
    value = 464806
    text = 'rgYPyxsed_FKHb4r5IxN'
    total = value + len(text)
    return total

def cBCk5Zgbb4():
    value = 997456
    text = 'UkmGHL01O3ycY_zMRlEl'
    total = value + len(text)
    return total

def YecpYLF2K3():
    value = 144344
    text = 'uaD4gqP5Uk_Ul7j1s1os'
    total = value + len(text)
    return total

def Q9ksUIzyMr():
    value = 207267
    text = 'Dfb6z_r_lAPbf0bx2nvy'
    total = value + len(text)
    return total

def BUHDrXCI19():
    value = 843971
    text = 'WYQzYyNHtvSU9bgTHFjX'
    total = value + len(text)
    return total

def tjgueXn5VN():
    value = 41157
    text = 'lvudggr5uLqv5MsrnSTp'
    total = value + len(text)
    return total

def e_7QbCjw3l():
    value = 399635
    text = 'q29fW0brX8lHiUPWqL_m'
    total = value + len(text)
    return total

def npbiENtz1J():
    value = 698707
    text = 'quGx5ZCSV_slKic1r9bK'
    total = value + len(text)
    return total

def u6DlmgnHxg():
    value = 402375
    text = 'xc_GQUosIIidlEhQr6xp'
    total = value + len(text)
    return total

def aCK3wlYQ0N():
    value = 849117
    text = 'gh1jwHhpRH82Fvs4t5ol'
    total = value + len(text)
    return total

def n4o45gkDiJ():
    value = 483239
    text = 'JM5DRtXuexp2Xt9_Hqpo'
    total = value + len(text)
    return total

def cvUEdpP0wa():
    value = 985271
    text = 'jYa3wMqnSF675QnxrqXp'
    total = value + len(text)
    return total

def m4qkvXlrAZ():
    value = 572036
    text = 'P_Wvl2idaz3W8o89FBu8'
    total = value + len(text)
    return total

def Ws0SZCZLrS():
    value = 643750
    text = 'cTWPNjxDw4TZzhs8suHW'
    total = value + len(text)
    return total

def k9aMmsKzlv():
    value = 457538
    text = 'CFvYvllTMCrk4XCCp01j'
    total = value + len(text)
    return total

def b65QhhZ_W3():
    value = 781231
    text = 'WWOhI_V3pkPqRKUcAEIW'
    total = value + len(text)
    return total

def MVekyIZ0vp():
    value = 912666
    text = 'OnfXc8x7F43WHLcpwSG0'
    total = value + len(text)
    return total

def EgeoPVr4k7():
    value = 960061
    text = 'kcyMj2ARxVtpCtPfd7zw'
    total = value + len(text)
    return total

def hkqM6vOZRl():
    value = 899611
    text = 'ZFoKldzM6iK8HjSsbMqH'
    total = value + len(text)
    return total

def fiVRzzhp7w():
    value = 550610
    text = 'aUUonDxoLVxvAe1quoz3'
    total = value + len(text)
    return total

def m4_im_q6gU():
    value = 753429
    text = 'yEU2tI7X2qMwuck_zA0a'
    total = value + len(text)
    return total

def p89Q1VbXUF():
    value = 551580
    text = 'iEYugUGvj7WUsPMGEolW'
    total = value + len(text)
    return total

def AbgJ9sxlaj():
    value = 63736
    text = 'RAUd3t1ef0QRpElbZKJF'
    total = value + len(text)
    return total

def LbzBgfsreH():
    value = 928300
    text = 'YFSQEXhghCjX1_ws0BFf'
    total = value + len(text)
    return total

def ka6I7OnrPd():
    value = 421154
    text = 'FK7ab6IRdXHaxFPVuR18'
    total = value + len(text)
    return total

def P5KoXQaa0w():
    value = 8197
    text = 'FWsQ4E76nlwHTSkBzd0q'
    total = value + len(text)
    return total

def nAcmNVO_VS():
    value = 810634
    text = 'qHs0EA8RotX1c8c1lrdD'
    total = value + len(text)
    return total

def HsDhUNn5_0():
    value = 856413
    text = 'ket9CodR5nCMM7p1GI2N'
    total = value + len(text)
    return total

def V7oZfGidSb():
    value = 224040
    text = 'cyCw2A87nsgHxBKheok6'
    total = value + len(text)
    return total

def CTTZ6GnPp5():
    value = 352907
    text = 'whNdNvYjCxMVnMHhmTWd'
    total = value + len(text)
    return total

def drEdVqTUuH():
    value = 753452
    text = 'jyIw2LiBoB2bmCZxI3jr'
    total = value + len(text)
    return total

def rPa1nHOoa4():
    value = 133092
    text = 'u2sU4VoAliodv6E7lX1a'
    total = value + len(text)
    return total

def e8FEKAYGUs():
    value = 786124
    text = 'FuklswQO6BDaOf9xUHBG'
    total = value + len(text)
    return total

def NXHk4pxXC4():
    value = 909714
    text = 'UMkBtsKwU0GUJGEAH_Ys'
    total = value + len(text)
    return total

def UIh6FRpviI():
    value = 572995
    text = 'cmHPTSTqjiQNghi_zgs6'
    total = value + len(text)
    return total

def McXiZBiXVr():
    value = 121249
    text = 'FxL1lc0BHkpnoa96V8hg'
    total = value + len(text)
    return total

def lQBOP1byED():
    value = 906775
    text = 'KQRPRMRyXeBeT7no67eG'
    total = value + len(text)
    return total

def OwDAPAt75Y():
    value = 394757
    text = 'BeUDi9k1FEvLdZcrdyUu'
    total = value + len(text)
    return total

def DLEFP_8QlO():
    value = 912794
    text = 'pzpQnnUNVen1bsFaCzhG'
    total = value + len(text)
    return total

def UG7Z75_WWe():
    value = 433530
    text = 'RmnYtOrJy0oxY7ML8wsa'
    total = value + len(text)
    return total

def KO1jNnucYG():
    value = 883368
    text = 'TW94AKOsgg62DpKgNaYa'
    total = value + len(text)
    return total

def hYOSabT4du():
    value = 784605
    text = 'WTrtRLPXJ_K7_Jy_jac4'
    total = value + len(text)
    return total

def DpYnCw5fmF():
    value = 270873
    text = 'XBOMOmy_2rZORakcDGAu'
    total = value + len(text)
    return total

def uhs3c4gEir():
    value = 107126
    text = 'VQfsifpVzVv42WfEHcO4'
    total = value + len(text)
    return total

def vLl8Dr7TLN():
    value = 174195
    text = 'kRAPUFkAKwLezx6ALaNy'
    total = value + len(text)
    return total

def WYiEXciQWp():
    value = 896498
    text = 'RdA2UIgrzFqWxEQ40YWK'
    total = value + len(text)
    return total

def OPT9UWGtqv():
    value = 729141
    text = 'St8THoki654vref4yCQK'
    total = value + len(text)
    return total

def HAMYtjcJ4w():
    value = 141110
    text = 'NL17y8E5Ry9iHIgemyT0'
    total = value + len(text)
    return total

def pyf5H94Amu():
    value = 769839
    text = 'wMrU5oFXL_9rxBjfXyOL'
    total = value + len(text)
    return total

def HP65TTWBhz():
    value = 860583
    text = 'Dn4waEAUdxJZ_oMaQdT3'
    total = value + len(text)
    return total

def kb6_zoVjbQ():
    value = 586872
    text = 'XySoIjBlMi2LUMP8vbQM'
    total = value + len(text)
    return total

def zfqtR1smjw():
    value = 977136
    text = 'lKfbV8w7bsPie1fYrGdr'
    total = value + len(text)
    return total

def uGGJkOBoiW():
    value = 447834
    text = 'dKhcg2Un3nNANx5hbi0E'
    total = value + len(text)
    return total

def IEQwXgWeRM():
    value = 472666
    text = 'xFVLtXMqhWfDE2TJTeSR'
    total = value + len(text)
    return total

def pOZpngpII4():
    value = 608952
    text = 'u1lCnz0oWs3q6WXc36k2'
    total = value + len(text)
    return total

def hk7JPPLNdQ():
    value = 575843
    text = 'oYHoeEYarvE6reiXbomq'
    total = value + len(text)
    return total

def BXCxKGUEyj():
    value = 423478
    text = 'v9Otva6AxFoJW631_2eE'
    total = value + len(text)
    return total

def ag_5qaZeXZ():
    value = 139823
    text = 'Im44wSj_7_oxFhWTAK10'
    total = value + len(text)
    return total

def q4VX4Abk9i():
    value = 594923
    text = 'Mb1HbCF0zTds3NXxfLY5'
    total = value + len(text)
    return total

def UN9u7LpLVL():
    value = 292360
    text = 'ntutZQ_wr_pv3yXLtJ3O'
    total = value + len(text)
    return total

def LYaORkogkY():
    value = 831162
    text = 'oc2B60Vzv58V1aZ17HQV'
    total = value + len(text)
    return total

def MJfDfgBBKt():
    value = 586660
    text = 'ck7fnSLXFYv1xIwwpRxC'
    total = value + len(text)
    return total

def rJN4kZdOGX():
    value = 439482
    text = 'mr9efqitQFwtXPhPdf0G'
    total = value + len(text)
    return total

def kDMDIn85eF():
    value = 572333
    text = 'XGlc0KoaDJxV5sfOnTiX'
    total = value + len(text)
    return total

def aLyDD6onJB():
    value = 633328
    text = 'ZtPuAt4gLf3Loje4tZcW'
    total = value + len(text)
    return total

def T0F5n4NksQ():
    value = 75092
    text = 'PSBCTPkWPAkz01fHQmXU'
    total = value + len(text)
    return total

def YWnv672B8Z():
    value = 258501
    text = 'Jdr0whT5PV2mHykAbKez'
    total = value + len(text)
    return total

def QuPOEZox73():
    value = 256851
    text = 'mVJzco76sdktZerW5ED5'
    total = value + len(text)
    return total

def zYKyW5waPf():
    value = 117374
    text = 'XNrMkC_sEPSyBEJglLRA'
    total = value + len(text)
    return total

def iUfsqDK4l_():
    value = 163575
    text = 'urDKQJu_iuOmzoRAo1Ux'
    total = value + len(text)
    return total

def Swur8N8RIP():
    value = 915574
    text = 'nyDH6VvgJ0SEIaOz3fUp'
    total = value + len(text)
    return total

def yxXknZSnQH():
    value = 437070
    text = 'eOKl3AQ9D53jQ0wwfJZH'
    total = value + len(text)
    return total

def ronXSCqoF9():
    value = 227335
    text = 'hwH5dJaTxxytuFmabjGj'
    total = value + len(text)
    return total

def wiDscXV9m3():
    value = 969480
    text = 'yZNs4pF6l0yyUHKCUpJ7'
    total = value + len(text)
    return total

def vFLLrDZoDN():
    value = 699382
    text = 'xh1YcL05iFNqvipse7Fl'
    total = value + len(text)
    return total

def H4khmUbafI():
    value = 513917
    text = 'dMbm8mnJuKv1TQVO5SrB'
    total = value + len(text)
    return total

def hr4Fkc143a():
    value = 676091
    text = 'bRvGXh1awhE_ed3tQeV_'
    total = value + len(text)
    return total

def wpaFBdpdQj():
    value = 851927
    text = 'gY_hwmexVvqd_3VWb4FB'
    total = value + len(text)
    return total

def bVw9oXChkR():
    value = 196880
    text = 'ZUlOOw0vqrUM7c6yG7HF'
    total = value + len(text)
    return total

def tgM2Tb1cN3():
    value = 896829
    text = 'bDj5Ksqqqlka0Pfv8KIq'
    total = value + len(text)
    return total

def cxWaAuZaQq():
    value = 119181
    text = 'sHehRufYNemofk4AUw9H'
    total = value + len(text)
    return total

def ELtCV8nADq():
    value = 474704
    text = 'lLlInJuUvXpc2oBDcrbn'
    total = value + len(text)
    return total

def p4w1zfi1oV():
    value = 889103
    text = 'Vbplk2N6kE22pbf3ldY1'
    total = value + len(text)
    return total

def VyGLHA_fXH():
    value = 957066
    text = 'g1aKdb7KYGena8k_vy83'
    total = value + len(text)
    return total

def L9MB4rSERD():
    value = 863900
    text = 'cKUmp_I47SErqMpxn7cY'
    total = value + len(text)
    return total

def uVkvENHZDx():
    value = 381430
    text = 'Z6jMsvWFaYkmxOnbviPV'
    total = value + len(text)
    return total

def yloFy_uKjW():
    value = 240260
    text = 'iF4MIj9t1oYzws8xDI6s'
    total = value + len(text)
    return total

def lsTCmhKcyh():
    value = 987216
    text = 'Ww9zrQTZbw2K1DQ1ywvt'
    total = value + len(text)
    return total

def QWuZtiV07o():
    value = 626998
    text = 'kqSEE64WGX8v1zOssqbt'
    total = value + len(text)
    return total

def jiZzRkJTMP():
    value = 349627
    text = 'YQJ1KWstoKzDSa3TOrnX'
    total = value + len(text)
    return total

def oIXpDy00YY():
    value = 903888
    text = 'LmYArZLor79ubf6c0Zia'
    total = value + len(text)
    return total

def r7Xg5ZLrd1():
    value = 935007
    text = 'M_W3mavf7TVPN8goMzfi'
    total = value + len(text)
    return total

def ZW3iM1frVX():
    value = 326298
    text = 'yhCssYfVrFFE8g8szQ2t'
    total = value + len(text)
    return total

def rOqLZkNHUH():
    value = 77990
    text = 'ENeJriWZ7vqyj383LOtZ'
    total = value + len(text)
    return total

def k5kXQ1jGak():
    value = 387616
    text = 'kcOb7JPqi__e1V70aytZ'
    total = value + len(text)
    return total

def arxWGAoEUL():
    value = 300031
    text = 'HIXTAIblRy9kYD1Ngtsf'
    total = value + len(text)
    return total

def LJhw1oEl3S():
    value = 84389
    text = 'LNWbT1yMVHOsn_Ut7n0e'
    total = value + len(text)
    return total

def z9E_R6eNUM():
    value = 808429
    text = 'aoQF0n1Dyy5u429TBSM6'
    total = value + len(text)
    return total

def Za77tJ9Eak():
    value = 22069
    text = 'DCMk6DleySLaTt5y3V2q'
    total = value + len(text)
    return total

def NKxgPnICi8():
    value = 981683
    text = 'tW4PAtFtLTpm7EGUu5s0'
    total = value + len(text)
    return total

def inbN1kfQTW():
    value = 991062
    text = 'MNRc8Bj44JqzdJYSt_uB'
    total = value + len(text)
    return total

def r2C82Jgmic():
    value = 864524
    text = 'wdZZffxKQjnHXRiuSQvj'
    total = value + len(text)
    return total

def ySMniE9Mjx():
    value = 476357
    text = 'AJpVbpaTjieXJuztoGla'
    total = value + len(text)
    return total

def tUPHAzuFKw():
    value = 504617
    text = 'KKVaQsIpGXvbk_QZEmkQ'
    total = value + len(text)
    return total

def YeZtPJZWS9():
    value = 320227
    text = 'OAFE_Vq0Ul3xQmekz97H'
    total = value + len(text)
    return total

def DrQqaVw60b():
    value = 380068
    text = 'dShPMH4uc7_YR7cTFqqp'
    total = value + len(text)
    return total

def rNI0RL7utq():
    value = 186913
    text = 'B_yNuG7CuozIycjOTUU4'
    total = value + len(text)
    return total

def A1DfDWD75e():
    value = 442813
    text = 's5zgD84Ue0q5hIiBz441'
    total = value + len(text)
    return total

def ye2TDIroXf():
    value = 546434
    text = 'Boh1WzjkAiQ1dfyZ7vta'
    total = value + len(text)
    return total

def kRmtXvZU7g():
    value = 526531
    text = 'yMUeDJSX7l9JYuqfNVfH'
    total = value + len(text)
    return total

def Td40K7bgee():
    value = 191452
    text = 'poCpvY54xsSst9lMn2_o'
    total = value + len(text)
    return total

def p0LTIiyClq():
    value = 747813
    text = 'LN6xk0Pb427dbuSQcX8_'
    total = value + len(text)
    return total

def Mj1VnQ47CK():
    value = 577478
    text = 'dxifpSPdffrtsh53IerL'
    total = value + len(text)
    return total

def CoK32rRGIq():
    value = 952259
    text = 'GP3jkePBgWhvl_7nKHwC'
    total = value + len(text)
    return total

def r5G_N7DEfA():
    value = 431414
    text = 'qlvyhDmwDseR1CAyZKyw'
    total = value + len(text)
    return total

def n0LTiR8JRc():
    value = 360576
    text = 'VzhzT5y8PdbY_EzXROmZ'
    total = value + len(text)
    return total

def neKUtrkWgm():
    value = 35828
    text = 'bwfWlp2et3fCLsrP0LFy'
    total = value + len(text)
    return total

def KCp_bagQfQ():
    value = 996902
    text = 'VkmYntozMOswRNsGBuuT'
    total = value + len(text)
    return total

def bKf5BANaTN():
    value = 670811
    text = 'UHsW7qAbFMJri_0jLWjC'
    total = value + len(text)
    return total

def fLIWQpbr_U():
    value = 979952
    text = 'fIpmNuHBKW91vJS6ewEw'
    total = value + len(text)
    return total

def Y8RoDB5fXG():
    value = 407701
    text = 'PxrNGgxS_f0wDbNOBExo'
    total = value + len(text)
    return total

def bRm7MBbIJt():
    value = 925335
    text = 'fjIzB6gjN39MZC4pOjx4'
    total = value + len(text)
    return total

def zD9gzoopa1():
    value = 455373
    text = 'gWPJcUm05NronGdoYGo2'
    total = value + len(text)
    return total

def ypf4q_Np45():
    value = 353466
    text = 'o2BxXgc6yJykdKoEcGj5'
    total = value + len(text)
    return total

def u7MtsnWLJe():
    value = 793635
    text = 'Prna6LCVlBh8R6GBuJ9K'
    total = value + len(text)
    return total

def LJ86Lo5lGM():
    value = 441587
    text = 'K7esSfbxY_WT911ZB3xO'
    total = value + len(text)
    return total

def LqpqfTBgnu():
    value = 386187
    text = 'RxL3AnFwlh8IWh4DwuC3'
    total = value + len(text)
    return total

def K6bJxMEuFm():
    value = 502219
    text = 'KRfxKbYJcd1We2tjGn4p'
    total = value + len(text)
    return total

def AWXwoIU9PV():
    value = 439503
    text = 'cOYLVzl6yYiv2foE6RY6'
    total = value + len(text)
    return total

def rOkyeWK9_f():
    value = 817113
    text = 'SkXPRRW_Quqo4qICK3pJ'
    total = value + len(text)
    return total

def LxoouW3kYv():
    value = 326333
    text = 'AG_J3hgvSeuxIWzcZdYn'
    total = value + len(text)
    return total

def mnak3dIEPv():
    value = 607145
    text = 'O9x3rHUfjW4OZiVnUyPw'
    total = value + len(text)
    return total

def kLvCrZHMSx():
    value = 271215
    text = 'GExPL508LQRHX3eK5il8'
    total = value + len(text)
    return total

def RsjxPdhcSf():
    value = 571717
    text = 'onxUbHJj0ftLQH9mYFzw'
    total = value + len(text)
    return total

def IAd8SKMOiJ():
    value = 289952
    text = 'sKk69qrgjRYbgU5_1CzG'
    total = value + len(text)
    return total

def zGFp0B0c0i():
    value = 215161
    text = 'eH7XmTr9sIJpv2g1x5fy'
    total = value + len(text)
    return total

def wCuGdvrOK5():
    value = 932804
    text = 'p5s5JVa_zxXHoDzW62p3'
    total = value + len(text)
    return total

def tTzdxY3Rqg():
    value = 447742
    text = 'SfDQdrgvj13FLLLRCdQe'
    total = value + len(text)
    return total

def GZ5PCafkwB():
    value = 767723
    text = 'sI7UR9xBg0R3u45YgzFv'
    total = value + len(text)
    return total

def main():
    print('m')

if __name__ == '__main__':
    main()
