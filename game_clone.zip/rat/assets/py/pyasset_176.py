import os
import sys
import time
import random
import string

def xCYZ90Pg7r():
    value = 140951
    text = 'DKDN_A5Lc3YhfK_kEWmO'
    total = value + len(text)
    return total

def kjwF7d3dwF():
    value = 291207
    text = 'eM75ycPFNC9lOlOtOQoZ'
    total = value + len(text)
    return total

def Yov1LvQYEE():
    value = 522857
    text = 'kIRNYRlARvMxAQed5Aqd'
    total = value + len(text)
    return total

def BkhwJ7D8YH():
    value = 434164
    text = 'pLlCRvZk78demeexouLU'
    total = value + len(text)
    return total

def y4bJZNdROu():
    value = 880166
    text = 'ypI0GzLYESTVXyWy8BZR'
    total = value + len(text)
    return total

def gZORWm9eON():
    value = 212068
    text = 'pPlHuNpoPF2teprA3QGO'
    total = value + len(text)
    return total

def AODgWQWKAK():
    value = 102760
    text = 'VJRdgmn4CXBpeS6bZHnX'
    total = value + len(text)
    return total

def p9bnXJcndl():
    value = 211339
    text = 'UBrblBT8N5DLPNYiI9ce'
    total = value + len(text)
    return total

def mV5H0V3YbL():
    value = 320158
    text = 'YVGuwV71XNTGVA4iA9fs'
    total = value + len(text)
    return total

def DKQ7OksCT4():
    value = 997061
    text = 'mgyTRk9Jf6GdBU4oHuE1'
    total = value + len(text)
    return total

def LZEIUzItQR():
    value = 352511
    text = 'ii3N9qOBMmgBkwKSvAOt'
    total = value + len(text)
    return total

def GPOpdEGbdN():
    value = 891432
    text = 'LeNTGbf0U0prpFHMr7CD'
    total = value + len(text)
    return total

def f1NiNYCFkw():
    value = 409889
    text = 'f4NNyTdozWYljLSXWoT5'
    total = value + len(text)
    return total

def X62ttyBXzU():
    value = 97602
    text = 'yGQlridmmXXB8kRHHPeE'
    total = value + len(text)
    return total

def A3_SsW5iz5():
    value = 234054
    text = 'C_RvoA8xYw4QtjccLEKy'
    total = value + len(text)
    return total

def ewjeKcwlej():
    value = 854519
    text = 'gPgoZqFZ7bjFRnel7eA8'
    total = value + len(text)
    return total

def g9EkQ1g2qs():
    value = 13954
    text = 'uBzYdwniW1MYttQb6uBf'
    total = value + len(text)
    return total

def awSRjiBeQW():
    value = 117265
    text = 'FaeWWi246h5vDrXsM8Wh'
    total = value + len(text)
    return total

def n5AbZluUYr():
    value = 442917
    text = 'KZbvxoQTvdPXCX_2APhT'
    total = value + len(text)
    return total

def OXFTznTCdZ():
    value = 84771
    text = 'vv1HJ48zc4UTP6q_G0y3'
    total = value + len(text)
    return total

def uHRZbbV7hK():
    value = 640330
    text = 'taYKfh6_Qli3wdO6TOqR'
    total = value + len(text)
    return total

def wIGq8z1L99():
    value = 456521
    text = 'xvuhFvib2vc810h4XIOg'
    total = value + len(text)
    return total

def aCdf8XQTHT():
    value = 606324
    text = 'ArOfzImsTs7xkuLgekIO'
    total = value + len(text)
    return total

def Bl_QKo7cgs():
    value = 890824
    text = 'MD9rpH9QdG6Z7fElRl7f'
    total = value + len(text)
    return total

def gx3GjpE5WP():
    value = 653853
    text = 'BSNZ5epkI0z226QxZ4Ep'
    total = value + len(text)
    return total

def m5Cz4RGJOa():
    value = 831021
    text = 'T5VLcUq9K0hnM7ri0oFC'
    total = value + len(text)
    return total

def merx9CFw5_():
    value = 350585
    text = 'L2YaboRMz7hsdl_8_jsX'
    total = value + len(text)
    return total

def g0Guh7Gp6M():
    value = 791427
    text = 'mILnJh7V56MwwPJlrhVm'
    total = value + len(text)
    return total

def Pz4rGluGUQ():
    value = 180728
    text = 'kgSjx1dbIGkO6eyrU4mN'
    total = value + len(text)
    return total

def DtdVZyzPGy():
    value = 413172
    text = 'tWYkNqWeiJLMlkWB0dpT'
    total = value + len(text)
    return total

def mNDsD7VUhJ():
    value = 386209
    text = 'pXIhr95rRRtIH7yQ7PQ_'
    total = value + len(text)
    return total

def sSk6mxdaAA():
    value = 649411
    text = 'ar8a1C3VnqpoAx1HaXUA'
    total = value + len(text)
    return total

def FUfcyduLdD():
    value = 80997
    text = 'K3tWxJvhRn3gn8ZF3PU2'
    total = value + len(text)
    return total

def V2tTHvLzze():
    value = 927451
    text = 'FsekXN4dMTtYjfFRzsDe'
    total = value + len(text)
    return total

def xTGG1NCPGq():
    value = 928806
    text = 'AJNe7UOko7amiTyZFe1O'
    total = value + len(text)
    return total

def JwMep1v1jb():
    value = 582924
    text = 'dQGRxKMitRWFeFK4Tx8r'
    total = value + len(text)
    return total

def kXffs9QIcu():
    value = 35662
    text = 'tapr7FGcRfQ2zRshDanN'
    total = value + len(text)
    return total

def jfOXGV9L76():
    value = 472208
    text = 'i20Y7rd3WayEn6MheOhB'
    total = value + len(text)
    return total

def A9Zf2rXDlU():
    value = 70517
    text = 'qy4hzgKLwpQTWthVz26U'
    total = value + len(text)
    return total

def ydpE90VJe4():
    value = 575900
    text = 'qc50vWqiurGhh1QHxcH1'
    total = value + len(text)
    return total

def ZJui4JgA_2():
    value = 51323
    text = 'iaHBeQ3YUsQ3VZOS_fxn'
    total = value + len(text)
    return total

def V4Ohnie9wo():
    value = 469267
    text = 'LGguSkDyRJcN9CTwIh7c'
    total = value + len(text)
    return total

def XcP4p9QE8Y():
    value = 80664
    text = 'qBZdVqJsycxwmev1yVNE'
    total = value + len(text)
    return total

def GpsP9HAxEw():
    value = 417633
    text = 'QXUHkjWslOcF06zMq14L'
    total = value + len(text)
    return total

def U1Dyqakdpk():
    value = 139345
    text = 'DG8RIkMYFb8PhtHlDK36'
    total = value + len(text)
    return total

def t0iNaNs3yy():
    value = 333655
    text = 'Q4XuLLI32q2JdqjjwA2w'
    total = value + len(text)
    return total

def v09jGSKQPx():
    value = 929521
    text = 'CJAvr0MnKEKDW8zGkOzQ'
    total = value + len(text)
    return total

def s8LGvrqQv9():
    value = 732448
    text = 'ywuGR_iWOJ53NFMaPuwy'
    total = value + len(text)
    return total

def joueFsEYur():
    value = 509841
    text = 'p21S11diqQcOP1VEctCt'
    total = value + len(text)
    return total

def Z5ooILZxM6():
    value = 615570
    text = 'xTeHw9LU93bbvyaOXpyp'
    total = value + len(text)
    return total

def LpSvpQ5Iu0():
    value = 593706
    text = 'zXm_zSsFJ_FklacwxvH7'
    total = value + len(text)
    return total

def TLV7tuPSpr():
    value = 674284
    text = 'nPgDNsJWPOGpgFS8Pail'
    total = value + len(text)
    return total

def zZYlGhvB_M():
    value = 28678
    text = 'FMBEBlURFTLI1rLQTDvg'
    total = value + len(text)
    return total

def XTVzKzKG2Y():
    value = 421792
    text = 'THBZDj1lEzKJY8Ikz_Ko'
    total = value + len(text)
    return total

def H7U1zatLgM():
    value = 535590
    text = 'vBnHb8SkDqP0YhSr6me1'
    total = value + len(text)
    return total

def OHuMQ1zrsQ():
    value = 260258
    text = 'C3qps5TeNNBByIYQhLEX'
    total = value + len(text)
    return total

def see2bhfDRS():
    value = 446404
    text = 'ZFMo2CL5DLUWLX5MXeJq'
    total = value + len(text)
    return total

def aq3ZUQkYZ4():
    value = 776939
    text = 'sQp2Ypn6btZDto_p3OUb'
    total = value + len(text)
    return total

def j4HVJYocBs():
    value = 732322
    text = 'V6n6hjMErxfyjQjJUlDK'
    total = value + len(text)
    return total

def P6Ql4O2nLu():
    value = 452126
    text = 'bzo08tY1kNOy2A3VcF4a'
    total = value + len(text)
    return total

def JlN2RnhQ2m():
    value = 371698
    text = 'TYEfBB6TuTndBBOUoGvW'
    total = value + len(text)
    return total

def MsMwIxvFVu():
    value = 879391
    text = 'O0pFWh_Si8uIKHACWSaY'
    total = value + len(text)
    return total

def cx3vzJLqj4():
    value = 907165
    text = 'c5vhRltuXrUBWOKswHqQ'
    total = value + len(text)
    return total

def ymAm_kgRkl():
    value = 75578
    text = 'c_oZnXz_2l9gY7fgha_s'
    total = value + len(text)
    return total

def JCirjoyxSu():
    value = 414282
    text = 'JvLJ0YjZqQ_JCwwbUA7r'
    total = value + len(text)
    return total

def lFkv9XsvMb():
    value = 621384
    text = 'lvGVksSN9r2lseWcANX2'
    total = value + len(text)
    return total

def NO5ecCwjHG():
    value = 234912
    text = 'jT1wPAHpIAXaGF5kQG7R'
    total = value + len(text)
    return total

def wHQsgo2iv9():
    value = 268167
    text = 'PIJlfYZYiBr1FMHEFq7W'
    total = value + len(text)
    return total

def N_AVOdUYtN():
    value = 641626
    text = 'GmBunr6t38o1XLZN9Yhf'
    total = value + len(text)
    return total

def cu4bN0JohF():
    value = 985790
    text = 'trV4H52L5QAcMP60Jby4'
    total = value + len(text)
    return total

def BPsB_toGON():
    value = 21185
    text = 'UNmWw2IA48QvLQyQrs01'
    total = value + len(text)
    return total

def NXplI_A6y_():
    value = 749981
    text = 'I7hfaTFMc9WwLtB9uJz1'
    total = value + len(text)
    return total

def YdBFsR6Q85():
    value = 330841
    text = 'HLvHh0QFyCql6CILqfVc'
    total = value + len(text)
    return total

def YUv9_w2OUE():
    value = 717014
    text = 'IfIi92hmMdVLO1K_m5Ug'
    total = value + len(text)
    return total

def JEnLwFYOuf():
    value = 636497
    text = 'O4NdFL_cp9H1rreI_JBd'
    total = value + len(text)
    return total

def okakhSqvRX():
    value = 841491
    text = 'VM0LVgkvg06UfKZEOJ6U'
    total = value + len(text)
    return total

def ZaGWRWsbTB():
    value = 401405
    text = 'YUfzBzDAUNPcxO3Oc8jd'
    total = value + len(text)
    return total

def RW5YK46Olb():
    value = 557494
    text = 'mDOYMN4qjFUhdUKtWQok'
    total = value + len(text)
    return total

def Lz2D6ro2mX():
    value = 84623
    text = 'eZREb2PAqrCcwr31xaq5'
    total = value + len(text)
    return total

def BPvYCpIFjo():
    value = 608426
    text = 'CpXqdZKPtAlGLCVg3kB0'
    total = value + len(text)
    return total

def TdhFJi7WGt():
    value = 988769
    text = 'cKYV2vOVPZNskTm9P3pC'
    total = value + len(text)
    return total

def HoplgMgB1Y():
    value = 638386
    text = 'YPrb8JsSGtzp9QDxV96Y'
    total = value + len(text)
    return total

def vF7yrcWIsw():
    value = 672284
    text = 'NuBI_JMeusi4TsrXQA5s'
    total = value + len(text)
    return total

def kCWPYAHFzM():
    value = 179844
    text = 'DFpS5SG8dFRLRzr8t7iK'
    total = value + len(text)
    return total

def L2E56e3al8():
    value = 408706
    text = 'yckJkSbseshl78is6TnQ'
    total = value + len(text)
    return total

def oIRTUiHPcR():
    value = 706846
    text = 'vo2LRS3rQE4322nMadFp'
    total = value + len(text)
    return total

def DhiH9JkW0o():
    value = 730595
    text = 'cMeikKbqrQdbc9c4IpEC'
    total = value + len(text)
    return total

def rAY8Vux3ls():
    value = 844014
    text = 'Ngg5We9cXITIQINVyaFp'
    total = value + len(text)
    return total

def jbqYVYtMoC():
    value = 974992
    text = 'jl4PctoWXAmLT_wJNvWW'
    total = value + len(text)
    return total

def YcfdWGeMBo():
    value = 357260
    text = 'm7Be2pcUU7hPU3BBstnm'
    total = value + len(text)
    return total

def bLJhJKs0_0():
    value = 292372
    text = 'xE943Fj9BP1IAYK2Noxk'
    total = value + len(text)
    return total

def NrEH2whJae():
    value = 962517
    text = 'jiJfKqgpiin5Rpa32spb'
    total = value + len(text)
    return total

def N65s35UZah():
    value = 353204
    text = 'j492ab0RnSfWEvLWfLW9'
    total = value + len(text)
    return total

def p59D6bYVi2():
    value = 513903
    text = 'rsQ7sbSpDJdp59TGfLPO'
    total = value + len(text)
    return total

def mqt9XXrQKW():
    value = 423709
    text = 'G4pDOwR15Ibs7v5oTrMV'
    total = value + len(text)
    return total

def aXkRvZeejC():
    value = 925894
    text = 'G6HoiVhdrnHlTaB6RjSd'
    total = value + len(text)
    return total

def BBY8n9qdza():
    value = 801627
    text = 'sq5JaG79LsuTFtXQbNJV'
    total = value + len(text)
    return total

def AGP8O2eRhd():
    value = 171043
    text = 'BItykJTFZYreGASAEa7l'
    total = value + len(text)
    return total

def bcyInrxQK2():
    value = 86417
    text = 'V6Y1njsgANXf9O9fqJbD'
    total = value + len(text)
    return total

def QkSgkkSL8C():
    value = 97555
    text = 'npwkBkYNbx2Xrw2Ycz8q'
    total = value + len(text)
    return total

def vQMW3WRIy5():
    value = 714162
    text = 'o7jMCUFdCyjr7V7vG7KD'
    total = value + len(text)
    return total

def Ru683L6YOR():
    value = 206588
    text = 'CHEAm0oDFsjskSQUdDFK'
    total = value + len(text)
    return total

def CnOtL_YCgL():
    value = 506288
    text = 'fN2AIHgb3DvgbwQIIDqH'
    total = value + len(text)
    return total

def on_O9muiKC():
    value = 981449
    text = 'aZ7BkJ1UpGwznT2Kkyoj'
    total = value + len(text)
    return total

def URyD1Ga10l():
    value = 257673
    text = 'f78d6GFMENzhN1_agZk_'
    total = value + len(text)
    return total

def NpirFc0kL1():
    value = 828878
    text = 'gqeO_eI4eTr1DhmrBstf'
    total = value + len(text)
    return total

def YKCELYysnH():
    value = 59293
    text = 'GqkZMEI12DV_EYFViH7h'
    total = value + len(text)
    return total

def HE4R2FnzbQ():
    value = 586295
    text = 'Wzp_lKL_hbPWu_RuERd2'
    total = value + len(text)
    return total

def gFd1i8oJQf():
    value = 64860
    text = 'KN3hp9GxVpssYILQcqq9'
    total = value + len(text)
    return total

def tgUqDzDD9T():
    value = 841510
    text = 'Tflfcmkk54UafXa3mK_j'
    total = value + len(text)
    return total

def oG4mjZFiUE():
    value = 930340
    text = 'qtxOReVH3t7rSVHeSwYL'
    total = value + len(text)
    return total

def LlySCv8uM8():
    value = 263647
    text = 'h17_vJAbzCRNlgb7SBdf'
    total = value + len(text)
    return total

def YlrtRYbYOM():
    value = 62513
    text = 'FlLbqBTim8tD19352yAe'
    total = value + len(text)
    return total

def aDczxudW1O():
    value = 662838
    text = 'zzayZMKDr2XX753yYJvL'
    total = value + len(text)
    return total

def mhrJyGMbll():
    value = 612894
    text = 'kbJCZUzgjkANm4R1WwvG'
    total = value + len(text)
    return total

def Crq6yn4VDD():
    value = 184828
    text = 'sGRGq_mSj0Yb86GxH_Iw'
    total = value + len(text)
    return total

def SNNvVTMqqR():
    value = 841857
    text = 'IeeQVMBGSxwJ3Yc19N31'
    total = value + len(text)
    return total

def TfrIoxi5Y8():
    value = 934062
    text = 'AtnQWFM9tDUcvUjYwgUq'
    total = value + len(text)
    return total

def m3FL57drHb():
    value = 607739
    text = 'SfmFxSLv53BrOqvwtDS1'
    total = value + len(text)
    return total

def tGO17qhj9u():
    value = 339364
    text = 'ISxDTx_p6mlwyBVIYMZw'
    total = value + len(text)
    return total

def lsRsZ7Fnv4():
    value = 704103
    text = 'VL8GXbOK3cIWg7stxeAK'
    total = value + len(text)
    return total

def vXcQaxOLaJ():
    value = 389349
    text = 'k6CRmbqFLvbLThIYPnQj'
    total = value + len(text)
    return total

def qb3_lkNgHf():
    value = 719299
    text = 'JDK_eIg9sK3ZKZTu2RSB'
    total = value + len(text)
    return total

def zi2ue0Pqtm():
    value = 88719
    text = 'udbr50IETMlcRtX0iPRr'
    total = value + len(text)
    return total

def Te8EVWS2Il():
    value = 602352
    text = 'h9B3LRlg5dIkbySny2vj'
    total = value + len(text)
    return total

def FU47CLT0G7():
    value = 732675
    text = 'kh7tR9Obp6DqTpay4pgS'
    total = value + len(text)
    return total

def gFiXiGbWi1():
    value = 85683
    text = 'shtICv3lb1g8ChAbrhT8'
    total = value + len(text)
    return total

def hsQDQJScbb():
    value = 320945
    text = 'D5l6v7TR9Yf9MdFMekyV'
    total = value + len(text)
    return total

def uaCkCT5Haa():
    value = 831178
    text = 'f_X3gcFgUsSwHhnxWFiq'
    total = value + len(text)
    return total

def zj0w2jU5Bn():
    value = 505885
    text = 'CKAXSgNjXyV74gTulb6W'
    total = value + len(text)
    return total

def fHt5F7XgCI():
    value = 69978
    text = 'UmyJ6CL57HNTr8lqOKwa'
    total = value + len(text)
    return total

def KjK0k0KI57():
    value = 611210
    text = 'nFdSmzacQ4LtagWWEQ2C'
    total = value + len(text)
    return total

def oTOUAHuw4j():
    value = 628486
    text = 'N2UvhbtHb0lvuyctFyi2'
    total = value + len(text)
    return total

def EOyMzCt86b():
    value = 741854
    text = 'N3nP2dJNI4hTQIxiumvZ'
    total = value + len(text)
    return total

def IroQ1pSLcM():
    value = 77254
    text = 'vOVRQbZpWJ_pcqdB8iN2'
    total = value + len(text)
    return total

def bPVCI02JnL():
    value = 117891
    text = 'qsuAz6pl1ReE4Rhaahr2'
    total = value + len(text)
    return total

def guyR5PpJjr():
    value = 448078
    text = 'crBeMudU0Jbf28I1dnVx'
    total = value + len(text)
    return total

def OGjH0cWi8y():
    value = 109124
    text = 'sEJYivVDOh3rfoRniTJW'
    total = value + len(text)
    return total

def rf7NRSgh5y():
    value = 278985
    text = 'Ghaw67kXEvTzCLYfdslz'
    total = value + len(text)
    return total

def bpre1gQUbn():
    value = 212320
    text = 'NAu2t4PNEaO6KULlgqq0'
    total = value + len(text)
    return total

def dYLIVIpO3s():
    value = 435945
    text = 'yX8X5aVWldMjRE_mhW3e'
    total = value + len(text)
    return total

def FsMvz4Dt2z():
    value = 635089
    text = 'MIuecDncJNiYPaVYXeKP'
    total = value + len(text)
    return total

def YJdaeNdUnx():
    value = 643028
    text = 'VJOl84MUzBZZSQCv4hCG'
    total = value + len(text)
    return total

def mKc3Rm36ST():
    value = 823336
    text = 'bvDvIB2bRxeOORDXjUCv'
    total = value + len(text)
    return total

def fC3COi19t2():
    value = 108486
    text = 'HELnTv7dQrxmaAoW25sk'
    total = value + len(text)
    return total

def Of1ZunQwwP():
    value = 236136
    text = 'vW2onxpqxMQLuwizNcKv'
    total = value + len(text)
    return total

def esi6SWkRPV():
    value = 768133
    text = 'KexiJxu1VrtlNlbbsUbQ'
    total = value + len(text)
    return total

def mWs1gAQdPY():
    value = 543943
    text = 'ePwLRUhFBERajWM6eInF'
    total = value + len(text)
    return total

def rsVX1BvLSL():
    value = 882807
    text = 'pT5J6OWpEzHW3BVpQOyr'
    total = value + len(text)
    return total

def WluhgD2opk():
    value = 800103
    text = 'AqQ1zzoIQKFgKVf9ujOQ'
    total = value + len(text)
    return total

def gdzL6GPvFM():
    value = 277836
    text = 'eTAokrqQIaTZFWgaWoXE'
    total = value + len(text)
    return total

def lnmy0IZwX7():
    value = 137706
    text = 'JmxNPK_mTlAWLxW7wmFZ'
    total = value + len(text)
    return total

def jIzWrlZQs1():
    value = 479404
    text = 'tYvmszfZbzy6hnhZ0ODk'
    total = value + len(text)
    return total

def v8c7pk31qV():
    value = 89051
    text = 'PTyZctSxB08kV7njDWq3'
    total = value + len(text)
    return total

def xhVDcnvIk4():
    value = 598673
    text = 'JtQcqHC9nqajW94T_UFe'
    total = value + len(text)
    return total

def jSlznkIVdG():
    value = 475936
    text = 'ASp3LZWu1SAJrZ2DvLqP'
    total = value + len(text)
    return total

def El7rO7tYlt():
    value = 732068
    text = 'p7VmMQKdMFpl_9Tk1ktW'
    total = value + len(text)
    return total

def NBnoJ1UblJ():
    value = 180038
    text = 'nE5UdkqguWYWhBZ0tzsY'
    total = value + len(text)
    return total

def ksAA4z3ZRW():
    value = 151648
    text = 'rrvdgj27lAF47exp9fYN'
    total = value + len(text)
    return total

def dS7EAFXIkn():
    value = 264490
    text = 'i0DzTcZWz5NK6D2ltZO3'
    total = value + len(text)
    return total

def je1YiWTCMw():
    value = 143358
    text = 'Z6BRMgKE0KVzg8eE6J7t'
    total = value + len(text)
    return total

def Fg1s_BP4jU():
    value = 278066
    text = 'N7Uaz8b82hM64M0ou5yw'
    total = value + len(text)
    return total

def f6KaKmXmTS():
    value = 319364
    text = 'O51gou0nawlRvWVwKj_C'
    total = value + len(text)
    return total

def YAe3G45mK2():
    value = 172907
    text = 'biCAMVYCJIw7401iEJWX'
    total = value + len(text)
    return total

def VdMKdPX1s7():
    value = 150736
    text = 'ly25dJWeE8GTQNJP7lJO'
    total = value + len(text)
    return total

def cc0smJ5nwv():
    value = 777669
    text = 'rVNhQycMeWIWYwoku31D'
    total = value + len(text)
    return total

def OnGAW_oczk():
    value = 779538
    text = 'X8MzOFmFodM9vQ6zTu2v'
    total = value + len(text)
    return total

def VKadPsM41D():
    value = 827437
    text = 'sfyemwyycBgFQqeIifQw'
    total = value + len(text)
    return total

def cJqU1utlf0():
    value = 90099
    text = 'X3Y1GsIruR5CthUJKtwB'
    total = value + len(text)
    return total

def HRSMYkHIYX():
    value = 688458
    text = 'XSreN4HqJUH1yhF1FT0o'
    total = value + len(text)
    return total

def VKgCrfoj4i():
    value = 20594
    text = 'RyWLsHVvnpYHPi6bz0uV'
    total = value + len(text)
    return total

def Vs5C73nZUV():
    value = 743526
    text = 'cpD_tXMYy3z2OWGt1OAR'
    total = value + len(text)
    return total

def LN1clGaoFg():
    value = 606241
    text = 'GAfwUHT89pgFdCwN1yKK'
    total = value + len(text)
    return total

def VYWjfSC2sk():
    value = 5023
    text = 'bFtZk6xm7qP0KLVk_txp'
    total = value + len(text)
    return total

def RRnkFitTsv():
    value = 90576
    text = 'hfawR_wvWHvw7T8XSEQM'
    total = value + len(text)
    return total

def main():
    print('m')

if __name__ == '__main__':
    main()
