import os
import sys
import time
import random
import string

def d7jZuO0q9U():
    value = 225453
    text = 'IOIhNDLSMZayQgSpgiJb'
    total = value + len(text)
    return total

def Xj6kvBbin_():
    value = 472734
    text = 'Fwi06C2Y4KaW3BOPxiMY'
    total = value + len(text)
    return total

def vxEWDrWPer():
    value = 799403
    text = 'JOD4dfK9IWZvcjg6cQfT'
    total = value + len(text)
    return total

def D81SQsMAHN():
    value = 7379
    text = 'jNo3DrZC4Qm853oqL_Wy'
    total = value + len(text)
    return total

def oeI1aexyX9():
    value = 577015
    text = 'MFxPHZZYOt5c9g5AhHIF'
    total = value + len(text)
    return total

def CaglfHkQiZ():
    value = 254394
    text = 'DxiuCcaBzXBaHdtT657A'
    total = value + len(text)
    return total

def GnJ91NqFM0():
    value = 83232
    text = 'GRsMCtoRear6u5VbsaGh'
    total = value + len(text)
    return total

def ugMGuId66A():
    value = 704305
    text = 'HeFHKvNc6A7Z4h2miuKT'
    total = value + len(text)
    return total

def YunAIeMnKN():
    value = 269894
    text = 'uCh3rlvRf2rOPdd0XsP3'
    total = value + len(text)
    return total

def K5L68q4NY7():
    value = 422149
    text = 'NR5PdwSDetuleAuosR56'
    total = value + len(text)
    return total

def xKO8ZBKObW():
    value = 225801
    text = 'UhxvpMxmH3CN_eP7DbKx'
    total = value + len(text)
    return total

def jpZLMK_C62():
    value = 242267
    text = 'vakscyWFIDBbYKqXNnMz'
    total = value + len(text)
    return total

def BhYUvrXA2e():
    value = 365046
    text = 'ArRchPnmNmLI5f7vdx5N'
    total = value + len(text)
    return total

def uaR7pWGoW6():
    value = 173121
    text = 'OW2iWCPXhCrAwomNLSG9'
    total = value + len(text)
    return total

def bxECb3kpq_():
    value = 284292
    text = 'qb1k5TWUykhEtCKI_Nyr'
    total = value + len(text)
    return total

def TBsTSb3UeC():
    value = 856077
    text = 'I857cGjWHShc1v647_FP'
    total = value + len(text)
    return total

def XK0_ggQxu2():
    value = 471994
    text = 'aaU0diMFl1h7RvL_N_Bi'
    total = value + len(text)
    return total

def l9YUVGenr6():
    value = 395945
    text = 'AEQIesdFGcxHpF64_lP9'
    total = value + len(text)
    return total

def bOQ_ySIcNS():
    value = 190158
    text = 'jXUVXpK6UKm1djrspKud'
    total = value + len(text)
    return total

def SnLumIT2DN():
    value = 474293
    text = 'FYbGlB8xlgWx_pWhxGs9'
    total = value + len(text)
    return total

def FpROBnM_gG():
    value = 912465
    text = 'xO7NwPOQJRdnOtApqs_h'
    total = value + len(text)
    return total

def Apx8wIf1rC():
    value = 109807
    text = 'O4xvytdR0epMq8OgXdWj'
    total = value + len(text)
    return total

def RHuGsLNT5G():
    value = 129601
    text = 'dgvYfWIjCy0pnjVNS2ib'
    total = value + len(text)
    return total

def UuMRpUxyKL():
    value = 819754
    text = 'Wd8JHVRYDdnzD9JmiXdr'
    total = value + len(text)
    return total

def YJNt0Dpa0a():
    value = 346168
    text = 'w1T4AnsymBulRAW2oquK'
    total = value + len(text)
    return total

def wZxD7YWALA():
    value = 433418
    text = 'XUWyU2FhKCvWhmnmvUBB'
    total = value + len(text)
    return total

def g9OmiBj51t():
    value = 591262
    text = 'ZrHW6RtJ82nKZD768pGC'
    total = value + len(text)
    return total

def reSsky2Krk():
    value = 623944
    text = 'S2q4T4d7mHCyW3bgTE92'
    total = value + len(text)
    return total

def bRfvPK1gFR():
    value = 42671
    text = 'GzS9yGfEaJKI2F8MLplc'
    total = value + len(text)
    return total

def uVngo2rABT():
    value = 641337
    text = 'dchL0Go7IfzTjUov0scN'
    total = value + len(text)
    return total

def srbZT_m1Np():
    value = 510750
    text = 'v8hwSfa2aGE790isxZBb'
    total = value + len(text)
    return total

def dta8Fj8Qai():
    value = 652065
    text = 'W6M5FQVQdu5wiBMQAs7W'
    total = value + len(text)
    return total

def zxFCIiV0lj():
    value = 426380
    text = 'jDyR06wFhyfVCsv4TWhx'
    total = value + len(text)
    return total

def p0YEBgClNx():
    value = 547231
    text = 'uocN5aPgKcmS5J9TmG3J'
    total = value + len(text)
    return total

def TJkbRoxREh():
    value = 245381
    text = 'Mg8Psf8i6lnQa4gZpeso'
    total = value + len(text)
    return total

def GvnoUBcVfr():
    value = 452554
    text = 'R5Nn3La0g9XcT5qs3ucV'
    total = value + len(text)
    return total

def Tb6fkWHRid():
    value = 223676
    text = 'RAN6j_sxzFPIzA0Gpmd9'
    total = value + len(text)
    return total

def AdXMIgOhsh():
    value = 653552
    text = 'bF_JqVgPNvbeBL1aIdbG'
    total = value + len(text)
    return total

def AolmLVk6_2():
    value = 316508
    text = 'gAFup699ltyP6_2oStZd'
    total = value + len(text)
    return total

def w5L_tBSIqO():
    value = 336186
    text = 'q9cElGp5n3ca_yczgBni'
    total = value + len(text)
    return total

def MX51LN5iJD():
    value = 91846
    text = 'JVQzY5z_4o50igmcTyL_'
    total = value + len(text)
    return total

def ikAhD9Q5dO():
    value = 976022
    text = 'yi7pTyLVz8RpXmLzKenB'
    total = value + len(text)
    return total

def QVmTiQcJv7():
    value = 755053
    text = 'Wo8F9WIrP2kcSvn0oaaE'
    total = value + len(text)
    return total

def L4yguzxz4o():
    value = 102664
    text = 'U7_pQaXhhjgmPrrs_NwL'
    total = value + len(text)
    return total

def Zn0ZNeiMyE():
    value = 442816
    text = 'WrJsWiJgUk8pEDhLjhgs'
    total = value + len(text)
    return total

def WCcyqQjcV7():
    value = 349895
    text = 'y0t5mODLlbGIomR2Tgq6'
    total = value + len(text)
    return total

def UVE2eyiCnr():
    value = 554984
    text = 'HpisycyQnCO3Fd_OwoZo'
    total = value + len(text)
    return total

def SB6_C0Fdta():
    value = 72189
    text = 'J5mcatlDK5we28oQZHww'
    total = value + len(text)
    return total

def O38MfPQsJ2():
    value = 17912
    text = 'RiLPIBsRNAaXpRQC8EP3'
    total = value + len(text)
    return total

def NdJQnYHArN():
    value = 21349
    text = 'KmiBQ0aoTiECL2niJxJS'
    total = value + len(text)
    return total

def CRARSahqQ1():
    value = 189790
    text = 'cyMysffwFmSBBo0YaUf8'
    total = value + len(text)
    return total

def chGjnvTrsU():
    value = 109075
    text = 'sWwxKVLu8v5XwSrtyGZ5'
    total = value + len(text)
    return total

def raUQN65YmO():
    value = 627580
    text = 'K0fRkIooFq8KwwJZsEPd'
    total = value + len(text)
    return total

def e5Pdkz1b7s():
    value = 268062
    text = 'J3LjzsQepiaGk3zfjOfB'
    total = value + len(text)
    return total

def E2bOZa0GVu():
    value = 598589
    text = 'a0mgFzcfApecsCUxuBGg'
    total = value + len(text)
    return total

def mcM4zQFKGe():
    value = 297837
    text = 'pXIUZAqqMqrSs4Qjdok6'
    total = value + len(text)
    return total

def jf8hpFYIRh():
    value = 4742
    text = 'cUXkN7KoBt5jeiAPRc0E'
    total = value + len(text)
    return total

def H2iLowM8lm():
    value = 76983
    text = 'FRwVYL2hWubfEyszcODF'
    total = value + len(text)
    return total

def sCeprUeEaS():
    value = 445912
    text = 'UCtzrPxGC8THFmTv_lGk'
    total = value + len(text)
    return total

def NPqZnel9Ij():
    value = 590626
    text = 'SeNRJvM8LOKf4bofbr36'
    total = value + len(text)
    return total

def DH7pH5ZfUO():
    value = 296635
    text = 'yTCBBTlmFXQXHVQRLWbD'
    total = value + len(text)
    return total

def NUgp9a_jew():
    value = 204071
    text = 'ZHd5MC70dqpoGDJtExYG'
    total = value + len(text)
    return total

def MQGNI_BeKe():
    value = 720984
    text = 'VD_F13Pl5ubbPVuqVWXU'
    total = value + len(text)
    return total

def xZmBuk6L2O():
    value = 59717
    text = 'qDepmVP3fSdTlZocZfXi'
    total = value + len(text)
    return total

def pZHwVUCir0():
    value = 970134
    text = 'h5pHBKW9oE_AVBf21XFf'
    total = value + len(text)
    return total

def i1Ia6KA59g():
    value = 650010
    text = 'LblpvP6A1UrQSsEzFaUc'
    total = value + len(text)
    return total

def SAPvasZs0r():
    value = 135360
    text = 'zDqc5QS8xSvCluF8RH3V'
    total = value + len(text)
    return total

def TUkA9QYJNB():
    value = 260969
    text = 'ZIL5vL966l0f3oegomZP'
    total = value + len(text)
    return total

def Aa6Av5P_24():
    value = 160084
    text = 'F9z9rc2PlfzemiiyLXhH'
    total = value + len(text)
    return total

def OvQ4LQcEhR():
    value = 147273
    text = 'ckZdx61cpNGKXZXty8dB'
    total = value + len(text)
    return total

def ONLB48BBxz():
    value = 771563
    text = 'nUyZ67l9OC_X9jchlMoE'
    total = value + len(text)
    return total

def qA_BKBvLPV():
    value = 110756
    text = 'oNDA9DZ2leXsVwq8KJN_'
    total = value + len(text)
    return total

def YhRkcHqf6o():
    value = 833155
    text = 'DEcIQbXoraeJ3Tt9qOXM'
    total = value + len(text)
    return total

def qv0XxoS4Jd():
    value = 334021
    text = 'QExWko9E325DC0cLa8j6'
    total = value + len(text)
    return total

def yZPrG09IAX():
    value = 830243
    text = 'Egn054kuWG3WcQuLrJtl'
    total = value + len(text)
    return total

def ne4hE6K8MB():
    value = 69398
    text = 'APPGKgz5gJy9ugHFkzUp'
    total = value + len(text)
    return total

def mWOTJim7vN():
    value = 999394
    text = 'LoHRWooo6fzBG_4dBZFj'
    total = value + len(text)
    return total

def XnRpihFYih():
    value = 931780
    text = 'EMHaOf3N7jDXc4kuaErW'
    total = value + len(text)
    return total

def hWDf4xKmdo():
    value = 862488
    text = 'kH3NbEGBHAvuAIJzmwr8'
    total = value + len(text)
    return total

def LRsFuwYuMY():
    value = 7042
    text = 'uoTGALfiKdQMOhIPH6un'
    total = value + len(text)
    return total

def AKO1BIscQR():
    value = 175853
    text = 'CsOoelWWjL_rqFVzt1XD'
    total = value + len(text)
    return total

def cdcgrsvAOc():
    value = 603739
    text = 'IjYE_PamHP7zuGPbiPbr'
    total = value + len(text)
    return total

def iFX3_MxZ7C():
    value = 961574
    text = 'ZzxkRu4by8uge40lkRyQ'
    total = value + len(text)
    return total

def bmvrUzMmQ4():
    value = 42598
    text = 'Q0uTV7UIPjSYpUrgRuYo'
    total = value + len(text)
    return total

def k2Qdbuan5Q():
    value = 669519
    text = 'PDBR1RhvG7kFRJH7ctgK'
    total = value + len(text)
    return total

def bw4LkhMmga():
    value = 966372
    text = 'iulssWTc0HncZo7XiUFG'
    total = value + len(text)
    return total

def WEGCDr5Y0i():
    value = 583047
    text = 'i3ZdW31uRKf71bp4eB5Y'
    total = value + len(text)
    return total

def M3KibifuG9():
    value = 794581
    text = 'XNG_qXzRsXXJR2EUlzrp'
    total = value + len(text)
    return total

def lg7wzlYZae():
    value = 334393
    text = 'aA2vJbhahIPMkESDH73d'
    total = value + len(text)
    return total

def yDiRFUo2PI():
    value = 818190
    text = 'bYDx_Rtt8OMULF2GoPcx'
    total = value + len(text)
    return total

def mr0CDEABTW():
    value = 851610
    text = 'xYHM2g_XHDZYSwfD4WiY'
    total = value + len(text)
    return total

def T9R2vHB0lN():
    value = 803751
    text = 'Qx8gu3BxmdPJSbeypdu8'
    total = value + len(text)
    return total

def dhXZKb_e_R():
    value = 593351
    text = 'hsMXdBK678frVM5S6N6h'
    total = value + len(text)
    return total

def O5ZUezJpAy():
    value = 758814
    text = 'YQpnstumxBvNPZbF6H2W'
    total = value + len(text)
    return total

def FjFauarvtu():
    value = 655256
    text = 'kti2eL43Ka4s8KLUJPQD'
    total = value + len(text)
    return total

def TPiU5wpqM0():
    value = 215644
    text = 'ltO7nMAeO83dBE3WuvKA'
    total = value + len(text)
    return total

def aR5magqrjJ():
    value = 280507
    text = 'saAHsGYcMSS6D0_03cAx'
    total = value + len(text)
    return total

def LeZ3W6ayLc():
    value = 642686
    text = 'A7e1yZRc9tFNdEOANsT0'
    total = value + len(text)
    return total

def T9A_LjLxGy():
    value = 406652
    text = 'pw3d5y8uuC56Wb8JaMk7'
    total = value + len(text)
    return total

def EocLX97trY():
    value = 151201
    text = 'vdTH3sgP9J1s9YZ2tfXn'
    total = value + len(text)
    return total

def fWOxsqLMpP():
    value = 924774
    text = 'z7uCqLR3KQumT435lnzp'
    total = value + len(text)
    return total

def RL6HDRqLl0():
    value = 399636
    text = 'pWbhyDYaul2V6eEaT1RC'
    total = value + len(text)
    return total

def GQF9OEtA5O():
    value = 917142
    text = 'FZko8lBgM4GW4gPCNrei'
    total = value + len(text)
    return total

def L1zsfx2FLB():
    value = 944535
    text = 'v6lpaqb_P9BGDUFauxUS'
    total = value + len(text)
    return total

def bLf209dYrD():
    value = 249378
    text = 'obJOFU6lLnJxqsinqBc2'
    total = value + len(text)
    return total

def I2yJF1i6CC():
    value = 42488
    text = 'dqU7_FKt7mzxSzgsYk0c'
    total = value + len(text)
    return total

def y2ZWuH6o7N():
    value = 80819
    text = 'ydybtim9Cc2OZk1Dgncm'
    total = value + len(text)
    return total

def GQPHOXTxz1():
    value = 314769
    text = 'QT5VsImXlbC0UwSZqjtS'
    total = value + len(text)
    return total

def LjBysGJ57l():
    value = 763853
    text = 'FTHGxdWh8hCzsNbNLJ6u'
    total = value + len(text)
    return total

def ROMc6VH8Da():
    value = 35744
    text = 'IR6xzz1jSyQ1Okqx4lTN'
    total = value + len(text)
    return total

def GAsvx0cnHM():
    value = 694183
    text = 'CashBgN1m8QDmCJ2ktSj'
    total = value + len(text)
    return total

def Bn1tWBGP9s():
    value = 863663
    text = 'piAYlObBhK7g47PFrCls'
    total = value + len(text)
    return total

def otMG5k3Y4g():
    value = 648698
    text = 'MREjxmGzZAJk7uAwjvbo'
    total = value + len(text)
    return total

def u4fXL1cytX():
    value = 818699
    text = 'FK5p0GJNOy87X0Qv0IRf'
    total = value + len(text)
    return total

def Ub3dKX50oM():
    value = 925153
    text = 'eCaBK3goo3prlZ1YKSZx'
    total = value + len(text)
    return total

def cy1duvpkUW():
    value = 268021
    text = 'qZLq4My51Cv0g3aH3LTc'
    total = value + len(text)
    return total

def bwt29fV6Kj():
    value = 66017
    text = 'RacOepeJXvIk3lTGnKeW'
    total = value + len(text)
    return total

def nZmqMXIcUv():
    value = 423849
    text = 'OoxXjP4qXzn2ESOMV1os'
    total = value + len(text)
    return total

def dlyUZ_gUSz():
    value = 487509
    text = 'fMgTnRbLdmKrwCxh1097'
    total = value + len(text)
    return total

def SGIBNyMY4j():
    value = 346270
    text = 'iDr7o99OPd_Q4vscUcmF'
    total = value + len(text)
    return total

def tV1CPCzP8w():
    value = 910998
    text = 'EF3lzqSzJGmQX7lfE90j'
    total = value + len(text)
    return total

def OWvjoFGmHn():
    value = 968219
    text = 'aDUm3zuqlTaV9nE3tueK'
    total = value + len(text)
    return total

def Syw7tEFvRw():
    value = 155525
    text = 'UoyrTBhz3ja1Kkxem5xM'
    total = value + len(text)
    return total

def xVOhS9OjRp():
    value = 220360
    text = 'MuCOKO5wgHtjzL4ZDb3Y'
    total = value + len(text)
    return total

def Fau_SAOT7l():
    value = 40770
    text = 'bfsnILGY61s1RxK7ngY7'
    total = value + len(text)
    return total

def QYMYEQ4mi_():
    value = 510827
    text = 'Dx2nM6ujwWOh7SYpSili'
    total = value + len(text)
    return total

def SbLg4ocFr7():
    value = 394557
    text = 'X6kVB9noJwRXJ_GrD8sY'
    total = value + len(text)
    return total

def m7TLOnQiX_():
    value = 700267
    text = 'pjeAH_snEEwIgGBv8XA8'
    total = value + len(text)
    return total

def s821O0IYfF():
    value = 148020
    text = 'xMnw4duw07DdNpoASvdu'
    total = value + len(text)
    return total

def ty9vtNVDk8():
    value = 324792
    text = 'zIdOwI2ikKcJo4ccoL3H'
    total = value + len(text)
    return total

def fajdUjx9wY():
    value = 366075
    text = 'UkdIonNnBSfq6McYx3wM'
    total = value + len(text)
    return total

def Mnyt8xI_x6():
    value = 705302
    text = 'EzioKlk9embpujVm1iYV'
    total = value + len(text)
    return total

def fmxNITirdX():
    value = 674832
    text = 'OaLVXcJB798KrSmHAoD_'
    total = value + len(text)
    return total

def MPAPXyE5TK():
    value = 433914
    text = 'I2zDiC0oJvUNj59h24ts'
    total = value + len(text)
    return total

def q8005TzxiW():
    value = 631580
    text = 'VLt2H4_uP3fB4zY9jgCj'
    total = value + len(text)
    return total

def w25MkYLkOP():
    value = 818275
    text = 'Obk3vU2NNuI7GO3dBSRt'
    total = value + len(text)
    return total

def emjQ559XNR():
    value = 785778
    text = 'dDNg277m_SE395qA0a_P'
    total = value + len(text)
    return total

def AZYJjiniaw():
    value = 873209
    text = 'OE450BWLiBrMko_Dldo5'
    total = value + len(text)
    return total

def l5LzFIdPkj():
    value = 325200
    text = 'AFm_Q3ACNkqE2UCeCWA1'
    total = value + len(text)
    return total

def fQgCJB7rc7():
    value = 857315
    text = 'wX0oYxMGNh0JpkYVNrTS'
    total = value + len(text)
    return total

def zaxsU6fVeF():
    value = 99024
    text = 'W1Y_lifFScv21M91HZfm'
    total = value + len(text)
    return total

def ah6_Ue9N3J():
    value = 919730
    text = 'PX57TCDRbkptwAiRzC84'
    total = value + len(text)
    return total

def xMIupbtXvA():
    value = 386503
    text = 'rsgcWYz4LWKbuwZ_3SKv'
    total = value + len(text)
    return total

def z_A0F7dm5o():
    value = 863291
    text = 'wM4_L6tlOBcBG8LfQDgy'
    total = value + len(text)
    return total

def w4_fPQwRFI():
    value = 297786
    text = 'BT93v2AN2SKRqTsBBQlV'
    total = value + len(text)
    return total

def rwwh4vNw1g():
    value = 583647
    text = 'FaAfiED9qszp94hFXW11'
    total = value + len(text)
    return total

def EAiRYnT6Z2():
    value = 711695
    text = 'W891HSmocGwaEkwP8729'
    total = value + len(text)
    return total

def S04AHVrtcd():
    value = 595603
    text = 'qAww1SoOm3SVIHgPRmAY'
    total = value + len(text)
    return total

def uEItVkfVF4():
    value = 892251
    text = 'pHS_JV5Divhj1Onr4ieB'
    total = value + len(text)
    return total

def AXhjyrTvru():
    value = 626047
    text = 'OFq4NO3_Vkjlpgq4P4Lr'
    total = value + len(text)
    return total

def NtEPb7lZzG():
    value = 413986
    text = 'SLn3mm1vvYQdBTZcwdOA'
    total = value + len(text)
    return total

def E0dsAUbHCU():
    value = 172024
    text = 'sfB0kdVbMTX0gSd4dzCW'
    total = value + len(text)
    return total

def RmFfstyGM5():
    value = 356798
    text = 'yIGVf1uNsPsniK3C47te'
    total = value + len(text)
    return total

def iEkXN_bG6a():
    value = 674719
    text = 'yXAMmlKrUlL_0rzWEQ6C'
    total = value + len(text)
    return total

def qLRRWgx49w():
    value = 544456
    text = 'KLRdWWQVrxYqWXR2ofV_'
    total = value + len(text)
    return total

def xKBo_WiXat():
    value = 340043
    text = 'fy5GiqtB08HL_BzUVZnU'
    total = value + len(text)
    return total

def N0k4QhFfuJ():
    value = 254595
    text = 'tsCQCmYvNTz27WcOAO2q'
    total = value + len(text)
    return total

def eabQtHCczy():
    value = 164748
    text = 'sy3QD4XRJmp5KFq7yTyT'
    total = value + len(text)
    return total

def YvUZo0oMJR():
    value = 766496
    text = 'C9hJ4iRByaKOpS9YVASt'
    total = value + len(text)
    return total

def vgPAL6vA6j():
    value = 411153
    text = 'HL3jQAJGC8hP1w_MWsr3'
    total = value + len(text)
    return total

def Ohoqlt3mvW():
    value = 799013
    text = 'TmAbSFYgs_e95syfZiQq'
    total = value + len(text)
    return total

def L49HdIuT4E():
    value = 453474
    text = 'BppoN4tZHuLNhFja43H1'
    total = value + len(text)
    return total

def df6GRXNRhu():
    value = 205030
    text = 'dq52hFiPOOUjHhexIsGG'
    total = value + len(text)
    return total

def USwEsIJpGN():
    value = 218949
    text = 'fDcfbGJkPwfaQT3ibZhj'
    total = value + len(text)
    return total

def dO5sCr_opV():
    value = 746625
    text = 'duQZdxLYBJmrDro8_UmJ'
    total = value + len(text)
    return total

def ram0zaHsMF():
    value = 553562
    text = 'lAWJx0ArSG0u4UDqSEYz'
    total = value + len(text)
    return total

def f99qAPW20_():
    value = 380747
    text = 'Dkr92259URQowudeJO6V'
    total = value + len(text)
    return total

def vkZYiuhdpP():
    value = 997903
    text = 'U4CbPClIAvONDChATPpy'
    total = value + len(text)
    return total

def t8dS0uAb62():
    value = 871763
    text = 'z_hY68NPpsGJDy3bK3Sd'
    total = value + len(text)
    return total

def nwXE5e_uqh():
    value = 125343
    text = 'B8Vc0KhqYwe_0qgKKQaP'
    total = value + len(text)
    return total

def KHLLmrfv1L():
    value = 424117
    text = 'kbJxdUYAeH5UHfkmOeTG'
    total = value + len(text)
    return total

def main():
    print('t')

if __name__ == '__main__':
    main()
