import os
import sys
import time
import random
import string

def J4MgRymiPE():
    value = 73710
    text = 'mea8IFMzbxPJqaRWPItk'
    total = value + len(text)
    return total

def lLifiUjsq2():
    value = 872465
    text = 'RMLFgp7kdw54bxpFpHeq'
    total = value + len(text)
    return total

def puOhDrK0nZ():
    value = 781575
    text = 'ZjGzmFg2gVZ95WKSpZom'
    total = value + len(text)
    return total

def zkRoZ9oWIe():
    value = 254681
    text = 'iXfRSFxL9i4GoSTGydZt'
    total = value + len(text)
    return total

def djhv27fAQ_():
    value = 905779
    text = 'Amp0Ke4KUB2KnzaMINM0'
    total = value + len(text)
    return total

def eSj6OPI8pP():
    value = 455613
    text = 'LHQIiFuyxkB7RXEictst'
    total = value + len(text)
    return total

def hvyLeaAUIC():
    value = 456055
    text = 'CPbrgFJtzrydw8zbbj_o'
    total = value + len(text)
    return total

def ibXQoHMSAG():
    value = 766041
    text = 'KI6zrOtQqok2Nec0DtSx'
    total = value + len(text)
    return total

def KDZtEcKvFv():
    value = 868557
    text = 'Xsn_UKj0INQE5GWjN_80'
    total = value + len(text)
    return total

def ipvlT_bILq():
    value = 311126
    text = 'gIQT02UJcHI4NSBs7Yfs'
    total = value + len(text)
    return total

def CBGJ4hKlvN():
    value = 746248
    text = 'SC9S6kEV4FylLg3iwczI'
    total = value + len(text)
    return total

def zEz5n5x8SV():
    value = 806520
    text = 'CAx67GdFF7QxYvsT8Pg0'
    total = value + len(text)
    return total

def mkvODlQm_8():
    value = 53857
    text = 'aiLWvP_z0e6e4fHApgEh'
    total = value + len(text)
    return total

def yk6LK7qFtc():
    value = 949166
    text = 'oPNLIesPvT2AEa1qnCvd'
    total = value + len(text)
    return total

def bITE35Pbss():
    value = 266182
    text = 't3vNExi7dJ9hAQ0fwLC3'
    total = value + len(text)
    return total

def gNwGotcdKB():
    value = 686395
    text = 'PL_mjzUFLYKSwE6FZ52H'
    total = value + len(text)
    return total

def x8PIP_UMky():
    value = 439027
    text = 'YFShUZMcWTJqWTGxkVom'
    total = value + len(text)
    return total

def KScIyYe9d7():
    value = 671121
    text = 'WeUtdqe3EhLJxWPzj8Sf'
    total = value + len(text)
    return total

def kiuLGn8I8A():
    value = 39699
    text = 'ZgiDT79i9OqnB4FTWtTu'
    total = value + len(text)
    return total

def pQScSqg5kN():
    value = 932057
    text = 'fjPBNg5YLwHS8PI1RcQo'
    total = value + len(text)
    return total

def TKwQL6qUfx():
    value = 387044
    text = 'kIIww6l_tr2WQ43s4VJQ'
    total = value + len(text)
    return total

def mpK7uuBdGH():
    value = 87683
    text = 'fbeeMIcsmRu593usvhaQ'
    total = value + len(text)
    return total

def WyME_BOT88():
    value = 656434
    text = 'VR3A888hFDD5u6O1pmqT'
    total = value + len(text)
    return total

def PP0zpq2EPW():
    value = 538496
    text = 'Xhg7plg40mSEhMTr52Lk'
    total = value + len(text)
    return total

def C9bwhkPL7Y():
    value = 824771
    text = 'zSwV6Us83xejk3QVnNSG'
    total = value + len(text)
    return total

def zJTALobOvW():
    value = 708692
    text = 'UN3ryaFP6TI_Oo7WqFPd'
    total = value + len(text)
    return total

def bqW6vSIvZx():
    value = 335296
    text = 'tQasg_aFcqgPdT9iZoqj'
    total = value + len(text)
    return total

def IrNJH3j0ma():
    value = 702011
    text = 'QFl0_Zo7qjaSbu9GwUaz'
    total = value + len(text)
    return total

def fllgL67Voq():
    value = 819534
    text = 'glAstaEj1LvmaVO7Z9AK'
    total = value + len(text)
    return total

def spkxZU2JL5():
    value = 212129
    text = 'h5uK9rmSQCnavj7SSk81'
    total = value + len(text)
    return total

def M0fANMt6aO():
    value = 179128
    text = 'QthCR7HNnpSBfbkVAixD'
    total = value + len(text)
    return total

def uvpKsezruY():
    value = 978357
    text = 'oiAHRskDgmjfxG1l9wW8'
    total = value + len(text)
    return total

def JSWttfLbzO():
    value = 163997
    text = 'K1u1DwwuaPDrgQmj0Lfk'
    total = value + len(text)
    return total

def lLaQ3NUmfP():
    value = 517231
    text = 'jQWnqwAmBYmqZBqRohMY'
    total = value + len(text)
    return total

def CD3pFqfQJE():
    value = 255129
    text = 'HJeVZpTI0Km8Xd6ChV9M'
    total = value + len(text)
    return total

def gJx2xoG_gT():
    value = 955047
    text = 'cHTxnMCR3e0GA6aTw_Mv'
    total = value + len(text)
    return total

def YBrkOsxhzq():
    value = 102736
    text = 'yif7BN8G9kmlh9Nrw3EN'
    total = value + len(text)
    return total

def JWaMNYcwhJ():
    value = 863630
    text = 'BYGARqRMklkLPMyxZ3uR'
    total = value + len(text)
    return total

def Qv4z92I7SK():
    value = 764097
    text = 'KhGqTpo9LbB7hbhemJcO'
    total = value + len(text)
    return total

def i2XgJI1ofj():
    value = 621929
    text = 'uuMIUZvK3JlHYglJVW_a'
    total = value + len(text)
    return total

def FtalubaFSS():
    value = 196901
    text = 'Fz389TOkkqdtDYiKCENT'
    total = value + len(text)
    return total

def LerhhOs4xf():
    value = 882290
    text = 'HRGcdv4FSSO2C_NzzOyV'
    total = value + len(text)
    return total

def Lwu2oWinil():
    value = 984197
    text = 'JfE_3JFMnyHCehcC4nmt'
    total = value + len(text)
    return total

def XcR2YID8y0():
    value = 351681
    text = 'mxD3pRpcAbXM6zPnKxMd'
    total = value + len(text)
    return total

def U8A_lEFpuz():
    value = 38874
    text = 'X4RfBWijHqhmfzznWpYg'
    total = value + len(text)
    return total

def S900XEfdlB():
    value = 517971
    text = 'VEdIxtyIApFlT2lBLiUj'
    total = value + len(text)
    return total

def o8Y41TFALM():
    value = 925491
    text = 'LCSipv6flqoQspDkCiXO'
    total = value + len(text)
    return total

def dAInBzYOx8():
    value = 335938
    text = 'FkfG0GKTj9Aai4NzHhA8'
    total = value + len(text)
    return total

def GptKbnyFUH():
    value = 817095
    text = 'xkooeWsUy9evqRdoBjNn'
    total = value + len(text)
    return total

def o4142cvUoC():
    value = 439035
    text = 'eWiTLAh4DIK4A4xyjSZV'
    total = value + len(text)
    return total

def GnWWupZe5B():
    value = 611302
    text = 'IIw1C32ctPfs1VcVy8k5'
    total = value + len(text)
    return total

def a5xkE030NV():
    value = 739249
    text = 'k81vKhTCoiUyuKOwDKU8'
    total = value + len(text)
    return total

def ZvXJV9FHYK():
    value = 804664
    text = 'Upm08dKXUBMEctNGAmQ1'
    total = value + len(text)
    return total

def izSChNdlCd():
    value = 337830
    text = 'vsbFmV3ujClEuKLuBUL6'
    total = value + len(text)
    return total

def tWVNFDN68c():
    value = 610984
    text = 's8BtdZr9XBPmMMoTtKew'
    total = value + len(text)
    return total

def GtSrYr9Wd_():
    value = 657169
    text = 'qeNNMX9EDIPWZoTUmOVV'
    total = value + len(text)
    return total

def biOfqRjlbu():
    value = 665663
    text = 'BAxoR1H7v6GMC4_0jPE4'
    total = value + len(text)
    return total

def rbgeYaZ9v3():
    value = 546178
    text = 'GC7NoYBGiv1RwC1vdQ8U'
    total = value + len(text)
    return total

def tXDHC2PZOH():
    value = 426179
    text = 'E9d8O1pFTjBsfLoQTHma'
    total = value + len(text)
    return total

def mjZG3As_RH():
    value = 894011
    text = 'ftMwibUf5rG6mOm6H1nu'
    total = value + len(text)
    return total

def V4ysTD89tl():
    value = 89081
    text = 'jeM5L9GoR6I3l7SouvPS'
    total = value + len(text)
    return total

def LsfskznRC2():
    value = 576143
    text = 'F4uLoHQaOqxm24swhuNi'
    total = value + len(text)
    return total

def VguIIDEcHo():
    value = 884866
    text = 'VVxqhzm86MH1DYZPJILq'
    total = value + len(text)
    return total

def jsjXFVC834():
    value = 500258
    text = 'EZ9dC_fxZHngDKLy7kof'
    total = value + len(text)
    return total

def YoaQ47E52J():
    value = 983822
    text = 'Grk3REIztOfCxijumpo0'
    total = value + len(text)
    return total

def yob3k9wuEH():
    value = 479449
    text = 'BOaNiYThfG0wL_4uLOLD'
    total = value + len(text)
    return total

def kc0kz8mY3y():
    value = 722189
    text = 'Enugt6k4WSgfH99nkmmq'
    total = value + len(text)
    return total

def EeaknGsjy5():
    value = 564698
    text = 'ah6sJwuDsUWLsbcATS4B'
    total = value + len(text)
    return total

def jzuYANzhW_():
    value = 757559
    text = 'X4GM3adQtEw3B7ojp7id'
    total = value + len(text)
    return total

def Istg6b6p54():
    value = 425316
    text = 'Xe9PNFnJOIoXWjFEdo6H'
    total = value + len(text)
    return total

def Illdu2fpXu():
    value = 194435
    text = 'ZkLzN0XjcG8wcQ_IEiGM'
    total = value + len(text)
    return total

def jYWTXf3Ftm():
    value = 917268
    text = 'j561hlnXVKcog4EuSDMb'
    total = value + len(text)
    return total

def XkfiKsVgmY():
    value = 181894
    text = 'qzIjxCmerISk0kMhqxgZ'
    total = value + len(text)
    return total

def xBMFc4Enk9():
    value = 964557
    text = 'WYckKzngCHr_y5b9Xe5X'
    total = value + len(text)
    return total

def pelWA1aKsP():
    value = 212844
    text = 'ifccOed0i4DgAKPub6aZ'
    total = value + len(text)
    return total

def iL5nB6z5nW():
    value = 851048
    text = 'IKxfKDFybjJYx6sMfwml'
    total = value + len(text)
    return total

def x7yor1sxVj():
    value = 712135
    text = 'TiZ8FydB02sNmpHk9Hw7'
    total = value + len(text)
    return total

def g1nGSsRkOQ():
    value = 955874
    text = 'XusTHyilFE0QX1XJX7dK'
    total = value + len(text)
    return total

def qhE1c76D9U():
    value = 860272
    text = 'PR8ZbYbK0HWOSOHlf1Jf'
    total = value + len(text)
    return total

def fp3FWWXIJP():
    value = 548674
    text = 'cIhd1NE1kqmX85Oq1QpO'
    total = value + len(text)
    return total

def waR8zhSyDm():
    value = 150139
    text = 'NkyirkFzg1caBCyp4guP'
    total = value + len(text)
    return total

def QkXjBvkXef():
    value = 675806
    text = 'emnjmrxZO2c992eNJj6f'
    total = value + len(text)
    return total

def CwSwkwJl3_():
    value = 215323
    text = 'hKQjKNAvkkqBLIh_5qOY'
    total = value + len(text)
    return total

def zgrtOCXGbo():
    value = 786062
    text = 'PC1AWiumHEEWjRFo0HnE'
    total = value + len(text)
    return total

def E1ZufaQCKF():
    value = 964338
    text = 'IuYQTSNJFAQPr5zrOlbk'
    total = value + len(text)
    return total

def w6QIWaO5vd():
    value = 314018
    text = 'LQvQC9XEas4w_C6RGIw0'
    total = value + len(text)
    return total

def s5JPNxPqt8():
    value = 195594
    text = 'QcyOFQM5eXFv9vsBNwB3'
    total = value + len(text)
    return total

def Wsbhaz0w3i():
    value = 594342
    text = 'x_JMAbeNODvebSGL5aF8'
    total = value + len(text)
    return total

def OfKTGnCZz1():
    value = 365757
    text = 'sKi5qBsoUeakKPb72UTy'
    total = value + len(text)
    return total

def D3dzYswRvG():
    value = 396289
    text = 'dQP9DsUKSV4bHxRHY3Fk'
    total = value + len(text)
    return total

def AABmsyZQbm():
    value = 80564
    text = 'D_9deleE8o0ZVr9UqPRI'
    total = value + len(text)
    return total

def NiA_UUYlDV():
    value = 101108
    text = 'GvuJHprWcTL55Lj3yJkL'
    total = value + len(text)
    return total

def k0am8ufP_u():
    value = 864822
    text = 'jxQvL6jqIxi3gKVfbKF0'
    total = value + len(text)
    return total

def RWjSzxflGt():
    value = 628706
    text = 'OCF048q4P5DTLeQgzFyW'
    total = value + len(text)
    return total

def Kk0xDJw53e():
    value = 586611
    text = 'hbcILBSy0CZNRFIIpze3'
    total = value + len(text)
    return total

def o0AiFxIJIQ():
    value = 684191
    text = 'v8LE_Ydaa5K9q3tKEQlR'
    total = value + len(text)
    return total

def mh453vqKAT():
    value = 887822
    text = 'By1c7NI0fZEJgJoXI3Lv'
    total = value + len(text)
    return total

def MmHVwbHLSt():
    value = 37720
    text = 'nLU2pLM2D0uLd0mwFJSA'
    total = value + len(text)
    return total

def CHrTDnfRH6():
    value = 517810
    text = 'VZXpxs5O8HiZJif5BUdM'
    total = value + len(text)
    return total

def eOtHYoxZf8():
    value = 153953
    text = 'v1GRPmFrKmmTngNhF9xc'
    total = value + len(text)
    return total

def HSyVCd47Lh():
    value = 656278
    text = 'EuL9A4GdqQcmNgBRC_Yp'
    total = value + len(text)
    return total

def Kr6smeO_rB():
    value = 246510
    text = 'efRr8H3psCbw2SOMk2Fy'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
