import os
import sys
import time
import random
import string

def d04c12nh1U():
    value = 500650
    text = 'rz7z_2we8sQnwtgIvFPc'
    total = value + len(text)
    return total

def Azk5AL5K07():
    value = 107961
    text = 'xMt5llt6DrP_oKG7dmgp'
    total = value + len(text)
    return total

def wSyXy0aUU0():
    value = 993251
    text = 'QH3uScfVN0lcIldOvwse'
    total = value + len(text)
    return total

def SFl7Ulq4ET():
    value = 426779
    text = 'dNo29OYJhnkRLnfZemD1'
    total = value + len(text)
    return total

def xx59hwi4yQ():
    value = 763098
    text = 'wOTiLV36g8oTTAMcBwY4'
    total = value + len(text)
    return total

def iNHUoyEHBU():
    value = 189500
    text = 'q1ZKFYmsRlF324jKbTYu'
    total = value + len(text)
    return total

def wEdvypSdLy():
    value = 426034
    text = 'cNtCgmpUsirQyvMeQvuY'
    total = value + len(text)
    return total

def LhIPWGvnp5():
    value = 638834
    text = 'kT5190CK8Sw1n_hua26S'
    total = value + len(text)
    return total

def S3g97bQZa4():
    value = 128472
    text = 'fISiVdi5vgnNFwWsOLwS'
    total = value + len(text)
    return total

def k2qZssS4Xj():
    value = 305849
    text = 'yjTcDOLTHHzIoHmBqe5t'
    total = value + len(text)
    return total

def JCYQLrmHhO():
    value = 298039
    text = 'yp6ZmpVaXQPa5AxAc9H8'
    total = value + len(text)
    return total

def Un1OFuHiDT():
    value = 144178
    text = 'ivhPbhCf4ox7yZanPQCs'
    total = value + len(text)
    return total

def BmAbooy3l6():
    value = 929913
    text = 'hRQ96h4PJiqn7gPsgOf8'
    total = value + len(text)
    return total

def i2W3J_q8cD():
    value = 195102
    text = 'nzIWo8oOGhXHwnrPZnyK'
    total = value + len(text)
    return total

def Dpm1gbwW7E():
    value = 78537
    text = 'JajosNzoeqe9aIeUryqg'
    total = value + len(text)
    return total

def AQiWO81IsY():
    value = 3322
    text = 'BDMFFQb9GxvUskbxuWpm'
    total = value + len(text)
    return total

def lVBnvwjN5c():
    value = 940341
    text = 'jH9HaKFdb4euehR03eRW'
    total = value + len(text)
    return total

def OoPHwGNCCs():
    value = 153720
    text = 'eII4DIFNY3x_dqRsfoZE'
    total = value + len(text)
    return total

def SRTrFYSzmS():
    value = 489414
    text = 'MlQkXJMKi5GP3U9zz8vr'
    total = value + len(text)
    return total

def pjdvKNO8Ls():
    value = 730937
    text = 'uInVn1_S6YEaLuG2yNyY'
    total = value + len(text)
    return total

def oZQVRCgdEY():
    value = 819373
    text = 'e8A0Q9esefUJtE7CPzmj'
    total = value + len(text)
    return total

def SyfBqS5s2i():
    value = 711727
    text = 'ZbRjrR4RJ76VT8Emd_8Z'
    total = value + len(text)
    return total

def X6yqWNPczf():
    value = 574486
    text = 'GLq6crSnIhvEcnvKJGBh'
    total = value + len(text)
    return total

def cnmVFLnkPl():
    value = 972384
    text = 'Sdvt73jhRqCHrlZXUWkR'
    total = value + len(text)
    return total

def VUtoQ5Z76h():
    value = 558366
    text = 'oCgpNVT8YPz6_O9gt7z1'
    total = value + len(text)
    return total

def Uz190KUD5_():
    value = 277223
    text = 'E7uuzsTc8Zof07S1TQrn'
    total = value + len(text)
    return total

def BNc4M9DVnh():
    value = 707533
    text = 'bjL4EcknPlJnifQQpbf2'
    total = value + len(text)
    return total

def QE19Syi5K_():
    value = 169886
    text = 'lewv62W14DLmzl1HexRl'
    total = value + len(text)
    return total

def UGQa_5qOpD():
    value = 746708
    text = 'EHaOCsyYgpeXQHmnvMEN'
    total = value + len(text)
    return total

def TZmMq0Nquk():
    value = 622072
    text = 'BWSJOt4thGyxG3kGIoae'
    total = value + len(text)
    return total

def hsotSV3JGI():
    value = 658981
    text = 'LEYvrrLXLOYycJQHN1Pj'
    total = value + len(text)
    return total

def QyYe392J3K():
    value = 215127
    text = 'D6xwMbJgA1X3OwDaRaW3'
    total = value + len(text)
    return total

def ZssNgyFYEP():
    value = 750139
    text = 'Dbbww0xCjgAFGJNskyGH'
    total = value + len(text)
    return total

def zPuyNIHIRr():
    value = 598375
    text = 'OtP5ZBWIQLx7i0SJdka8'
    total = value + len(text)
    return total

def lPWC0mgN7Y():
    value = 319026
    text = 'guT3FYCPOTDYKFThjRBy'
    total = value + len(text)
    return total

def qiOQ8OAdIw():
    value = 335314
    text = 'ZNTifmgfbe4UuHl_0IMW'
    total = value + len(text)
    return total

def deuDMeR0fc():
    value = 583703
    text = 'RL_moUheyq0csNjfEv2_'
    total = value + len(text)
    return total

def KiK86stjnL():
    value = 148790
    text = 'Ick_HllKTMT7s1fOgvqK'
    total = value + len(text)
    return total

def HYlGIpKCmN():
    value = 533647
    text = 'Aws4J0D5CFgzYolVcbFX'
    total = value + len(text)
    return total

def ANZ7kuRYsQ():
    value = 357936
    text = 'ZXQc59aTPhur4_GzrJBR'
    total = value + len(text)
    return total

def hGa0VyLcRq():
    value = 317213
    text = 'oYFnuN46cpnCCDuZ0JvU'
    total = value + len(text)
    return total

def Ko0_LMfjw9():
    value = 717313
    text = 'f6PXRCkxE7ls9REMBlBc'
    total = value + len(text)
    return total

def tH5PPBZGOa():
    value = 455883
    text = 'yXweCnl9DoDgiHRmFPEE'
    total = value + len(text)
    return total

def oaNbcDnNis():
    value = 582891
    text = 'sO1h1IWkpPGJ4V3wtIKv'
    total = value + len(text)
    return total

def Lq1uaHu55K():
    value = 766967
    text = 'EeLjSTK8tZ07BqmA9jWa'
    total = value + len(text)
    return total

def fp9I6uw8Kx():
    value = 473066
    text = 'ZsO7MRXvWgMIKsYd79g4'
    total = value + len(text)
    return total

def Sk_bpRObp6():
    value = 702226
    text = 'fOSToC1LRlu9Sp1ZIaWY'
    total = value + len(text)
    return total

def n4njsOE9Ru():
    value = 838320
    text = 'V9jTt3E4O7UFVfJTbs5H'
    total = value + len(text)
    return total

def I8aI0Y06_H():
    value = 42768
    text = 'PU1NUgz6PAbSPL8YlTUo'
    total = value + len(text)
    return total

def sTLDKajlyS():
    value = 306145
    text = 'STJdQQ04cKNA5yboxij1'
    total = value + len(text)
    return total

def jK_7M6dwfK():
    value = 552170
    text = 'j7QEP4cwBf6f1895RPiQ'
    total = value + len(text)
    return total

def XtpWFnkC0R():
    value = 726549
    text = 'kgJOIe9CVdGALvTJTadl'
    total = value + len(text)
    return total

def rTRJI2ZWSU():
    value = 283565
    text = 'kUaxxG2dCZ7ecJUPRCSa'
    total = value + len(text)
    return total

def CTgOw3NHC9():
    value = 425234
    text = 'zZMyXH_rIIVPoKYRLdSR'
    total = value + len(text)
    return total

def cdnjSDlY6c():
    value = 758260
    text = 'BtUM2Vz73INAY63VttJ9'
    total = value + len(text)
    return total

def xLz7b9sl9N():
    value = 554573
    text = 'kQlV7mRgl9l7TWZHYdV_'
    total = value + len(text)
    return total

def KTxYmBplcn():
    value = 215427
    text = 'uAahb1DpO1jC6ddkag4Q'
    total = value + len(text)
    return total

def vDPxd8F6hW():
    value = 740640
    text = 'LPOTytB3Xr9sv_oqYAnP'
    total = value + len(text)
    return total

def lqzoSGM9my():
    value = 969768
    text = 'bK7L3cEYxxAIR1TfMqn_'
    total = value + len(text)
    return total

def uG3nGzCTRZ():
    value = 863617
    text = 'eXzwsEjYMx_2fuggutZU'
    total = value + len(text)
    return total

def fI42oPXutG():
    value = 906037
    text = 'O0Lf9l7NRjm0JmZ0bO0J'
    total = value + len(text)
    return total

def JQ9E8V7Aiu():
    value = 777286
    text = 'VS0pGzePvvyRuigrAOWY'
    total = value + len(text)
    return total

def OeiRjCrrD1():
    value = 105387
    text = 'qelWwnMkHQcBNS8xx3Br'
    total = value + len(text)
    return total

def puCJYlRwFf():
    value = 600863
    text = 'Sa2OZuZSGucx_oYI9oi5'
    total = value + len(text)
    return total

def KeT13Pim0h():
    value = 419145
    text = 'pb_jwLe1pM7tRb6lLniq'
    total = value + len(text)
    return total

def nMdPrT0uJ9():
    value = 741901
    text = 'qKVVoJy48W_xiscQfzQW'
    total = value + len(text)
    return total

def NzVXPUfagb():
    value = 129887
    text = 'eekBBsgJarqVcALdpc5h'
    total = value + len(text)
    return total

def DC2nqIKz4R():
    value = 807365
    text = 'Lcpxbd8lCUI1KgvDGHE9'
    total = value + len(text)
    return total

def yHzFxIiids():
    value = 5092
    text = 'KDnTdPOtM0tCkkTYGSMd'
    total = value + len(text)
    return total

def tZZYAGwgRb():
    value = 36138
    text = 'LZDuK0m5blazr8q76O8c'
    total = value + len(text)
    return total

def coYuwA6a3A():
    value = 66173
    text = 'L4h86X_Akzhxxdy6fouq'
    total = value + len(text)
    return total

def dtshmkaXwT():
    value = 964447
    text = 'Z7NminL2bGUAzhNFxuJq'
    total = value + len(text)
    return total

def ZYKQBMChEW():
    value = 43220
    text = 'wt8LAiJteDtWZr4N5IrZ'
    total = value + len(text)
    return total

def FXz4ZljTBq():
    value = 793001
    text = 'fpgjbAZO_FIgGIdW4S6F'
    total = value + len(text)
    return total

def mTQ9Ol3DIe():
    value = 153894
    text = 'HyG7wpZSuD7AmvfOg9PE'
    total = value + len(text)
    return total

def wB02jU5lYQ():
    value = 779786
    text = 'PRC2g3v2DBYcZ2ZA85uc'
    total = value + len(text)
    return total

def YcVGxXzmyc():
    value = 996309
    text = 'kwto0YsXbCHhoa23PBiE'
    total = value + len(text)
    return total

def VmFvMhnBqL():
    value = 753399
    text = 'tKC187OafDgNQgWo_3cM'
    total = value + len(text)
    return total

def REAzH1APBv():
    value = 262833
    text = 'VAGxKmTlAmhhiiIrbhSB'
    total = value + len(text)
    return total

def tl4rd7v1CA():
    value = 79075
    text = 'Ep3e64t24LvfXfvuGKIl'
    total = value + len(text)
    return total

def s7wnGaUa1Y():
    value = 239738
    text = 'BkbyJEch19IjlVD4wIGA'
    total = value + len(text)
    return total

def UQjMZhQZOQ():
    value = 645374
    text = 'r_CP4A6JYMsuqRLcagf4'
    total = value + len(text)
    return total

def bLbMrHK1tr():
    value = 621050
    text = 'tv5uAKsma5TVqXJCS3hN'
    total = value + len(text)
    return total

def b63lsg7tRR():
    value = 715236
    text = 'MCAOSTyhGRNfKZLQqnkV'
    total = value + len(text)
    return total

def hoLVzrLRS_():
    value = 756798
    text = 'QaryszlT7FfwJPWgqImI'
    total = value + len(text)
    return total

def y8O0xkw8YH():
    value = 450378
    text = 'IubhLXtZHkkdUx37dHIi'
    total = value + len(text)
    return total

def JosxmT5Fxt():
    value = 578107
    text = 'Q66SQLrzpJx7m_7LqG4w'
    total = value + len(text)
    return total

def C_sNsV8j0y():
    value = 805593
    text = 'UmIAh2KmwVRAew_mj_VD'
    total = value + len(text)
    return total

def UV4Yx_X_mR():
    value = 885651
    text = 'gbd6bSQJoHjRRgiR3u2J'
    total = value + len(text)
    return total

def hS6mRkAQ9F():
    value = 372530
    text = 'NnN2HgUctXcq0aus9EHh'
    total = value + len(text)
    return total

def TTjvNOgJU4():
    value = 567712
    text = 'NaXhnuAynuWQ6vXh_rWj'
    total = value + len(text)
    return total

def Y2YCaz78px():
    value = 77404
    text = 'kv7uaWbsXZMBayc8YNkn'
    total = value + len(text)
    return total

def dGkKpme037():
    value = 865750
    text = 'q87PW0P5Z6YJd8qZZUzR'
    total = value + len(text)
    return total

def NAxk65wRem():
    value = 505540
    text = 'J1lTlWm07S6L_iH7Ww5G'
    total = value + len(text)
    return total

def enmV3GuXoO():
    value = 751232
    text = 'kfHQXEQ3ofM8l7mllw_d'
    total = value + len(text)
    return total

def UD6GTemCwv():
    value = 21288
    text = 'K1wDcMTB1ZcHlaC6aQ2N'
    total = value + len(text)
    return total

def y8VGDxCkrZ():
    value = 755049
    text = 'uicoCk6N3M6WNymYSVyx'
    total = value + len(text)
    return total

def GsewN9P7x4():
    value = 420223
    text = 'NiuYQ5vOXZqd4m9S2MYD'
    total = value + len(text)
    return total

def Td9M6N1rBg():
    value = 339211
    text = 'BfXzH6ZuU776ZM1QcAvR'
    total = value + len(text)
    return total

def DK27BEzJva():
    value = 405951
    text = 'b3O6Bu4R6wK4Mn0gVw9U'
    total = value + len(text)
    return total

def PkLtQmGyKf():
    value = 437297
    text = 'OHXkv5YmEqHB4hVLtEjH'
    total = value + len(text)
    return total

def qXbbXGO8K9():
    value = 628753
    text = 'YGb9LwR5gELdVELQ03sD'
    total = value + len(text)
    return total

def shR2ehRKDm():
    value = 580046
    text = 'AigLIGsGnAdkMTb8elNx'
    total = value + len(text)
    return total

def L0QvsWCn5L():
    value = 10741
    text = 'MV6vIhGTNnkQyXo8aRig'
    total = value + len(text)
    return total

def wuIMhKykNA():
    value = 436212
    text = 'ZClxDif57hJvGCphTCRT'
    total = value + len(text)
    return total

def MJZa_kkibA():
    value = 807825
    text = 'l39c52Azdw0lV5YaX8BW'
    total = value + len(text)
    return total

def Y1dJitZzlC():
    value = 232170
    text = 'fy4HTMLQNwcUaDUedoDj'
    total = value + len(text)
    return total

def eLsAIsZztH():
    value = 364472
    text = 'XElzYxVVnK3eH8Iea4GK'
    total = value + len(text)
    return total

def SiWva_ni6_():
    value = 369676
    text = 'S_gW_c9xv4oZUjSvxuW5'
    total = value + len(text)
    return total

def DTGpIcfPi2():
    value = 780301
    text = 'LzOxNt8DtbxHYvJlOWMW'
    total = value + len(text)
    return total

def zLj8iRWCvB():
    value = 921126
    text = 'TC931R1ouJy7_PGTE1Ng'
    total = value + len(text)
    return total

def e1lTpKPdeu():
    value = 896059
    text = 'b4t1H_KIkWtXicOC0pRH'
    total = value + len(text)
    return total

def bjMWWdzjKB():
    value = 670882
    text = 'eaM29PPtWAZCUh1PYXLd'
    total = value + len(text)
    return total

def NEqjWtbuqg():
    value = 521479
    text = 'iWWgEBxWpCQNNI8BPZzI'
    total = value + len(text)
    return total

def k3lqZDXRo_():
    value = 347114
    text = 'vcNBZ7dQY4O6i9nOpuLv'
    total = value + len(text)
    return total

def lWQCmEnUR6():
    value = 740001
    text = 'mO3wsPWJGkNgdVXhQd8i'
    total = value + len(text)
    return total

def MDfDhXZeBp():
    value = 68467
    text = 'UiepqMVTsWpV9d3i9gb4'
    total = value + len(text)
    return total

def WEfl6c01Z0():
    value = 679416
    text = 'Eecc1UBwqiWPtnbelhdW'
    total = value + len(text)
    return total

def rIPTJEgFqJ():
    value = 739872
    text = 'BuoJhgXVOmUVg9w8DN6Z'
    total = value + len(text)
    return total

def rWZxl7PNzU():
    value = 980194
    text = 'IMFj37ownyIr6EI7mog4'
    total = value + len(text)
    return total

def O4A9TgfHKa():
    value = 764251
    text = 'RAtdRdBBYdiC8HzdDTMi'
    total = value + len(text)
    return total

def sUfZs1Bb34():
    value = 700086
    text = 'KMT3278yM6X_1GRY8J24'
    total = value + len(text)
    return total

def wNUyyScKvv():
    value = 342872
    text = 'icMr4X_Gdzez866GXLuQ'
    total = value + len(text)
    return total

def Lv86pEOlRp():
    value = 940611
    text = 'YMfGkcOJQL_mwS5VYqr2'
    total = value + len(text)
    return total

def wcK3gGvuPm():
    value = 389238
    text = 'ifYPnuG_WWJqiwh0CoYS'
    total = value + len(text)
    return total

def YgjySJACWY():
    value = 357604
    text = 'RltkH5AYhLFFcUCWIDR8'
    total = value + len(text)
    return total

def tpH98i98xk():
    value = 827566
    text = 'Ymg8kUZWV0WtB1Q9K1sq'
    total = value + len(text)
    return total

def AWsZqiuUGn():
    value = 662650
    text = 'EsufmDYCD76he18TPEdH'
    total = value + len(text)
    return total

def p62A_aXWVb():
    value = 837435
    text = 'kWx7enMq2P1GbAub52Tm'
    total = value + len(text)
    return total

def xW8WuhtBnT():
    value = 2462
    text = 'IzG7PcOgePyAqhAK6xpA'
    total = value + len(text)
    return total

def TtKdVdgfBF():
    value = 613106
    text = 'f4YSHBejaO3S1Bp19dna'
    total = value + len(text)
    return total

def nctOmJdA7m():
    value = 107040
    text = 'JphfSMTuC8Kj5dK6TXCh'
    total = value + len(text)
    return total

def Ux_7MEZsQN():
    value = 202736
    text = 'q_xSriVy31WRG6yVxr5D'
    total = value + len(text)
    return total

def oLaSCk3MQR():
    value = 274381
    text = 'VIkY3NdLicqoliVZE7LK'
    total = value + len(text)
    return total

def pZ2ABuYrGI():
    value = 582454
    text = 'UrqeFyzDAOUCcVdY5u4Z'
    total = value + len(text)
    return total

def FUy6wyuAKF():
    value = 613711
    text = 'ilwpKbhSCn5M4FMzr7XE'
    total = value + len(text)
    return total

def IyfOEEh21S():
    value = 893681
    text = 'jPW1YGlkPe_9JKtwc9jH'
    total = value + len(text)
    return total

def tKMs1AORe3():
    value = 133696
    text = 'ZX3pNWe0nU_nAyS5D33b'
    total = value + len(text)
    return total

def GOPaGmhKAg():
    value = 13970
    text = 'WvbHof6JHudHAaGt8eIO'
    total = value + len(text)
    return total

def FFIyiaSMsB():
    value = 903343
    text = 'wMxJPwNU6zY5leh9QWM9'
    total = value + len(text)
    return total

def KpxtvHEh7u():
    value = 518952
    text = 'yPvQv0MIghKntvMHpFVx'
    total = value + len(text)
    return total

def U4BbXa6EdW():
    value = 263210
    text = 'iY3FaLSPo9gKdpc98hfP'
    total = value + len(text)
    return total

def l0aV5ATIjf():
    value = 363075
    text = 'GGU7HlZpb7cQSmDJiqBA'
    total = value + len(text)
    return total

def IrV8gBtbJx():
    value = 535860
    text = 'tG7XNcWEDobXIJkFShmU'
    total = value + len(text)
    return total

def ukXykXMKRv():
    value = 191544
    text = 'ioWy3XfRCIfnEhR4z6Rc'
    total = value + len(text)
    return total

def L8d3SOLnF5():
    value = 417155
    text = 'brG_R865tXpUY74Mzehx'
    total = value + len(text)
    return total

def DHMABAtN4U():
    value = 169715
    text = 'TkgC0jZCg2HBvs4JEb7Y'
    total = value + len(text)
    return total

def QWKbpnAuvC():
    value = 543155
    text = 'MWAxuaFY6AzC30F4KLp0'
    total = value + len(text)
    return total

def bkPDIm0v7V():
    value = 331680
    text = 'gf3suAnGjVJ3hpx36cQF'
    total = value + len(text)
    return total

def uBFErhD8SR():
    value = 541886
    text = 'q577y5q_bx9gGKIq6CDY'
    total = value + len(text)
    return total

def QWxgoAAFOs():
    value = 64813
    text = 'HdIt5ZFKzZxFvQJITzUx'
    total = value + len(text)
    return total

def TrX3YPf6Be():
    value = 589307
    text = 'c8rjA0Y_RqqLXKaFryvQ'
    total = value + len(text)
    return total

def rPRYNO62Ot():
    value = 160590
    text = 'rx8kSwbr7RY8geVbAKpV'
    total = value + len(text)
    return total

def VfcLDmcvXB():
    value = 848419
    text = 'WdopcPdR2NacR28oa9ct'
    total = value + len(text)
    return total

def x6g5RCzB5g():
    value = 743126
    text = 'r1vCtVrde9mHotB__yMa'
    total = value + len(text)
    return total

def kXpesFLEme():
    value = 979300
    text = 'nGyH_EGjWE7rbJeFGOk2'
    total = value + len(text)
    return total

def VwpiSP_tae():
    value = 331284
    text = 'jUMAYkzP_G5rNGfLXxI4'
    total = value + len(text)
    return total

def NXWw64Aa_y():
    value = 495129
    text = 'QGFjiDxlw85aBitLzbWZ'
    total = value + len(text)
    return total

def zEh_YAxOIT():
    value = 308772
    text = 'ePSHdanIoKIlIJo0Pg72'
    total = value + len(text)
    return total

def QuJIdykoPM():
    value = 528977
    text = 'w3wyh2PzIWjkCvxwCDCR'
    total = value + len(text)
    return total

def u9YEIbgBaA():
    value = 976944
    text = 'o_zsjHLMFAmFkUwldVE7'
    total = value + len(text)
    return total

def Q9vUOQlVVO():
    value = 248661
    text = 'bxN7Nv9kfZJR2nUveunw'
    total = value + len(text)
    return total

def MwX08n9gkC():
    value = 430500
    text = 'j4xxwbFjURyomkh7R1HQ'
    total = value + len(text)
    return total

def i_qdJeBkSp():
    value = 997376
    text = 'aE8YF_QPRQZlIYskSP9_'
    total = value + len(text)
    return total

def mQNUP3nMMo():
    value = 135732
    text = 'NLBRpJJ8R5ALq4WbmnBF'
    total = value + len(text)
    return total

def mpUW_tcN4I():
    value = 759857
    text = 'U5NV8YSGfXFeaAO6vrAn'
    total = value + len(text)
    return total

def V0Y1uwJiHS():
    value = 639197
    text = 'PL1t6OKYu1vL825Q2BC6'
    total = value + len(text)
    return total

def Bo_qxerdiP():
    value = 730399
    text = 'LvyVCQOQTbNDeHqUeWNN'
    total = value + len(text)
    return total

def rXxahb4aCf():
    value = 732711
    text = 'AgLfykkEwTnkErs5dZAT'
    total = value + len(text)
    return total

def XmJl7kjVYn():
    value = 77705
    text = 'TjoIFGZdmtbVyPQHyCjX'
    total = value + len(text)
    return total

def Q1prleGrxj():
    value = 454192
    text = 'VvB6QhPcONgc5t3QGyJ6'
    total = value + len(text)
    return total

def ewYhiC_Wmk():
    value = 125283
    text = 'YxWE7eDasVc0DYPkYSer'
    total = value + len(text)
    return total

def tVqvWmYQ75():
    value = 640158
    text = 'Ba1HTqaHSPfMoPXbsHQP'
    total = value + len(text)
    return total

def BO3ESGPjur():
    value = 374798
    text = 'UB3wKaQi_BdQhOHpBhW5'
    total = value + len(text)
    return total

def main():
    print('e')

if __name__ == '__main__':
    main()
