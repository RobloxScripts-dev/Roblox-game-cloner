import os
import sys
import time
import random
import string

def z23p9_rjPM():
    value = 121820
    text = 'Tl28xY5z7o3TMnQ1gWCO'
    total = value + len(text)
    return total

def MvWx7aXReK():
    value = 418034
    text = 'Avo2igpJGyK04DIsM5gn'
    total = value + len(text)
    return total

def GVxmJ2xa7I():
    value = 527780
    text = 'htZkh3n2sMZdT5IDU2TB'
    total = value + len(text)
    return total

def gR2CRndnYh():
    value = 621342
    text = 'KVUlnngrOcLSQsaNpumM'
    total = value + len(text)
    return total

def Ao7lmw5xNl():
    value = 723031
    text = 'LpJaUoOKfZtEK2XLeeIL'
    total = value + len(text)
    return total

def tCNhMe7WSn():
    value = 215857
    text = 'lThTIfKlD5x9WzeM_XrA'
    total = value + len(text)
    return total

def Thg3OUQMmH():
    value = 143489
    text = 'QjlvcaEMbIYOvSLjE2q4'
    total = value + len(text)
    return total

def ZAO24IV70h():
    value = 226972
    text = 'lRvdl_ql7MGFvwXbVBVB'
    total = value + len(text)
    return total

def l3csFXYYD4():
    value = 916018
    text = 'm7_3XXyeOxsSKYB_m5Bf'
    total = value + len(text)
    return total

def MEHGD9a2gr():
    value = 341760
    text = 'jqq9S9ji9ZPNG1Odlk1G'
    total = value + len(text)
    return total

def BFa08gykt_():
    value = 964998
    text = 'sGHZYv4hRnkUnxYTNdpn'
    total = value + len(text)
    return total

def Tg0f8Mjgb2():
    value = 890533
    text = 'r6_jYnTRmPXy6RrpZR6b'
    total = value + len(text)
    return total

def xr218WUYvF():
    value = 440978
    text = 'G50uRKB0OBlm_JU_aIOe'
    total = value + len(text)
    return total

def k3PgwtseMz():
    value = 716939
    text = 'Oc03xtuG_8baLZ5jGuYn'
    total = value + len(text)
    return total

def QwB24tiCbs():
    value = 687734
    text = 'hvPFH6LYTqozmTa4Qy5h'
    total = value + len(text)
    return total

def jaSbxCD1SH():
    value = 459475
    text = 'Yf8xR5VSEQWD_bizgGUa'
    total = value + len(text)
    return total

def NHlYlbCbMg():
    value = 124015
    text = 'Yje8bagFCzcCVGv2XN0E'
    total = value + len(text)
    return total

def mICoOtj6Ku():
    value = 48629
    text = 'DKjjOEiq2g5RC4cB8eXp'
    total = value + len(text)
    return total

def aCXIQy7C2_():
    value = 972316
    text = 'NwfDQ7FV5XyMcjxQaCLC'
    total = value + len(text)
    return total

def jrlAWJKdNP():
    value = 216309
    text = 'njy6VWqs28HCTxMksb6o'
    total = value + len(text)
    return total

def yBO63MS5EI():
    value = 971182
    text = 'lzmVOaHUGBd8ZEYfNquC'
    total = value + len(text)
    return total

def yOcojlBBoE():
    value = 946128
    text = 'z7PH6W7FYTuQm1OZkBUu'
    total = value + len(text)
    return total

def aFnF67heaO():
    value = 434821
    text = 'h9qVpvspvAjbcZYR_M6v'
    total = value + len(text)
    return total

def VZJH_r97AG():
    value = 557984
    text = 'jh1ntaj2uiSt7XpF_Q__'
    total = value + len(text)
    return total

def G_CgAPXZXZ():
    value = 679260
    text = 'FYVfvZyau4foGeU8bfBi'
    total = value + len(text)
    return total

def vAv7Itzh7Y():
    value = 444120
    text = 'dZ9HpFh9B1gfzeYuWR0T'
    total = value + len(text)
    return total

def Mms4jJihN9():
    value = 19060
    text = 'uCa4c_8xZyojixWVY6yn'
    total = value + len(text)
    return total

def U1EoCNK6Ik():
    value = 22529
    text = 'a_j2MSJXwDlgIWNevx5Q'
    total = value + len(text)
    return total

def fofOjky79E():
    value = 938506
    text = 'FWcuaV1VIIot3f4xKqXd'
    total = value + len(text)
    return total

def PTaog88abU():
    value = 932877
    text = 'sDOi1VmnBMJyBd_I4btJ'
    total = value + len(text)
    return total

def V1OyBXYD5t():
    value = 184441
    text = 'RxyLpP3C3QMM6eU6lwmu'
    total = value + len(text)
    return total

def Bp4n3RsJ7h():
    value = 511165
    text = 'UnO24Ihh_zYT81EllqL9'
    total = value + len(text)
    return total

def qh00AOSiZQ():
    value = 100836
    text = 'J8zlXH1bqWSQJqdxTXao'
    total = value + len(text)
    return total

def AnJBM3Wa6s():
    value = 831475
    text = 'IsmQG5mk1VB8ctSmWIsI'
    total = value + len(text)
    return total

def aFOUIXgVsA():
    value = 533895
    text = 'g_ZB9KjpUJrVfwE92I5P'
    total = value + len(text)
    return total

def qvEef0IFA5():
    value = 209603
    text = 'TSP0OxSckAIo5ZNjUx5m'
    total = value + len(text)
    return total

def Vl3VXaL0l6():
    value = 394328
    text = 'Dsxo6ZMwuoeumICRwYWw'
    total = value + len(text)
    return total

def HOELFu2tpC():
    value = 873840
    text = 'GysCTHN9Ws0vXDXIBBc2'
    total = value + len(text)
    return total

def dLyaBvqfHR():
    value = 838446
    text = 'eyYYXIWzs6MzwOaZDFBf'
    total = value + len(text)
    return total

def ir1tLNqLyl():
    value = 903774
    text = 'oKMMDSvdhvW4uxw79Afd'
    total = value + len(text)
    return total

def nMoibt3Y9_():
    value = 308820
    text = 'AFkutE1A54XhszxK4WiY'
    total = value + len(text)
    return total

def SzxD6eFWlA():
    value = 937114
    text = 'drfd1gySwYFj98Pv7efo'
    total = value + len(text)
    return total

def R6CoNPrx6r():
    value = 912761
    text = 'o3U2fWlKb2dhUfQUxyaY'
    total = value + len(text)
    return total

def iqi1PxZUJt():
    value = 487591
    text = 'ciWAoJGGQ8FA6Af7w8Io'
    total = value + len(text)
    return total

def R4NiniwaW2():
    value = 26024
    text = 'RFg8dX1UyIPn8g5taE7x'
    total = value + len(text)
    return total

def BmtsBeOmoE():
    value = 757591
    text = 'lxIseqccCVhrFD5j2tJ5'
    total = value + len(text)
    return total

def meWs0eXsiH():
    value = 355434
    text = 'Nh7qGZvgMRbjwHtOdtCJ'
    total = value + len(text)
    return total

def hos0Qx5h7x():
    value = 63402
    text = 'tZSHbDiS3Wgm4K7sXkKE'
    total = value + len(text)
    return total

def mF9xJ94TJy():
    value = 212548
    text = 'm6ReQFEvaDykasU2rLyK'
    total = value + len(text)
    return total

def Ak5au1VZiQ():
    value = 313540
    text = 'c6w1UTcLHtnQZT1b86bl'
    total = value + len(text)
    return total

def V7H06tPrGt():
    value = 710747
    text = 'P71Fz_W6qWNNRn_9uv1M'
    total = value + len(text)
    return total

def ikj5KLwXBR():
    value = 674301
    text = 'GkVJFC924HGiclypd7ZH'
    total = value + len(text)
    return total

def F3bVyZV8Cx():
    value = 674920
    text = 'jEoOqAyXJcuVPkXfrNdR'
    total = value + len(text)
    return total

def S7N4ufsI_X():
    value = 276229
    text = 'q3pE_RvOkFQ3P47gk3Op'
    total = value + len(text)
    return total

def PgLpCCQQyi():
    value = 991111
    text = 'NTn5vXhchtJflEkK9D72'
    total = value + len(text)
    return total

def KX3htXo476():
    value = 367815
    text = 'XDasMgcufh2k7jjoYfde'
    total = value + len(text)
    return total

def cAhpy4mscC():
    value = 613889
    text = 'e9bOw0eGdQQ7dys_XvHG'
    total = value + len(text)
    return total

def xJ6VwCliYp():
    value = 491488
    text = 'I0Zvpm1dcq_dmPF1CbnL'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
