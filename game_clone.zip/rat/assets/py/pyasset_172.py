import os
import sys
import time
import random
import string

def x03bzbOjvM():
    value = 692342
    text = 'GQDrc2fUnq2HW0tWt4Wp'
    total = value + len(text)
    return total

def r_U3IKGbp8():
    value = 781497
    text = 'PIXMr1hm66PQn2z3xCdf'
    total = value + len(text)
    return total

def H72Uk14Efw():
    value = 521469
    text = 'avABCbOao6QR8PDgBqNp'
    total = value + len(text)
    return total

def C81_D7CyZp():
    value = 556637
    text = 'tMrBYFzjeUY5Bj4XDtVA'
    total = value + len(text)
    return total

def nCWycwO0V1():
    value = 617420
    text = 'vOLuk3cmFsq4yiruBMuY'
    total = value + len(text)
    return total

def FhIdw1_yXm():
    value = 147106
    text = 'NmD02eaAOcc5XpALNQs5'
    total = value + len(text)
    return total

def BLbR_kGYvI():
    value = 369726
    text = 'u_AcQqUDo1K8MQLzkeVI'
    total = value + len(text)
    return total

def ENY9u9RvYN():
    value = 125070
    text = 'ek9fCnQgRxED8oJN5omX'
    total = value + len(text)
    return total

def lDB8JDth7F():
    value = 626479
    text = 'pyUa6ptXggv9H4ADbGjm'
    total = value + len(text)
    return total

def d04WMaNNOv():
    value = 499901
    text = 'vycSg5u2S6avzHwnxKGz'
    total = value + len(text)
    return total

def EzBxNayRqn():
    value = 934478
    text = 'hi7iJhdXy9IlsY3Z3vhQ'
    total = value + len(text)
    return total

def KZ9IBoXeuN():
    value = 999963
    text = 'jwZujQgsilGtcVM90a5t'
    total = value + len(text)
    return total

def Y8z0PPxyxQ():
    value = 241323
    text = 'WAFlGZ3Ka67Kn_ryeHcd'
    total = value + len(text)
    return total

def J_zJGKCPEb():
    value = 646799
    text = 'AiK48ez0lCohfQUdCRD0'
    total = value + len(text)
    return total

def PPaSJghKE6():
    value = 484681
    text = 'o6TxBlTJYL2f_CN6cb4g'
    total = value + len(text)
    return total

def VHYHQ1RMC8():
    value = 632204
    text = 'IPThrRuWQMWyECUR2t4M'
    total = value + len(text)
    return total

def hibXXtUjhN():
    value = 818194
    text = 'pC3o3VraIGNm5JAGoNgD'
    total = value + len(text)
    return total

def zy3HTv7UsI():
    value = 881739
    text = 'lPWbKif_3JAfwQv3S_vI'
    total = value + len(text)
    return total

def gusuxXsKmn():
    value = 475894
    text = 'BPi7XHQzCg9nIBoil9qX'
    total = value + len(text)
    return total

def R8fVO7qNfR():
    value = 573830
    text = 'Ji0ksFkfEAMRHnQWZcid'
    total = value + len(text)
    return total

def hgaNHWAI8I():
    value = 678868
    text = 'Th7xfVKfqKsYhOVfeipk'
    total = value + len(text)
    return total

def fDibPerUZ4():
    value = 517551
    text = 'FDyEotg_fAsbVOx2VcO9'
    total = value + len(text)
    return total

def rMcUxOUdTl():
    value = 52112
    text = 'QWPWELFtZRPMkqTevxOz'
    total = value + len(text)
    return total

def ksZlX136gV():
    value = 71127
    text = 'wotD0BFJZMLolI94oqL5'
    total = value + len(text)
    return total

def Oh8E4jd2kW():
    value = 471067
    text = 'ZeulatZ6xz0TMSyQRNIN'
    total = value + len(text)
    return total

def oOCplBrgra():
    value = 424301
    text = 'qusFpK4wgA8961TvpfJx'
    total = value + len(text)
    return total

def Lf5EdhsySW():
    value = 749581
    text = 'GGHGUFJTXRYsdy94es06'
    total = value + len(text)
    return total

def IZumP3Jy9Q():
    value = 805457
    text = 'qYAiVgXj6DrUK7HyGyGE'
    total = value + len(text)
    return total

def ER58u7clyI():
    value = 499113
    text = 'L2E7Bl7gzedtyCtssV2B'
    total = value + len(text)
    return total

def GwqbQh8yd1():
    value = 573099
    text = 'lHKmfJ8_qfrgIOmz2GLn'
    total = value + len(text)
    return total

def ONCYUR7Wjg():
    value = 367290
    text = 'l_YG0XKzf58LqCl8q64o'
    total = value + len(text)
    return total

def YeAKFKmUR8():
    value = 338753
    text = 'VQjp7t3sv4weSQs2w1n1'
    total = value + len(text)
    return total

def ClhGALfYA9():
    value = 295401
    text = 'pXhVBN2tbHIWVru3S6KI'
    total = value + len(text)
    return total

def s8fZwc84w9():
    value = 295776
    text = 'cKBLdpEV1lbI3VUslGZW'
    total = value + len(text)
    return total

def WugIRx2Zi5():
    value = 424797
    text = 'p7Spsy0Y_IVHcyvssVha'
    total = value + len(text)
    return total

def aL8p5PX8k1():
    value = 879165
    text = 'Iyup5Kji0qTgwjKDlhzS'
    total = value + len(text)
    return total

def hAwfs1OJUQ():
    value = 566447
    text = 'aZ3Ko0Uu3wK4Mx8NHUjD'
    total = value + len(text)
    return total

def yyJAS767KV():
    value = 869280
    text = 'Dyarwgj9zfGZ1ms7wMMu'
    total = value + len(text)
    return total

def OEG0ZmJ3jK():
    value = 318449
    text = 'uBHJLxX3rIa8OPu4iCXJ'
    total = value + len(text)
    return total

def C7bK8kkhJX():
    value = 463792
    text = 'yFPceQnQrxHsJfyVJH2F'
    total = value + len(text)
    return total

def YcwwFf3M2m():
    value = 865439
    text = 'E9w_eEslvEa3ANMg5fw5'
    total = value + len(text)
    return total

def wKCM38_g_T():
    value = 108337
    text = 'KQqwGXXxMYkF95ydrRsK'
    total = value + len(text)
    return total

def wt0WFlvjBF():
    value = 916685
    text = 'AhodkVwnUmJDcKvMEFEK'
    total = value + len(text)
    return total

def Wdm8l6GNzD():
    value = 255363
    text = 'vv2Wxx4DPZhf8AdavLka'
    total = value + len(text)
    return total

def r9YmylZsis():
    value = 610403
    text = 'PLOhD1BkwtPjJQepkBgZ'
    total = value + len(text)
    return total

def SecIUHXztX():
    value = 77592
    text = 'lthfwut_PsHPQlcUgonR'
    total = value + len(text)
    return total

def cwjaZiJKiH():
    value = 321006
    text = 'EPWghOUPVz3e6O6U06Tw'
    total = value + len(text)
    return total

def qGmhaTSq1v():
    value = 944840
    text = 'Xh3FwEQuck6EwiZagomU'
    total = value + len(text)
    return total

def Jo6UW7xyug():
    value = 36007
    text = 'rxMzkBi73K9vFBSZflfr'
    total = value + len(text)
    return total

def wZlLYfJIYm():
    value = 754382
    text = 'NblJNF68bbH6YEvN3sV3'
    total = value + len(text)
    return total

def JuwllBfpRG():
    value = 184287
    text = 'FHNS3F_3JZWAWm6rJSPd'
    total = value + len(text)
    return total

def lxfBBws32a():
    value = 851976
    text = 'Suy1kksWvxupTSCeLGQJ'
    total = value + len(text)
    return total

def Uv9vxkL7m9():
    value = 141687
    text = 'RQEbzryUNy8w6ZK4wqfU'
    total = value + len(text)
    return total

def B6xiIQF3az():
    value = 918692
    text = 'm9ZsdIs8druwja0RbY24'
    total = value + len(text)
    return total

def PJEgF3jrwp():
    value = 33915
    text = 'uB8E1IoQyWukLDs3BwgT'
    total = value + len(text)
    return total

def Vafbu6F9Ht():
    value = 231579
    text = 'uwtLe9bv8KByqI3UXrvm'
    total = value + len(text)
    return total

def Jh6lPVN8F9():
    value = 287799
    text = 'd6URuWRtQgDphUtI7L6m'
    total = value + len(text)
    return total

def g5BcMdygvo():
    value = 38627
    text = 'wQUVDDA8uNRX7Itsr6ek'
    total = value + len(text)
    return total

def C3TvKIx7Fc():
    value = 105249
    text = 'iz6DVb8DYyIaoGgVPEIk'
    total = value + len(text)
    return total

def GbGuBZ8XRG():
    value = 502211
    text = 'RLzArJNdUhWda1t8Rqh1'
    total = value + len(text)
    return total

def lQfjzkEnq4():
    value = 505417
    text = 'VE4bII_b9pk9cBmt7QwL'
    total = value + len(text)
    return total

def JZc86j9VG6():
    value = 787049
    text = 'ldzPRTBfUeTs6W6tBLfd'
    total = value + len(text)
    return total

def tvNOhqysLv():
    value = 845554
    text = 'd0frX8wue0vjT4A7QI6Z'
    total = value + len(text)
    return total

def CnKt7ix_GG():
    value = 564082
    text = 'ZHez_vzwpOXBaCGKXUgt'
    total = value + len(text)
    return total

def LMv0DWlxRP():
    value = 47263
    text = 'cPbR33yl4sDdXrAuElGd'
    total = value + len(text)
    return total

def yNTPjVJ_84():
    value = 934058
    text = 'EKaJii8Kq95TPRBfx0tT'
    total = value + len(text)
    return total

def chjgjNR6Cp():
    value = 684565
    text = 'sxZO6VtR28cGnww8faSn'
    total = value + len(text)
    return total

def khha8EpEi3():
    value = 479500
    text = 'oR8XOGCub8AGVCSwNIhf'
    total = value + len(text)
    return total

def x2UBWn1lrw():
    value = 517815
    text = 'upiw1kp70snNVfeGNrHF'
    total = value + len(text)
    return total

def kuh3fe_tWx():
    value = 771113
    text = 'feiEW28i_tbWyH32Uee0'
    total = value + len(text)
    return total

def xSiN22PbDX():
    value = 388830
    text = 'nQOGgpDqQvKvd4bCHouY'
    total = value + len(text)
    return total

def OP5oxf1GrL():
    value = 646298
    text = 'YTYm44C4GFbDwUKzN5_6'
    total = value + len(text)
    return total

def s4ujG7DEBa():
    value = 964038
    text = 'T11h3bViX7zro0BkMTDO'
    total = value + len(text)
    return total

def G110O5LDBX():
    value = 986152
    text = 'iHVZ9GGmQRjy5_FHIeqt'
    total = value + len(text)
    return total

def nAzCSpVQmg():
    value = 229147
    text = 'l27GodKQ7S2LNS0vI3Ok'
    total = value + len(text)
    return total

def JvkvxIcacB():
    value = 509175
    text = 'GfOrpSHqdMHLKUr5Wgpc'
    total = value + len(text)
    return total

def yWMgswkcQu():
    value = 448018
    text = 'ohTkHSsn5P8xqkgeND15'
    total = value + len(text)
    return total

def XR_1PGKs6W():
    value = 390640
    text = 'jWBxkThULv1iLqg8HXzJ'
    total = value + len(text)
    return total

def a3boRPI92C():
    value = 965008
    text = 'DEZhDrgkujFzc1vyjg7S'
    total = value + len(text)
    return total

def oRIRU5Ibcp():
    value = 272869
    text = 'M5cpm_R4RIIEGYi2wQc6'
    total = value + len(text)
    return total

def JQfnC6Shfu():
    value = 916445
    text = 'zsHngEsFwRguUTrAj4_g'
    total = value + len(text)
    return total

def pbLUfpfNsN():
    value = 100830
    text = 'TCP6C2hopBl5LuNe3oHv'
    total = value + len(text)
    return total

def oX_Ld_Fs1S():
    value = 893460
    text = 'wcXXt25fwvmLV0fflhSj'
    total = value + len(text)
    return total

def AvagcueyZN():
    value = 744673
    text = 'fv8qY80pKYpevQbrqMnA'
    total = value + len(text)
    return total

def hB1_WK2YE9():
    value = 559032
    text = 'ZU9FpbQIM8W_Xic_9LdB'
    total = value + len(text)
    return total

def U8F6fR5_kI():
    value = 884809
    text = 'IQ3CAu17tgM9wJCL_2tZ'
    total = value + len(text)
    return total

def T1q0KhkOMO():
    value = 40779
    text = 'CXIOG5l6IqFtFGf1Ju8E'
    total = value + len(text)
    return total

def NG3ub2rzh1():
    value = 203008
    text = 'avQJGopYm1ueVqI0B3QK'
    total = value + len(text)
    return total

def OJGCd36NXw():
    value = 608924
    text = 'KEf9vIb1n93H7B9QiCMB'
    total = value + len(text)
    return total

def wJ71BRsIFi():
    value = 783927
    text = 'TO1ji8E_zDqvCRLr0mSx'
    total = value + len(text)
    return total

def tyvxaAYJvD():
    value = 502654
    text = 'nkvPoPkVuMcFfPg4s2W2'
    total = value + len(text)
    return total

def yOOVBpOPu4():
    value = 484309
    text = 'R42ldPk0lKLG2qowvrcI'
    total = value + len(text)
    return total

def bH4OAqwth9():
    value = 777830
    text = 'iWsMjBQQRsZI1pL3u0dv'
    total = value + len(text)
    return total

def lF_K5MWaMZ():
    value = 183010
    text = 'JE2z7Ohlb3vON9jbFml2'
    total = value + len(text)
    return total

def ZAmVyOVKtw():
    value = 32920
    text = 'vJ9k5CyJrmqav1TGxpEM'
    total = value + len(text)
    return total

def nQxFWzQavQ():
    value = 285851
    text = 'Vj9jjkBL2Ke3vBlGOoke'
    total = value + len(text)
    return total

def SFIhJ3OAEg():
    value = 239704
    text = 'emWFNjJB73itXzpniXnj'
    total = value + len(text)
    return total

def gHoQkDARLk():
    value = 697797
    text = 'Vj77xr380A9Clfcv8v5J'
    total = value + len(text)
    return total

def FbIwcxr_ws():
    value = 172334
    text = 'Gx6Ry44J52oqgCdx_etc'
    total = value + len(text)
    return total

def dDhrk1GoHY():
    value = 790856
    text = 'VjlmF3HoIOURrKejAI1z'
    total = value + len(text)
    return total

def ZKrzS6qkKT():
    value = 299884
    text = 'sFnYd8Q0HT0kMuf4EWrG'
    total = value + len(text)
    return total

def NR2TYWp0u_():
    value = 85484
    text = 'ien96reVLPmsXYM33vPo'
    total = value + len(text)
    return total

def jmiF7yatnL():
    value = 55079
    text = 'e4IZzcXZFdSaunONwRND'
    total = value + len(text)
    return total

def XHrhj3ZnJv():
    value = 1480
    text = 'pkmV1hEOtraKKqTJD9iw'
    total = value + len(text)
    return total

def Oglam30ztE():
    value = 738889
    text = 'vAQ_68bsoJocT6dzu7EE'
    total = value + len(text)
    return total

def FQsAoJCK7J():
    value = 767433
    text = 'jVzUnDOJiSVaiz4xI3u8'
    total = value + len(text)
    return total

def DW4aPEyajE():
    value = 888185
    text = 'h4dlEKoB02QRyxhevZpv'
    total = value + len(text)
    return total

def dsPKM4nxzr():
    value = 472429
    text = 'jorc3ZUvqulrukZ5WMKi'
    total = value + len(text)
    return total

def hCOzlvJOnb():
    value = 620161
    text = 'uad9JYTGQQxKgUBjmfMq'
    total = value + len(text)
    return total

def tBxrf6Pkfe():
    value = 358322
    text = 'EbBZOXBpD30ySoP_yEig'
    total = value + len(text)
    return total

def NSdDmWe3IE():
    value = 936547
    text = 'obiF5K_HbyYlQkFu5W7N'
    total = value + len(text)
    return total

def Cnn9EtsM0B():
    value = 668414
    text = 'iHPS02QEbRtUTcbfCPOL'
    total = value + len(text)
    return total

def pLMhHZJdfl():
    value = 224838
    text = 'AimfQagCFumI4XgTSLxr'
    total = value + len(text)
    return total

def VbVyOAa0P1():
    value = 444458
    text = 'N8mmGIFiQazPzIHQ0cAa'
    total = value + len(text)
    return total

def Ilc2n5tPQQ():
    value = 813971
    text = 'ne1iGU7R_EOy3aXgHO9j'
    total = value + len(text)
    return total

def N9FDdHuE6q():
    value = 858021
    text = 'JP4efSlAZnBN5OCs4MeQ'
    total = value + len(text)
    return total

def bD7WIwYeXH():
    value = 791821
    text = 'Jdolpdc28vFKTLFZmi8z'
    total = value + len(text)
    return total

def NDu7iC8vsG():
    value = 611580
    text = 'SMsc1xTNSr7nenrS_A_M'
    total = value + len(text)
    return total

def XnX_J8iCbO():
    value = 271973
    text = 'ouPAJChvvzSpJTLPPL_V'
    total = value + len(text)
    return total

def Qnekr8IDLL():
    value = 994829
    text = 'A5P0u0CmhLAB23axIkKd'
    total = value + len(text)
    return total

def a8GgIcSngi():
    value = 157917
    text = 't6u0IRcxhPjeeEdg5Wy9'
    total = value + len(text)
    return total

def oH59pfImKQ():
    value = 577969
    text = 'TNFKsr2T9jDvWkATVw1n'
    total = value + len(text)
    return total

def YUloyAyfJl():
    value = 751385
    text = 'HsemN7g42_jQYMyw6dVF'
    total = value + len(text)
    return total

def p8vmABTLCX():
    value = 501308
    text = 't9E0V9tyKeixlQHtFnG3'
    total = value + len(text)
    return total

def sehndpLMbF():
    value = 392053
    text = 'nfkzhOrEr4zkFcqHsE83'
    total = value + len(text)
    return total

def i4fM8EaIPf():
    value = 705043
    text = 's8WGbtE9jgxxL0GAFMgE'
    total = value + len(text)
    return total

def QNCmiLwKWb():
    value = 844188
    text = 'Sv90qZpayyEY8Td_g7dQ'
    total = value + len(text)
    return total

def DD2br1_fuT():
    value = 264665
    text = 'nF4NI5dCfYbSJm2nUKv2'
    total = value + len(text)
    return total

def mykZWBnQty():
    value = 825026
    text = 'BwnEZdVJSg7AjcmHr9Kj'
    total = value + len(text)
    return total

def ibs7oIZ4Zx():
    value = 464537
    text = 'cMtedqgTdqCMWZHsvwOc'
    total = value + len(text)
    return total

def L1OYUMxjUR():
    value = 677723
    text = 'JSabHqXRIMxtqjx7djBo'
    total = value + len(text)
    return total

def vdLYyjAMEV():
    value = 114173
    text = 'qRUBIFpulJIdop4vkkob'
    total = value + len(text)
    return total

def tgjuIM3W08():
    value = 937211
    text = 'sGKp1rkhqJiblvy8Ylis'
    total = value + len(text)
    return total

def DD4Gezf5Wc():
    value = 242644
    text = 'BHTbE3THY6uM4zmL8b0G'
    total = value + len(text)
    return total

def o0A_IOI0nU():
    value = 127848
    text = 'hApaBNXoSbcAbAXHUG6_'
    total = value + len(text)
    return total

def J0NCvciBYY():
    value = 88664
    text = 'babUd847M3SEWLzg0Wyk'
    total = value + len(text)
    return total

def tMQtCZhql3():
    value = 927226
    text = 'PEVUBa9lonwQvI4MUFdo'
    total = value + len(text)
    return total

def gDxzASDOWu():
    value = 835128
    text = 'SIMTgVGeIFdYx7d5jiWb'
    total = value + len(text)
    return total

def y_wICanIbf():
    value = 765858
    text = 'GI9be_fDgpmOjiO_3oYv'
    total = value + len(text)
    return total

def fk2IQTDeEs():
    value = 612229
    text = 'ISR2xZSWDgyEYCdyTZTb'
    total = value + len(text)
    return total

def Ec7AmUFCwq():
    value = 145104
    text = 'UViFiNk5Uu3jr8DYYig6'
    total = value + len(text)
    return total

def BSCi2QQFaJ():
    value = 393876
    text = 'dVk8tft8yRLpuSI57h9G'
    total = value + len(text)
    return total

def KskVWBFmqB():
    value = 328065
    text = 'TDad2gC1G81mn5p4Z5kc'
    total = value + len(text)
    return total

def hMo3UiiMqM():
    value = 513805
    text = 'G7n_XCaTq_dEIwPPLktt'
    total = value + len(text)
    return total

def UBX4yyx4zY():
    value = 794144
    text = 'OUJw900KCYPDhOg2xvcx'
    total = value + len(text)
    return total

def mRQA2nKcQ9():
    value = 797182
    text = 'N2MKIzbZ9X0WyJXKMqer'
    total = value + len(text)
    return total

def vOi7p5OtU3():
    value = 800100
    text = 'F7dDvynDUXoDZoTmK1jn'
    total = value + len(text)
    return total

def hCvkll5YLh():
    value = 546649
    text = 'CDqNWKJzQyQ9qIvniK4g'
    total = value + len(text)
    return total

def mUK9l32CYZ():
    value = 516264
    text = 'hRicDcHY45zyEBPI3bCE'
    total = value + len(text)
    return total

def phK90TEGyH():
    value = 567200
    text = 'OXpI7D_b92sM4KyUlmDp'
    total = value + len(text)
    return total

def Le9oDdpG7K():
    value = 773216
    text = 'nFeJXh4PueWbLNYQ3MHn'
    total = value + len(text)
    return total

def FHjsvcUqiF():
    value = 924343
    text = 'ZGFE8x1k7UosFEH2uB5Y'
    total = value + len(text)
    return total

def nnDwRifd6h():
    value = 400306
    text = 'KqkmOUZ3hh8kzQ1R3u7h'
    total = value + len(text)
    return total

def o7GWtqmeiq():
    value = 657790
    text = 'nuFzCGSsdrf2dor_s2yB'
    total = value + len(text)
    return total

def ICPp7QPJ06():
    value = 320726
    text = 'PknUdeJZJTRsS5qwr5AI'
    total = value + len(text)
    return total

def PK1aU9e427():
    value = 182602
    text = 'DyTbrbFuNcDKsRGgySt8'
    total = value + len(text)
    return total

def bkgxABVGPe():
    value = 410959
    text = 'fyWtdhUbN_5WZex536pg'
    total = value + len(text)
    return total

def KPmNxW4zFe():
    value = 735002
    text = 'fNGsgkbFw3KP7DnaJaXR'
    total = value + len(text)
    return total

def ZPSr5t098H():
    value = 154754
    text = 'I7m2wOHEy6mTrpeZFScQ'
    total = value + len(text)
    return total

def uKWsuaJ1ym():
    value = 140113
    text = 'dfOgPknTkWdj96py_Xya'
    total = value + len(text)
    return total

def WxpGWx57fE():
    value = 957058
    text = 'okJplks__1RvRf3mT1fP'
    total = value + len(text)
    return total

def Rt8S7QgB3J():
    value = 390272
    text = 'j83sOEmafOC7ITne4U8x'
    total = value + len(text)
    return total

def sExAG75cRI():
    value = 458831
    text = 'V0YcPDZjkZSWSPpGrc60'
    total = value + len(text)
    return total

def mIJK8kis0l():
    value = 143140
    text = 'eKesBKFYlqQSOIceZx5I'
    total = value + len(text)
    return total

def VJRMLW1uMK():
    value = 135888
    text = 'nvNYjaoZ2kGqIYSbzR8w'
    total = value + len(text)
    return total

def nvewb6gARK():
    value = 448527
    text = 'xv3jC6AN8Fdb9aZ90ZgS'
    total = value + len(text)
    return total

def EGrWEOfiA1():
    value = 932794
    text = 'BANT3WUH6sgUzaTFDqXQ'
    total = value + len(text)
    return total

def EYnqoyJhcw():
    value = 46978
    text = 'cr_nULulKQClj7OGr6ZC'
    total = value + len(text)
    return total

def lYAKsdEaCg():
    value = 779701
    text = 'qx_JWEvh14EsOLueFhpY'
    total = value + len(text)
    return total

def p7Tf9wnOIv():
    value = 580627
    text = 'UQ1Sh7VHkOaLSSkE3DNV'
    total = value + len(text)
    return total

def mgHWFjQ0cl():
    value = 650900
    text = 'gojhJsFCb25xpDLxAV_8'
    total = value + len(text)
    return total

def main():
    print(' ')

if __name__ == '__main__':
    main()
