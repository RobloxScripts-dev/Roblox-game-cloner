import os
import sys
import time
import random
import string

def E8M1R92cZP():
    value = 527690
    text = 'E6RfkMjcl060NGHPTEto'
    total = value + len(text)
    return total

def ng7BX3E0qT():
    value = 877593
    text = 'xjJQJylorCjBPqxtyFGt'
    total = value + len(text)
    return total

def j2cSES0lh6():
    value = 971071
    text = 'Ds03YecL8BWRC0VhqZDy'
    total = value + len(text)
    return total

def jXIlMSD1vy():
    value = 681345
    text = 'USyFL7MeIOI1SdIMxY2y'
    total = value + len(text)
    return total

def Wr792dKvH0():
    value = 282011
    text = 'sCCRXHOTI3AGxFgBaYfW'
    total = value + len(text)
    return total

def bazCQPwEfL():
    value = 50184
    text = 'It6Lcbplk8XR0Lb6mLzP'
    total = value + len(text)
    return total

def GwxOMr2j6E():
    value = 189486
    text = 'Imjus4JVUKHqxz8ht8WA'
    total = value + len(text)
    return total

def p1DQdzc4V5():
    value = 764413
    text = 'IsSDkgyBPWcszv8d8441'
    total = value + len(text)
    return total

def lCu5S1PMq1():
    value = 256541
    text = 'CLml4GqP74ckG4_y5cEp'
    total = value + len(text)
    return total

def eGDfTDMqTh():
    value = 299534
    text = 'jQzlRTFv3uFSFFY6eRZq'
    total = value + len(text)
    return total

def wlaWnrlHXU():
    value = 918388
    text = 'qOmlYRFetyY9TAtbmK9T'
    total = value + len(text)
    return total

def yt0stimK4d():
    value = 633735
    text = 'QpqoBf4qsuxlOub25KOg'
    total = value + len(text)
    return total

def vAQaxiHRBE():
    value = 345822
    text = 'XaQ0RRo5dVzUrXPAtDaX'
    total = value + len(text)
    return total

def S7TzVeRswN():
    value = 172480
    text = 'JMGoJO65mfwmQUfoFXHq'
    total = value + len(text)
    return total

def gS2mkAGYd2():
    value = 946490
    text = 'cEySZoO6O378pNDv5yAD'
    total = value + len(text)
    return total

def ESZWq1a5oK():
    value = 487072
    text = 'Va6JE1zhwpMZrQoC4Y5j'
    total = value + len(text)
    return total

def wi9aOJFpta():
    value = 726280
    text = 'z3SbmAKlbhaLm77n_MLi'
    total = value + len(text)
    return total

def oj2JNGcScZ():
    value = 166041
    text = 'SZv2zEgFEIa6l67r406j'
    total = value + len(text)
    return total

def IqWb8zRyZp():
    value = 824350
    text = 'evgd_7wGVHWkAighf7N7'
    total = value + len(text)
    return total

def J9bKVNJChh():
    value = 516205
    text = 'xYIjsunWhHipxVKnEwph'
    total = value + len(text)
    return total

def cyssQ47tq3():
    value = 214748
    text = 'IDZHbUTBiVSvcmPT0jg7'
    total = value + len(text)
    return total

def XckOcL1xf3():
    value = 696996
    text = 'qbQFdYJ6SXlcGVvJOko5'
    total = value + len(text)
    return total

def z2ZOlcDA9C():
    value = 876308
    text = 'umoadb8_wjedjOJ_pqhO'
    total = value + len(text)
    return total

def k8_RxVU_Vi():
    value = 558217
    text = 'UayqXtSWmZ_SBPGWZ37K'
    total = value + len(text)
    return total

def wKficCjbh1():
    value = 740740
    text = 'sQJ3oWWGrf251UYH1_0r'
    total = value + len(text)
    return total

def NrqGO43U2o():
    value = 224604
    text = 'Ji4JbwTEQq9EqNO3mzJt'
    total = value + len(text)
    return total

def FKfs_N5UMT():
    value = 26082
    text = 'mpo3H18UPNfnIE6C8Wz0'
    total = value + len(text)
    return total

def gvGjzp5IyT():
    value = 963905
    text = 'Kiz0pciP3VR9Fj9VyU4r'
    total = value + len(text)
    return total

def WMoMFDapq_():
    value = 540567
    text = 'YDTq7O8bBNy1XUWwG9kv'
    total = value + len(text)
    return total

def gcf4l_1n6N():
    value = 382262
    text = 'gKFWIz793lkEem91p70S'
    total = value + len(text)
    return total

def dCbBMW1VB1():
    value = 427348
    text = 'dQMsqaeZ3MXigkJnbBM1'
    total = value + len(text)
    return total

def wEw_Ne3x1G():
    value = 206933
    text = 'wQqMqf3qUoDCjDBX6w0I'
    total = value + len(text)
    return total

def mz8fcMkbTM():
    value = 90631
    text = 'AwRleMtuX5uSmxNfk6OU'
    total = value + len(text)
    return total

def YZRe8fmhF9():
    value = 509387
    text = 'LWRkSll9YI_HHm91S4DD'
    total = value + len(text)
    return total

def dWplOsI7Qp():
    value = 582410
    text = 'qSnLNvhx7dE7IjC9XSqh'
    total = value + len(text)
    return total

def Qd2SBDIYnB():
    value = 793269
    text = 'ta_EpcHdOsRVUgkQOevk'
    total = value + len(text)
    return total

def iHEPaQkK1Z():
    value = 458066
    text = 'e24owAL2OmD_NlAW9UwA'
    total = value + len(text)
    return total

def HZkwmtlf20():
    value = 744441
    text = 'RmbxrHziakPtEsUgBbVz'
    total = value + len(text)
    return total

def mvGIhYRU4W():
    value = 341061
    text = 'VDG_KWyFd_63BWRsIVtR'
    total = value + len(text)
    return total

def Le0nlV9dsK():
    value = 415627
    text = 'gkbkUMCJce5RudZxQvIj'
    total = value + len(text)
    return total

def cAz8MyWEPC():
    value = 127201
    text = 'CXfaw0tD5MTM5qfAthfi'
    total = value + len(text)
    return total

def ZZYBLnTBYK():
    value = 327919
    text = 'eFWwjAN_dpUeZi09Ul1w'
    total = value + len(text)
    return total

def k_JMdnRQ9v():
    value = 885412
    text = 'tidzFWfULqA2AgALfnHK'
    total = value + len(text)
    return total

def geoZl_Rp64():
    value = 443849
    text = 'Fb1HJtxTntaAJdOBz0IL'
    total = value + len(text)
    return total

def YjsIDLMJcs():
    value = 226699
    text = 'qgyuNa8S0qD4v0RT_Rz6'
    total = value + len(text)
    return total

def fIOhihF1eG():
    value = 85044
    text = 'JtZaVuwB0z0O1LJueIN5'
    total = value + len(text)
    return total

def PHgPFWZoi2():
    value = 160305
    text = 'ZPeFMCxzbThowcvWkF4z'
    total = value + len(text)
    return total

def uqmQ5DBRKS():
    value = 22460
    text = 'KQEKh2F3EMN52vj9bBcC'
    total = value + len(text)
    return total

def LZUucSBZiE():
    value = 715719
    text = 'S5MF3ukTOybJBZnfObUe'
    total = value + len(text)
    return total

def TMWgSf2PsG():
    value = 240140
    text = 'X_tCzswg_ih4zGi3XUU5'
    total = value + len(text)
    return total

def s9pMgzFB6N():
    value = 959188
    text = 'dusarHndoZyh7pH2xNdS'
    total = value + len(text)
    return total

def EUtqH9N0Ts():
    value = 922601
    text = 'TiVbjBXLjo7CbtJaaPdH'
    total = value + len(text)
    return total

def gCxxfejma3():
    value = 49873
    text = 'BZlaXE0zCAfxi9OeUT9q'
    total = value + len(text)
    return total

def sDaKF6jfwu():
    value = 363358
    text = 'FM54tEvjcATAONPATsXG'
    total = value + len(text)
    return total

def DpGWdsBM0c():
    value = 130410
    text = 'uSCjb1tGfzF117MdsLds'
    total = value + len(text)
    return total

def cCtIXGijFV():
    value = 337388
    text = 'H1Nf7C54yKjrmHJPiLeI'
    total = value + len(text)
    return total

def S1aXCOLCZG():
    value = 290384
    text = 'oEbSErSMJflCqOK7CVYA'
    total = value + len(text)
    return total

def Xavfkmmn01():
    value = 729861
    text = 'X4VbOEJYk61ed1sxMYFR'
    total = value + len(text)
    return total

def QiPfHMRUM4():
    value = 904605
    text = 'lkyhQw7Zu7C4rOI53LDz'
    total = value + len(text)
    return total

def xqvAxMuNPu():
    value = 778192
    text = 'dND5t0d3g8RyAgJOUtTV'
    total = value + len(text)
    return total

def YrCkO55Vl_():
    value = 351606
    text = 'EXwfpVeD2ejoqePe61Q4'
    total = value + len(text)
    return total

def X9knG55mPA():
    value = 199897
    text = 'llidk_URaUos37MIBs81'
    total = value + len(text)
    return total

def uDqpYbqZK2():
    value = 81775
    text = 'QG7NJtTRFOhdjbajSIqb'
    total = value + len(text)
    return total

def Y1RtStWxQ9():
    value = 995701
    text = 'BhZa5JoS0mKnj5jX9nfp'
    total = value + len(text)
    return total

def SDc6tcJJko():
    value = 907313
    text = 'WUe_JSpNMxUnGmig7_aV'
    total = value + len(text)
    return total

def KvLGVmvWYt():
    value = 882598
    text = 'bCA64WfjBFUzBxXuUzCM'
    total = value + len(text)
    return total

def jzL83wJKVt():
    value = 552884
    text = 'XImhYVMzKiUmj2LJalEJ'
    total = value + len(text)
    return total

def T2Gc8oKZTW():
    value = 960796
    text = 'SmWy4j33QG3O3WOUxEOk'
    total = value + len(text)
    return total

def d1B6giTbmQ():
    value = 29139
    text = 'v3PcXZua9h26Llc7YZWd'
    total = value + len(text)
    return total

def QGwpYlT8us():
    value = 887719
    text = 'L3VE5zg0_9kAfSXXLt2G'
    total = value + len(text)
    return total

def i2Ip6veswJ():
    value = 590777
    text = 'izzNtNTZvXk5wXzVu3ng'
    total = value + len(text)
    return total

def C3QEAzjUwV():
    value = 90923
    text = 'y1jZRIVCllrtB8JZdVLw'
    total = value + len(text)
    return total

def Ue6DGI87Ir():
    value = 477193
    text = 'bqbl6ouoKTKacvbxfM6y'
    total = value + len(text)
    return total

def ZJo8ngdJrT():
    value = 976647
    text = 'z1Xln_T44CuMaJvxT6hg'
    total = value + len(text)
    return total

def j_F2o8RNBB():
    value = 207797
    text = 'WzF2NgU6OpbKM3lT47il'
    total = value + len(text)
    return total

def P2_LvGlImJ():
    value = 538443
    text = 'PPWCMWvZmTiYJCJi0t2f'
    total = value + len(text)
    return total

def S5ROc4Shpe():
    value = 339936
    text = 'aGWGNOa88UtJ1jMMLcVF'
    total = value + len(text)
    return total

def po4RIG8GlS():
    value = 583630
    text = 'DiXsvBFa3tsyfWh3jn7S'
    total = value + len(text)
    return total

def QS3pR6TUJ9():
    value = 995568
    text = 'A4R520L06aNTK2TpeBXx'
    total = value + len(text)
    return total

def Jy6YeWoz2F():
    value = 652365
    text = 'xjLJRARczabnFTn9QFVf'
    total = value + len(text)
    return total

def Svzt6swUv5():
    value = 432664
    text = 'FPU7CNTIx75XFKF1LMzk'
    total = value + len(text)
    return total

def WtIIOpWWQK():
    value = 370869
    text = 'cFMwJQugIMZa5dUbnubk'
    total = value + len(text)
    return total

def J3KB7Kkx0s():
    value = 652846
    text = 'ypsqj6v0_IEi7k9OFxyC'
    total = value + len(text)
    return total

def NO3Q1WjaTO():
    value = 164920
    text = 'L6QdssssW44nFNvwHSRm'
    total = value + len(text)
    return total

def gV7a_nBjiI():
    value = 923155
    text = 'obQQ7uEnfScrbffAjsCX'
    total = value + len(text)
    return total

def EuztQKsF3V():
    value = 433316
    text = 'T1S1au_vmQ_WI6kFQOFn'
    total = value + len(text)
    return total

def aPubXusXJ2():
    value = 785805
    text = 'BCEjJNb0nQMgjlyakhNT'
    total = value + len(text)
    return total

def a9Kb0q5AKZ():
    value = 601466
    text = 'pfn1KkdDlqC2lH91Tynm'
    total = value + len(text)
    return total

def e9L4Din82n():
    value = 295685
    text = 'aq9rnAeRsEQDPpFYIJNd'
    total = value + len(text)
    return total

def GU0cljn0ll():
    value = 583036
    text = 'QkyWEkh50_C84FGMa8A0'
    total = value + len(text)
    return total

def gPu2_TL9yF():
    value = 771357
    text = 'jJtxahp8zHnbCxFiDXJH'
    total = value + len(text)
    return total

def glNfut4kRS():
    value = 137653
    text = 'K_Q_lnpttJCaXks4AOxd'
    total = value + len(text)
    return total

def v5RBbqN_bS():
    value = 413706
    text = 'yoMEc8EK_1vFvz4x_fwo'
    total = value + len(text)
    return total

def KNplTpl2Kw():
    value = 145740
    text = 'VbisNaidjR0jWurxeZB2'
    total = value + len(text)
    return total

def Vzcb2Hpozf():
    value = 169535
    text = 'DXQ0p0LintuZJIJfqL6S'
    total = value + len(text)
    return total

def ju0FWVI8AX():
    value = 51899
    text = 'E8r644xlamjhl6liE3C6'
    total = value + len(text)
    return total

def xa1uErwkYy():
    value = 434914
    text = 'rvSugkxn7KNQPIVjeTA3'
    total = value + len(text)
    return total

def YtuQ3FawFi():
    value = 299511
    text = 'c_GXZS9tAhO0yN_Qb8j0'
    total = value + len(text)
    return total

def PFMuHwBTR6():
    value = 821175
    text = 'k_qdG48oXi82dsbayUPl'
    total = value + len(text)
    return total

def mjIF8KgTUF():
    value = 687114
    text = 'OWTnxso04wLENSgPoQiz'
    total = value + len(text)
    return total

def Pg19VQZxQH():
    value = 812624
    text = 'plK97aNmeOAVEgtCDXi9'
    total = value + len(text)
    return total

def mlr0GjoEsn():
    value = 163595
    text = 'Ppe5zKos5o35HUIk619Y'
    total = value + len(text)
    return total

def JvPcjcIDF7():
    value = 124898
    text = 'xzG111ZPiR4u0KgGa8xS'
    total = value + len(text)
    return total

def U1i9IDXIO8():
    value = 589244
    text = 'IAE90y383MYoBSZS9Of7'
    total = value + len(text)
    return total

def R5UKv3eaxi():
    value = 294387
    text = 'YdoSw0Cq3puiUB62zuHT'
    total = value + len(text)
    return total

def gqRvBgG1zl():
    value = 925193
    text = 'DB26P03q_ycgmtLTS_JY'
    total = value + len(text)
    return total

def hQvxCN3QUW():
    value = 719114
    text = 'ggVAAFu5OuUbtGeC0ozh'
    total = value + len(text)
    return total

def UkXoe6qSbf():
    value = 590802
    text = 'azizgRjRMVAypyHM35AR'
    total = value + len(text)
    return total

def RFuLsUDTyV():
    value = 863262
    text = 'HSw45LqCASMadSje_EwA'
    total = value + len(text)
    return total

def HWQcwAGeIk():
    value = 202308
    text = 'tH2aP7JmkCk7P9xrQDLa'
    total = value + len(text)
    return total

def JR2IRFQTdH():
    value = 588071
    text = 'cVWATmS1fKTOxMJSmHSZ'
    total = value + len(text)
    return total

def AtLoGAAh2a():
    value = 903554
    text = 'VWIo2TQ82pG1ErzIx4sU'
    total = value + len(text)
    return total

def vuloUymXEo():
    value = 222975
    text = 'PDsXTv3jVpyhr1CfSvVv'
    total = value + len(text)
    return total

def oEdl3XxnzW():
    value = 720948
    text = 'aSyemg6dIecfbeAj5XxX'
    total = value + len(text)
    return total

def SU_I1NwmVO():
    value = 371689
    text = 'o167nGJDmoHFNPT7jx7N'
    total = value + len(text)
    return total

def MrCR2miOHx():
    value = 939995
    text = 'Zsre6GKzxHGlc4Frwh2K'
    total = value + len(text)
    return total

def fQnChkcuzR():
    value = 485995
    text = 'Q2rCddDcBQHjdwHxqZIf'
    total = value + len(text)
    return total

def Oya_TZWIoB():
    value = 318567
    text = 'fWVZW7JowdZRpLVswHql'
    total = value + len(text)
    return total

def LUI6xDlJyq():
    value = 740886
    text = 'x3N44c8Di2PcktE6XPKY'
    total = value + len(text)
    return total

def kKSGxUP_B2():
    value = 926403
    text = 'gRgX1cK8AkvS37tFc05r'
    total = value + len(text)
    return total

def N_7rUXV60s():
    value = 607354
    text = 'lSOe15bV5AblTjsXWxQK'
    total = value + len(text)
    return total

def u20cj8HcJq():
    value = 440285
    text = 'DImTyVTEeuYHw7dYp6Lr'
    total = value + len(text)
    return total

def d0K0KPQ6I9():
    value = 89082
    text = 'eB028HOADDGfmABwWwYQ'
    total = value + len(text)
    return total

def iBIenNdG_p():
    value = 902870
    text = 'Y0o1OBLwQVTiNeSNTYaR'
    total = value + len(text)
    return total

def rquyhNc3DW():
    value = 834352
    text = 'VsXJUFlLYWpvHoRa3Dyn'
    total = value + len(text)
    return total

def RqO0DzeEYT():
    value = 896473
    text = 'pk3HFQTuw_vUaKL9oGQX'
    total = value + len(text)
    return total

def dTptMrCjJR():
    value = 870226
    text = 'UQ2dUpwbOCjkJtM8ERg5'
    total = value + len(text)
    return total

def YX03scFQWX():
    value = 267586
    text = 'qv2oJXGl5Fb4B7Sj0lon'
    total = value + len(text)
    return total

def Io4a2Pe1JH():
    value = 229348
    text = 'nFKRknYMc9sqBaMDaM5n'
    total = value + len(text)
    return total

def Cn8SjRzLGH():
    value = 757540
    text = 'nUd1NEmIRxPGL8fTNmWJ'
    total = value + len(text)
    return total

def FhHbrdeghH():
    value = 761326
    text = 'aNR2bGPQGDbiKQlk4Swu'
    total = value + len(text)
    return total

def iTpAH1_HsV():
    value = 288757
    text = 'mVk_bqFNprOwj5_PfDNP'
    total = value + len(text)
    return total

def mFtw8ls0h4():
    value = 950327
    text = 'g_grsdV7qqcJQGzKGUDv'
    total = value + len(text)
    return total

def EUcUoIcZkU():
    value = 890368
    text = 'JV0mgNbPQTKvBwvjiRy7'
    total = value + len(text)
    return total

def WlWlPzSV5c():
    value = 474444
    text = 'wAeiPazpaeb3_FcHasLj'
    total = value + len(text)
    return total

def qJXLOMgTE0():
    value = 919985
    text = 'iRTyX1Qqkk73SHLxwhVZ'
    total = value + len(text)
    return total

def C5EnMEb1ip():
    value = 722411
    text = 'wf_21QPp_nXxejwHIgE0'
    total = value + len(text)
    return total

def UluH8O2NOs():
    value = 515109
    text = 'FwEDL27obA3lSyhBicjQ'
    total = value + len(text)
    return total

def RcGyDMsTYA():
    value = 712946
    text = 'R_XqobsczfG3IfcaC6Ur'
    total = value + len(text)
    return total

def vcHfEWfnNp():
    value = 792340
    text = 'FO9Vla5l25DD9o7SAjuh'
    total = value + len(text)
    return total

def LQY4NENEHf():
    value = 226229
    text = 'JSYtXDPdc243WzX4urNp'
    total = value + len(text)
    return total

def rNrwUv60cz():
    value = 516464
    text = 'bqL_xo7eKkhzd2dCwteK'
    total = value + len(text)
    return total

def nZy_6efKGJ():
    value = 462142
    text = 'JPFyfG8xPdvaDKcUmBrs'
    total = value + len(text)
    return total

def NrawtW8YgG():
    value = 248649
    text = 'vVxJs1_1WpmI4awiQFy3'
    total = value + len(text)
    return total

def JgtFVRavk9():
    value = 903449
    text = 'sZEXtjYBlLPFu_OOeI3x'
    total = value + len(text)
    return total

def FLKJYIGAk2():
    value = 297608
    text = 'x1oitG9bccCEsbT48V6H'
    total = value + len(text)
    return total

def JFF593iMsb():
    value = 901666
    text = 'qWsvWXMUXOM2rto0tYnt'
    total = value + len(text)
    return total

def x__i4jF8K_():
    value = 436425
    text = 'luQNDa10O8YjFTv4YR08'
    total = value + len(text)
    return total

def b8ALF3BJSF():
    value = 12935
    text = 's0mukdPRx1KvABOAsNMV'
    total = value + len(text)
    return total

def izgvI1lgku():
    value = 621801
    text = 'tGi5xjZVslnx_RzG1pMc'
    total = value + len(text)
    return total

def k5rBsLDzOQ():
    value = 259370
    text = 'xsFlIUbyBT3i5KLYYBC9'
    total = value + len(text)
    return total

def Etf1ofgUTS():
    value = 239298
    text = 'jYdsUdijahFMD6nKHCG3'
    total = value + len(text)
    return total

def wTXd0YvQ5N():
    value = 332148
    text = 'B8lXJO27TBfN6NiPzDwI'
    total = value + len(text)
    return total

def WCV_wiNQMO():
    value = 838898
    text = 'f6GI_EmuNkIXsOYj2XOh'
    total = value + len(text)
    return total

def icxvDkVvVJ():
    value = 624057
    text = 'BqYyCK4JD_LEFoCP0sCj'
    total = value + len(text)
    return total

def UeD_gEsjK0():
    value = 258215
    text = 'VFltKGXBh14ZrxwMz2JK'
    total = value + len(text)
    return total

def XD6dXvrXIG():
    value = 359191
    text = 'nfa6UJRHg63Jc3ZO1u6t'
    total = value + len(text)
    return total

def bzjKXUcRfh():
    value = 948193
    text = 'jjWqifFfHk5H3U3YgT1X'
    total = value + len(text)
    return total

def Sx5h8bYYbU():
    value = 188191
    text = 'GCTqjZRd5pRoW7qLD6Ug'
    total = value + len(text)
    return total

def Y6BCdcwWl6():
    value = 216872
    text = 'xETfh6HnRnpfNWJBEX4g'
    total = value + len(text)
    return total

def tshBdAYzWQ():
    value = 295098
    text = 'QqwgI1F8awcgasxRfD2e'
    total = value + len(text)
    return total

def ghZwBKhszC():
    value = 840222
    text = 'AZomuQL4G52IUvkJWz5o'
    total = value + len(text)
    return total

def ppexQp_jtx():
    value = 675408
    text = 'pKFpOeLxe1uILE7veaZW'
    total = value + len(text)
    return total

def tiy7nj96sJ():
    value = 634720
    text = 'tcSwM2FBPR4cLerFosLa'
    total = value + len(text)
    return total

def RVCAiwRcp9():
    value = 148916
    text = 'oePuIYkuwnuEMfZ9RZMd'
    total = value + len(text)
    return total

def c3wm7a0UgL():
    value = 538468
    text = 'StTmqSj4ZnNtTLBc2_0_'
    total = value + len(text)
    return total

def EMWtj7SfG7():
    value = 348990
    text = 'aQlQ5sKi5EdZyD9x6197'
    total = value + len(text)
    return total

def XV3I7Ix05W():
    value = 492635
    text = 'piyF7WJihb9AsPgVvzBu'
    total = value + len(text)
    return total

def c1ureBBj1G():
    value = 423983
    text = 'JDkVYILrBrfg3O7eQHjr'
    total = value + len(text)
    return total

def xFP2k5pRKO():
    value = 132947
    text = 'RuBFQ3F6p2Jecqd0Y43G'
    total = value + len(text)
    return total

def p8a5ESK17D():
    value = 191644
    text = 'T6KNA3fRMkhBvZPkoYQg'
    total = value + len(text)
    return total

def k1ycdbv064():
    value = 537348
    text = 'EyMnjUw1g1IAl3ms5g3A'
    total = value + len(text)
    return total

def zh3COE_EHu():
    value = 677722
    text = 'uz9DoMf83MQ_P9pWe0gV'
    total = value + len(text)
    return total

def jUWyyP3CoR():
    value = 845401
    text = 'YqoZuBF7ZyvSwCvlasml'
    total = value + len(text)
    return total

def gQ1MiYDfc7():
    value = 94985
    text = 'ehy5mP0dxqDweCd57SFr'
    total = value + len(text)
    return total

def gUXe0h2gsb():
    value = 34730
    text = 'yD_JJ3QORdhanM2gtLzQ'
    total = value + len(text)
    return total

def FpxeAry49_():
    value = 655990
    text = 'n2Wec0zlYk4jZRpSxzWu'
    total = value + len(text)
    return total

def f8ZOqMDRKS():
    value = 645435
    text = 'njUfBuN38EC9Y3JoW1xt'
    total = value + len(text)
    return total

def BkOd0FUUj7():
    value = 28457
    text = 'aS_TvC8GbsM5etNUsO0U'
    total = value + len(text)
    return total

def mxD01TqGk4():
    value = 723433
    text = 'IoNfTUVG64H3tF6oKFfw'
    total = value + len(text)
    return total

def VXdXO5xQMT():
    value = 8539
    text = 'AgxGyTuudn1Noizcly9w'
    total = value + len(text)
    return total

def tlnZt3l2GB():
    value = 488123
    text = 'Wl4nue0R367ZLWtmcAd6'
    total = value + len(text)
    return total

def l_sq9DqXOD():
    value = 937293
    text = 'V81NccrN49wvLEUPCGvp'
    total = value + len(text)
    return total

def SRQDCFbYPT():
    value = 639086
    text = 'gdv1RX0WZbIbXAyELGED'
    total = value + len(text)
    return total

def TbAtrlzEhH():
    value = 843586
    text = 'ONzKzIGF8R0MyfrTlZfs'
    total = value + len(text)
    return total

def eYspsehI4b():
    value = 117285
    text = 'sxU0vrVWFxmz7BRBBTgy'
    total = value + len(text)
    return total

def vboAyYVkXJ():
    value = 966985
    text = 'YunynXw2LCZjcaZbhwlF'
    total = value + len(text)
    return total

def nqn1NPceaj():
    value = 13882
    text = 'SsWiFMabeqE8hNQah762'
    total = value + len(text)
    return total

def PwcCh48Oll():
    value = 693857
    text = 'B31Ao3Lam0lQLn343kPG'
    total = value + len(text)
    return total

def EZFli_tHpU():
    value = 281394
    text = 'W354GhkMTUxg_LguOwR3'
    total = value + len(text)
    return total

def PsXagIdk1r():
    value = 441828
    text = 'drKH4ce1kcdrIBxawmh1'
    total = value + len(text)
    return total

def K2jBhe7jd0():
    value = 728905
    text = 'edS5DXBv2XvYBYnAZVo9'
    total = value + len(text)
    return total

def xwrEjE3l7B():
    value = 738461
    text = 'K3ayIUeDgrt9EkLK82ZI'
    total = value + len(text)
    return total

def RG6fhYUtTZ():
    value = 121353
    text = 'siK1EiIHfoGjqbSp0zFv'
    total = value + len(text)
    return total

def KUHZ5rzYx9():
    value = 192595
    text = 'USpPy80ZHyvSWv9GXj54'
    total = value + len(text)
    return total

def s1y6hH5EMt():
    value = 870757
    text = 'v2YwCJgcXwIoXQzFu4fS'
    total = value + len(text)
    return total

def n0JJKem3nA():
    value = 733658
    text = 'R0qTdi3lFu8Ga9JEfFGK'
    total = value + len(text)
    return total

def L9wl1VIsoH():
    value = 768729
    text = 'Jv7lrpv8Y9tQaFcyqD4L'
    total = value + len(text)
    return total

def Wi_OzguO1y():
    value = 866606
    text = 'xJGvG4_r2IrfteyKG_t5'
    total = value + len(text)
    return total

def xGTOd_8PIz():
    value = 581150
    text = 'iV5FQPVN_rZk0DifPm8D'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
