import os
import sys
import time
import random
import string

def UGMrb8tt_i():
    value = 116148
    text = 'r7jpoYUJm08dq01gZd3i'
    total = value + len(text)
    return total

def WjF511fpXY():
    value = 666121
    text = 'mFTRmSRxVecGMFTHvQ6l'
    total = value + len(text)
    return total

def hlfDHHbKiI():
    value = 720926
    text = 'wpVfQ6l7SxxRAk6MYVJ7'
    total = value + len(text)
    return total

def RyoYmbKqe5():
    value = 502147
    text = 'A2YB5ybKxaRuexMoA5ao'
    total = value + len(text)
    return total

def o3RAa2pzI9():
    value = 869892
    text = 'tHIEu85l6eRjdtSfcuna'
    total = value + len(text)
    return total

def sU0dEyYBCZ():
    value = 953622
    text = 'PxdrSo6waLlHGzHNcSEL'
    total = value + len(text)
    return total

def RGFpfogjPW():
    value = 938451
    text = 'KkbSKxGy45yvXiEKYyBQ'
    total = value + len(text)
    return total

def DtRe0PEqQI():
    value = 939801
    text = 'djpdd9Si6tx5xe7mW3cR'
    total = value + len(text)
    return total

def Yuo3pJquBz():
    value = 440951
    text = 'tc9E7d7PJMe4InGUXfVn'
    total = value + len(text)
    return total

def OdB2QqGx96():
    value = 275429
    text = 'nBKFtdIZ6ds0jmsmIRFj'
    total = value + len(text)
    return total

def E89GuuI6qk():
    value = 456438
    text = 'eYVHYEOEKGZ6DXnUamSO'
    total = value + len(text)
    return total

def oo7PoH7mFv():
    value = 220886
    text = 'IDEOmj65FRL5KYS0DWKp'
    total = value + len(text)
    return total

def AWLhCWoXaF():
    value = 164082
    text = 'jFF1izjzaS7ed9odBIRX'
    total = value + len(text)
    return total

def sqi92XHHtw():
    value = 581904
    text = 'Fl5dHS3XwP8Zps7xCLks'
    total = value + len(text)
    return total

def Lsnm0wlkqe():
    value = 8895
    text = 'UhFpe9bxLqFXq_Oib5TB'
    total = value + len(text)
    return total

def iasszRM3Ze():
    value = 209773
    text = 'hNFlfjekEycD8r1mD2NP'
    total = value + len(text)
    return total

def idd8OjVVyK():
    value = 109919
    text = 'UcnmRhR2sY3h3LDRJ10F'
    total = value + len(text)
    return total

def MOZtBhUJM9():
    value = 997747
    text = 'pQTvNSbvkIAqU7PV2QaJ'
    total = value + len(text)
    return total

def PIhdX_4GRg():
    value = 570864
    text = 'VXTqHZQ9T5YwhmmyZbhG'
    total = value + len(text)
    return total

def O164IsbsTQ():
    value = 689200
    text = 'GwbbBG66Q5J3Be01aGGy'
    total = value + len(text)
    return total

def m_v0ZTbpSf():
    value = 784495
    text = 'fAbJg1FbkL5Qz7l8XD_G'
    total = value + len(text)
    return total

def W8OR6lOdnj():
    value = 54544
    text = 'qyPciCzTlG4tVI8WPUAL'
    total = value + len(text)
    return total

def P02Kyw1gYg():
    value = 400631
    text = 'LG64yZUeU4dbJJUSf4QW'
    total = value + len(text)
    return total

def fO14rNEQtp():
    value = 272798
    text = 'hrH6dOVBKDajlqeXnF4T'
    total = value + len(text)
    return total

def GPZRth7DhU():
    value = 313733
    text = 'QQ0cBXzFiTZaTVj_byDA'
    total = value + len(text)
    return total

def eoZ7ZpPx4o():
    value = 77636
    text = 'sEpKUI6wUcRWjF3rbSDe'
    total = value + len(text)
    return total

def B_fiPQvM0J():
    value = 577597
    text = 'VtSyNY3ZGlC_qcuZnxPG'
    total = value + len(text)
    return total

def zRQNdWd_xP():
    value = 740857
    text = 'O5YVtQcmMvVxQf1B6f4B'
    total = value + len(text)
    return total

def tzEPaeydEg():
    value = 839381
    text = 'jKpzrS48Eil4mF1Oy_A0'
    total = value + len(text)
    return total

def gU1FDVQgmE():
    value = 374369
    text = 'aHaUxba3kP7ZRoAwM8mE'
    total = value + len(text)
    return total

def nTyCYIZhIQ():
    value = 657992
    text = 'D0RBD3vHRx18EFBa7zFN'
    total = value + len(text)
    return total

def t5GdTsp3rP():
    value = 939337
    text = 'iUZQQb4jOwDIWnc5YjbY'
    total = value + len(text)
    return total

def POQFunp3AZ():
    value = 100534
    text = 'TLT2pEhbouJy70CXgOFH'
    total = value + len(text)
    return total

def q9iNmj0FFU():
    value = 27153
    text = 'LFcSxygM7Shp4LCf0Rgk'
    total = value + len(text)
    return total

def mKQqiDuDbB():
    value = 35644
    text = 'ZdRAbcORBjXLTgYHDPT3'
    total = value + len(text)
    return total

def Jez5B9G6BT():
    value = 108692
    text = 'HS_WH1sSUQ7tTopqd3F3'
    total = value + len(text)
    return total

def LnZaoh7dh2():
    value = 770981
    text = 'lbpVplsoUxmJk1DvbO4S'
    total = value + len(text)
    return total

def fLynpSjeFV():
    value = 230356
    text = 'kRaCdJ0qhEkYq0cSU3xe'
    total = value + len(text)
    return total

def vWkj0eaGg2():
    value = 369775
    text = 'Qp6bD0dbPt98ZqcYoPS7'
    total = value + len(text)
    return total

def LU9DTBPSiV():
    value = 319016
    text = 'I1ra9hRAxdpNAy8cHqWq'
    total = value + len(text)
    return total

def OhjBYERK0s():
    value = 896611
    text = 'cvt09gabN8SZiiVnJSBD'
    total = value + len(text)
    return total

def p0_2MgpV2n():
    value = 541847
    text = 'ZzktCfpPxe4ujI3PME98'
    total = value + len(text)
    return total

def AdZdNGhLGZ():
    value = 961832
    text = 'L8ANzWHJ0oKYrWet6Wqw'
    total = value + len(text)
    return total

def jDBYSxK5Bx():
    value = 533865
    text = 'tGOwJha8myIsdl2y9A1l'
    total = value + len(text)
    return total

def PfYIK3wom4():
    value = 214306
    text = 'WKbKtrmfJ4dJvrGue8Ly'
    total = value + len(text)
    return total

def HUNB9JjRHL():
    value = 981666
    text = 'cUi5H3jMB8k0XNYu5vBD'
    total = value + len(text)
    return total

def p4JKiLiR4g():
    value = 646794
    text = 'fGrueX9GwAvxp02Z8_ra'
    total = value + len(text)
    return total

def sjNjNRKql7():
    value = 242144
    text = 'ThfRow7NHrMXwy3FSgio'
    total = value + len(text)
    return total

def sK_gRl9uCX():
    value = 809683
    text = 'mrb_PX_GI0w_0rS9C01t'
    total = value + len(text)
    return total

def a2Q4EKtqCf():
    value = 632727
    text = 'ePqQAmRIwDv_oUGSRZVM'
    total = value + len(text)
    return total

def Z4lPYroE94():
    value = 354681
    text = 'yqqekHRp5o_Xa9uQMYKd'
    total = value + len(text)
    return total

def V_DttdKoFI():
    value = 419325
    text = 'IJjuMuJl2FeDgMuR57Jx'
    total = value + len(text)
    return total

def GbQDNYfJtY():
    value = 580712
    text = 'saeWNAchxoe3iEEcb5Ac'
    total = value + len(text)
    return total

def DnVLKzFicU():
    value = 864442
    text = 'NhmiTQSifdfHFa0bGKBP'
    total = value + len(text)
    return total

def uZ9yuFbLRA():
    value = 353453
    text = 'WmYpzwRqQHHFSwcyq20n'
    total = value + len(text)
    return total

def cabKCvHG8J():
    value = 879325
    text = 'zD8aZXgMPorU8bqrwlKl'
    total = value + len(text)
    return total

def smulim7uPx():
    value = 618342
    text = 'lO6XCXVS6kmc61RpRmhs'
    total = value + len(text)
    return total

def oy6SGVj1iA():
    value = 678087
    text = 'ozUkbXPAJPB8PBCyiHSR'
    total = value + len(text)
    return total

def c02qG2io7x():
    value = 313075
    text = 'EwhfQCUk5qj_x3U5LMZ4'
    total = value + len(text)
    return total

def twhjx_DIRF():
    value = 154165
    text = 'HRlUdjFuPCcfY3V_GjH6'
    total = value + len(text)
    return total

def BB8GuK6zpc():
    value = 21335
    text = 'peDyWjJ5f5A979qGm1Y6'
    total = value + len(text)
    return total

def aZ_rv1XP3t():
    value = 800214
    text = 'jTjsnzhQGYxRTNKMZaGt'
    total = value + len(text)
    return total

def euNGmmj86d():
    value = 304318
    text = 'oC8Jka3D_uSF5TAiD0QU'
    total = value + len(text)
    return total

def j4w5FCy1PX():
    value = 488349
    text = 'WEcdK1cavXyR9u3du3UX'
    total = value + len(text)
    return total

def fKpYYkBEVA():
    value = 932917
    text = 'wA_b693OjQDAmr8wmT5u'
    total = value + len(text)
    return total

def f4_psw59XB():
    value = 449625
    text = 'ore1frSi9pFFyboLQWsp'
    total = value + len(text)
    return total

def QeRWwlFRml():
    value = 393193
    text = 'Ajv5IsZBMt9Pgc5OxoC2'
    total = value + len(text)
    return total

def n60TqWyQ2F():
    value = 512365
    text = 'v2SWs4MNEFUZ8m2lP6N2'
    total = value + len(text)
    return total

def NWuOengyVn():
    value = 649860
    text = 'KmofdqZ0p5WmriXhX_TG'
    total = value + len(text)
    return total

def AAy0qoQMVS():
    value = 258952
    text = 'sL0CQ5QWcI1kGNVtzcNx'
    total = value + len(text)
    return total

def s4cXVXTmEp():
    value = 16623
    text = 'AeuWonqQo8kXjFWZGEA6'
    total = value + len(text)
    return total

def peFFLY71dx():
    value = 164579
    text = 'YGwOTYf7CkkkQl0ANkqL'
    total = value + len(text)
    return total

def wnrDccY_xu():
    value = 869567
    text = 'qMOnQ5A4cr7i1y3BqstD'
    total = value + len(text)
    return total

def YYbzEGLAWy():
    value = 884588
    text = 'pKPQCqO24Zti3BZsNZzi'
    total = value + len(text)
    return total

def V7KUa_4A6e():
    value = 426342
    text = 'IkAhu9ydLhkhFzUmAfht'
    total = value + len(text)
    return total

def BOuBzMUnVM():
    value = 52482
    text = 'gcOMmmLpS2EG020spemX'
    total = value + len(text)
    return total

def y96XV_4oeo():
    value = 658514
    text = 'eWu_e2RlUOxPqRfZmmu6'
    total = value + len(text)
    return total

def gnnKJ3MIO2():
    value = 216777
    text = 'j5pIcLDz4nv0e0Kf8FBB'
    total = value + len(text)
    return total

def KygNJGq8yt():
    value = 899449
    text = 'IlMAZSPCUAJej2uSF31n'
    total = value + len(text)
    return total

def mCAPdnbSeb():
    value = 304598
    text = 'z2HkDXw86s3Wy8nyk_yD'
    total = value + len(text)
    return total

def uTgPNegRZJ():
    value = 249077
    text = 'xjSVLmO_bi0RNiUrzLmZ'
    total = value + len(text)
    return total

def fRJUipvtZW():
    value = 282056
    text = 'dxQ8K2BeXXntjqYJ8uxs'
    total = value + len(text)
    return total

def wm61_bQn2g():
    value = 451533
    text = 'A0uKHjy8NZhLP8sSI5NA'
    total = value + len(text)
    return total

def sz17u_rBnd():
    value = 908110
    text = 't0GkQ5w1EvoPEFIdnW8O'
    total = value + len(text)
    return total

def kRPKnoU5PQ():
    value = 653345
    text = 'IuUnG74zO1Ul0zqfXjCC'
    total = value + len(text)
    return total

def Y6t9Zparif():
    value = 949746
    text = 'Jx6mUOrSVp2jqlZmPLOe'
    total = value + len(text)
    return total

def fbpJ4L32TI():
    value = 423840
    text = 'hOD4y_Vvx3LRVwW66RMC'
    total = value + len(text)
    return total

def PAkaSoC8IC():
    value = 90296
    text = 'tQV_EWJQ3VPfUJINugR_'
    total = value + len(text)
    return total

def F9X3_9k4LZ():
    value = 529557
    text = 'TCdmbeuKEfxVlAFUDP5T'
    total = value + len(text)
    return total

def ACLuNcTxzz():
    value = 289778
    text = 'N7Ga8jdIDmXXaXeNDn8v'
    total = value + len(text)
    return total

def FBqJjxi_xr():
    value = 865581
    text = 'rIeYLWScoPdg3lccJe9g'
    total = value + len(text)
    return total

def RNuVBxVr_y():
    value = 293100
    text = 'aYGUynABTxE4JOTTfNkJ'
    total = value + len(text)
    return total

def afR3dJ_OgM():
    value = 904313
    text = 'W0NMlLfRh_4AcpyL72vg'
    total = value + len(text)
    return total

def qcjkdbxY7T():
    value = 197250
    text = 'KTrIUye6Nx17pQVGYWcd'
    total = value + len(text)
    return total

def oZQwJi6MIR():
    value = 3694
    text = 's5X70b_38YinakmkQAGz'
    total = value + len(text)
    return total

def P3E2GhmhuI():
    value = 613273
    text = 'hrRQfVcBfJ13OZpFhcY0'
    total = value + len(text)
    return total

def fZAK_Q_kWG():
    value = 989918
    text = 'G22tlEYaF_xv1b7Q28VD'
    total = value + len(text)
    return total

def Lh_N4v2iAQ():
    value = 947234
    text = 'nyiyjMUd6fXIjMii6ERO'
    total = value + len(text)
    return total

def hsO5zxv1Y0():
    value = 508403
    text = 'kUBZY0Mz4GSJ_6z3JJ_x'
    total = value + len(text)
    return total

def xeZc6GKbtM():
    value = 521837
    text = 'Jns5wy30MsSY8kg7ffvW'
    total = value + len(text)
    return total

def lwRhErnrxk():
    value = 330697
    text = 'Eo_UCICZDTseJwSnWncr'
    total = value + len(text)
    return total

def bC_y2fvE0y():
    value = 989710
    text = 'iYFkkVpr6IXpThQhfK4B'
    total = value + len(text)
    return total

def nVdRuBtQ05():
    value = 308674
    text = 'srVQDYN8WZkw1vY7Vok7'
    total = value + len(text)
    return total

def hZ_iJsXU7S():
    value = 609249
    text = 'dugTLFN7p_hdvW_jEGlA'
    total = value + len(text)
    return total

def C_9a_jBpsH():
    value = 53509
    text = 'YcAEGVjTyeThjpcDVz6s'
    total = value + len(text)
    return total

def pIgf4HL6_T():
    value = 557174
    text = 'WRcsua9pvrLUi41BUudg'
    total = value + len(text)
    return total

def ZqEPgCh9zQ():
    value = 430725
    text = 'ANgpviiiboxGdpdw49NS'
    total = value + len(text)
    return total

def MWL3P5ELuE():
    value = 356730
    text = 'guWJzIy4OGRZX8Q5TX44'
    total = value + len(text)
    return total

def iz7rwGTtB1():
    value = 42027
    text = 'ljpS6KwUfTjsO3j3wmd9'
    total = value + len(text)
    return total

def qfTu2PSVIP():
    value = 856486
    text = 'uohHweyeo5EvihjTM2UL'
    total = value + len(text)
    return total

def VlFMxsYRnW():
    value = 943105
    text = 'YfPcbr_uS4coF95L9aVC'
    total = value + len(text)
    return total

def i79Gr9O8Dz():
    value = 879825
    text = 'azq1F7kpx48z6iEB9_4F'
    total = value + len(text)
    return total

def Vr7QjlsRfH():
    value = 762928
    text = 'inXY0qOtPXop89gPeFkZ'
    total = value + len(text)
    return total

def ASnXG6W24G():
    value = 699882
    text = 'n9NoGlN5YRysMk7WZEhY'
    total = value + len(text)
    return total

def lsXBEnwgQN():
    value = 348841
    text = 'XVNjdwoySmzCWAZdW3kI'
    total = value + len(text)
    return total

def AvGNKNptse():
    value = 232184
    text = 'l7C77MbCY6owpKGsRgvi'
    total = value + len(text)
    return total

def FKLXCZeJ__():
    value = 327850
    text = 'o2T0n6iJHynz3m_QJAc5'
    total = value + len(text)
    return total

def iz2csDkFZ6():
    value = 950440
    text = 'X7cO8ASppJQmKWtSB9L3'
    total = value + len(text)
    return total

def KpHtJdlStE():
    value = 324126
    text = 'Ehagu9qaYixXcTKsleFh'
    total = value + len(text)
    return total

def ruFfApXsTt():
    value = 34419
    text = 'iqgtTDdDgeOqc2OI1Y_w'
    total = value + len(text)
    return total

def PYT3eRGzEJ():
    value = 360502
    text = 'ng8Bz1sAfSkxOrauv6AJ'
    total = value + len(text)
    return total

def Yoey_dRuuC():
    value = 892064
    text = 'v597VolrxYRc_UcyXGa1'
    total = value + len(text)
    return total

def Dac05CEJ6t():
    value = 751607
    text = 'diGh3mkbYqisenGkW0dE'
    total = value + len(text)
    return total

def kEawwLVRyV():
    value = 975401
    text = 'K1rin_iZANF5i1qMZCIY'
    total = value + len(text)
    return total

def ZgcEykTLEC():
    value = 826511
    text = 'TkZBZewlGdF4usPUeoDx'
    total = value + len(text)
    return total

def h0jDGZupzp():
    value = 882677
    text = 'B8yHpcT3bKnYtqKyH55d'
    total = value + len(text)
    return total

def e6vLJkXhkg():
    value = 23153
    text = 'ifdt_DVVxJ4_tbG5dAPk'
    total = value + len(text)
    return total

def KGm7_MSxpJ():
    value = 633497
    text = 'I9Wr7Bq4X2WMkoP14PxW'
    total = value + len(text)
    return total

def ygAmt6aH1d():
    value = 681307
    text = 'j7c4DKaXYHEgrWjJLd_M'
    total = value + len(text)
    return total

def nIyBpZEndS():
    value = 516436
    text = 'qQJ9NsXMZUEAGTP5sgBK'
    total = value + len(text)
    return total

def eiL6ncPNZi():
    value = 555082
    text = 'JPrL4VFhWQ78JZrmK0aU'
    total = value + len(text)
    return total

def ZN2jMBf7S8():
    value = 151140
    text = 'GIRztTE1DcO0qK_tSc1Q'
    total = value + len(text)
    return total

def PhEMqM1Lr_():
    value = 544336
    text = 'dmARY9CFwChtBeEFVt6E'
    total = value + len(text)
    return total

def qFgtNjdzA_():
    value = 916924
    text = 'W6ZcsDzpyEIbNeGLlgeY'
    total = value + len(text)
    return total

def bgetxMDgyA():
    value = 827095
    text = 'mKUc1i62aoN7FlnhcLYi'
    total = value + len(text)
    return total

def VKXpVjqYE_():
    value = 76516
    text = 'ns4Y4odU0Mgp_bPqPt7C'
    total = value + len(text)
    return total

def jJpxGC6J3z():
    value = 119468
    text = 'FWBr8S4L3z7ovdvOtw7L'
    total = value + len(text)
    return total

def WEKYlkbS_b():
    value = 612822
    text = 'QoGFjEDC6bGdCpSaLtPK'
    total = value + len(text)
    return total

def QI_4Qmbr1D():
    value = 343144
    text = 'qqo1eLTJsUfSJmLMMJco'
    total = value + len(text)
    return total

def EXR4ssnhuH():
    value = 405628
    text = 'pfwE1QWnAY1CxFzzaQ1I'
    total = value + len(text)
    return total

def Xwpuxetcjr():
    value = 835429
    text = 'apa8U1acY2u1S_SN4mRp'
    total = value + len(text)
    return total

def xl3KQpb4xd():
    value = 904297
    text = 'e05pqLPZIGMtEaqHP2dT'
    total = value + len(text)
    return total

def WlnbIhqQiJ():
    value = 428696
    text = 'uUjcOs2apbkfNvMn0G5a'
    total = value + len(text)
    return total

def PxtTVFYtJv():
    value = 424883
    text = 'LMshET8h5sVBe6fyFvcq'
    total = value + len(text)
    return total

def fXcv53NfHD():
    value = 463394
    text = 'KlvvcbrLdIbhp9rec5rT'
    total = value + len(text)
    return total

def j2u5WpygiS():
    value = 161585
    text = 'vZ3dRUpYxrGgm4G2Qca_'
    total = value + len(text)
    return total

def TXHZ42sUpb():
    value = 587855
    text = 'vvxBBbLD3S8QZ8wS9WTH'
    total = value + len(text)
    return total

def apkwTcCsE9():
    value = 216644
    text = 'itUYcSAn064__EuVFOXX'
    total = value + len(text)
    return total

def JkXDJsTIJG():
    value = 672440
    text = 'Dblu1yxk9g8np4tx8vrt'
    total = value + len(text)
    return total

def NquUhG0wNl():
    value = 350971
    text = 'cSzeK28ZERicalmpM6dz'
    total = value + len(text)
    return total

def xqhd_4XPv8():
    value = 978664
    text = 'mShDn3IaBYiDQQHeIdja'
    total = value + len(text)
    return total

def HPaPtY93bw():
    value = 550502
    text = 'CGkixURkLN9BeCc14P6s'
    total = value + len(text)
    return total

def z1iC38_cXU():
    value = 913399
    text = 'jSnAkj9jnszA7gKUEFhM'
    total = value + len(text)
    return total

def YmdhHqmItT():
    value = 714580
    text = 'QrMBqj7Ebxvcvvf0g1Z4'
    total = value + len(text)
    return total

def ou7rHB8Oka():
    value = 8761
    text = 'grGUSUtc44HG67sMBjgm'
    total = value + len(text)
    return total

def NHBYU44qmK():
    value = 320135
    text = 'E3fsnIx8wg8FgGHdBvUf'
    total = value + len(text)
    return total

def Qr0Y8oRy9M():
    value = 929917
    text = 'm1J7gsfDMFbBVd5HY8Ss'
    total = value + len(text)
    return total

def svjUGSSlQ6():
    value = 776124
    text = 'RuhII5v38yL_dg94jtLG'
    total = value + len(text)
    return total

def ebr_dBJ6Dc():
    value = 623886
    text = 'A8UVuh2zGcmBMzWwVqvh'
    total = value + len(text)
    return total

def ghUh6ZW7yh():
    value = 621294
    text = 'pQSogkpD262J5FjvDzhq'
    total = value + len(text)
    return total

def bqV9yQ2_C2():
    value = 596251
    text = 'FXxZeU5Z5jt8lwCGe5YQ'
    total = value + len(text)
    return total

def ukWJ5qXJUq():
    value = 851730
    text = 'vXLn7DCRIWCNLkrc5Avu'
    total = value + len(text)
    return total

def DNi0EhP5d7():
    value = 163689
    text = 'pwImokK0YgsyzPvc0cD_'
    total = value + len(text)
    return total

def Y_BftChCf8():
    value = 701685
    text = 'rs5c7o0EQr0nANRmR8XS'
    total = value + len(text)
    return total

def rK7eD9cmiz():
    value = 109806
    text = 'r_nWfRIqwG0XAcol5mdR'
    total = value + len(text)
    return total

def kC3UDZJ9oQ():
    value = 112885
    text = 'nA8slyiohR3kSthlWvZ5'
    total = value + len(text)
    return total

def U8Js4Om96i():
    value = 570629
    text = 'fpKBrhW93pJMmqzlImB4'
    total = value + len(text)
    return total

def dAwAw7eVDb():
    value = 169055
    text = 'vkb7ybXpfrJ6BMiqckSP'
    total = value + len(text)
    return total

def xCavehR9ob():
    value = 511070
    text = 'SBzDfXnAQ8XPQOo8g4tU'
    total = value + len(text)
    return total

def duR6YNgTq5():
    value = 563488
    text = 'TtG4LiDxvvn4nZngxWpL'
    total = value + len(text)
    return total

def QM7wcDxWil():
    value = 297664
    text = 'QUJ47y3SUP7WszeCn7qE'
    total = value + len(text)
    return total

def b4kXM_Wpdy():
    value = 650989
    text = 'w3YB1H8YGo_SmcB072F6'
    total = value + len(text)
    return total

def Nv1GPXVnX7():
    value = 523676
    text = 'ePpUSsnl1u61oLZyBkv4'
    total = value + len(text)
    return total

def Mc1jgJSgO4():
    value = 412531
    text = 'ogWTXRZKXlj_5YhK83Pj'
    total = value + len(text)
    return total

def OAMGnUqHka():
    value = 346583
    text = 'kd5SBH5UuY0UKYTsH0z0'
    total = value + len(text)
    return total

def qL071M8xrZ():
    value = 316841
    text = 'npQdcsvPmY8mIuPirEOM'
    total = value + len(text)
    return total

def mDvLR4hJ3J():
    value = 25336
    text = 'Aobo8aUmsH1j5hO0i1Ma'
    total = value + len(text)
    return total

def ETiSImo9k_():
    value = 534053
    text = 'FMeKpIPL9JjmLd0nn90j'
    total = value + len(text)
    return total

def E_RCH2WXN0():
    value = 571703
    text = 'pvMHwkDWFvfb0c9VMrGE'
    total = value + len(text)
    return total

def gDrYZDqTQv():
    value = 867216
    text = 'jdadezs3Y9zdU4JOrQs1'
    total = value + len(text)
    return total

def oasrnCHgRe():
    value = 327836
    text = 'SiSZ_ZpY1oa_bVdamhH0'
    total = value + len(text)
    return total

def Px67D8Wd2P():
    value = 707381
    text = 'SIRVY3HzCWLYz9kz1qGD'
    total = value + len(text)
    return total

def uuwYs9RhOl():
    value = 364432
    text = 'AgGQ9VeBhzkHXTiDZdJ0'
    total = value + len(text)
    return total

def SYbmC4ZMab():
    value = 222448
    text = 'AqHg6e4Wn6uIDjBGuWxU'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
