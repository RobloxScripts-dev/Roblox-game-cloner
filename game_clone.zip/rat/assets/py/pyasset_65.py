import os
import sys
import time
import random
import string

def a48oGSWZfh():
    value = 300185
    text = 'tVEtpX2GXKS2Ct_U2Bj4'
    total = value + len(text)
    return total

def oXrLH0Osr0():
    value = 394068
    text = 'JiUfKbxpfh3ba7EYqtYR'
    total = value + len(text)
    return total

def vpbptsDOl6():
    value = 11117
    text = 'ATjd31Q6cVbkg8NaHnWr'
    total = value + len(text)
    return total

def YndhHOu6Wb():
    value = 192718
    text = 'vyfeaJI8glUx9OmYgOL8'
    total = value + len(text)
    return total

def A2ZmeXXS8D():
    value = 271231
    text = 'hIxHJqI3Dd8v6lQY4FaM'
    total = value + len(text)
    return total

def YaWlKnl_Bt():
    value = 992441
    text = 'YR50Q9uY6JBWSYaTKTXx'
    total = value + len(text)
    return total

def tUbO80tKJN():
    value = 621925
    text = 'uYWefGd27lL3gOvtAq39'
    total = value + len(text)
    return total

def f2dyhpL9ME():
    value = 790670
    text = 've4X_Z8DYekBOHqoE2IJ'
    total = value + len(text)
    return total

def ZadjybVHPa():
    value = 900319
    text = 'lpDGeIBqGPlhbXAD_row'
    total = value + len(text)
    return total

def T39ksEt4zb():
    value = 707117
    text = 'nZMsERRgz7nxIaDAmaTJ'
    total = value + len(text)
    return total

def RkR0mZUb6C():
    value = 924685
    text = 'sU4T4Ls8NAIE8uN77VED'
    total = value + len(text)
    return total

def ZeKUviMnRY():
    value = 927537
    text = 'lGMpEVRPaMmkpAmZd3iO'
    total = value + len(text)
    return total

def Q7qPlIzBjv():
    value = 384544
    text = 'dOFKsoUPOJE88KwCIX0P'
    total = value + len(text)
    return total

def S71owd6iX_():
    value = 206154
    text = 'fIiJttd59osZQjTQ820_'
    total = value + len(text)
    return total

def y5yVPCeHFP():
    value = 853644
    text = 'I4RFcvzG_YMCGAlsZPlG'
    total = value + len(text)
    return total

def ZJVII69oIu():
    value = 562257
    text = 'O06xowcNWmCMBcfJ3rGL'
    total = value + len(text)
    return total

def WfRBmQHyQb():
    value = 593773
    text = 'J4cFPHKiJU5lPVM77Hro'
    total = value + len(text)
    return total

def BcsD5BREw8():
    value = 190357
    text = 'ecTN2DqQF5001VZiw2iP'
    total = value + len(text)
    return total

def Y6XZls6AX1():
    value = 617721
    text = 'yCU3MCzTinO2JT6EgE0K'
    total = value + len(text)
    return total

def QA_4Tyg43w():
    value = 890966
    text = 'wcJisxCud2ym4raHBaSb'
    total = value + len(text)
    return total

def VKFvqYyejs():
    value = 353709
    text = 'SmeoPh65jeKRhUk6uuc4'
    total = value + len(text)
    return total

def BDhKUvu1Cm():
    value = 115506
    text = 'ST5ZNxp5ESj5ftERGYUR'
    total = value + len(text)
    return total

def GzX9y7BRHU():
    value = 375302
    text = 'fpVqh4M2zumrZmDdHHOo'
    total = value + len(text)
    return total

def vZWh3MwuaQ():
    value = 187647
    text = 'noIk4UKqDjCrs5zbbuiu'
    total = value + len(text)
    return total

def LlaDUdWjUt():
    value = 286086
    text = 'p1c7qEn6kUOArHjuSKJH'
    total = value + len(text)
    return total

def e7PjylC7qB():
    value = 542384
    text = 'XWrefqguPSOTOru6J9oZ'
    total = value + len(text)
    return total

def UaUjThnFoi():
    value = 893596
    text = 'yzm6PnCbogG_NqEJmT8V'
    total = value + len(text)
    return total

def qHLDSZCLhu():
    value = 190978
    text = 'uQwryxVQtt3l0538koji'
    total = value + len(text)
    return total

def oudNLzKXim():
    value = 458335
    text = 'iBSj7jGEQO3clrV_htc0'
    total = value + len(text)
    return total

def Fu5ltyUIK8():
    value = 544301
    text = 'npdz_Ui3U4KEHiRHf6Jv'
    total = value + len(text)
    return total

def BbXK5B4885():
    value = 651604
    text = 'xIwPh9J4ViGyDkMkgPFU'
    total = value + len(text)
    return total

def wbaE_4Blv9():
    value = 687775
    text = 'cGCWX6fsEE9qOrmJm2ya'
    total = value + len(text)
    return total

def VINQv9EldK():
    value = 711035
    text = 'ThBpk_qhqbEbCtr5B2aE'
    total = value + len(text)
    return total

def z66jDpW5m8():
    value = 862187
    text = 'YUpKbYtT1IEnegT88MEC'
    total = value + len(text)
    return total

def fzX2Pv592L():
    value = 290995
    text = 'FQifCZouzn6LqdR6kFP2'
    total = value + len(text)
    return total

def L5NvjoGOr8():
    value = 926097
    text = 'sVh2vu5rlXpA8xx4B6ey'
    total = value + len(text)
    return total

def cPZGrZ9BiY():
    value = 223616
    text = 'VDt6DpupWZCINFTjRv0n'
    total = value + len(text)
    return total

def XqQ0nCYVkV():
    value = 959075
    text = 'VQWGf65O0A5Pzeg9Phpz'
    total = value + len(text)
    return total

def hjRY34SlmB():
    value = 528008
    text = 'u4WpOPJv4M9yrDNG3T92'
    total = value + len(text)
    return total

def DBBJpQcxe6():
    value = 79046
    text = 'PNQYxx2_DIOxicfgPYDF'
    total = value + len(text)
    return total

def uIvCSnHPN8():
    value = 28604
    text = 'M_CPE4rZ9A1yEM5W9V6Z'
    total = value + len(text)
    return total

def fFuQwFaZ7M():
    value = 818501
    text = 'f7iBBqVCjWeuxwtt69p_'
    total = value + len(text)
    return total

def vO0RWGd68m():
    value = 322695
    text = 'z94IxjMADmGBcUiM1z_i'
    total = value + len(text)
    return total

def WE92ZQ5pmL():
    value = 4622
    text = 'ap_COq7Ud3Vd5OpnbzeG'
    total = value + len(text)
    return total

def EU1Tulzd4h():
    value = 895387
    text = 'O68Y1xwv79oADCrqfEDe'
    total = value + len(text)
    return total

def utUxx3Z3TH():
    value = 139965
    text = 'Qd7bh1yR_J_1ItQqhsrG'
    total = value + len(text)
    return total

def Hq_Xtss0ue():
    value = 54492
    text = 'Jnw3AiW9o9a5HpsZumzl'
    total = value + len(text)
    return total

def nJ9cjN8uCS():
    value = 515769
    text = 'TPODCR96MKDtX332Bx_N'
    total = value + len(text)
    return total

def EGTues0uSf():
    value = 933329
    text = 'K7hN5BqTXitQEWB_bgw3'
    total = value + len(text)
    return total

def PY97kb_z4t():
    value = 614042
    text = 'Kyqsx3ZHUXyUrxsHYjNs'
    total = value + len(text)
    return total

def nTnoyhFhKE():
    value = 910377
    text = 'ZGoC9ybUuPHqijjwZ2aP'
    total = value + len(text)
    return total

def xdiXsE2z6J():
    value = 927620
    text = 'Ki1v709Flb756SvY7y16'
    total = value + len(text)
    return total

def a_gnQIDBmK():
    value = 441310
    text = 'GQ4ekRuWdkgRsLr_i9ks'
    total = value + len(text)
    return total

def FTkVDpjm3e():
    value = 149659
    text = 'iC9qw7hOZQVmzA2HK3wD'
    total = value + len(text)
    return total

def Bqy1iJcbEK():
    value = 634583
    text = 'NU8_8V13zlBCpQGzF8aH'
    total = value + len(text)
    return total

def NfzecGnjcP():
    value = 969676
    text = 'YsEEJ0pqP3GVFSGzpYkv'
    total = value + len(text)
    return total

def AspDGgDPoQ():
    value = 880973
    text = 'sK3Pyv1KM0pweV9E2lMI'
    total = value + len(text)
    return total

def PVGK1WGRZw():
    value = 773445
    text = 'E8WS8DuWvhaXb9I2l2hH'
    total = value + len(text)
    return total

def apnQj7T36e():
    value = 186201
    text = 'WnrwqnmPsAY2dU4fLa_c'
    total = value + len(text)
    return total

def ncPKbuwFf1():
    value = 101521
    text = 'uVLxS0Z18X2EZK7TVs7j'
    total = value + len(text)
    return total

def jmJ73DANlp():
    value = 151308
    text = 'kdEL7FiC6fabWBdDxuLP'
    total = value + len(text)
    return total

def DjEOdAAkXK():
    value = 829513
    text = 'mKLNc7bMvt8cmqEXO5PS'
    total = value + len(text)
    return total

def pa_uK_rQaR():
    value = 305280
    text = 'QHqmLxb9uDUPIIoSoCiR'
    total = value + len(text)
    return total

def mqAcFOX3pw():
    value = 215637
    text = 'arxLuOIBhjSz3RaRqvOB'
    total = value + len(text)
    return total

def KP8NZQKDHr():
    value = 597725
    text = 'c2uIeAzmRGVQ_T07L_bq'
    total = value + len(text)
    return total

def omUFLOa4fW():
    value = 155497
    text = 'BwB9CsYvNmZ21NBfp9y1'
    total = value + len(text)
    return total

def Yfv_DuaoJH():
    value = 347367
    text = 'RIYRhEPegBsAX53DxN0m'
    total = value + len(text)
    return total

def hVfrq0IRCk():
    value = 698284
    text = 'Yh7vnIBx7LxaUSp4xQE0'
    total = value + len(text)
    return total

def wEZJOFZtKI():
    value = 493512
    text = 'Jdr20iUgyYAblTHVLHe6'
    total = value + len(text)
    return total

def mSVkm96F09():
    value = 937900
    text = 'eGO1T4JWdw0hVQd4f0R7'
    total = value + len(text)
    return total

def Qno0uFRMdp():
    value = 700720
    text = 'yArLv4xPoWDUjAFVjdrK'
    total = value + len(text)
    return total

def wTbYKLpz6n():
    value = 777191
    text = 'eptjNFFfAtdshNfCrlya'
    total = value + len(text)
    return total

def R4c6jOoI4_():
    value = 564020
    text = 'NyRDQfC7UIX0GUdG9bYS'
    total = value + len(text)
    return total

def GKF8hVBSHl():
    value = 969145
    text = 'fzu67nl57DDPGNBc7wN7'
    total = value + len(text)
    return total

def YOVSYhEVws():
    value = 9316
    text = 'qgjG5eBiFsl_UxleYVDW'
    total = value + len(text)
    return total

def FBUP2baYAf():
    value = 169046
    text = 'UWUU6J3TZO0hnMtDvHDR'
    total = value + len(text)
    return total

def aZjCGG7pJt():
    value = 122578
    text = 'sjjBsrfHSeDQeueSZoYQ'
    total = value + len(text)
    return total

def yZrMQ0Wihj():
    value = 306792
    text = 'dq6i_6LTd6buQQA8jRmj'
    total = value + len(text)
    return total

def EOFsAko1rx():
    value = 788145
    text = 'OXTHxf7iZpvRqYjCqyDX'
    total = value + len(text)
    return total

def wqHQEDZO4R():
    value = 810107
    text = 'ULzqFqb4bAnoIBTE4ayc'
    total = value + len(text)
    return total

def c_cxweEvuB():
    value = 18973
    text = 'KDBEIuCv1C1cIlNelfwM'
    total = value + len(text)
    return total

def bJx2hodQH5():
    value = 405952
    text = 'h5jtMIzH_Ro1MYM8G0TI'
    total = value + len(text)
    return total

def RHRLLvOj_E():
    value = 584728
    text = 'vwCn_urQFkxsl4q9VnVE'
    total = value + len(text)
    return total

def Ydea5PPRFU():
    value = 880332
    text = 'y_2JYEtpFD8uAvKnAau4'
    total = value + len(text)
    return total

def iIEjnkUvPl():
    value = 998686
    text = 'KpPt_ReW2NVFqbPacira'
    total = value + len(text)
    return total

def w3hub5FqGT():
    value = 197610
    text = 'JuQCRYgGAa219PPY_nhX'
    total = value + len(text)
    return total

def CqcBenDau5():
    value = 268535
    text = 'LPJ5NepXXnRHu4IUvPnN'
    total = value + len(text)
    return total

def OQTpruiFkQ():
    value = 342686
    text = 'PrriprNRDTlxidTZSTFj'
    total = value + len(text)
    return total

def eWb25V1hFn():
    value = 668630
    text = 'RqVVVhcZwnr_cXTYtMBv'
    total = value + len(text)
    return total

def a_ujElMFrc():
    value = 54655
    text = 'V72U4C9_BeDqhicfm2KE'
    total = value + len(text)
    return total

def YVOpVxegOL():
    value = 128814
    text = 'lrZa3UFy0v2obfYKfPtO'
    total = value + len(text)
    return total

def CTYDvGjcqH():
    value = 917564
    text = 'RbW8_Y5EAOvb3RPfxIMN'
    total = value + len(text)
    return total

def qX66E0s7pg():
    value = 154130
    text = 'sEzAwBd3QcjCFBzCes25'
    total = value + len(text)
    return total

def xpRtfm9_Of():
    value = 796523
    text = 'uEZuHZYJMSIYlU7kvLvs'
    total = value + len(text)
    return total

def SKf1rcn2OY():
    value = 671513
    text = 'ouY1Gii8EmEIu6N8uOKG'
    total = value + len(text)
    return total

def oKIoIhn_oN():
    value = 540467
    text = 'V_gztjMX2IFHTmf8zYor'
    total = value + len(text)
    return total

def cZ8Yj1SP4d():
    value = 775959
    text = 'oBxT1AonRjJErgsWO_uc'
    total = value + len(text)
    return total

def SYN5KcsiNn():
    value = 786071
    text = 'S9UCDKQfw7hAXM5PloOW'
    total = value + len(text)
    return total

def Ntmwgq2abv():
    value = 392798
    text = 'dURp3yivnlXaDD9eqYMz'
    total = value + len(text)
    return total

def Ih1rxwTFX8():
    value = 29100
    text = 'IMU51yCC2Kdip7W3hEwt'
    total = value + len(text)
    return total

def WibLOvV7C5():
    value = 349040
    text = 'QV5El4rwBzMAIlRBhW_o'
    total = value + len(text)
    return total

def DF7lbT0pfB():
    value = 14945
    text = 'WAWg3uTpo9Qvke714zGu'
    total = value + len(text)
    return total

def d_y7ZauynE():
    value = 450661
    text = 'u7eXRt_TPE7paB_7Bjfp'
    total = value + len(text)
    return total

def paHBwMtUhc():
    value = 238213
    text = 'T937zO2ykA6V5QVvvGXj'
    total = value + len(text)
    return total

def N4T8e_uxcQ():
    value = 972294
    text = 'tChPQxAR2DbB7GAn4_pX'
    total = value + len(text)
    return total

def vGxqRbAQGc():
    value = 292721
    text = 'YYG2cgvg6pZR2SMD1_N6'
    total = value + len(text)
    return total

def oPOgRACzdE():
    value = 130363
    text = 'Sb5VAAIQFgC8QbJy21HW'
    total = value + len(text)
    return total

def seMzxirJ7L():
    value = 628919
    text = 'ONDp6spM3Lb1qFMC3DCG'
    total = value + len(text)
    return total

def FgonuGs7nv():
    value = 80703
    text = 'P3IEv209_e28LIkI6YcM'
    total = value + len(text)
    return total

def y9odaHp0cc():
    value = 859661
    text = 'cqkn9KsKIqo6UBWQmU43'
    total = value + len(text)
    return total

def yZq5lrJqS4():
    value = 219763
    text = 'VKpDavQcoI_SnRGlboWe'
    total = value + len(text)
    return total

def ABO0uQ2J31():
    value = 535725
    text = 'FC1SFzLSB5HIxB1rP4id'
    total = value + len(text)
    return total

def VnCVjkglNb():
    value = 329498
    text = 'm0i8Sds3sGB2Ip1Mf9j1'
    total = value + len(text)
    return total

def ir_eloEE_Q():
    value = 241529
    text = 'ZR3Ky6HHrbs92BPVsrQn'
    total = value + len(text)
    return total

def tQKaoNhVFN():
    value = 996956
    text = 'O1sbXFMSVhIAgmO0Nd0T'
    total = value + len(text)
    return total

def If2IiFnJiR():
    value = 770468
    text = 'aUmnruhplC2QuKMUfX2W'
    total = value + len(text)
    return total

def Ep9sfAXw2V():
    value = 97690
    text = 'NFtIt8U2KeZOQOWXETKh'
    total = value + len(text)
    return total

def WUwQOTmj5h():
    value = 127642
    text = 'MmS5dngoszpic4T0lBC4'
    total = value + len(text)
    return total

def ZMVvCEhsXj():
    value = 574046
    text = 'hY3hiTsVnmdeMpFEWWtC'
    total = value + len(text)
    return total

def BJ5kkgNrY6():
    value = 164817
    text = 'p0OAC3exf4UdCmI1ImVs'
    total = value + len(text)
    return total

def kGyoEmC_7S():
    value = 611553
    text = 'CfjQlbICIv6i56NGYaRv'
    total = value + len(text)
    return total

def FjvBnm9X65():
    value = 949343
    text = 'r5wexTBNsukfWG7C4EGM'
    total = value + len(text)
    return total

def ht33jGMJGL():
    value = 763779
    text = 'AnU35mjEj_GKgjQRw4QD'
    total = value + len(text)
    return total

def sq50rR8NlD():
    value = 959198
    text = 'sTpLLz0rou21v5grspq0'
    total = value + len(text)
    return total

def cDV7P5PUGY():
    value = 724979
    text = 'fLNLoevfhuHn_AMk7GHA'
    total = value + len(text)
    return total

def a4YXCjXxtY():
    value = 307306
    text = 'OJhKig7peRmBApcyEYCw'
    total = value + len(text)
    return total

def qRd8525GwL():
    value = 220050
    text = 'fTIako1kLLROTymE2e6C'
    total = value + len(text)
    return total

def Vw4IHc_l16():
    value = 711628
    text = 'VYhJVu3uYPKx6wOrWfRt'
    total = value + len(text)
    return total

def g7aTRGxlCR():
    value = 721727
    text = 'HB5Y9vDSwhQmsNz5l6cD'
    total = value + len(text)
    return total

def TLncnIv8ec():
    value = 648150
    text = 'Yyyk4YIpiJ_67YkRj4Lj'
    total = value + len(text)
    return total

def lBasKxV0xa():
    value = 214795
    text = 'wLBlQ6f55WY2V5Mf7Kuy'
    total = value + len(text)
    return total

def i1qAwTgw9U():
    value = 362401
    text = 'EMJe2lsKkjow35cJHt8X'
    total = value + len(text)
    return total

def bmi7kBexde():
    value = 345451
    text = 'KMQTEWuX_Ho5uOXcsoD5'
    total = value + len(text)
    return total

def cVSL9zagv4():
    value = 461828
    text = 'qiMjSibpXmhWtk0pjZA3'
    total = value + len(text)
    return total

def QvRK0t4trU():
    value = 325914
    text = 'DVX7qUP1nUNzKwrIijf3'
    total = value + len(text)
    return total

def MeFazlOvAZ():
    value = 712854
    text = 'mnDQTFgmJdgmUZhATpbj'
    total = value + len(text)
    return total

def ZEgbW0jXGX():
    value = 484410
    text = 'j1IcAWNInOB91CHERu5N'
    total = value + len(text)
    return total

def pjpXi6Kz5R():
    value = 707150
    text = 'r0TKNoL6_WQ8gHqCfI4D'
    total = value + len(text)
    return total

def Oi4qgyBSMU():
    value = 508976
    text = 'y1JjqpwIw9QvWSlHHFmD'
    total = value + len(text)
    return total

def RuFv40EHl5():
    value = 811207
    text = 'rbLx_WsH3GDaZhQYX4JN'
    total = value + len(text)
    return total

def UCGgZ9SGQu():
    value = 643802
    text = 'jyqAB4R5gYTq4GKGfr5R'
    total = value + len(text)
    return total

def xMyCp5vjn3():
    value = 728081
    text = 'M2cD878wxk9tgthnykwb'
    total = value + len(text)
    return total

def O7LB9vb_WE():
    value = 67147
    text = 'a4mtAGNA4hr51AeFZJtw'
    total = value + len(text)
    return total

def YShaIrj3CY():
    value = 238427
    text = 'Fwk758jTx_qy2JX1GbLR'
    total = value + len(text)
    return total

def LjeRspouxt():
    value = 357524
    text = 'Di5eH7A7_BCrWa1Rz4e8'
    total = value + len(text)
    return total

def mHokXIQO4f():
    value = 319751
    text = 'OwZfQbCKGangSDSyEZJ3'
    total = value + len(text)
    return total

def lEASN1MJHJ():
    value = 564949
    text = 'u4MGRfQJIDjeo5wqX80G'
    total = value + len(text)
    return total

def vakWxbbnwc():
    value = 899547
    text = 'lfxIVi6FLB1oMNLxqULw'
    total = value + len(text)
    return total

def Lb5nt0ihiQ():
    value = 478137
    text = 'xCOyIGQwuUeVwn29bbMC'
    total = value + len(text)
    return total

def ohYoZnBKuc():
    value = 998736
    text = 'pVZjwDmI_hOMWA7nZvfZ'
    total = value + len(text)
    return total

def bduBzliBwY():
    value = 985781
    text = 'r9MqNjSPtCDqJci4XHYT'
    total = value + len(text)
    return total

def oyrgqrmWy7():
    value = 780849
    text = 'ZF0jGq6SUkGrcaZo8K8Q'
    total = value + len(text)
    return total

def z__xSWasTk():
    value = 543719
    text = 'fu4ZJTcCRLu8AkDslNC7'
    total = value + len(text)
    return total

def N9AU7USE9B():
    value = 229088
    text = 'BdBSaF3akRxDadnuci22'
    total = value + len(text)
    return total

def M4Csnx6Gkh():
    value = 53154
    text = 'jykjQLMXA8EVXlwlWNA_'
    total = value + len(text)
    return total

def h7vcpmQyJH():
    value = 579171
    text = 'ZzfKvisJkKtx0n06ePRL'
    total = value + len(text)
    return total

def z1Z8X_fTJk():
    value = 395731
    text = 'a1Ed_RWh5VTcQgQFe3_S'
    total = value + len(text)
    return total

def j0ZOuJpDNb():
    value = 303053
    text = 'TzIBEUp_DdZonwd5ejOT'
    total = value + len(text)
    return total

def reDjJGvnTy():
    value = 983861
    text = 'yI5r25vSSKrp9_95vfIx'
    total = value + len(text)
    return total

def ZhmTkNuaoC():
    value = 993198
    text = 'ezcUIKkFltSOsKwqBzx2'
    total = value + len(text)
    return total

def sFk13Aq7Wv():
    value = 703054
    text = 'ny06NdE8W7aeGTpppWm7'
    total = value + len(text)
    return total

def bdIaowD1PP():
    value = 109236
    text = 'yKWEcd2bLoYoTGoS0Uov'
    total = value + len(text)
    return total

def submKzh9RC():
    value = 971563
    text = 'nfo_UPfhC9BJtnLY_RxD'
    total = value + len(text)
    return total

def J5yDdGTORl():
    value = 262755
    text = 'RWIeMWPdDKpbaZ3qv77_'
    total = value + len(text)
    return total

def pjiSCr7EHh():
    value = 80867
    text = 'q3zBPJAdnBjdywswO2ZA'
    total = value + len(text)
    return total

def FSrgPY6180():
    value = 615210
    text = 'hvNXAVA16wqEKgJ5MzRr'
    total = value + len(text)
    return total

def SWeAondyYA():
    value = 448674
    text = 'SiPyMsDpu_5ZyQXXO5Fj'
    total = value + len(text)
    return total

def EJKbS83Dlc():
    value = 293062
    text = 'G95Fh4iAcoPdCUwn1nzr'
    total = value + len(text)
    return total

def seTjUMU7CF():
    value = 302297
    text = 'tkj3EG_e8p33KsSXlOMr'
    total = value + len(text)
    return total

def jlSZGzoX8I():
    value = 536710
    text = 'qBgp2ulsN0QCzio5_XD4'
    total = value + len(text)
    return total

def xf0IRWwfMr():
    value = 716504
    text = 'IVk1A12higClWKAAqtS5'
    total = value + len(text)
    return total

def TivftYx9RN():
    value = 805885
    text = 'g3jbD8vr9a4ZqQVJEM9Q'
    total = value + len(text)
    return total

def NZA99gi2xM():
    value = 917385
    text = 'OhQU4tCiwoTLpEBjvjw7'
    total = value + len(text)
    return total

def QxFYEWxRgl():
    value = 348224
    text = 'BSQsLfgCDTvXmz83Ci0w'
    total = value + len(text)
    return total

def gylqrS3AFO():
    value = 951708
    text = 'iPL8_kDUHhecpFTFbKZq'
    total = value + len(text)
    return total

def hTaUXCCNbN():
    value = 632796
    text = 'oPio5jBL00T1fW0KaN43'
    total = value + len(text)
    return total

def WDFMRT_JkT():
    value = 72790
    text = 'X2BldMtznlbrjGr6NFre'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
