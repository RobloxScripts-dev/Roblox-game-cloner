import os
import sys
import time
import random
import string

def cRqGJy1WRI():
    value = 763668
    text = 'jFXDWWXX1ZmGUg_tNoms'
    total = value + len(text)
    return total

def oezQvnGIv2():
    value = 310986
    text = 'XC9tLIg9X_qNsREk0Gxq'
    total = value + len(text)
    return total

def gOdufrXqtr():
    value = 993544
    text = 'ZjIACJhwYQ7HnepgCixk'
    total = value + len(text)
    return total

def TAFetdmXYp():
    value = 825041
    text = 'VBJjQRxJiN9g15NYbxzV'
    total = value + len(text)
    return total

def fffrH1Klak():
    value = 97941
    text = 'cx56DeoLZIrCeVNHCNQW'
    total = value + len(text)
    return total

def y4eHhv2JHY():
    value = 744297
    text = 'lnZ75ITMsUxuIOz7TRqZ'
    total = value + len(text)
    return total

def zNV8npVlue():
    value = 909907
    text = 'dmcavDmUy0236Fo2lTH5'
    total = value + len(text)
    return total

def BDZF29gio6():
    value = 942947
    text = 'FBPqHm3rO4LArt_rLbyw'
    total = value + len(text)
    return total

def LRkvYtyzJS():
    value = 932865
    text = 'DdRHvtkm0ylYZNn5tG7m'
    total = value + len(text)
    return total

def HXi3PUVnRs():
    value = 382040
    text = 'yR9p4L_YQ82AdT8euw4Y'
    total = value + len(text)
    return total

def No3HIBph8Z():
    value = 571093
    text = 'B0nUtNpyQhdH_JWVa4vT'
    total = value + len(text)
    return total

def UGFr_lUmjP():
    value = 731951
    text = 'cFM_hkaDQBIjYSfbWU58'
    total = value + len(text)
    return total

def hySsGNdPfT():
    value = 235098
    text = 'Fpjayw9OS1wNgiF2jme7'
    total = value + len(text)
    return total

def xBm9IbUPDC():
    value = 572255
    text = 'nYYsvO24Lxyt4YxfqWxq'
    total = value + len(text)
    return total

def UzlKktevrI():
    value = 813433
    text = 'vaMLMwaDat1BWo9GazJZ'
    total = value + len(text)
    return total

def bnDgreAQWr():
    value = 945682
    text = 'XXeBXZl7uFEPF1122Qkl'
    total = value + len(text)
    return total

def cnDspzTEIF():
    value = 116096
    text = 'CGSkWfIF_W4K4BIiPAs1'
    total = value + len(text)
    return total

def z2nGdVJDzj():
    value = 363824
    text = 'nULZlC4tnpRMjRh04yj9'
    total = value + len(text)
    return total

def skZCSVZDh8():
    value = 409711
    text = 'l2KFZHXHGq31voKCXHnL'
    total = value + len(text)
    return total

def rfze5bPYO7():
    value = 465897
    text = 'oPgkm2xsgtgCAzRJo09f'
    total = value + len(text)
    return total

def HqfZPrQI2J():
    value = 860469
    text = 'zCmSIdEhE9FBUOjthXlC'
    total = value + len(text)
    return total

def Sv1z8zsBk_():
    value = 81714
    text = 'ysz_0T8i_ofqM44c9AxV'
    total = value + len(text)
    return total

def XQM90OPhfG():
    value = 67240
    text = 'updVhlICl8ayYhYEvZ2I'
    total = value + len(text)
    return total

def eAubI_piSR():
    value = 841144
    text = 'PmX91l8Y4_0alRkmTBNI'
    total = value + len(text)
    return total

def MM0tenpsmG():
    value = 818426
    text = 'AVbQDUZzpu8ak7r7bNx0'
    total = value + len(text)
    return total

def Ubs_dLndqB():
    value = 267179
    text = 'cvI_VpC4_Q4RtMrihxJ2'
    total = value + len(text)
    return total

def V0k2MQMpYt():
    value = 491675
    text = 'GgXGEozabKTFO76333KP'
    total = value + len(text)
    return total

def OphraX_VBF():
    value = 708055
    text = 'VBLbOhx8JbThLD9v3MHV'
    total = value + len(text)
    return total

def qPRYaeI27w():
    value = 380351
    text = 'rdMDdg48gFxPBBwyr_8j'
    total = value + len(text)
    return total

def x7KkNqELsB():
    value = 978377
    text = 'ZiX1ojeH0c9FNpJVQ8i5'
    total = value + len(text)
    return total

def eIg882cRde():
    value = 322364
    text = 'MGLorxPIqNTOdvz6jJXR'
    total = value + len(text)
    return total

def SiKBeIl4g5():
    value = 341646
    text = 'A9n8FazDq1lZatrBacpM'
    total = value + len(text)
    return total

def CjIEz5Uf8S():
    value = 369318
    text = 'W62LoUOKtj9T5HosY3tU'
    total = value + len(text)
    return total

def lH2aT9zi6i():
    value = 891955
    text = 'KDQTTpA5IxqxN_W2Ee_E'
    total = value + len(text)
    return total

def IcD96eduKP():
    value = 220640
    text = 'PtPdVaj7gjZr02U_OZDo'
    total = value + len(text)
    return total

def tTU_qB0OsW():
    value = 166835
    text = 'mh_S9NOhChDuNdVSqoV5'
    total = value + len(text)
    return total

def qroVxe_Cic():
    value = 882411
    text = 'Mwmsw5SAVnZmib5Leq7J'
    total = value + len(text)
    return total

def GeaZlUip4b():
    value = 689689
    text = 'egRZRxe_rFU5I5sIYsOo'
    total = value + len(text)
    return total

def WBtGCWKupo():
    value = 660873
    text = 'yqxTJSdkWvUCYo96XBMY'
    total = value + len(text)
    return total

def QBFL9_3T1l():
    value = 555135
    text = 'T3Lj375xkU5vD3gnzWAt'
    total = value + len(text)
    return total

def eAXPE5AcVe():
    value = 62247
    text = 'iYCNqGRvsiZmnz93kceq'
    total = value + len(text)
    return total

def Gb4fKkhlUK():
    value = 360238
    text = 'Qhf_MFNEbUF2ldwdPoQo'
    total = value + len(text)
    return total

def EdscWgMdGh():
    value = 17956
    text = 'yaeoYW70K4ChjfopOljG'
    total = value + len(text)
    return total

def Zar3HMG8__():
    value = 783738
    text = 'yCD9m23Imwv7LsbUy_AL'
    total = value + len(text)
    return total

def Hua3uP_QkF():
    value = 243737
    text = 'k9dEiQIoUIpbPSevElmX'
    total = value + len(text)
    return total

def dcgcBVcsOE():
    value = 856464
    text = 'ag_STsmqCFvcY87T2Emi'
    total = value + len(text)
    return total

def XRMhk9NXwh():
    value = 734063
    text = 'o0b59RzndtRQnfvrNSvA'
    total = value + len(text)
    return total

def gDxqBc6RlE():
    value = 85022
    text = 'HTfD0YD9ZqkaGTlaZmeC'
    total = value + len(text)
    return total

def UG8Sx7EIG7():
    value = 369276
    text = 'rzrsD1TFsk0JY6hW5wlP'
    total = value + len(text)
    return total

def IynlKWgKsK():
    value = 98840
    text = 'NMgq9jbChcxVHtmkCs8T'
    total = value + len(text)
    return total

def esbWUVzIPn():
    value = 242725
    text = 'qXGun0vYRsm6MHdvGhdQ'
    total = value + len(text)
    return total

def iYBjTSqLzx():
    value = 931135
    text = 'uMHWbBeAp5S5i7vWfcDO'
    total = value + len(text)
    return total

def tWSyV80ttZ():
    value = 355843
    text = 'iFwdwLXenLpygqvXR87Y'
    total = value + len(text)
    return total

def yVMNPPmx4Z():
    value = 182746
    text = 'x9W3OYxbsWVMBnj2sM5c'
    total = value + len(text)
    return total

def zD65AdGSWi():
    value = 155720
    text = 'NgFlaFC3FB2zsMOXf7Nf'
    total = value + len(text)
    return total

def NUqjbjWTo6():
    value = 662773
    text = 'YvKWFskBy_bE8VzXjELB'
    total = value + len(text)
    return total

def RPFQOT_0Q_():
    value = 387589
    text = 'z3xqHKiVfRZezYvQxinx'
    total = value + len(text)
    return total

def LpFE2BP2zm():
    value = 419666
    text = 'ojT7NiMYGRzzHJPbFKIW'
    total = value + len(text)
    return total

def h9W15hrA5A():
    value = 302739
    text = 'xV_USOn8jjkCLoYkYkAM'
    total = value + len(text)
    return total

def sGTshM_alL():
    value = 888984
    text = 'LCuDgulg4p2KGrMh9RbE'
    total = value + len(text)
    return total

def vYoIIo7Eem():
    value = 637020
    text = 'oy7AdAGkraxjB9sDMI6v'
    total = value + len(text)
    return total

def EwjMcw53Wj():
    value = 341504
    text = 'sYutliYSiAUILc3rgxzh'
    total = value + len(text)
    return total

def S3hVCFeKTv():
    value = 214027
    text = 'cW7QT7HKgUieFX1LfULZ'
    total = value + len(text)
    return total

def DZDjAhSQBY():
    value = 861273
    text = 'Q__uZcG5qUHqCbIkSiS0'
    total = value + len(text)
    return total

def hs0UD12n9F():
    value = 422617
    text = 'giHQu28zzwFVcFfJVmux'
    total = value + len(text)
    return total

def YRp3_p0Qqb():
    value = 411682
    text = 'k_0n3gODxfTv00ovkoqV'
    total = value + len(text)
    return total

def Yinq1DZC9j():
    value = 704275
    text = 'dX1liR3mN5v9KVu_KdR1'
    total = value + len(text)
    return total

def nmkS8CZ0oN():
    value = 220650
    text = 'YTOP48UZHz887dkJSOzd'
    total = value + len(text)
    return total

def MDA62z7nPW():
    value = 171251
    text = 'YnDBv40q8G8SfHcc8_r5'
    total = value + len(text)
    return total

def iR2_2858Hr():
    value = 129462
    text = 'QTGLHOHm3hEscVID9KNE'
    total = value + len(text)
    return total

def K1KWYQKxJg():
    value = 921457
    text = 'Ix_wqyj0RylR845dqbWH'
    total = value + len(text)
    return total

def sZxffI0Yu7():
    value = 668091
    text = 'd1EQFq4sKYnzOmc06kdg'
    total = value + len(text)
    return total

def WWUsRWtkbt():
    value = 370244
    text = 'GEnxxkKMDNdu59O0M9sf'
    total = value + len(text)
    return total

def JT73J5StxU():
    value = 732375
    text = 'VeRITnkA9u324CdSvBac'
    total = value + len(text)
    return total

def jHFyrmrXxh():
    value = 681509
    text = 'uZqudCQGX3I3BjwC3nfr'
    total = value + len(text)
    return total

def ZZ65tLKubB():
    value = 560556
    text = 'tA5j00EpnOmAVhAcLm26'
    total = value + len(text)
    return total

def zVG_bejN8R():
    value = 176491
    text = 'sjG9uNYgihvtXtCME5ce'
    total = value + len(text)
    return total

def DzUFIW91rF():
    value = 122972
    text = 'ZgEW2tQ64v8B0NFpgTZ2'
    total = value + len(text)
    return total

def Th16CvtVZ1():
    value = 396186
    text = 'pBlye9xOsbIuGIGkIA1S'
    total = value + len(text)
    return total

def de1bXOonIR():
    value = 65298
    text = 'zSK5Hcqm0aO8_O1AMW4f'
    total = value + len(text)
    return total

def PeJCs38oE0():
    value = 667720
    text = 'kbsLi12dIj_TxExOz1Oz'
    total = value + len(text)
    return total

def ZarL1_JSFQ():
    value = 555752
    text = 'KJkSmVZbeGFZ30usxGW0'
    total = value + len(text)
    return total

def iCunF6zcNR():
    value = 420919
    text = 'OsJjvRDrKkJFImRlE5Zx'
    total = value + len(text)
    return total

def VFJIINKHpa():
    value = 536217
    text = 'UddelP9psGuZM6GzZrVU'
    total = value + len(text)
    return total

def lqlSakkLqQ():
    value = 916822
    text = 'DjrlH7UFjYDStQEmGlPV'
    total = value + len(text)
    return total

def BbCBgQg0tt():
    value = 345261
    text = 'lhrJhedAUUx71XIcxUU5'
    total = value + len(text)
    return total

def ARwOZd9yH0():
    value = 473450
    text = 'mx7p2ua8wD9KiceeCRTs'
    total = value + len(text)
    return total

def F9GLkwgfLT():
    value = 294905
    text = 'O3ua3JfiuhNaYaFSgCdx'
    total = value + len(text)
    return total

def XXXUYRjTwZ():
    value = 762224
    text = 'hbG2Qu8yxyGixZPiIhsu'
    total = value + len(text)
    return total

def Vfr04JSgBq():
    value = 140215
    text = 'XdoRs3z6SU3QurCxN37h'
    total = value + len(text)
    return total

def IP9Ey075aY():
    value = 681089
    text = 'JHXalMliU0z5Aur4sbSe'
    total = value + len(text)
    return total

def IPugHlyxGI():
    value = 732496
    text = 'WPmvwvdRsXBbwfVYO3Xf'
    total = value + len(text)
    return total

def sahJMB9RdC():
    value = 647814
    text = 'UbbOKAV74YEw1nyjaHNv'
    total = value + len(text)
    return total

def MPyRBPQwiQ():
    value = 111217
    text = 'nWs9CUPiI6QEvixSThFL'
    total = value + len(text)
    return total

def Icv02p19b6():
    value = 731822
    text = 'FdMMygedGxGUg_Baz97m'
    total = value + len(text)
    return total

def w18NAOHcxY():
    value = 88199
    text = 'B8jAiqwaBdt75U7nd8Mm'
    total = value + len(text)
    return total

def RluRUy98T8():
    value = 602675
    text = 'prLfpZWEDsfP0MkeV3gl'
    total = value + len(text)
    return total

def oJmW1_s8PS():
    value = 60751
    text = 'mWFF1HCukkjr8fQPyQax'
    total = value + len(text)
    return total

def SeO4zRSnnw():
    value = 399445
    text = 'g_DUCEXAajqxhO6Ye0ip'
    total = value + len(text)
    return total

def iuMTeePUiu():
    value = 583035
    text = 'i1mk0gpdNo77MecIzxfm'
    total = value + len(text)
    return total

def rZOFmwIgpO():
    value = 594632
    text = 'FJHYfst1Ua8zzkB3SFme'
    total = value + len(text)
    return total

def ipmWDoURoO():
    value = 59960
    text = 'gK4sYSQfPZswLQt8Hy_X'
    total = value + len(text)
    return total

def BU3honQkGd():
    value = 470590
    text = 'F8RFmakmSOnL4NcAs_j0'
    total = value + len(text)
    return total

def RtBBeKd1KC():
    value = 196511
    text = 'gTE4WKsvwTEDwUHFwhxI'
    total = value + len(text)
    return total

def OZNz3g3urj():
    value = 838925
    text = 'sgmZAzEDh7bbENnBD2Su'
    total = value + len(text)
    return total

def bTd_n2bbWm():
    value = 915595
    text = 'X35lqj0RLGQhG_QBHWjq'
    total = value + len(text)
    return total

def DIs8e_txMj():
    value = 62456
    text = 'VokPfJrSsaAVqFbmxUmZ'
    total = value + len(text)
    return total

def K3SUGNlFnB():
    value = 396929
    text = 'ZHS5LOjK_j2SzTpyE9ee'
    total = value + len(text)
    return total

def a_9VO11TIl():
    value = 802346
    text = 'eL1ZOyY4onKPiW8Ce1hx'
    total = value + len(text)
    return total

def h90f5Jvimk():
    value = 90131
    text = 'ZtDZXD8oiMu05KKi8da1'
    total = value + len(text)
    return total

def rZJtu26Hyt():
    value = 714991
    text = 'ZaB6Ob29rmqZ94XKTcEW'
    total = value + len(text)
    return total

def UPOMey3kyP():
    value = 134401
    text = 'ymgIVd44TLwFVQPezuMW'
    total = value + len(text)
    return total

def m8QkeiPOzr():
    value = 989683
    text = 'bGPEUpntEZ3M7YW_BiSR'
    total = value + len(text)
    return total

def V9r1T6SVRG():
    value = 320459
    text = 'XS9atAeP6myA2ZSvGvfG'
    total = value + len(text)
    return total

def s7gtpXZJDq():
    value = 245189
    text = 'ghsJ6UpUFCZHpk3cJTHe'
    total = value + len(text)
    return total

def nQ0mrASJw5():
    value = 505042
    text = 'KV2DBfLvo8WZ3HKEdEId'
    total = value + len(text)
    return total

def jBy8cxoI_B():
    value = 538673
    text = 'diUkG3kSKgyPRZE0q_PF'
    total = value + len(text)
    return total

def IUnUFnCkD0():
    value = 755530
    text = 'JtzkjsoUim85kVfBMGVR'
    total = value + len(text)
    return total

def LLC7gn3Tpl():
    value = 915300
    text = 'Rf4m6JTdhsd0u5If5OmQ'
    total = value + len(text)
    return total

def tmlcufsTM0():
    value = 864620
    text = 'zjJQuLkRx5NG1ghomzk3'
    total = value + len(text)
    return total

def Sl0cCQ3FCX():
    value = 21342
    text = 'XNYWGL0aOhDBCWfenS0_'
    total = value + len(text)
    return total

def rV27_flTy4():
    value = 254199
    text = 'lOQmSof3VH3jdcn_M8Md'
    total = value + len(text)
    return total

def yZXIi5TT5n():
    value = 49027
    text = 'BI1IUfsORV6DlLkNM8Hv'
    total = value + len(text)
    return total

def JQ_4cheTvZ():
    value = 246724
    text = 'UG5gEQYT6SaDUw02V_MZ'
    total = value + len(text)
    return total

def GkGY3udyg6():
    value = 984031
    text = 'rKXrMsL520ASUW7APDCX'
    total = value + len(text)
    return total

def G17_DBu3MW():
    value = 284482
    text = 'KIirOXJRWXd9SR3T0Loz'
    total = value + len(text)
    return total

def fA1pV1F1Rw():
    value = 450448
    text = 'HJDF9Bk83E8VQiqXC_Ca'
    total = value + len(text)
    return total

def XzE_YAcEm7():
    value = 373818
    text = 'EPubCw62pmKBYqLQQTUy'
    total = value + len(text)
    return total

def fe_ArHhAvE():
    value = 318870
    text = 'W1rHi4JmTDNAL5VSvOwE'
    total = value + len(text)
    return total

def lKch7HAUGG():
    value = 943828
    text = 'RFeAFIiCJbOZhaSvnlJU'
    total = value + len(text)
    return total

def Gop9NETAbX():
    value = 266591
    text = 'CH6TffExu4W6tNX7fr0Z'
    total = value + len(text)
    return total

def main():
    print('m')

if __name__ == '__main__':
    main()
