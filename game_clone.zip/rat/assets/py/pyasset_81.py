import os
import sys
import time
import random
import string

def QxdD1wyspt():
    value = 445277
    text = 'gXVs_vkZE2NKC6CYJKEC'
    total = value + len(text)
    return total

def yp6_LSeBEL():
    value = 694051
    text = 'A2TZkD0mIKvCQZcnJtc9'
    total = value + len(text)
    return total

def ldnABDbt_m():
    value = 989030
    text = 'EYli_M5sxhzNEBYdhKkj'
    total = value + len(text)
    return total

def STBpOoMBak():
    value = 105496
    text = 'yW8xJUBw9UacgvrVe1U_'
    total = value + len(text)
    return total

def RyJZ4wtE26():
    value = 947889
    text = 'rzPJ9vbnG3fy_M7ibXr7'
    total = value + len(text)
    return total

def sXv7rpNQO4():
    value = 525294
    text = 'itW8DB_kYWrWE0On_6Wf'
    total = value + len(text)
    return total

def Xz4hlOsZFz():
    value = 162240
    text = 'vXxUyxOCEeO2xnyCs2fg'
    total = value + len(text)
    return total

def LbjlqQMWBF():
    value = 347230
    text = 'bS2GJVgRoEOsvwOVWhtt'
    total = value + len(text)
    return total

def XXJclRJU7B():
    value = 663447
    text = 'P8HgY_76QB_7FD3f5jKf'
    total = value + len(text)
    return total

def x9ozcEzr20():
    value = 881347
    text = 'W1LSbQ5btEBGUWg2neIg'
    total = value + len(text)
    return total

def TwSuFalDmQ():
    value = 242004
    text = 'JsU1hOWh1OisTlgwXpNl'
    total = value + len(text)
    return total

def TzQD9T911m():
    value = 653707
    text = 'WAtJZMzpTLImRBlB7OfA'
    total = value + len(text)
    return total

def SkR_5yFAYN():
    value = 822412
    text = 'fuxFYCUIIo7cT5nWXMGM'
    total = value + len(text)
    return total

def eWCxIIkyhP():
    value = 490606
    text = 'tbJ2sbhbtejVtsO6bvrX'
    total = value + len(text)
    return total

def dyKxO3dHe0():
    value = 977012
    text = 'p5VoI7G0ViKGx_pdfAfL'
    total = value + len(text)
    return total

def GAcfqOEOZr():
    value = 970679
    text = 'kTlUV64MqR_ois0yN8TL'
    total = value + len(text)
    return total

def XyTzcsiCO3():
    value = 988269
    text = 'gtyQ4wSfC4qQVCA0GpGl'
    total = value + len(text)
    return total

def eJN2e78IzY():
    value = 232773
    text = 'P1I1EoTFNPQ_uB9Ro4_d'
    total = value + len(text)
    return total

def pWtVLl4HMt():
    value = 601228
    text = 'sscfl7irORa2lUKLtCKh'
    total = value + len(text)
    return total

def UCd9SLPTqX():
    value = 679934
    text = 'paoVj1APacXoAE5FA9Xg'
    total = value + len(text)
    return total

def T70m8WEXJ7():
    value = 297742
    text = 'I3HxXbJ3I1g5RXTKQFTm'
    total = value + len(text)
    return total

def Q5uQmTutyh():
    value = 485212
    text = 'XZk2rAMfboUuGrDQ0h2K'
    total = value + len(text)
    return total

def ibSEATA_A6():
    value = 497693
    text = 'alI7tfOedYckjo8uz8Xq'
    total = value + len(text)
    return total

def Z09At4Z0bF():
    value = 597949
    text = 'sp17bpHay151f1PGX2HN'
    total = value + len(text)
    return total

def L0F9N2Rm6u():
    value = 916927
    text = 'Wgl20q36HOXNCHG0IcIR'
    total = value + len(text)
    return total

def FALDgpmEBX():
    value = 644586
    text = 'NrTBgjnETj00vVlQwKJ2'
    total = value + len(text)
    return total

def dL4BaQq8MH():
    value = 711373
    text = 'lzW0Lf_Ee0TEgzWWRafW'
    total = value + len(text)
    return total

def mcrRtPMhNV():
    value = 610081
    text = 'Gv85TUgSS6wyvI0rZHwS'
    total = value + len(text)
    return total

def tS8L9ywn4W():
    value = 71369
    text = 'z_mcWEukzICYC3deJ5mN'
    total = value + len(text)
    return total

def sB5DUUlnN2():
    value = 497038
    text = 'GTyiJUlHqF8oBy4HGUUD'
    total = value + len(text)
    return total

def stZuucFuOw():
    value = 923794
    text = 'oy5ASEKurd5khCvYsGZQ'
    total = value + len(text)
    return total

def VOclT1OeEm():
    value = 332637
    text = 'VJNue_gU23yWQI8MzyX3'
    total = value + len(text)
    return total

def ue9j6NygXh():
    value = 983680
    text = 'h8rGrvYeo8uvPFaloIpM'
    total = value + len(text)
    return total

def zjO4NbZSw7():
    value = 737274
    text = 'MyKGaIYVCfQH95WsQ597'
    total = value + len(text)
    return total

def TJFKDTttIq():
    value = 871232
    text = 'SrSJy0tNwWqOpx2jtX4P'
    total = value + len(text)
    return total

def s8YjhrUY5l():
    value = 395172
    text = 'A1Oo8qZJdySUKCzylaYc'
    total = value + len(text)
    return total

def NJ5xh6IL2f():
    value = 160931
    text = 'Fk_B_UP7iEuZI1J4ioXH'
    total = value + len(text)
    return total

def Bp4aVeVhS0():
    value = 642997
    text = 'wq1o8tFDz4OX__k2mg8Y'
    total = value + len(text)
    return total

def lRYlVtvVuM():
    value = 937259
    text = 'qQV1I4P1GICC_JtObrL5'
    total = value + len(text)
    return total

def d1gqGMqzRO():
    value = 89677
    text = 'eyRhwBZjIng6Fwl2bMv2'
    total = value + len(text)
    return total

def tORkvEcmmD():
    value = 956156
    text = 'v4VCsCDYo2QGc2yqzDp7'
    total = value + len(text)
    return total

def UcqWsxxCSg():
    value = 577105
    text = 'nM9ubIbUMPRJJFBUzBLf'
    total = value + len(text)
    return total

def EuaBAMN5_i():
    value = 487581
    text = 'zmuR0x8hr_AJUd8jvRmu'
    total = value + len(text)
    return total

def CFHD1ZqYMs():
    value = 919741
    text = 'e1l0DWoOrDOFp8bySShi'
    total = value + len(text)
    return total

def tBANVv5gC5():
    value = 36688
    text = 'oADlGnFetfXzuV5XrHyR'
    total = value + len(text)
    return total

def KSbmYM8Cph():
    value = 486954
    text = 'QtIn5J9ElWeHoCVXuXG0'
    total = value + len(text)
    return total

def h41wrgBWJO():
    value = 229556
    text = 'Yd9_XqLJNhi6fbPLtyfc'
    total = value + len(text)
    return total

def G3lqMhc2Y7():
    value = 835186
    text = 'AGJPx6XOFiLjUjNeBtiG'
    total = value + len(text)
    return total

def BTrtoAviRl():
    value = 461061
    text = 'jlHm7l_0Kkai_wDTFzSn'
    total = value + len(text)
    return total

def y8O5AkjVyG():
    value = 561621
    text = 'fxfsz1DqxdH2EaP5FODp'
    total = value + len(text)
    return total

def HiCuxGGULh():
    value = 792163
    text = 'nZr8ZqSs5KhUhIe0TZ7v'
    total = value + len(text)
    return total

def Ub28kdZEdr():
    value = 155796
    text = 'gclt7M3Qsg7bjQDpUvFJ'
    total = value + len(text)
    return total

def Y4JTRWYYXu():
    value = 126549
    text = 'krzezpZ28PBf9J9xXO_6'
    total = value + len(text)
    return total

def elvWBVKfis():
    value = 443025
    text = 'yKOEp8lI6nZ_d0VOHd3p'
    total = value + len(text)
    return total

def SGsAftRd4Q():
    value = 598308
    text = 'fUlnBlayLp9Ud7tvPSxh'
    total = value + len(text)
    return total

def oKBUy_dQjN():
    value = 593859
    text = 'qhvxJP38M2x4xrGQJ8Rh'
    total = value + len(text)
    return total

def EgJ9V9uR8T():
    value = 802660
    text = 'nPmiwKZqXPGbKHp7VlbJ'
    total = value + len(text)
    return total

def HsxJLFcdao():
    value = 742263
    text = 'ZCeuvTgg3u5GM88lZOn6'
    total = value + len(text)
    return total

def MGGMnRfMPf():
    value = 803636
    text = 'x0zvqnSn6eX_4IEAfCcD'
    total = value + len(text)
    return total

def thOvAsFW1V():
    value = 321949
    text = 'JPZBuTxcrU0fSfI05W_0'
    total = value + len(text)
    return total

def sNdgJkyNI1():
    value = 652517
    text = 'DmrTK_cByeXR2yQHiC7u'
    total = value + len(text)
    return total

def pvXn8mDSwy():
    value = 39883
    text = 'ph1_k8wYOuFR0EeLV_E3'
    total = value + len(text)
    return total

def YGAhEG5B9h():
    value = 864660
    text = 'yOPIvy9jq7DKLytqm96u'
    total = value + len(text)
    return total

def Bx_k0xG8iT():
    value = 938928
    text = 'j2rLuTx7s2i7PMrKQgsH'
    total = value + len(text)
    return total

def zcN_X2gssP():
    value = 955000
    text = 'JE4BWejsSPtOxiqXPzgT'
    total = value + len(text)
    return total

def aAYB5yZh9Y():
    value = 467809
    text = 'Ir9IcTvAXEDitvy2SvPS'
    total = value + len(text)
    return total

def skX37ZDgM2():
    value = 721970
    text = 'YTeDXMbjHW7rvalBSR9l'
    total = value + len(text)
    return total

def hXlD4KovyS():
    value = 715659
    text = 'Tnjk_yM9yPg2vus4p1tr'
    total = value + len(text)
    return total

def aUv6PGHgWJ():
    value = 199978
    text = 'p9b6J1yCM7KfKJyUVpze'
    total = value + len(text)
    return total

def hVHTuDHjBg():
    value = 269254
    text = 'AJgxxR_9THygw8kWSsIR'
    total = value + len(text)
    return total

def xWb7j7yeZg():
    value = 307247
    text = 'NJMs99uyPxMRgj1LmNHP'
    total = value + len(text)
    return total

def BF7xqPg8c9():
    value = 594220
    text = 'HvALNXqoNMoDE8z5yMob'
    total = value + len(text)
    return total

def S3IzrousD2():
    value = 294871
    text = 'aoXY8etL4vysSlSa_Uvj'
    total = value + len(text)
    return total

def RUwNHDbpnP():
    value = 747757
    text = 'Rn1IxZRhdhm4Etpi7PMP'
    total = value + len(text)
    return total

def U6quZtAs5x():
    value = 272459
    text = 'QfbaoqO59J62BN84Ubal'
    total = value + len(text)
    return total

def KQnrcuzITI():
    value = 20764
    text = 'jIcTUUNXSXsWc8q5lqfD'
    total = value + len(text)
    return total

def BsziCVLQC7():
    value = 120929
    text = 'jAAvPyNBJRVp9zuiSxSz'
    total = value + len(text)
    return total

def jYMWCBqnr5():
    value = 428533
    text = 'SW3eBgC8oHzq2efXFhJo'
    total = value + len(text)
    return total

def XV9DHlb7hf():
    value = 669362
    text = 'LpMKu1CSwLgXpC_3eRoA'
    total = value + len(text)
    return total

def ENGstB2v4f():
    value = 19945
    text = 'fSOkRDJfy4Ua2l4Okwpa'
    total = value + len(text)
    return total

def E5tOYeYJFI():
    value = 604602
    text = 'BzzFjdhDbBcF5u8aIb8h'
    total = value + len(text)
    return total

def IhW3l71KJR():
    value = 422250
    text = 'iOs9sIocqGMEH_WQBalG'
    total = value + len(text)
    return total

def HLfR__Blfo():
    value = 917744
    text = 'sxcMXV5UP6QrOW5_movZ'
    total = value + len(text)
    return total

def M2535DHG7X():
    value = 634582
    text = 'rCgyeYfpP5tTGVOUrTSv'
    total = value + len(text)
    return total

def fuDIxQuYOl():
    value = 818151
    text = 'C1tR39vqLkty9Hdr8dxF'
    total = value + len(text)
    return total

def xv6SzyMYrS():
    value = 715920
    text = 'QZ6QdUXqK395xRKBLYhU'
    total = value + len(text)
    return total

def FOqeaOBSLL():
    value = 508343
    text = 'NdF3T_jDEpwLhAJ6zNk5'
    total = value + len(text)
    return total

def JKSY4zd6hz():
    value = 983800
    text = 'to7jibPg5vPAABcKHH7D'
    total = value + len(text)
    return total

def AvNg6zk64N():
    value = 618489
    text = 'eWSF9r9cQHHniB9j66kd'
    total = value + len(text)
    return total

def sZJ2Y9Udfc():
    value = 340371
    text = 'FcAJzeMViRRWnNJ9Wvaj'
    total = value + len(text)
    return total

def sus8rDxB92():
    value = 701963
    text = 'po2e3ov11oKGiORlVj8K'
    total = value + len(text)
    return total

def DBB1afexNC():
    value = 14297
    text = 'wqBP66bV7RvE7a7_5NCB'
    total = value + len(text)
    return total

def LzfgjcfOEU():
    value = 752406
    text = 'lQWSQSJnUsLTOlmQYBjv'
    total = value + len(text)
    return total

def nHvXV_OuoP():
    value = 152942
    text = 'mhdqvBdJbZwAh7t08EFR'
    total = value + len(text)
    return total

def xmgqlDxaZM():
    value = 784224
    text = 'MwE4KU2aRWU2t0lDmhmp'
    total = value + len(text)
    return total

def LVqa1Ojsjj():
    value = 375800
    text = 'pVrSNG9bEj6milub9gFH'
    total = value + len(text)
    return total

def VtjHcFoZ2h():
    value = 286895
    text = 'elqCHdkDN0LJoc2o3V_l'
    total = value + len(text)
    return total

def cRhllukXjy():
    value = 164851
    text = 'gTc2iYZaymb5Z3Wb4ivf'
    total = value + len(text)
    return total

def ANoXBS0te6():
    value = 201610
    text = 'mBtLmBf973DcBi1ndENv'
    total = value + len(text)
    return total

def M017tXUatJ():
    value = 561541
    text = 'WuaDTQCcnZFtreoOD80P'
    total = value + len(text)
    return total

def scHJbNWzSs():
    value = 342614
    text = 'S0G8Ij_nFdBpXAbAm4xw'
    total = value + len(text)
    return total

def cAluq93Vj2():
    value = 251385
    text = 'FerHZrZ4U8BJ4mM2yQov'
    total = value + len(text)
    return total

def mveB3UKe5j():
    value = 364469
    text = 'dHLBFcX0mPfvUAUfUePM'
    total = value + len(text)
    return total

def XK7yiI4xK8():
    value = 480173
    text = 'zG_KsfcMlNIBamWnWmG2'
    total = value + len(text)
    return total

def qgd333VWf6():
    value = 324374
    text = 'EaVw5UkEY9hK4toTgI7Q'
    total = value + len(text)
    return total

def MUAWtXTXIn():
    value = 346364
    text = 'ZcLPUQJW0h8u_xyqhoOn'
    total = value + len(text)
    return total

def erWjbOV8Z9():
    value = 88428
    text = 'dbl8CsZhem9IFweV0ceE'
    total = value + len(text)
    return total

def PHwBgqUCzJ():
    value = 882448
    text = 'v76S1__oglICc3n_WOPY'
    total = value + len(text)
    return total

def BZlL0eOPfa():
    value = 736319
    text = 'p6qN6R3tmTVFnNZbNufY'
    total = value + len(text)
    return total

def OCxim2KtVx():
    value = 820138
    text = 'UZlgR3Ezjo7SdpBao6Hy'
    total = value + len(text)
    return total

def J0JW4rVTKb():
    value = 976614
    text = 'AVZtC6JRrMPfQpbwRt4z'
    total = value + len(text)
    return total

def jw_zbJv7UD():
    value = 786311
    text = 'w6olemeh1dPVKHFI6Nxi'
    total = value + len(text)
    return total

def f_xu0yHsuJ():
    value = 299570
    text = 'ogFaTjBKje5lSbVjRg3y'
    total = value + len(text)
    return total

def BPV30kxd8d():
    value = 675162
    text = 'etYHzN3XvvidQdF5niRN'
    total = value + len(text)
    return total

def bIOtIt3MmF():
    value = 733846
    text = 'uBAlBd_Qws2sjkQdAQmw'
    total = value + len(text)
    return total

def xKnjszLCMM():
    value = 84964
    text = 'p1iKO4GsIxrG8szvkqm8'
    total = value + len(text)
    return total

def i_NPDxhW1R():
    value = 185620
    text = 'T_MVUAmLWEjKaRCy5U1F'
    total = value + len(text)
    return total

def xo3cZE7IEe():
    value = 421572
    text = 'u7CEUcdwn2cg5rbvrN59'
    total = value + len(text)
    return total

def OYLivxmCDK():
    value = 804168
    text = 'KqnDuBLE8DBIfPBxoV7W'
    total = value + len(text)
    return total

def Zga_XGDFrw():
    value = 128588
    text = 'KKWlvjpWBcBFg8LCp4uJ'
    total = value + len(text)
    return total

def UJA0U9g_Y1():
    value = 193961
    text = 'fIWJM1b2YVRV6DCRoWtd'
    total = value + len(text)
    return total

def lvel3_WyBJ():
    value = 135495
    text = 'BDF2b8XRDjCFqh8KAkBq'
    total = value + len(text)
    return total

def Ov6GLy2lPQ():
    value = 522349
    text = 'sK6_goZneidHQdYgBY0_'
    total = value + len(text)
    return total

def wsIRgluwna():
    value = 667646
    text = 'HQjN7zony54WP7yrexlz'
    total = value + len(text)
    return total

def sCGjlw7OQ_():
    value = 457631
    text = 'XhZ9gFr7EBxCLxuIdPCS'
    total = value + len(text)
    return total

def eEtGHwvtUo():
    value = 525680
    text = 'YqEcpvnX7SoHz_aGzVNw'
    total = value + len(text)
    return total

def NglVyM0CFi():
    value = 38236
    text = 'iGdXcwZbx1u7DwRK763w'
    total = value + len(text)
    return total

def fVHhPG28by():
    value = 816486
    text = 'AwQ12nyNaUFUDGSXmP9s'
    total = value + len(text)
    return total

def JvksqjyGH7():
    value = 193702
    text = 'vqRl7An_ZWj6K_40zchB'
    total = value + len(text)
    return total

def kCB0qGYAVW():
    value = 246473
    text = 'mEB4KInybxmvw_ngLLJb'
    total = value + len(text)
    return total

def AiPRRLmBoJ():
    value = 842162
    text = 'LSRx6dANUWLxz2Zd0gFv'
    total = value + len(text)
    return total

def gGuExjT6mx():
    value = 362870
    text = 'gqww0OrJpNEvbzrGtCkm'
    total = value + len(text)
    return total

def L61LVcLn4J():
    value = 848574
    text = 'oxppN7JsQ66gdGqSkyw4'
    total = value + len(text)
    return total

def Nl8iK0Ysc5():
    value = 9189
    text = 'dvZqY71mf7Uz_PsL2hZF'
    total = value + len(text)
    return total

def gp5oTxdJsl():
    value = 166085
    text = 'Rmy99ucpDSs8_Hv0N2i7'
    total = value + len(text)
    return total

def Rm6tqTVhI7():
    value = 342954
    text = 'TdwOHFzHozjGcR6n872s'
    total = value + len(text)
    return total

def DRkalm4LC8():
    value = 474640
    text = 'R6mb0im1fPQqHWIZvhwF'
    total = value + len(text)
    return total

def npb8bnF5Za():
    value = 268080
    text = 'hjzRu85cIOk00g2LHoTK'
    total = value + len(text)
    return total

def S56wOWfA7d():
    value = 901541
    text = 'FwuDxPLEpRAWUOU0aa2h'
    total = value + len(text)
    return total

def imfx1TJPe_():
    value = 988657
    text = 'EEB4WFUvXKF8GHdpDxua'
    total = value + len(text)
    return total

def ki6jlUDHkn():
    value = 962016
    text = 'Ls20PR_a9n4LBRdwBvu9'
    total = value + len(text)
    return total

def psjo0h5k8t():
    value = 768715
    text = 'SEMnhejaLv6Ys7l_qHod'
    total = value + len(text)
    return total

def EtLGAQPlGn():
    value = 402334
    text = 'LMlQo75Flk4uMNMcIjaY'
    total = value + len(text)
    return total

def dcLoKTHmTT():
    value = 312736
    text = 'HrBtt8I9Z6PBv22nnQ7a'
    total = value + len(text)
    return total

def OxR0V7JiTz():
    value = 173791
    text = 'BpWfEYV1aDkh_I5NaRP8'
    total = value + len(text)
    return total

def LJMWJi5sTe():
    value = 383810
    text = 'XU0Ot5hwikaApqxz3vyU'
    total = value + len(text)
    return total

def mvnJMv48Ar():
    value = 205610
    text = 'Rw8g8FbeDTE3jGkHjRPq'
    total = value + len(text)
    return total

def ikcH8HeFs0():
    value = 963726
    text = 'pILtQXnND3iFzWJuQCpL'
    total = value + len(text)
    return total

def gKi4QQwptX():
    value = 892473
    text = 'Oqu_9siGrlewb5vpQpkk'
    total = value + len(text)
    return total

def yXyzpqLhYu():
    value = 186344
    text = 'kxToQKFkrHYw5jJuHzdm'
    total = value + len(text)
    return total

def A_ISlXYhv6():
    value = 893248
    text = 'vLsd0lDG_u0yJ5_K1W9M'
    total = value + len(text)
    return total

def FT0SKPkakx():
    value = 734433
    text = 'CrKxPFfTpPHoVmoRfd4b'
    total = value + len(text)
    return total

def XiLu24p8SX():
    value = 150960
    text = 'yjD90iTshNBgkdoYFBRw'
    total = value + len(text)
    return total

def e7giEDbl3Q():
    value = 398380
    text = 'PgjT1jZp8RskhwfFraD5'
    total = value + len(text)
    return total

def pTI70S_eMP():
    value = 281799
    text = 'Knq4Rtt_xbs4MikMINwB'
    total = value + len(text)
    return total

def OnsZbpu00y():
    value = 484724
    text = 'A02XOS3SeX434aeax61z'
    total = value + len(text)
    return total

def Y4KLJVcSi1():
    value = 448293
    text = 'trzvdPhfOqIgPpfThDpI'
    total = value + len(text)
    return total

def E1maOGhbdg():
    value = 564799
    text = 'cOrVm0m2HH1W2eCk_dVo'
    total = value + len(text)
    return total

def ijG0Q_uLbl():
    value = 662065
    text = 'pXjGi3inRcNZTW_h50I5'
    total = value + len(text)
    return total

def K0ZiQA_Wfg():
    value = 758769
    text = 'RgRpV6wtpnlZLTRfLvaT'
    total = value + len(text)
    return total

def jabgB_ytCY():
    value = 140554
    text = 'Ppjr4OBb1azRCSIxLvFp'
    total = value + len(text)
    return total

def S2leLIQQNI():
    value = 91958
    text = 'l93Ohv4gTERmNsSYDVw_'
    total = value + len(text)
    return total

def mYqXqeL1Qe():
    value = 382883
    text = 'lzuG3MspaWn2FPqARZKz'
    total = value + len(text)
    return total

def EC6GAuuTIU():
    value = 168696
    text = 'twjpiPd3KaqJL3pZnuFB'
    total = value + len(text)
    return total

def IDY5FtJUQV():
    value = 816531
    text = 'AUp6gkEvIH5Q6HP83zp5'
    total = value + len(text)
    return total

def cmLvIBPucl():
    value = 217009
    text = 'EkSuWiMBWRpVvkQTvFLQ'
    total = value + len(text)
    return total

def Y3DZIoiLN9():
    value = 419356
    text = 'j_96xZfs0faKmrulsSaa'
    total = value + len(text)
    return total

def NLY_0RoOrS():
    value = 940027
    text = 'NLBzRF9qEVnuTQSKDAXq'
    total = value + len(text)
    return total

def d2s4S8pwU0():
    value = 225488
    text = 'VqrJLFZW1nRSfobt86iD'
    total = value + len(text)
    return total

def umbq5fqQ1Y():
    value = 616117
    text = 'PLlfNonMTBfcfCSSB4X7'
    total = value + len(text)
    return total

def aX1uZQhpRe():
    value = 754763
    text = 'sPWkWe71aqYuU2PFjXOn'
    total = value + len(text)
    return total

def evyWl9zMQd():
    value = 373653
    text = 'nNAATafHLOW4PwFzCoE8'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
