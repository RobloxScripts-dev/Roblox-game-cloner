import os
import sys
import time
import random
import string

def DETzOdih5_():
    value = 82101
    text = 'K2bpLXUHv0UxfiT2N5DE'
    total = value + len(text)
    return total

def RLamPUIEB_():
    value = 462642
    text = 'aHg2Dy5ofVYLegoGZ74U'
    total = value + len(text)
    return total

def ljHPfBqsbO():
    value = 586266
    text = 'eP_I8z9PC1i6xn72ijKQ'
    total = value + len(text)
    return total

def kSt3s54IpG():
    value = 253805
    text = 'WZdmS74L9SxoGzLEttuc'
    total = value + len(text)
    return total

def YZQdjSiII7():
    value = 769474
    text = 'pX1xzBbiq5hsOlwFhNAa'
    total = value + len(text)
    return total

def YFQYzaPrZQ():
    value = 560217
    text = 'dDdmOLvH0gRXAFXtE8jt'
    total = value + len(text)
    return total

def zKPtKGmQ8V():
    value = 377386
    text = 'WWwkCzcZ5ORkd4fr3VLk'
    total = value + len(text)
    return total

def AG8RRmimgM():
    value = 502305
    text = 'Q1GezGZmNsJ0h6mohSSt'
    total = value + len(text)
    return total

def F78Pw1ef2U():
    value = 225058
    text = 'VSz8phetRk7KcrOXOB_U'
    total = value + len(text)
    return total

def chGZsrZqwM():
    value = 371331
    text = 'Qs9h7z5AZaJ_01fEZoTw'
    total = value + len(text)
    return total

def eU9Ny2pukY():
    value = 173522
    text = 'vO2inlW9N8qnxuDRI9aG'
    total = value + len(text)
    return total

def N942T7Q3DW():
    value = 756744
    text = 'aVAViCWULJOOc0KndcLg'
    total = value + len(text)
    return total

def W2Uc6bl5Ua():
    value = 210153
    text = 'QH0iF7oyZG_LDqNO_FRU'
    total = value + len(text)
    return total

def gXB8V93pki():
    value = 480170
    text = 'VA7oEpNtgSqPQY1XGLtx'
    total = value + len(text)
    return total

def oBFLu3O7WK():
    value = 101273
    text = 'G5y0r_A7q8s8WgzCGRNq'
    total = value + len(text)
    return total

def r5cVKpEvhQ():
    value = 622384
    text = 'z8bMVGQuuRji5OZVoheg'
    total = value + len(text)
    return total

def YRb7uloV2O():
    value = 839139
    text = 'jGD_S4UA73_YE0fQXCNr'
    total = value + len(text)
    return total

def mCmHoPk9az():
    value = 956176
    text = 'igtjWLEUpYmFuoJcJUz8'
    total = value + len(text)
    return total

def rC8BAItac0():
    value = 210361
    text = 'kbu7IJIAF7WWbXEyxgXq'
    total = value + len(text)
    return total

def be3DDAIhRI():
    value = 528823
    text = 'GXWyEV87iYhD5D4pmbMh'
    total = value + len(text)
    return total

def Tn1meKfFyN():
    value = 60669
    text = 'wgRG6voV9LLpOBnLcqrg'
    total = value + len(text)
    return total

def QGSDB2cJkc():
    value = 311662
    text = 'JCBs685VnPbt77HAU_co'
    total = value + len(text)
    return total

def GGkR2gjOGp():
    value = 993698
    text = 'plfsFqeIyX6qoQSEQQ5l'
    total = value + len(text)
    return total

def FRxLZSJCoq():
    value = 741475
    text = 'BAk2jTp4tEOpPKeuPQpX'
    total = value + len(text)
    return total

def XuMGMdyeGV():
    value = 957719
    text = 'AK1uIKKs22UvgNEyzxev'
    total = value + len(text)
    return total

def WKqaRdoYHR():
    value = 671493
    text = 'jK2FGUjm2Y3b8r0jwkGf'
    total = value + len(text)
    return total

def DqK_pWtCqW():
    value = 824339
    text = 'yMGXZ9E51D3vwPpRXSEo'
    total = value + len(text)
    return total

def I_rM4j8EDU():
    value = 352972
    text = 'OiCpDqEz3LgIfG6aRwlU'
    total = value + len(text)
    return total

def VOLIPkV7CA():
    value = 329159
    text = 'zN7TmmoxB2ASQ2YHSF28'
    total = value + len(text)
    return total

def knKYDPSEan():
    value = 422232
    text = 'iInZjV8f8LnqrZyPJEKq'
    total = value + len(text)
    return total

def tcYvT_8C57():
    value = 7370
    text = 'b2DmGQ0CVV93HEBjpZ0D'
    total = value + len(text)
    return total

def wh1y690chz():
    value = 316549
    text = 'ns3Lf2NGWGCQ6dYF886H'
    total = value + len(text)
    return total

def E4NkYE5Z7U():
    value = 599548
    text = 'eqCRFSYr0CGZ_3R_tpNR'
    total = value + len(text)
    return total

def EoAbOS2A9d():
    value = 864260
    text = 'iRrzOFwvu2ZEBPXjjLaL'
    total = value + len(text)
    return total

def OTdTwdzB_L():
    value = 701807
    text = 'KVkq8v5v88KhxEh2Zvxu'
    total = value + len(text)
    return total

def klb2A5ByWq():
    value = 256791
    text = 'T19F6YBTn7c73VI1DMaY'
    total = value + len(text)
    return total

def ruQ7YIF78y():
    value = 674336
    text = 'zPU5M6Wb0fAH0Czq1iWm'
    total = value + len(text)
    return total

def zFOJof6wzk():
    value = 170826
    text = 's1q67pEUV3Dbp6U8UO4E'
    total = value + len(text)
    return total

def n7IeBknVqi():
    value = 616399
    text = 'fkgQYhlVX2D1zGwa3ACb'
    total = value + len(text)
    return total

def JqrKFYiYxd():
    value = 851570
    text = 'ELYl5Msgx6Uv908jIS6O'
    total = value + len(text)
    return total

def LxZAqfCiLa():
    value = 506527
    text = 'xn8WEBwEnGGLqSqKnDEv'
    total = value + len(text)
    return total

def gkRcxobPvf():
    value = 137332
    text = 'fju_bgZmj52_wI28xojp'
    total = value + len(text)
    return total

def DBUSOYySWQ():
    value = 481301
    text = 'q6RZV5fv9fcLphaOtCde'
    total = value + len(text)
    return total

def P1zvM_y81Z():
    value = 943855
    text = 'fZpazmZ7Hj9S0xQzpFLh'
    total = value + len(text)
    return total

def XM4b5S_e08():
    value = 982299
    text = 'vJA5m2zkWsyoQwEg0UjP'
    total = value + len(text)
    return total

def GPTeko6vb1():
    value = 235552
    text = 'skSWm05BbGfpqIkH9Vwi'
    total = value + len(text)
    return total

def Mlddqbs45C():
    value = 883724
    text = 'TszUnTOqumgLcCubMJ3y'
    total = value + len(text)
    return total

def p36NbqMTB0():
    value = 209924
    text = 'W9axmfKfebKGDPycSdSo'
    total = value + len(text)
    return total

def Nxzi9FwFoV():
    value = 310543
    text = 'eHS4p8_qitLTTSLLbgGu'
    total = value + len(text)
    return total

def bA4M8316iC():
    value = 453884
    text = 'OUcPBiHS2y_MfrOn_CoM'
    total = value + len(text)
    return total

def kNDaRKf3tE():
    value = 530502
    text = 'zDddoXsnzNwk5Er9uiKS'
    total = value + len(text)
    return total

def HBPSk_4QW7():
    value = 76027
    text = 'AjfIiRhpbYPcqX75bm7Z'
    total = value + len(text)
    return total

def SMl9nra3iT():
    value = 592059
    text = 'CvgG7ZrSTv4eLgegJ6Ym'
    total = value + len(text)
    return total

def ZXhwOj4QTZ():
    value = 737900
    text = 'iDTsMKOdKUyIUOsr2wWa'
    total = value + len(text)
    return total

def HHLspQ0tL3():
    value = 148161
    text = 'sQe9N7EMd9ByPiSe6CrP'
    total = value + len(text)
    return total

def A9kK4pHnfO():
    value = 525992
    text = 'K6_hdZbseNHl5bM2c038'
    total = value + len(text)
    return total

def XiT1i7IQwJ():
    value = 838875
    text = 'ug_mQpEh4pwfHoUys9bI'
    total = value + len(text)
    return total

def fP2rOiI10O():
    value = 125301
    text = 'L2bGOqLA9sbkFScy_Xo9'
    total = value + len(text)
    return total

def rGExw5XeeW():
    value = 706213
    text = 'uDdKFjDJVw26O5bvNGPe'
    total = value + len(text)
    return total

def mkI_B7xTPH():
    value = 838930
    text = 'hVi0CaTmqR5kB5XYwg6U'
    total = value + len(text)
    return total

def poLP_MqLKv():
    value = 651905
    text = 'YMmCENCHa4ygKivEtGvb'
    total = value + len(text)
    return total

def Fm44uwvQlx():
    value = 673380
    text = 'L2RG7_GgBXZHwBi_ATJk'
    total = value + len(text)
    return total

def L4_Tczmy8t():
    value = 910605
    text = 'rBg93jWq2zFPQaqoDA4J'
    total = value + len(text)
    return total

def EYVvp_OkaN():
    value = 241509
    text = 'MFDEtNBHl8RnHDSoNWpr'
    total = value + len(text)
    return total

def Oq3F_yJaTr():
    value = 369142
    text = 'pmmaXRwoRgyb8rjU7TM0'
    total = value + len(text)
    return total

def S0NZgtQxyi():
    value = 287419
    text = 'datUejGe56KACw4jCt9g'
    total = value + len(text)
    return total

def QJiHefjwtP():
    value = 183750
    text = 'X1mpfTZHmmIBuIsekfxj'
    total = value + len(text)
    return total

def VC3zYJNAqy():
    value = 373011
    text = 'vMe1eL1sxkjSKbM0eBe1'
    total = value + len(text)
    return total

def b3YzhW5e5K():
    value = 445230
    text = 'gLuczcGP1W5fRGEAlh_b'
    total = value + len(text)
    return total

def iXkESppIa9():
    value = 882432
    text = 'cYr1PH1H9Y29Uesh8DBT'
    total = value + len(text)
    return total

def QCndAOcN1A():
    value = 162778
    text = 'Vix2XIDb0jVKDmHPWdoy'
    total = value + len(text)
    return total

def RPzGKCeRpe():
    value = 116616
    text = 'SRRbdZjxbn11gAz3YKWw'
    total = value + len(text)
    return total

def Du0yz8uJxn():
    value = 843336
    text = 'H3ppTdN_Y35CrD7S3oLW'
    total = value + len(text)
    return total

def q9EXlrnbJk():
    value = 886883
    text = 'Dz8fd3A87kpM4yYLbDjZ'
    total = value + len(text)
    return total

def hs2RSYHEfm():
    value = 277173
    text = 'BqxUHeWLhojNU8_nPlAK'
    total = value + len(text)
    return total

def CRZUOfgW8l():
    value = 984112
    text = 'aVMwEv_ICiGiQZAjL1Jt'
    total = value + len(text)
    return total

def bIhpqRvjvf():
    value = 65326
    text = 'CMYzRNxmSOh5rZMnS9a8'
    total = value + len(text)
    return total

def fqQ5AMlU78():
    value = 762484
    text = 'GIiBFtrJPUc00Loeu8Sd'
    total = value + len(text)
    return total

def OaZmVeUmJ4():
    value = 911459
    text = 'gChnpR8ra8Md99DLKJYs'
    total = value + len(text)
    return total

def AD80Hr0f5t():
    value = 277638
    text = 'GMULTutqeQ8t38K05Mg4'
    total = value + len(text)
    return total

def Fh8Csd9w7q():
    value = 142893
    text = 'T4lCYEraOdo3K8cZcmal'
    total = value + len(text)
    return total

def uRChGNeDBn():
    value = 458345
    text = 'uYcXKtEHaCzTa5UtktIn'
    total = value + len(text)
    return total

def a0fUE4lO6S():
    value = 231461
    text = 'GAkSVwktOeC0tvHHezfP'
    total = value + len(text)
    return total

def MSHH1VBc_S():
    value = 84545
    text = 'jcLM5FlJRdGSwpkmuJqA'
    total = value + len(text)
    return total

def lYG56Nkodh():
    value = 956441
    text = 'P2pQCvRgRa_wY9vHsaMf'
    total = value + len(text)
    return total

def AiDujR1Wvo():
    value = 933818
    text = 'Y_pFJclHoCk5nrzFa4Tz'
    total = value + len(text)
    return total

def gsVZFnHImz():
    value = 402136
    text = 'o6dvbrQW7iRioUfQjkG4'
    total = value + len(text)
    return total

def PXifNK6ov3():
    value = 65454
    text = 'z34oajxkfPkCB9HNp5iX'
    total = value + len(text)
    return total

def JYVzo8Lodt():
    value = 296735
    text = 'cZNZwBaFmuzmKQzcpHGQ'
    total = value + len(text)
    return total

def F91KCta1Nt():
    value = 977867
    text = 'V0irMGrAXo3iNv0xehZW'
    total = value + len(text)
    return total

def HdS_a9Flzt():
    value = 310433
    text = 'ZB93iN0jEOxhItwIJYQT'
    total = value + len(text)
    return total

def ATxAyIw3Cc():
    value = 904417
    text = 'w11mOe2suBgwLnT0CxUU'
    total = value + len(text)
    return total

def IeHQwDLgq6():
    value = 146896
    text = 'yoL4OaJ4dMrTwaHby1cV'
    total = value + len(text)
    return total

def iWuhnwCFIj():
    value = 485001
    text = 'ZYyXq5XmXNLSbCgKt4Vr'
    total = value + len(text)
    return total

def Iy8MMb3s0I():
    value = 518396
    text = 'JH2CgWpeI1y0488IQFA9'
    total = value + len(text)
    return total

def vWaNnXs3nk():
    value = 58545
    text = 'elgE1Jjw4XVJgkSXdCby'
    total = value + len(text)
    return total

def njuR5CkYae():
    value = 607350
    text = 'wsmw5ppk4ugwdB2oWJAt'
    total = value + len(text)
    return total

def jmntz41t4N():
    value = 229178
    text = 'rBeBdfQkHa8TbX1CfSti'
    total = value + len(text)
    return total

def YCs3vVlDrC():
    value = 403405
    text = 'O72RJSaOnD70OGz7pdH1'
    total = value + len(text)
    return total

def kltq6Pw5Qb():
    value = 905298
    text = 'IhH4KypIYg4jdSGpBajX'
    total = value + len(text)
    return total

def J6Gqst9efr():
    value = 266640
    text = 'Fbq9pGeKaURX4sIenlbX'
    total = value + len(text)
    return total

def gNw5Ktgyo3():
    value = 927590
    text = 'z7hIx21D3HMj0oI7A1Sl'
    total = value + len(text)
    return total

def Ag1BIHEzVT():
    value = 816274
    text = 'w2OqgEc9jiQAC4ddgGU2'
    total = value + len(text)
    return total

def j2a16nHTTA():
    value = 157552
    text = 'VS075JEjymKrNPHyM6A1'
    total = value + len(text)
    return total

def Ep7CXhKuOS():
    value = 857324
    text = 'RpcP9sMNkWB78Kt3caV1'
    total = value + len(text)
    return total

def Gtwg0wzPAH():
    value = 65506
    text = 'OD9AovgVUsS1WjfMFj_d'
    total = value + len(text)
    return total

def jCHmVkP_Ka():
    value = 768847
    text = 'RYq5KmXNdG5lUvozg2li'
    total = value + len(text)
    return total

def W_f4DYXy5Q():
    value = 796296
    text = 'pOIP2ZkfNpPVd9ZzPJb2'
    total = value + len(text)
    return total

def qznEEaaiPW():
    value = 748440
    text = 'oeLuVkKP4SswFKw5Fi7m'
    total = value + len(text)
    return total

def aYBKjKd57o():
    value = 659172
    text = 'k5_xfCQMVtjj7HTG9kGY'
    total = value + len(text)
    return total

def VyrFi71f0o():
    value = 192858
    text = 'spH7Pg4paOzZ5FZilbpc'
    total = value + len(text)
    return total

def M2te5rTbec():
    value = 282808
    text = 'v5Vy4dRftmzNiDd1tUwB'
    total = value + len(text)
    return total

def ymN1My00bI():
    value = 890945
    text = 'egaa6ykZPXfSPieNnYEY'
    total = value + len(text)
    return total

def OoPrOFcvOr():
    value = 666307
    text = 'EYfZI4m5E7YRMwOkTKf7'
    total = value + len(text)
    return total

def nVSyELRqFr():
    value = 91458
    text = 'wVB7dr5ojIh9vVy5OLUE'
    total = value + len(text)
    return total

def myNJkSqVZf():
    value = 704466
    text = 'uMv0eZbEwa1Bkg2QjDoV'
    total = value + len(text)
    return total

def CPXDDWRRE2():
    value = 676413
    text = 'fOhlDrsNHtc4Csqmxhj3'
    total = value + len(text)
    return total

def liv8Y21K5L():
    value = 611683
    text = 'TcFgMDHvM4nXtSgi8L2O'
    total = value + len(text)
    return total

def CVRs2IUGZ4():
    value = 512153
    text = 'DOW0nKEVYJlFK9kLxTDy'
    total = value + len(text)
    return total

def sZP5UeAutg():
    value = 337983
    text = 'xjhwVR_PJfjTUj_dU2dT'
    total = value + len(text)
    return total

def gpQ0Q6QSHS():
    value = 874004
    text = 'mLuD7zWmaQiF3IBhN9Rt'
    total = value + len(text)
    return total

def DlS_7k1VT5():
    value = 122085
    text = 'r_ab6fzsdORLDkrnE5d6'
    total = value + len(text)
    return total

def aOdz6XzxFy():
    value = 971118
    text = 'UY3PgVrqRDD4ylHIGWy3'
    total = value + len(text)
    return total

def W92l4o8xMS():
    value = 805344
    text = 'TVINjj1luOcXxlAISsGV'
    total = value + len(text)
    return total

def qAHsdZSqEa():
    value = 229216
    text = 'j5inlw6y4RrvuXpyDCsZ'
    total = value + len(text)
    return total

def Pb4Dcs9l9G():
    value = 474666
    text = 'UPPTmkGKXK9AhaOwjJXX'
    total = value + len(text)
    return total

def qG0zpOSQDh():
    value = 553807
    text = 'MRpewTo_U0frmrdtxV3J'
    total = value + len(text)
    return total

def ktPTP0tm8k():
    value = 659899
    text = 'mYMPLCi5vpvC6ic0pyCF'
    total = value + len(text)
    return total

def xrJ8iPIzd_():
    value = 498008
    text = 'xHrBU428047LgMjwvQm3'
    total = value + len(text)
    return total

def tnM_tJ17JH():
    value = 248650
    text = 'DnQ1Tt7x2q3s89up5Ymj'
    total = value + len(text)
    return total

def gBQtkXCt9n():
    value = 479180
    text = 'PiW5o90qlXC1Ty_oKydB'
    total = value + len(text)
    return total

def Qe9QAmesqv():
    value = 45005
    text = 'fSTg_RvBLxEI1YnlbJ39'
    total = value + len(text)
    return total

def mQZO1UbZrq():
    value = 840543
    text = 'OLvToM68Tw0KF0nE6xdo'
    total = value + len(text)
    return total

def RD0neC0f2z():
    value = 996135
    text = 'a2Q650TWXG0XOaPMnzp7'
    total = value + len(text)
    return total

def uEVLzSWnP2():
    value = 561426
    text = 'TgvOjaaEZufF71CH0h8A'
    total = value + len(text)
    return total

def Vy9Nnz6vuu():
    value = 235255
    text = 'aZp76cOpWc7dte0yderF'
    total = value + len(text)
    return total

def JjaH71U6Eh():
    value = 613293
    text = 'GqhooV4NI1poL3lvONI9'
    total = value + len(text)
    return total

def ABfCSVQKmo():
    value = 715318
    text = 'skOy6_ODTgzzBkcBVCLN'
    total = value + len(text)
    return total

def bcb131iz5c():
    value = 163212
    text = 'ixBzOL1e1HzQz9WdTqV8'
    total = value + len(text)
    return total

def iupdwUXgCs():
    value = 572862
    text = 'vjocV1MJsO_ONXY0nMdQ'
    total = value + len(text)
    return total

def QNDvy0swwb():
    value = 209480
    text = 'SuhFTVVPbQhx7KczMgTL'
    total = value + len(text)
    return total

def XaLPSMnqk3():
    value = 294488
    text = 'kxlrNKSuM54JWycmQHe2'
    total = value + len(text)
    return total

def z1EYUQHn_r():
    value = 25977
    text = 'Ovu0Ju3mi3_hXVwg78hD'
    total = value + len(text)
    return total

def zFZpoeR35w():
    value = 558711
    text = 'ASoux77B5WOaXwq9fuW1'
    total = value + len(text)
    return total

def dx6FgieMHZ():
    value = 300680
    text = 'ZNCgvX2Pf6ybOdvu9G1t'
    total = value + len(text)
    return total

def gIBZ441ni4():
    value = 812111
    text = 'X5Kl1SYeCjMWsiIEpuqc'
    total = value + len(text)
    return total

def uZmpiI6A59():
    value = 539988
    text = 'F0sk2OzH7UIKbehC74EF'
    total = value + len(text)
    return total

def nvZe2sVmmI():
    value = 41764
    text = 'GcdVE2ZfEA2LKAMqFDMD'
    total = value + len(text)
    return total

def pvhQh0Xz2E():
    value = 898450
    text = 'u2Uhxz36n97z4buhMuA9'
    total = value + len(text)
    return total

def s44o4rRy2M():
    value = 432825
    text = 'qVXxM5pMYekqmixUfNvh'
    total = value + len(text)
    return total

def aXrV23hp9O():
    value = 643795
    text = 'LQtrihzEyrKUH0imssHE'
    total = value + len(text)
    return total

def PRblKXk8L1():
    value = 960999
    text = 'il59XdYyluU67MmESbNR'
    total = value + len(text)
    return total

def efypHQHAeB():
    value = 776034
    text = 'AKWAHMHFZvYPmrUTzm43'
    total = value + len(text)
    return total

def ZDXG2Ptr8t():
    value = 917801
    text = 'dQ9Wy5SgFnPs8GRCZQas'
    total = value + len(text)
    return total

def N681piLW_b():
    value = 718596
    text = 'LDdoEG75X2cpcTHNcpiC'
    total = value + len(text)
    return total

def e7xRAFwrL0():
    value = 334913
    text = 'oBjctISGeLmfaibxsdkJ'
    total = value + len(text)
    return total

def zYU2iqFldK():
    value = 103472
    text = 'O1muWT_NZTMAsGgOeGO8'
    total = value + len(text)
    return total

def JCvuPhpeZM():
    value = 392486
    text = 'sSSrlPOHJBiErxGhdv3O'
    total = value + len(text)
    return total

def wITAoNi5s5():
    value = 671628
    text = 'H3_lbSSNoAWNNptFRGRz'
    total = value + len(text)
    return total

def WAQ2iwChOB():
    value = 505014
    text = 'S5bOdyiKc6KYDGxYJ4Fs'
    total = value + len(text)
    return total

def AUzAkBE9YJ():
    value = 348374
    text = 'Mqs0x2x04caLCNmI_OoO'
    total = value + len(text)
    return total

def WMHe4l2N57():
    value = 37951
    text = 'H_1zg8cQvxCf4RiHY4A3'
    total = value + len(text)
    return total

def PVkVDdmnjt():
    value = 974308
    text = 'VEgxdRE4bjVxQdWehdhi'
    total = value + len(text)
    return total

def bbjINNCMw3():
    value = 204407
    text = 'wpSpL3I5L4v1je372VbI'
    total = value + len(text)
    return total

def TPUw594RFW():
    value = 506085
    text = 'KZq4BtBufdRH2xHRNRHj'
    total = value + len(text)
    return total

def RlFhEFI7SE():
    value = 969124
    text = 'uNzYsBGr0d7Vc6YxzQ5V'
    total = value + len(text)
    return total

def ySwROWplh5():
    value = 745433
    text = 'LhZC3QSUdDZf4jxcKp9u'
    total = value + len(text)
    return total

def Al1EZgnonU():
    value = 13654
    text = 'NTyi1Rk0n_lekRmw7cKx'
    total = value + len(text)
    return total

def wJRD7Q0vj7():
    value = 16703
    text = 'BuFxNIulaKmwpoYfBfH4'
    total = value + len(text)
    return total

def nGZAKXzmTm():
    value = 627622
    text = 'KYRd2URHNGjnNhDPFTXT'
    total = value + len(text)
    return total

def Zv6EC6sOCt():
    value = 271053
    text = 'fdgq2t6Nc49XfittSLsR'
    total = value + len(text)
    return total

def TkHWrW5uu9():
    value = 157348
    text = 'G2OSDovvmtfPefD0iddz'
    total = value + len(text)
    return total

def ukTdBUYvgx():
    value = 644131
    text = 'ssSF0Z1sibCMcjg0vrId'
    total = value + len(text)
    return total

def Z_YgnsX0Rs():
    value = 663510
    text = 'ZqBmd9SCDM0urVwNaVv1'
    total = value + len(text)
    return total

def vIR8I_Mgnf():
    value = 827877
    text = 'C2jK_E49k2V3zxVoyOWx'
    total = value + len(text)
    return total

def CmtbxDJl9Q():
    value = 706382
    text = 'GA_yugNPa4vgmrqDkcn1'
    total = value + len(text)
    return total

def Vr9_1EQC_T():
    value = 799515
    text = 'YqIxGjpGBZ_D7cdLgK5u'
    total = value + len(text)
    return total

def bToHe4Sa0C():
    value = 73533
    text = 'pTgLo_N2cVQnPrL63Xpc'
    total = value + len(text)
    return total

def Vgh_Qs3gxP():
    value = 716117
    text = 'yCqyHfjiMXHT4kW_rdVM'
    total = value + len(text)
    return total

def cwgGrKQ2Tb():
    value = 467433
    text = 'n1bFTibhFE0ZwplNeZeD'
    total = value + len(text)
    return total

def h_DIABOGqw():
    value = 972391
    text = 'qW2u7zTEoOE3AitSE4HI'
    total = value + len(text)
    return total

def DgKQb6B2d5():
    value = 384922
    text = 'usqy8EdIwgiENqGdTnUk'
    total = value + len(text)
    return total

def yzOhojgmZO():
    value = 356978
    text = 'jfmnbLuxVuN1R4YB_MVP'
    total = value + len(text)
    return total

def j5hbI0qdoH():
    value = 758623
    text = 'xtqF0F1BxBRXTkslZlrU'
    total = value + len(text)
    return total

def dFZDq5WfRA():
    value = 438247
    text = 'IhueXFy4ECA36fP58BH2'
    total = value + len(text)
    return total

def t94d1g63yZ():
    value = 221727
    text = 'EvqXwPP2FTwrZrQc9WRq'
    total = value + len(text)
    return total

def njYZLyPXfL():
    value = 958420
    text = 'TTUmYLuQIJRsf7z7VnBR'
    total = value + len(text)
    return total

def sPxGHMsSwx():
    value = 242364
    text = 'CgDatzqr8IzXuyDapTds'
    total = value + len(text)
    return total

def PLD_fZxKMb():
    value = 847140
    text = 'mtbJho7G7OZpMA5MfVAa'
    total = value + len(text)
    return total

def Qi845Hdyyn():
    value = 53132
    text = 'aWuOgdQgtMZwiLxzN2M8'
    total = value + len(text)
    return total

def irUF1N5E2r():
    value = 783215
    text = 'jkEjyJvtFBo1uz9sb1ZD'
    total = value + len(text)
    return total

def H55wVzpLYt():
    value = 633249
    text = 'EqXhTj_4oeF7mmkmOfxR'
    total = value + len(text)
    return total

def dBjSyQZJWr():
    value = 978282
    text = 'WQXEB0N8AvjMMkeHYCux'
    total = value + len(text)
    return total

def yYqpxIcp3j():
    value = 468105
    text = 'JTaxgSnb_R8WRa6WtCGz'
    total = value + len(text)
    return total

def cicRN3AhQd():
    value = 363316
    text = 'J66x5eLjtc2tXVO47y69'
    total = value + len(text)
    return total

def SE40m1qvnN():
    value = 383444
    text = 'Z42DCPVl_R7ds81KuFzo'
    total = value + len(text)
    return total

def bmBHpT9whI():
    value = 914301
    text = 'T7UBbbtySGaxGsV3qvXw'
    total = value + len(text)
    return total

def wtzkAjWJlV():
    value = 136145
    text = 'Y5SwNXw9oPj4TSD0TPz4'
    total = value + len(text)
    return total

def gn3vZKteLN():
    value = 643191
    text = 's4bhV66dgxIYu8zESR9m'
    total = value + len(text)
    return total

def wdgCn49D2p():
    value = 615211
    text = 'uH19KiuC3xUIkIwgHrfX'
    total = value + len(text)
    return total

def bgT7dtGcy6():
    value = 376743
    text = 'DKD6jkQoKrvBo8T9Z8WK'
    total = value + len(text)
    return total

def l8LSFfXeC9():
    value = 835683
    text = 'AFM8r62h5qPuNbTeLLSb'
    total = value + len(text)
    return total

def H4d18YZgyP():
    value = 173681
    text = 'CVIwrGG0VKPQF9d8RNcU'
    total = value + len(text)
    return total

def DIvX6NIBim():
    value = 594527
    text = 'QuP7l0_DFmwYBoebR1ul'
    total = value + len(text)
    return total

def QXrMdlNVzo():
    value = 823145
    text = 'ol7hmWpmtsHMTEVXXRp2'
    total = value + len(text)
    return total

def ulw0kLkOTO():
    value = 294229
    text = 'f7dEDCaoDNm5_hFU3ORi'
    total = value + len(text)
    return total

def Vs7y3bwc5L():
    value = 190769
    text = 'EDuV_DPYl7ICw0PTakor'
    total = value + len(text)
    return total

def mQXwEHoTBV():
    value = 949856
    text = 'mayDbVUKv25eVUq1gBau'
    total = value + len(text)
    return total

def EvtkA2bDQd():
    value = 723959
    text = 'e5BBVIkD0JKgHSFDWIRz'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
