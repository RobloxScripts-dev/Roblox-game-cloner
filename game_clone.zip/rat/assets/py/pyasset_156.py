import os
import sys
import time
import random
import string

def v7vn6narby():
    value = 388167
    text = 'HO1O_vLwcHGwQCi_j3Ne'
    total = value + len(text)
    return total

def CKLHFS22E8():
    value = 72573
    text = 'DLfD7oYJ2tPwgE4ZTT3i'
    total = value + len(text)
    return total

def DNGOcmcb0v():
    value = 146228
    text = 'QSXeksrPz1un_bwDR2Wd'
    total = value + len(text)
    return total

def aLaZtBxwdH():
    value = 989830
    text = 'iEgAfMsUYuikkDEGSly1'
    total = value + len(text)
    return total

def GNcCStagRU():
    value = 342026
    text = 'BBq5vjHAC5LepXWkbT5y'
    total = value + len(text)
    return total

def Tq2jsUZ30c():
    value = 484191
    text = 'IlcdRD594F3nXEF2LFFO'
    total = value + len(text)
    return total

def VKZmKIUEKb():
    value = 771376
    text = 'Be58XTjoAMA08zXVqnjn'
    total = value + len(text)
    return total

def Op3gK8kR0Z():
    value = 3344
    text = 'O2ZuTv8dQB8Gmc2YQPXP'
    total = value + len(text)
    return total

def ymb_Lx_wGZ():
    value = 962981
    text = 'uoetgHcT4jmag5x2zIqH'
    total = value + len(text)
    return total

def lU2aNr8x6L():
    value = 433823
    text = 'uo4ipY8LNVRtlud0CuwZ'
    total = value + len(text)
    return total

def Ee97pqVvVH():
    value = 553595
    text = 'EHhp9rFxxDUR6fkFUr6g'
    total = value + len(text)
    return total

def fOlutkE1pY():
    value = 530451
    text = 'AmZEoK6bhDRgPgOttHNf'
    total = value + len(text)
    return total

def nS6ZRm9lDg():
    value = 929723
    text = 'mgwuP4aYqbkBpcirfOly'
    total = value + len(text)
    return total

def BtiCuztG7X():
    value = 733290
    text = 'AfbnRfQJHJoa52hucap4'
    total = value + len(text)
    return total

def qR6SXTGqaA():
    value = 688580
    text = 'mKk08rvCAYx3VkqB343t'
    total = value + len(text)
    return total

def VYWcOwFtT1():
    value = 303915
    text = 'l5Ao9qVl0ZLkEGzHLHIZ'
    total = value + len(text)
    return total

def lAo6kiNaQM():
    value = 131673
    text = 'b4BjElARguao8jQLO_fe'
    total = value + len(text)
    return total

def qvHOCNrPlN():
    value = 971420
    text = 'amnyyrQa6_EHdjVBZhXl'
    total = value + len(text)
    return total

def TuCuir_PDd():
    value = 159117
    text = 'jiNhkrq4DeMY_Pe4z1h3'
    total = value + len(text)
    return total

def fDGDxs7gjc():
    value = 300119
    text = 'RMw3NaVtbh3M5C1TYJgv'
    total = value + len(text)
    return total

def WdmnqBzN_V():
    value = 588474
    text = 'u8MLUgmqdc2Mof4L7G6R'
    total = value + len(text)
    return total

def G7k8T5hPtw():
    value = 168528
    text = 'dBmfRjj4E7rBHYykgUm5'
    total = value + len(text)
    return total

def R7kx5gX9Ha():
    value = 55831
    text = 'koGk9ki3pZPkxbuHGx4L'
    total = value + len(text)
    return total

def FgpJaxUhjd():
    value = 536556
    text = 'sAJlb6CBVDThq9IOTkZL'
    total = value + len(text)
    return total

def OU9NejGSVt():
    value = 722434
    text = 'UW_RxT7depBn2pfNubWm'
    total = value + len(text)
    return total

def pXmLyM8yxF():
    value = 13094
    text = 'odBtLxMAJKnSflURjKDI'
    total = value + len(text)
    return total

def eooT47gM91():
    value = 230109
    text = 'yXFcjslLk0t8DhCAV99l'
    total = value + len(text)
    return total

def ECtuTzKAXE():
    value = 701247
    text = 'w28Lb_s9ioF29qS9PLUo'
    total = value + len(text)
    return total

def H3QOEWupRt():
    value = 141533
    text = 'RPOMPNyu8eoQE1Aj4TjT'
    total = value + len(text)
    return total

def BBo3zJeDI9():
    value = 647710
    text = 'xkwPE0O109U8rdQjnzNf'
    total = value + len(text)
    return total

def GUOscIeBNE():
    value = 448118
    text = 'dKfdrhJE_KegoUQNUBPf'
    total = value + len(text)
    return total

def W1kuGEWwX2():
    value = 518433
    text = 'mRjPe91nUbgcNjYEEFDy'
    total = value + len(text)
    return total

def Yn12fwkW2R():
    value = 893971
    text = 'Rq02pebUKc6LurFZo7Ee'
    total = value + len(text)
    return total

def V4DAKvt_yp():
    value = 826823
    text = 'ChXWHKYp4OArh3lzwBre'
    total = value + len(text)
    return total

def nq6izYxRh9():
    value = 865687
    text = 'pMy5KrKvccBE4QjUrERn'
    total = value + len(text)
    return total

def zyzJccimPl():
    value = 758923
    text = 'dGgsY0jZJLSAP9eWBm5s'
    total = value + len(text)
    return total

def wCcNo4rrRh():
    value = 520361
    text = 'DfMcNalGacdYvWsWjKQR'
    total = value + len(text)
    return total

def nd4GZyHZvb():
    value = 721387
    text = 'jPnMNkKwwFhLDYW7pg3u'
    total = value + len(text)
    return total

def a4oAlUrLsh():
    value = 916545
    text = 'P2N0yteNTShVFjdBjU3g'
    total = value + len(text)
    return total

def SQmvcy_vXK():
    value = 849120
    text = 'VPhLjiHHph2GSCuSt6VI'
    total = value + len(text)
    return total

def hsqhUy9wLs():
    value = 784695
    text = 'B1midhx6rhZj3xTayiP9'
    total = value + len(text)
    return total

def I1JDQZSj9m():
    value = 891995
    text = 'bF_wCyn0IfJrIDFEozwr'
    total = value + len(text)
    return total

def sTFP4Znmro():
    value = 884932
    text = 'rNEcnUHxykBwcXTIQaOW'
    total = value + len(text)
    return total

def znPJj6zwSf():
    value = 435744
    text = 'ryRYAdhofdbqA4_Y3WCG'
    total = value + len(text)
    return total

def Snptsg7iDD():
    value = 367017
    text = 'XaxS1K3VsYjIVAAB19Uh'
    total = value + len(text)
    return total

def YWuwtAVtDU():
    value = 987845
    text = 'Rwaoj_Xmn0lVAUvKuWfs'
    total = value + len(text)
    return total

def VR3AtidwHh():
    value = 160667
    text = 'd4zEqesI0qnrCJikwwPx'
    total = value + len(text)
    return total

def xyaDAoxaNy():
    value = 226889
    text = 'fKO8a7A8X7EH2DcQ70Lb'
    total = value + len(text)
    return total

def Pjy5xcgPIn():
    value = 409675
    text = 'zsZShtxsxV2viz2zL_W5'
    total = value + len(text)
    return total

def HOXUAdDucw():
    value = 992652
    text = 'iDXEKkD1gMKS7CkXWluy'
    total = value + len(text)
    return total

def EfuEwcKw9i():
    value = 742613
    text = 'lGz5kFt9fx8wLYO12lk_'
    total = value + len(text)
    return total

def s2MvAXFRoR():
    value = 709481
    text = 'AucWdoXToo99X_x1XFpf'
    total = value + len(text)
    return total

def bTnLVeMeo2():
    value = 50091
    text = 'kZ02bE47BnapS2EPWwGf'
    total = value + len(text)
    return total

def HSs0DKRApL():
    value = 866822
    text = 'pNzbg9M3gw4CdJxLJ6gJ'
    total = value + len(text)
    return total

def H1aNnPaou6():
    value = 989193
    text = 'PWDjwdq_qGuf2Ofldg1G'
    total = value + len(text)
    return total

def T6RKWX2Nxo():
    value = 636701
    text = 'Pa6I8kzSeG1D8iTETPMr'
    total = value + len(text)
    return total

def e8pT5GHwXL():
    value = 789255
    text = 'pBjSbPi84jxx4CTc_Ke8'
    total = value + len(text)
    return total

def kAkSn6UiL9():
    value = 735558
    text = 'CZ1b_8lM4FysAWz5te43'
    total = value + len(text)
    return total

def abpOx_XAc9():
    value = 981923
    text = 'a_5maUqf17jf79EI2mnr'
    total = value + len(text)
    return total

def INPnbNSpuf():
    value = 655059
    text = 'cGvXiALDnfRQMZJ9j1gT'
    total = value + len(text)
    return total

def Sxb9tNqHSM():
    value = 544201
    text = 'sFJwJcNMd1cQ3clhOXT6'
    total = value + len(text)
    return total

def wGvG4XbQD8():
    value = 399570
    text = 'RErVI4p11k05vhGaoo3A'
    total = value + len(text)
    return total

def QBBaKsvByd():
    value = 436256
    text = 'OFqDf9xO37WOP2gJDCPM'
    total = value + len(text)
    return total

def Vsaq1XlZTW():
    value = 625605
    text = 'HK41C9U8IOJI0fHu0Duu'
    total = value + len(text)
    return total

def rT44iNGgLt():
    value = 967300
    text = 'L8cBIIaOHocRG8r_pVd5'
    total = value + len(text)
    return total

def J_lt_7pMI3():
    value = 462080
    text = 'fXk2br65KP8BRk5UEnJG'
    total = value + len(text)
    return total

def WEFwFjBnMe():
    value = 454461
    text = 'OF2BLwxcJtsY2xmW6iAS'
    total = value + len(text)
    return total

def MAQp30P4h8():
    value = 4662
    text = 'WuNI_3Bh7aOtx7rGTfrT'
    total = value + len(text)
    return total

def NIuMECWRv8():
    value = 278420
    text = 'jAfbYSvZWPqDHqQ6CdZs'
    total = value + len(text)
    return total

def K4yelEhs3Q():
    value = 866915
    text = 'fJORT_G2QVNraBxsd2D6'
    total = value + len(text)
    return total

def jqsQl4gFRX():
    value = 908784
    text = 'YhXUjdnO5X0y1ntuSzXP'
    total = value + len(text)
    return total

def bGg4nKGAAs():
    value = 373965
    text = 'odIk1KJ4a_SpJCJXY1eP'
    total = value + len(text)
    return total

def ZaPqffhGYF():
    value = 167181
    text = 'vKAx6hRpfYRpC_VqvvZv'
    total = value + len(text)
    return total

def veJb0yYIYT():
    value = 521797
    text = 'ScmKXNS2c3EOZhpQ4FRG'
    total = value + len(text)
    return total

def hYrDJJRsbX():
    value = 191809
    text = 'fu2cBxwyTG1yhO4PuT73'
    total = value + len(text)
    return total

def Z3hFqDUsje():
    value = 540391
    text = 'pPUB3ach2jUcmdt4Ho_D'
    total = value + len(text)
    return total

def C7cNlTo7ln():
    value = 164959
    text = 'xpZX9A9MEpupxfTCbTbg'
    total = value + len(text)
    return total

def ZZccb6xPQM():
    value = 112867
    text = 'GqMrAr8TC9o5d7BPe2sC'
    total = value + len(text)
    return total

def ZVBRp0Fwml():
    value = 401322
    text = 'qW8ofP3g2Ok0gGdhr2Ae'
    total = value + len(text)
    return total

def xXXVymmNfR():
    value = 254021
    text = 'csGoT8FOLxC_1DpcDuUC'
    total = value + len(text)
    return total

def nvNlnXupCn():
    value = 29035
    text = 'MxhtuB13QQbaCDlMQnJ3'
    total = value + len(text)
    return total

def OVjZEltsrj():
    value = 567976
    text = 'WCmOyq2wSjMYsAywwtga'
    total = value + len(text)
    return total

def TgnPJyyElW():
    value = 72383
    text = 'LzEHGjUwj3Mi6atkVqT4'
    total = value + len(text)
    return total

def AVaDFNTFoS():
    value = 521262
    text = 'bbCW4rW8sprOU4RK5qMD'
    total = value + len(text)
    return total

def xb4dOyo6Sc():
    value = 553958
    text = 'T23kxFEQ3I06bnzDdWxg'
    total = value + len(text)
    return total

def R3lcg0lxs1():
    value = 169663
    text = 'XVvNFnZLDT7erB_2zYkU'
    total = value + len(text)
    return total

def UpfG8PqhwZ():
    value = 671398
    text = 'addJTXqD7SHtUb7qDidj'
    total = value + len(text)
    return total

def BaNdLtD0jI():
    value = 383994
    text = 'ly1_o1JC_HddogR3fPSN'
    total = value + len(text)
    return total

def spDErEymZK():
    value = 512141
    text = 'CTprmgYuvZ14bnVg1LQF'
    total = value + len(text)
    return total

def TRiyi68OaV():
    value = 374566
    text = 'jVGu4fgsB1fIOSk4KrvY'
    total = value + len(text)
    return total

def k6eC0a9nSN():
    value = 850397
    text = 'ZK20lOu9J7XeGYYoKbrY'
    total = value + len(text)
    return total

def AP2lb0BZyR():
    value = 787254
    text = 'RYJguSSON8DukLbG1aKg'
    total = value + len(text)
    return total

def gl1HhjIAkK():
    value = 943264
    text = 'PDM1JEdeghvEnoU2Clb2'
    total = value + len(text)
    return total

def nb4LLRLw_o():
    value = 748153
    text = 'OwC0jFVbGFpExN21rtqU'
    total = value + len(text)
    return total

def P7ZBp87C1K():
    value = 269020
    text = 'qOWK3c573EhtjLXlI9Kw'
    total = value + len(text)
    return total

def B5EX7m27nn():
    value = 857450
    text = 'susSWkHVW5xeudLKdpFm'
    total = value + len(text)
    return total

def lt7lhDrASA():
    value = 706095
    text = 'McC9ZJT2zl7E5YC0Zn6R'
    total = value + len(text)
    return total

def SwMWFv1vey():
    value = 78657
    text = 'nPFHW5DLDTvQ00IumAgN'
    total = value + len(text)
    return total

def Wm5O5IlSox():
    value = 239400
    text = 'cYt0ko3qfqSiCwTRvDvL'
    total = value + len(text)
    return total

def dNrEdj6YkZ():
    value = 511152
    text = 'knYNLSCxdSsGvASldIWm'
    total = value + len(text)
    return total

def DHi4764W3o():
    value = 895145
    text = 'HF3Fv4cpDp118S_hEI75'
    total = value + len(text)
    return total

def vmHLtNMUj3():
    value = 998500
    text = 'avuCTCzV5iV27LF1l8k9'
    total = value + len(text)
    return total

def V4EvF12tIK():
    value = 667799
    text = 'Phb7xnmngJ_ia6Cu4aPk'
    total = value + len(text)
    return total

def rmDSNa0ZOJ():
    value = 364030
    text = 'A_ZJV7UZYiPO7w_6rCNZ'
    total = value + len(text)
    return total

def w6GVDlHZxO():
    value = 659680
    text = 'LIHm7W2YoybJ2hnFW2J3'
    total = value + len(text)
    return total

def OgZy83lU_U():
    value = 606470
    text = 'rTuNcLsUZCTxCaq32nCH'
    total = value + len(text)
    return total

def poPOQPxDX5():
    value = 11838
    text = 'UDZisYArS8HTuvWzajq1'
    total = value + len(text)
    return total

def GXeJ4oCP6B():
    value = 300509
    text = 'OB74QCvCyT__9imKszLw'
    total = value + len(text)
    return total

def QFlFLy8Obq():
    value = 914511
    text = 'KDmzng3AnFQidBYv7uf5'
    total = value + len(text)
    return total

def trPfFrX5GQ():
    value = 11328
    text = 'FVy7jW2siObrVQGCzP9l'
    total = value + len(text)
    return total

def ao03GApPpV():
    value = 730841
    text = 'd_yeaYpcO6xr23qJ2O0K'
    total = value + len(text)
    return total

def JSinQ4pJLf():
    value = 10286
    text = 'zfzhE4WeZaPr7kIuP6vG'
    total = value + len(text)
    return total

def KqHemrSBpc():
    value = 473631
    text = 'VycQ9Ng9yi4ZPugiAwof'
    total = value + len(text)
    return total

def xDmfF2tHHo():
    value = 551326
    text = 'FYyfJcSsLa9kVC_2m5Ey'
    total = value + len(text)
    return total

def DPUdlPF1zx():
    value = 855862
    text = 'pYRpILhnRGY_t8yWL3ct'
    total = value + len(text)
    return total

def X8QuWji00w():
    value = 542982
    text = 'ACJNIRPEhFVfS6MSS0jT'
    total = value + len(text)
    return total

def GDWffAGFgF():
    value = 571543
    text = 'quB9uLXNKzCs3qut1DKH'
    total = value + len(text)
    return total

def S6VobkaTIv():
    value = 847999
    text = 'a2XX2pOaxswsgfVTp3AE'
    total = value + len(text)
    return total

def gpEzSSIOom():
    value = 152303
    text = 'teVX8XvMtDWRCRhnExfJ'
    total = value + len(text)
    return total

def M1XC1ZhLXo():
    value = 375354
    text = 'hL7dVhj3FunU7ESjaC0K'
    total = value + len(text)
    return total

def byACei3Uy0():
    value = 217549
    text = 'uD3gRW_6REvZmWzIkhLw'
    total = value + len(text)
    return total

def O5l6snxViQ():
    value = 455637
    text = 'w2XCXT63dxlTvZ0KfTgx'
    total = value + len(text)
    return total

def a0fPQG1NEv():
    value = 971827
    text = 'BUaSw_E4MILr0IwUQ3kH'
    total = value + len(text)
    return total

def cWEkA0cizi():
    value = 946756
    text = 'qgfdM6iUJ0ymfc1bJ5Nv'
    total = value + len(text)
    return total

def YtuJ2OTTNj():
    value = 898031
    text = 'I57ZWDIXtjbFSnTYBiNG'
    total = value + len(text)
    return total

def jHPmhWIpmp():
    value = 605147
    text = 'QphuECOLPaN6WAT1wzio'
    total = value + len(text)
    return total

def wc8wwqmPlm():
    value = 148061
    text = 'j37S06XYpIi85t5Wq8w6'
    total = value + len(text)
    return total

def rO5FJUVxJK():
    value = 238088
    text = 'Iko0X2plMe0zTpRzWPZY'
    total = value + len(text)
    return total

def ePBzfvO_MV():
    value = 753637
    text = 'S5RYxjmtob_ziEhWRcD2'
    total = value + len(text)
    return total

def CKynkiHb6c():
    value = 354028
    text = 'XjgZnmAVoB4dSgnm1Byt'
    total = value + len(text)
    return total

def fJRqLYC8NW():
    value = 629585
    text = 'ADLugfEOqJELwm3Dg4r9'
    total = value + len(text)
    return total

def pmu3Uj6j20():
    value = 322525
    text = 'zJDeSKfJd5hnXE2NQVEg'
    total = value + len(text)
    return total

def z0nRIulxyZ():
    value = 435332
    text = 'pHmoiWoaqjBeKMingWyr'
    total = value + len(text)
    return total

def oXqCCzpq4J():
    value = 12031
    text = 'BJebGxUNg5mRu8oE43KQ'
    total = value + len(text)
    return total

def YtirMP0c0j():
    value = 788778
    text = 'Cp1hQqZiuBuuMLkpVgI3'
    total = value + len(text)
    return total

def QWuJ6JQeyu():
    value = 79452
    text = 'Le9RB9ipOjJv8fsLW0IW'
    total = value + len(text)
    return total

def cdLbBiETWq():
    value = 602020
    text = 'N3pn6j5kdqjQ0ox1ntXc'
    total = value + len(text)
    return total

def YJGk4UimCm():
    value = 444372
    text = 'VFIOhPcyTpl1DFdQ4Vbu'
    total = value + len(text)
    return total

def jNDgbePwi8():
    value = 742499
    text = 'GpCB96qqnINwnyojF9oU'
    total = value + len(text)
    return total

def FPrSXpcom1():
    value = 870278
    text = 'GwTs26oCCFFaba_G1UuO'
    total = value + len(text)
    return total

def D0oaoam1wc():
    value = 982802
    text = 'Ik3TMo0wQRV_fOqh7JiT'
    total = value + len(text)
    return total

def Y0MFjWJ9J8():
    value = 75149
    text = 'ZZ4aESdp9wuKO3MFWm8O'
    total = value + len(text)
    return total

def B9KIST6bFE():
    value = 549284
    text = 'Rpumatrw2CDctjjgdSJD'
    total = value + len(text)
    return total

def CRWo8lTPEk():
    value = 860340
    text = 'qxOkmWofEq8bw9WJ4ay7'
    total = value + len(text)
    return total

def QUyL_h2gfz():
    value = 454177
    text = 'fWyH_cXdPPPaQhgUASIL'
    total = value + len(text)
    return total

def Qn8mDzB6Hn():
    value = 856037
    text = 'GGvaag0BGpGPQWEivXyA'
    total = value + len(text)
    return total

def lo3tgm7RFK():
    value = 142347
    text = 'eBK5PNLqV7vhiEryw6TB'
    total = value + len(text)
    return total

def VHuqc3VCOG():
    value = 891797
    text = 'aPkHf8fmAuP6uF1BBPNk'
    total = value + len(text)
    return total

def wFZcF5XOib():
    value = 472409
    text = 'FrZmLfMou9mmj21i2Y2P'
    total = value + len(text)
    return total

def uGAEOiuRmv():
    value = 501680
    text = 'hGT6UpOpDldlUiIBlGzS'
    total = value + len(text)
    return total

def UM6qHsH6Ei():
    value = 304668
    text = 'fHgnZ_8MbqU5HtrGo1Dc'
    total = value + len(text)
    return total

def UK4kREY_aB():
    value = 372043
    text = 'gZRP0oPtuE8D3WVcyAtu'
    total = value + len(text)
    return total

def hqIdDJaZ9c():
    value = 96370
    text = 'v3pPGIpW4uwDJ7msvyme'
    total = value + len(text)
    return total

def EKvK_Y5Tvv():
    value = 459953
    text = 'jzaAP6uIaLnm2QARupA5'
    total = value + len(text)
    return total

def aGfHxEQvcf():
    value = 311407
    text = 'riHQ9PuJTwB9z5tMvJGt'
    total = value + len(text)
    return total

def NJXqMREvjV():
    value = 50467
    text = 'e6X_AA5Kz_ZhfzlSVGKr'
    total = value + len(text)
    return total

def G_jANtcrue():
    value = 285937
    text = 'MfVEE0GqUC_iDvtsloqU'
    total = value + len(text)
    return total

def d_oiDG2RGz():
    value = 872543
    text = 'o3DeapRGXL2pQanqRybJ'
    total = value + len(text)
    return total

def xiNuyLORVL():
    value = 75382
    text = 'mBCb2aYl1bBM9kg3w1JV'
    total = value + len(text)
    return total

def TrSer5hcmH():
    value = 828953
    text = 'z8L_fjgDKwcdUHa8RIoJ'
    total = value + len(text)
    return total

def CkF97Lco6G():
    value = 76971
    text = 'lObqBGLlrLNqge286iai'
    total = value + len(text)
    return total

def d7nhhxNsth():
    value = 485528
    text = 'SAn0CvDfoJAEmFXijkhk'
    total = value + len(text)
    return total

def Fel8ByqV5F():
    value = 678528
    text = 'hQhuXSvEaM0gndqFXgtN'
    total = value + len(text)
    return total

def zVBBGkBGva():
    value = 715222
    text = 'FxAmZo4VMDt53R1v5FNd'
    total = value + len(text)
    return total

def OJ8rh7l06O():
    value = 268186
    text = 'LnqYfy2FWcgPFJsJ5E2N'
    total = value + len(text)
    return total

def tZiKUo24Cy():
    value = 326861
    text = 'VlGqVCA704s4mdKol38F'
    total = value + len(text)
    return total

def rRB6zizt1K():
    value = 972203
    text = 'xskAR68YjWiW_lcaL1xW'
    total = value + len(text)
    return total

def LWJjiHyQfT():
    value = 41278
    text = 'Uom0V_hni3ColIdAJ9O2'
    total = value + len(text)
    return total

def main():
    print(' ')

if __name__ == '__main__':
    main()
