import os
import sys
import time
import random
import string

def SzkqRZ4Pua():
    value = 54067
    text = 'Jx1GecAGkxBTbLihvClp'
    total = value + len(text)
    return total

def XPCjFwr_1s():
    value = 932904
    text = 'jkGxo42_4V11K3EKNbrv'
    total = value + len(text)
    return total

def qXCFxbhZt5():
    value = 898989
    text = 'xFk5rIiykZUPpQDxCx5O'
    total = value + len(text)
    return total

def WkKTVrh1QD():
    value = 922475
    text = 'Q1_59zMD36LwDP6N8pEK'
    total = value + len(text)
    return total

def ZxttSiVFqV():
    value = 794126
    text = 'TKaSxNE33P6zfIWIzcLW'
    total = value + len(text)
    return total

def xvkSnXBe1X():
    value = 180033
    text = 'NiYcSK1RRZGSM1CpWz8v'
    total = value + len(text)
    return total

def O5H135OmqQ():
    value = 27749
    text = 'OBQU0j1LsR3g4E2wo_Fw'
    total = value + len(text)
    return total

def Sqd9aVBkNv():
    value = 421733
    text = 'ruDhWBxuIX6Rrfjupgxi'
    total = value + len(text)
    return total

def XpCYgOdoFL():
    value = 802216
    text = 'HDabLXk4S29ZqqMzidX2'
    total = value + len(text)
    return total

def A34THGEo4d():
    value = 800673
    text = 'YUbK72NiAdYuaLfDdpYy'
    total = value + len(text)
    return total

def p5k6oYwQ5d():
    value = 504678
    text = 'SC3PBVxl1EjknfKfiunj'
    total = value + len(text)
    return total

def Q5B4Rq3Fo7():
    value = 450689
    text = 'g2uY9YXhJvkd3u0IMHrV'
    total = value + len(text)
    return total

def L_wQiJEZ3T():
    value = 115987
    text = 'U1gauZ6YdczedyQMt6Z0'
    total = value + len(text)
    return total

def PSIxmSEFZP():
    value = 608949
    text = 'oG2nGU7O2Y3lzOUjCKUD'
    total = value + len(text)
    return total

def BUEgAx162b():
    value = 463796
    text = 'l2FT5Tz5JbeLNkmQFqj2'
    total = value + len(text)
    return total

def JTWeGR5Pln():
    value = 143290
    text = 'w8gUS7Du8M4mTo5u5nq6'
    total = value + len(text)
    return total

def xC3ZQcP1cL():
    value = 389584
    text = 'q79rYIuhmTJAuqe3G9q1'
    total = value + len(text)
    return total

def fktRyoHsjQ():
    value = 349775
    text = 'VzHofSjnpyF5kHluKfeo'
    total = value + len(text)
    return total

def KaWncANrmm():
    value = 241726
    text = 'wVmxsdy6hHPJiu0mdANG'
    total = value + len(text)
    return total

def dxKSRLOz5f():
    value = 872994
    text = 'JH99InLbeHKGVt4GEX_L'
    total = value + len(text)
    return total

def iM9_W5emra():
    value = 498760
    text = 'wXI7d18jVTVA3NUlVGPp'
    total = value + len(text)
    return total

def Ck54SvNMXF():
    value = 917290
    text = 'FyxiH0Go962C0XK2yVwE'
    total = value + len(text)
    return total

def xkKedOEkhR():
    value = 522090
    text = 'Hwy1bVJGoezIxQvgCK1y'
    total = value + len(text)
    return total

def byxk7Gipqt():
    value = 879593
    text = 'E7yW0reirdD8276AkkCs'
    total = value + len(text)
    return total

def fjMwI0DGUt():
    value = 902579
    text = 'COxVFcPGsq5IC1rEAhlk'
    total = value + len(text)
    return total

def UAC1U4DQS7():
    value = 635560
    text = 'N9bnVv2bSbz9e_fMa0IG'
    total = value + len(text)
    return total

def RSpGiqK3V4():
    value = 403801
    text = 'A077qz89pEV985drPnVG'
    total = value + len(text)
    return total

def huBJ3r2oqU():
    value = 810494
    text = 'Uyb0SRkAomij7UkrsKYA'
    total = value + len(text)
    return total

def kMegXAdHSH():
    value = 988953
    text = 'PJRiyxu_ocRhzns1HHTK'
    total = value + len(text)
    return total

def Jr9x01wkC7():
    value = 130147
    text = 'nQWsS55wu1kjFR9InX73'
    total = value + len(text)
    return total

def qqt6Sm6ZqW():
    value = 549486
    text = 'qZ83t4rvvWkiJj3ojMD0'
    total = value + len(text)
    return total

def MkMmXxfQO2():
    value = 808513
    text = 'rkdohYQsPY99zgkRyqE6'
    total = value + len(text)
    return total

def NVqG8qCp8n():
    value = 785623
    text = 'tkB2cr0nZFZe6Jex0Eiu'
    total = value + len(text)
    return total

def I5sOK1XSOf():
    value = 578639
    text = 'pGMdrcDvd7lJF30sjUIl'
    total = value + len(text)
    return total

def c_hHkm8vDJ():
    value = 392754
    text = 'cfQdBDNTvuey9pGzQMoU'
    total = value + len(text)
    return total

def MziGoZkH2I():
    value = 946453
    text = 'M81YgcYPZbcqyWZYQoXa'
    total = value + len(text)
    return total

def d44A88gFbO():
    value = 372889
    text = 'P3tu3Y97Eldk_T0w0eoK'
    total = value + len(text)
    return total

def HhnNajxmey():
    value = 909161
    text = 'PtPPqto7a3w1Z7HaNLH7'
    total = value + len(text)
    return total

def HfXWu_FuQn():
    value = 302259
    text = 'KZlEBxDghk6RNxJbDXwM'
    total = value + len(text)
    return total

def CXRZ0PtxAo():
    value = 404996
    text = 's1lU_GwbgaSDdKb_xHcM'
    total = value + len(text)
    return total

def grwMykHB15():
    value = 480823
    text = 'JzooAvJVhhIziBXv9Kmk'
    total = value + len(text)
    return total

def sSUiN3CSXi():
    value = 918596
    text = 'oGcHpMvcL2eI_nzFVgdY'
    total = value + len(text)
    return total

def rEQ_IIqfsp():
    value = 609584
    text = 'ar7bbxAeKeumJOgU7AHv'
    total = value + len(text)
    return total

def dlDwqStGsW():
    value = 585012
    text = 'ANWkxqnFHOZpDoJzXWLb'
    total = value + len(text)
    return total

def qMlSiw8TXJ():
    value = 644714
    text = 'RJaQ07lCNNzJ_qo0IiK_'
    total = value + len(text)
    return total

def gkIHuSAMpW():
    value = 224537
    text = 'bkw34wXzUabUy6lNOhgu'
    total = value + len(text)
    return total

def Hu6ixVp4wh():
    value = 765451
    text = 'hjU1QmE63UbEoe5MmVxT'
    total = value + len(text)
    return total

def lTKjhxYnje():
    value = 817957
    text = 'IISgLnCKIkj82vJdixKX'
    total = value + len(text)
    return total

def awezPlQQGB():
    value = 583867
    text = 'fuvXmgfRg8dlU4kD5thI'
    total = value + len(text)
    return total

def p6RqRW3JMW():
    value = 880505
    text = 'pqagSSTsNtjhawqIccNO'
    total = value + len(text)
    return total

def bWdXNi_MI7():
    value = 777801
    text = 'hWtZvXidwDRvIQLM_3KR'
    total = value + len(text)
    return total

def doQTAoxL91():
    value = 640719
    text = 'UPE09sgHeED4bh9eXUZ_'
    total = value + len(text)
    return total

def oQIBYjiYdS():
    value = 25340
    text = 'mPBZl8hxuNbAm2UyBq7N'
    total = value + len(text)
    return total

def KLdG4_2H3o():
    value = 739674
    text = 'g0cotWjxR9gEtVaBSGrM'
    total = value + len(text)
    return total

def i4fdhRcOmR():
    value = 193621
    text = 'MaovOX1RXXMHYXrsIO6o'
    total = value + len(text)
    return total

def N8mmuCvjPK():
    value = 830138
    text = 'fhRD0w9V88jPkOJxFEJb'
    total = value + len(text)
    return total

def uKxTTH6_jv():
    value = 56320
    text = 'KKd359gm4Vd8wpYjaC8z'
    total = value + len(text)
    return total

def AJ2jK0JnIi():
    value = 965140
    text = 'ejzw9kIYyPJaFQe8lx2g'
    total = value + len(text)
    return total

def uCsYJ2LGwJ():
    value = 29363
    text = 'T6kk6wdHtWpiLRDlesw4'
    total = value + len(text)
    return total

def BIqY6HXaIC():
    value = 598496
    text = 'Ihcz42yEOoXiqPTVKpW2'
    total = value + len(text)
    return total

def kDTMccPBZV():
    value = 439604
    text = 'P_hh3mthAvfSRTOCwj8S'
    total = value + len(text)
    return total

def H_eKmqnwma():
    value = 705344
    text = 'wcEaprq0IeGvPQtiWzkX'
    total = value + len(text)
    return total

def TzZtfLddNd():
    value = 305797
    text = 'CfhRJ_ed92YQO5cx6eLW'
    total = value + len(text)
    return total

def rkTBaQlrKS():
    value = 649606
    text = 'xHjnpoDM4tIyLo0SRXQ9'
    total = value + len(text)
    return total

def eQmZ5QNNZ1():
    value = 83788
    text = 'izFR0LdqK_MClFjsOpqW'
    total = value + len(text)
    return total

def ENu3GraTkf():
    value = 253637
    text = 'F7OC0WkyPjn6qBNEIKVO'
    total = value + len(text)
    return total

def EZ1IYjUpiv():
    value = 484666
    text = 'rkfAmvrmu5HoxuugVYLX'
    total = value + len(text)
    return total

def hMlw2iC_T4():
    value = 242168
    text = 'kDHB0VcDWR5HhaALR3hp'
    total = value + len(text)
    return total

def EFXDd_oJbz():
    value = 902527
    text = 'Bihx5HdflRAuRuhQaPZt'
    total = value + len(text)
    return total

def Q0Le7sPJJv():
    value = 170839
    text = 'objZ2CKG38Wc4UmU6edC'
    total = value + len(text)
    return total

def ZOdTSujveJ():
    value = 618550
    text = 'PUmMqxzOWIBVnRy38MxU'
    total = value + len(text)
    return total

def yZJgZXSi4v():
    value = 674775
    text = 'U2CI_tYH_LumDEEWyoah'
    total = value + len(text)
    return total

def mgd7yEYvIk():
    value = 199263
    text = 'ii4DAR4mAhreBiR0kUFy'
    total = value + len(text)
    return total

def Sg1KbLo191():
    value = 549048
    text = 'GUqv0ipwika81LqJsFm0'
    total = value + len(text)
    return total

def CAU9ToKOFg():
    value = 873762
    text = 'Ne3tmVnzqKkcN96tNoMF'
    total = value + len(text)
    return total

def C7hrOaWyeA():
    value = 629928
    text = 'nDEtYPm_7_WFRx3QF1kn'
    total = value + len(text)
    return total

def R4HOSJV_4e():
    value = 107260
    text = 'RUS3aNqtqT6zpY1Lwwkj'
    total = value + len(text)
    return total

def auYVRJa9Pw():
    value = 702864
    text = 'twZNM8nM5RLlZMKm2TzP'
    total = value + len(text)
    return total

def LFlRDrutqy():
    value = 286059
    text = 'EoUYu5YpGmKNaUR4W0Bw'
    total = value + len(text)
    return total

def wmczJsh9e6():
    value = 219825
    text = 'pn53mzGNAB2vtqC7Fy3g'
    total = value + len(text)
    return total

def nY6R1L87RS():
    value = 20315
    text = 'OxZ1p2awu_CjlGINixOd'
    total = value + len(text)
    return total

def VkuRIRsamn():
    value = 424790
    text = 'K4Eu7djiC7aEMISm91KL'
    total = value + len(text)
    return total

def LT3lja6sIn():
    value = 349260
    text = 'LIAyfWB3z49c9qyYPm15'
    total = value + len(text)
    return total

def Gd0KPtPTDj():
    value = 250701
    text = 'W9GHBZpa3Z8JH3Q27ElS'
    total = value + len(text)
    return total

def eEfTXO1FC8():
    value = 539392
    text = 'wRAAjWPq9BYZkygmaluL'
    total = value + len(text)
    return total

def EQo_pwquZ_():
    value = 847933
    text = 'BlP6vGs4e0_NZ_lw12We'
    total = value + len(text)
    return total

def nylKV7b6w5():
    value = 837097
    text = 'bYPI_l2rF2i49wMFaQSN'
    total = value + len(text)
    return total

def fiJYH7tXD5():
    value = 936012
    text = 'Cf2PyFMKlzc9hzwZjWUx'
    total = value + len(text)
    return total

def TeNA5kBYrK():
    value = 152434
    text = 'dKMnz5LUURJwoPXsHCcB'
    total = value + len(text)
    return total

def gANT6TQhiK():
    value = 914774
    text = 'u38guLTuuol6qxEWpz3w'
    total = value + len(text)
    return total

def YHdOhYmLKm():
    value = 710143
    text = 'WtnYaMEcrK7Vi0Vr3yXb'
    total = value + len(text)
    return total

def ab7kAWdPkf():
    value = 90825
    text = 'cVs3ekQFmJcvlWCpzCM6'
    total = value + len(text)
    return total

def DhHFQvIUWx():
    value = 816330
    text = 'EOc5hJWXfyMj6SMwItPg'
    total = value + len(text)
    return total

def CssvjVUg5l():
    value = 958633
    text = 'LpfxXqBWxIR511QQxrmr'
    total = value + len(text)
    return total

def PUlsgT6BJd():
    value = 21025
    text = 'TC3WKPL9QUB6HeQTNG8s'
    total = value + len(text)
    return total

def zplrO1Uevw():
    value = 23668
    text = 'VLx0vL_TlKiyA3Dld7jR'
    total = value + len(text)
    return total

def yvQ3AlYLWE():
    value = 248453
    text = 'Cfpt5uAbPHnFncLRITqU'
    total = value + len(text)
    return total

def VKaEnFh1OG():
    value = 969372
    text = 'qGh4ojcnHaqpw4hylZWc'
    total = value + len(text)
    return total

def oLsenC8QhP():
    value = 593836
    text = 'hiqYlClQaXgdO2qF7xK5'
    total = value + len(text)
    return total

def WcJx8Qsio4():
    value = 394942
    text = 'LyBkgP6vvGD95jd_vQHO'
    total = value + len(text)
    return total

def wa61HeTNSV():
    value = 172711
    text = 'PEcXbXHrbB14x359k3OC'
    total = value + len(text)
    return total

def amfaWLZWln():
    value = 825283
    text = 'tyQbj3vMHri5z1Kehy4c'
    total = value + len(text)
    return total

def rcLC8TFgck():
    value = 92080
    text = 'BFvaNpXPoLNoRzXhZ61X'
    total = value + len(text)
    return total

def XxPrzFQoxj():
    value = 649053
    text = 'HS9YUnA9Nnsk4FJWG3Pn'
    total = value + len(text)
    return total

def Jy1LlcW5Aq():
    value = 862611
    text = 'Br5VYAeayCDsQbl8nD_k'
    total = value + len(text)
    return total

def PZ3Lh3CcdB():
    value = 853323
    text = 'VTQCDuGDdHUDhs6IID1r'
    total = value + len(text)
    return total

def adQyMDsL8d():
    value = 800575
    text = 'r90zp80Y2pxe2dZev5bw'
    total = value + len(text)
    return total

def skFQrI3urI():
    value = 350483
    text = 'Y6WotCucwz2YKzyMP9vK'
    total = value + len(text)
    return total

def BO2Avut5Uc():
    value = 296661
    text = 'XJnf_t5Jdk02b73msXFj'
    total = value + len(text)
    return total

def M8gDVRnVYA():
    value = 888125
    text = 'UKuVZ2Cqr1LhGH7Fjf6p'
    total = value + len(text)
    return total

def mEHPsBI__2():
    value = 901778
    text = 'kUQjkprqzPIV22Xz8CSK'
    total = value + len(text)
    return total

def e1_H9EOmVd():
    value = 586161
    text = 'Ky8CDb5NaO8tOmAaPApg'
    total = value + len(text)
    return total

def y7K1c7JqkF():
    value = 219347
    text = 'Gok0mb9lcp5GPN61mAUI'
    total = value + len(text)
    return total

def YUckjSeoRr():
    value = 410598
    text = 'Btcxnp3bC3skcm90gITB'
    total = value + len(text)
    return total

def AYHEflQUnH():
    value = 268602
    text = 'fEmpLO7m9ibh1HFBeIuQ'
    total = value + len(text)
    return total

def Saoz4nFjd7():
    value = 276348
    text = 't5Nq0txepSnLRxQBNqLt'
    total = value + len(text)
    return total

def V9P4Bmn_Bk():
    value = 91545
    text = 'iDv2fh0dAgmVrFjAR4J7'
    total = value + len(text)
    return total

def eUcjdAFbnu():
    value = 16402
    text = 'bFuat6y19GZzci4ShuIa'
    total = value + len(text)
    return total

def PV_9uiOKOk():
    value = 521494
    text = 'RrmeaAK2oQ7vfFsvApY0'
    total = value + len(text)
    return total

def Q46xOX_igM():
    value = 412012
    text = 'y8R9DWmBHsLiq5XqCJEw'
    total = value + len(text)
    return total

def VtSjpZaG3g():
    value = 256795
    text = 'xjxsMEetuL_yz3u4cybe'
    total = value + len(text)
    return total

def odlLh0J3HO():
    value = 860987
    text = 'CuNJp5Czu2qilsnrXemu'
    total = value + len(text)
    return total

def dtmAxg0wgw():
    value = 441012
    text = 'PNuw_YThuLzzUvsTrFIf'
    total = value + len(text)
    return total

def FDVUU1QLfw():
    value = 707525
    text = 'hfIU9cqMpc16erTgv66c'
    total = value + len(text)
    return total

def gFnovw0SdX():
    value = 792518
    text = 'oKuLJQW1QAbcunAWCmvT'
    total = value + len(text)
    return total

def nOgax4yMUE():
    value = 46461
    text = 'DFp28VZD82CN7uWI4xOd'
    total = value + len(text)
    return total

def VMxmnaouXs():
    value = 496401
    text = 'd5Vd93mMzdIpYbCUCCOt'
    total = value + len(text)
    return total

def Gx0oipewO3():
    value = 341825
    text = 'hrUhx5UjWSNMIwlUIfcN'
    total = value + len(text)
    return total

def AhL1wTE1OK():
    value = 876180
    text = 'x09BdVTivmOgHPsrkFEq'
    total = value + len(text)
    return total

def aTKbWp91Df():
    value = 186229
    text = 'Z692bWBwzG5mkyG6iDLj'
    total = value + len(text)
    return total

def rXQVYc4_XH():
    value = 888244
    text = 'fT0DC3t1z5OUOM0lLRRZ'
    total = value + len(text)
    return total

def xbGtNtQrZs():
    value = 639156
    text = 'ynFGDAPxbLqmS0RbiKkj'
    total = value + len(text)
    return total

def WhMgLu0NpN():
    value = 41750
    text = 'Rg_QjaF9luK0p5kRcVWg'
    total = value + len(text)
    return total

def dEOzcV2YN8():
    value = 810230
    text = 'l0cl6pAZPIde6vwqN3SH'
    total = value + len(text)
    return total

def NlFYBuGORe():
    value = 180053
    text = 'WYjAyQS8Buz2s1eJl8X8'
    total = value + len(text)
    return total

def Fc0VVQKQDS():
    value = 581730
    text = 'H8gMqKsmTgv8s4qJTllt'
    total = value + len(text)
    return total

def RU300rGAT4():
    value = 72323
    text = 'PkpzPiniimu0zWf_dGjL'
    total = value + len(text)
    return total

def RvFttrSIgo():
    value = 331978
    text = 'cK_m_6y3q3sOve0BUI4c'
    total = value + len(text)
    return total

def oXm3oY3Rny():
    value = 695252
    text = 'UAka6wlv1KVs7JyeQPO7'
    total = value + len(text)
    return total

def vr8ayMkTIS():
    value = 772752
    text = 'xj3wZm936cUIsdxgDUky'
    total = value + len(text)
    return total

def tcHbWLUlcS():
    value = 185999
    text = 'TvIeIq3LSZLDp9ZhXE_N'
    total = value + len(text)
    return total

def vQGt7cCRut():
    value = 688105
    text = 'vHFKcB2wtKdawzcNYNtS'
    total = value + len(text)
    return total

def EtpFw9T3o_():
    value = 799947
    text = 'ROv3yCmQ_5G42pJDtD0s'
    total = value + len(text)
    return total

def oME4IjGgaQ():
    value = 480069
    text = 'NT8iUZQGwxSTQ740eZc_'
    total = value + len(text)
    return total

def IyZ7eLYO6l():
    value = 244758
    text = 'vS03DgZFkISXOMtaliSr'
    total = value + len(text)
    return total

def zTWUXWaJ6Q():
    value = 498749
    text = 'gEuYArvb93TGShGB2avj'
    total = value + len(text)
    return total

def R5lkZpUJri():
    value = 368620
    text = 'objwatQM1GE_td9i7K6u'
    total = value + len(text)
    return total

def Wd4JMbIEGA():
    value = 305164
    text = 'KqPD8OQS8cXfvqcPuTDH'
    total = value + len(text)
    return total

def ci0drDygid():
    value = 401098
    text = 'ohGJs7LtagXiUs37CRIU'
    total = value + len(text)
    return total

def QN8bHtT_K0():
    value = 951722
    text = 'QXdecv6CkqhwAcJgGgbS'
    total = value + len(text)
    return total

def nnM2hZ7v9B():
    value = 593868
    text = 't8d_hnYms4inmVDEqBqa'
    total = value + len(text)
    return total

def uCTlH1qGWx():
    value = 137674
    text = 'dlWiEjzBA31QZR84a_BG'
    total = value + len(text)
    return total

def uQYMlTbIRk():
    value = 310734
    text = 'f1zE6CZ85h67jVgr6Eje'
    total = value + len(text)
    return total

def rPMxKSq0TI():
    value = 390258
    text = 'Eak_QiBNMbs9IDZEolg0'
    total = value + len(text)
    return total

def MgbOFGvYNw():
    value = 795088
    text = 'Vg_y5IMpUi5z7bFjOrXA'
    total = value + len(text)
    return total

def hLiW8eziht():
    value = 44828
    text = 'hweJqIwEHDcUSzyfSdAh'
    total = value + len(text)
    return total

def EQs_Q85V3Q():
    value = 873312
    text = 'DW7qsbF16SVhRJKsgtjD'
    total = value + len(text)
    return total

def AWumIOQaAs():
    value = 76358
    text = 'E1AxLZiVvs_ayLsnlLby'
    total = value + len(text)
    return total

def z_ci4But0Q():
    value = 548423
    text = 'z0iSwPJgqRG7rq9HKM76'
    total = value + len(text)
    return total

def yEFA3XcH3l():
    value = 528957
    text = 'pZCPRZQfW4cSg1ZlPcqK'
    total = value + len(text)
    return total

def gOhF_lkkh4():
    value = 772762
    text = 'vBUmD48ICwuki4wQwOFw'
    total = value + len(text)
    return total

def nPyJ8UQfw0():
    value = 716377
    text = 'E4Oi_zBZgd_R6K7yscaK'
    total = value + len(text)
    return total

def jN1enwTZKG():
    value = 123525
    text = 'sisluJXcpKY9ajYxh9i3'
    total = value + len(text)
    return total

def hADZgrDaV2():
    value = 596498
    text = 'kR00t2TTBnLDHK23wfnf'
    total = value + len(text)
    return total

def LXawHS1buH():
    value = 3189
    text = 'RgxGR04lJkvUzOmNwq4C'
    total = value + len(text)
    return total

def kuqojRh2WF():
    value = 445866
    text = 'XSFwi7KyijS5lw9o28Bo'
    total = value + len(text)
    return total

def RQDH0YXrvl():
    value = 178707
    text = 'IYBAkR9kE9eeEb3h9X5N'
    total = value + len(text)
    return total

def gP2kWt1hmZ():
    value = 819874
    text = 'Y3TN2COTy1Tw702GDzXw'
    total = value + len(text)
    return total

def F3NUAhgcQD():
    value = 54043
    text = 'rHdIf8jmRWE6txL9bqYL'
    total = value + len(text)
    return total

def hAcvKcEoIw():
    value = 682523
    text = 'mihPIWflZDkmFC5c1dTy'
    total = value + len(text)
    return total

def wbQYsHCpCw():
    value = 573260
    text = 'xyTVTRvmYgWRQEtZ6m4Q'
    total = value + len(text)
    return total

def jYZbYESkaL():
    value = 54235
    text = 'rfWlkzYW3feIRB5tRVGG'
    total = value + len(text)
    return total

def EW0Vjshhsp():
    value = 314879
    text = 'EboCqkixhUrycaX7BnG4'
    total = value + len(text)
    return total

def ZK9q35x1nC():
    value = 20796
    text = 't7yx5Q8YvH91tCTJis59'
    total = value + len(text)
    return total

def gPNanuXrOj():
    value = 725675
    text = 'awArnxmuLpsycOoUNJpY'
    total = value + len(text)
    return total

def fHNg6AVfkQ():
    value = 461105
    text = 'VBAoVXrdA4D3eI2sNhrI'
    total = value + len(text)
    return total

def ChXhf1kes_():
    value = 851532
    text = 'hxpFnqzEBf4hnVFJmWBh'
    total = value + len(text)
    return total

def GXI8CjnBFl():
    value = 164418
    text = 'sdHsx4VqEarGqLqaApAQ'
    total = value + len(text)
    return total

def m1GFmsGB3G():
    value = 690169
    text = 'GCMsecqW8AdkQLyFxrkl'
    total = value + len(text)
    return total

def GRHSy_b4Eh():
    value = 391234
    text = 'X4Sw9xUPgrmn9KZ4rA92'
    total = value + len(text)
    return total

def cddNxHe_Xb():
    value = 800065
    text = 'kJWzLlcv06nxc7EuPtvM'
    total = value + len(text)
    return total

def UBI9wnq8H9():
    value = 846101
    text = 'Wcbu4RacM0MjtK0Yhlo4'
    total = value + len(text)
    return total

def qwnQg_Z5DJ():
    value = 543232
    text = 'R7AD70lvTxwLfa61XWAi'
    total = value + len(text)
    return total

def VkPsRGXdm9():
    value = 336942
    text = 'jZ5NTEMJfhteCDjuEcYs'
    total = value + len(text)
    return total

def eC1f6aaYOu():
    value = 564616
    text = 'iXG8UMyfCqWEyvTFnmxU'
    total = value + len(text)
    return total

def y8RQX6gIYf():
    value = 465867
    text = 'CHWJ1DfiTRv5xJ_LNLD0'
    total = value + len(text)
    return total

def y2zeq0MA_N():
    value = 665734
    text = 'jMJVyn7Erkucd8iTLSwM'
    total = value + len(text)
    return total

def ug2wjHlQJR():
    value = 592968
    text = 'XS_fvhHrQOm9ZpevGGha'
    total = value + len(text)
    return total

def Nt8yYZDMM3():
    value = 924147
    text = 'zsYfdUBae0HxLwumrtoQ'
    total = value + len(text)
    return total

def TVQ1dd5PQZ():
    value = 104417
    text = 'pbRVHoZHyoascw1uL9G2'
    total = value + len(text)
    return total

def UZbJ9LpUNP():
    value = 552407
    text = 'khANQpNqdaeQvr_4VpLM'
    total = value + len(text)
    return total

def NFJCfWGxHN():
    value = 150264
    text = 'nv4w9gZBohtF7UYg97Mg'
    total = value + len(text)
    return total

def Y3_sUsW9gK():
    value = 6964
    text = 'EQLFGeCaycuo2qgRDM_v'
    total = value + len(text)
    return total

def GTe3NnETn0():
    value = 888614
    text = 'sqcL7TF0duTmqLjB7SFy'
    total = value + len(text)
    return total

def yDESh3ULKu():
    value = 74572
    text = 'Mgvp2cthalycke_f2C9x'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
