import os
import sys
import time
import random
import string

def uR3aOO9cpj():
    value = 220783
    text = 'ZsUSCQ2m7oSuqJ7E2fFk'
    total = value + len(text)
    return total

def H8ZN5ZE63u():
    value = 730560
    text = 'r90id3u1KvYXLp8nnse6'
    total = value + len(text)
    return total

def ZFV0KS1w_k():
    value = 686553
    text = 'qyrCKp56MPZVa15_suWt'
    total = value + len(text)
    return total

def tUvWKJPKvx():
    value = 474568
    text = 'z6o9rCs0bazDau_7bCRr'
    total = value + len(text)
    return total

def M6hzc3JI4S():
    value = 250515
    text = 'PjrGijD2eYqRDAHP9is8'
    total = value + len(text)
    return total

def O6UO78izDv():
    value = 319843
    text = 'N3Jp3mEKwup5buEYnAL4'
    total = value + len(text)
    return total

def V63Jj2Y2zC():
    value = 941458
    text = 'BSgG0e2A6pXrglgQ_xFB'
    total = value + len(text)
    return total

def hlFGZsYcwu():
    value = 393462
    text = 'ITklszWyIoAst21xxoAp'
    total = value + len(text)
    return total

def KQFhpbmEtp():
    value = 368802
    text = 'K7lfwJDUs9_mqXm3JJw0'
    total = value + len(text)
    return total

def BWxSN92rDf():
    value = 246110
    text = 'iNeEXS77vIdYaeZFIYzz'
    total = value + len(text)
    return total

def lmZZ5W2CpJ():
    value = 768918
    text = 'zXiOuNHMEE4Spe5BV2oF'
    total = value + len(text)
    return total

def vCxiwPnjsf():
    value = 740818
    text = 'gauNc92aWbXfr0RgsEts'
    total = value + len(text)
    return total

def J2DQ5FuKz_():
    value = 955177
    text = 'Ruhx2j_uxooVwEpAfR3o'
    total = value + len(text)
    return total

def fSbrYoqLl0():
    value = 513505
    text = 'VWOtMjRpBJZvKw8vgKUt'
    total = value + len(text)
    return total

def BYFopLJbgM():
    value = 201295
    text = 'bYqXZwtl4lSlLOdn2vg5'
    total = value + len(text)
    return total

def gC4joj9KjH():
    value = 615849
    text = 'ycDAoEfh8HkO7xpYVX0O'
    total = value + len(text)
    return total

def rquA5nwdL8():
    value = 340219
    text = 'aHUjDVzIjv2UDSYfCzFF'
    total = value + len(text)
    return total

def Xwi6VLdpdG():
    value = 165756
    text = 'PEDz4L8kTxxsOXym5l5K'
    total = value + len(text)
    return total

def J7hGdZDRxm():
    value = 309534
    text = 'mZj2yoWUosbqejaMcGk3'
    total = value + len(text)
    return total

def cQkA0v7NNt():
    value = 980146
    text = 'ArC0J_7M14WBhklw2W_J'
    total = value + len(text)
    return total

def KN9bKU9RSn():
    value = 44309
    text = 'szvhydE5YHRJqtFc0q3U'
    total = value + len(text)
    return total

def qSiCXPTElM():
    value = 778927
    text = 'GloQgN5MC0Tpd_g5uPmb'
    total = value + len(text)
    return total

def fDPmYODHqM():
    value = 153927
    text = 'Zta0jA4fludhdej3Ihom'
    total = value + len(text)
    return total

def dKeOtqmg8g():
    value = 775015
    text = 'AZ8XWVop5U5DCqvBqaZH'
    total = value + len(text)
    return total

def dCGw3VC9Dp():
    value = 758353
    text = 'pzNKhjYGva6CUrpsCGlx'
    total = value + len(text)
    return total

def zk22y3o_qi():
    value = 652773
    text = 'V3fss2KQjqoOaXQ1CH3y'
    total = value + len(text)
    return total

def fma0GbC01M():
    value = 226247
    text = 'aPwVPrki7xacCTpiBz1_'
    total = value + len(text)
    return total

def p7nbrmooVw():
    value = 674877
    text = 'vlEVLwqfokwOZM44MJ8W'
    total = value + len(text)
    return total

def eM73oXtTlp():
    value = 633411
    text = 'k9_3ePuyfJ1BW8oyw2Rd'
    total = value + len(text)
    return total

def q0Hctu1XEX():
    value = 558574
    text = 'fFNz7jxZYouXmMfJe6lX'
    total = value + len(text)
    return total

def toNxL3ZulF():
    value = 824495
    text = 'oIqjSaEQAEQC05gF4iJI'
    total = value + len(text)
    return total

def PXqfWG4Rdb():
    value = 735967
    text = 'PyFluWY7MYkyrE87v6zU'
    total = value + len(text)
    return total

def AGm0BtUxVB():
    value = 540769
    text = 'r8QfeWNpCUHGCaIhFE8y'
    total = value + len(text)
    return total

def B8UYKULaJ3():
    value = 413998
    text = 'gsaHbBm0_XdqWDJKv6HJ'
    total = value + len(text)
    return total

def LaeTdoB9hN():
    value = 510784
    text = 'ISN0v0IcDOrA0UfU1FkG'
    total = value + len(text)
    return total

def pBv79i8o8R():
    value = 976738
    text = 'uzigVPHgZ7O0Ac7kuGK5'
    total = value + len(text)
    return total

def qt2hPjV8XX():
    value = 629021
    text = 'F2EbPO2zbTIAvPXeG8rI'
    total = value + len(text)
    return total

def YwwnKHA0Mh():
    value = 431977
    text = 'KjJOTUpYX01CqVxTwGuc'
    total = value + len(text)
    return total

def Yi4AhtJ3CE():
    value = 223067
    text = 'LK8Hyc8j0VuFLHvwFvIG'
    total = value + len(text)
    return total

def Nt30iD5lD8():
    value = 551916
    text = 'oM9AV2gc_7jSQcVArvSM'
    total = value + len(text)
    return total

def pJinI11dYW():
    value = 344507
    text = 'rc8GZKknHQ3K5b8qbdAb'
    total = value + len(text)
    return total

def JhJDAEzxQW():
    value = 171947
    text = 'OGd0quB0oFiEGvpp39h5'
    total = value + len(text)
    return total

def jU65J4hwr4():
    value = 997262
    text = 'd2Aqffm7wtvQEoX9dS0B'
    total = value + len(text)
    return total

def G5xJMyH3MS():
    value = 263602
    text = 'go8rKf5NubgX3oUdxR1H'
    total = value + len(text)
    return total

def lxMsr2oBqg():
    value = 125776
    text = 'uI4tZVFq5tQ2v1H5wxrX'
    total = value + len(text)
    return total

def x3Iu7tFncz():
    value = 565981
    text = 'KNEbl0NepRqfH_fwZZqJ'
    total = value + len(text)
    return total

def zyYyR5sFO7():
    value = 111000
    text = 'oLD5EsTNltCzCYr0E4TS'
    total = value + len(text)
    return total

def wGhvFc3qaW():
    value = 870946
    text = 'd3_yAzuFOQZye4C1jGAx'
    total = value + len(text)
    return total

def UqhrXNpIhv():
    value = 710552
    text = 'c9ru0Y6nOYw0qsjOVtqf'
    total = value + len(text)
    return total

def Jzzom4Jw3Y():
    value = 230164
    text = 'cPBZnV0AshcQ5QIduaoq'
    total = value + len(text)
    return total

def NGyJIFsh5S():
    value = 254268
    text = 'iJxgkVJniYmDDg8vNsfm'
    total = value + len(text)
    return total

def Ud8i1It2SL():
    value = 850068
    text = 'lHkmyPtLiUzlDhIlXMGf'
    total = value + len(text)
    return total

def yZYcbvjN0u():
    value = 42365
    text = 'ZZPwnDwTqfaffmZAlA3L'
    total = value + len(text)
    return total

def wraTsHmUPv():
    value = 379100
    text = 'qCx75X3XVffJta2Oy30U'
    total = value + len(text)
    return total

def oVTYwnxUS1():
    value = 979546
    text = 'olffld54Ohx0GJRc5Geq'
    total = value + len(text)
    return total

def O3aR3E7mxg():
    value = 636249
    text = 'biQAOzVecWtdX6vT1_fG'
    total = value + len(text)
    return total

def XPbe4DgOwq():
    value = 57145
    text = 'psaWTxn6lNdc5cGiVkOh'
    total = value + len(text)
    return total

def hVWXObz2nv():
    value = 462817
    text = 'SXU9rEUk9ZiUApUiQocG'
    total = value + len(text)
    return total

def lV7Nbv065M():
    value = 870156
    text = 'irhbmmgtx_AQO0IWKneb'
    total = value + len(text)
    return total

def cDelTwmGuK():
    value = 59553
    text = 'Ojw24pxP8FLhLxSG16vZ'
    total = value + len(text)
    return total

def aFqVuBp1FM():
    value = 708078
    text = 'hEBgZnnXJFJ8MELgv5_8'
    total = value + len(text)
    return total

def hH1CJfv9EL():
    value = 635120
    text = 'hF5psf19Ng_Yf6y9ypTk'
    total = value + len(text)
    return total

def fkCqhyaaF7():
    value = 221741
    text = 'kP83TQUJ2s3U3cJoWJLl'
    total = value + len(text)
    return total

def wZYbqBVkJ5():
    value = 681486
    text = 'NahVFdphADBPlawXbG7P'
    total = value + len(text)
    return total

def Gsl5aJjDDY():
    value = 751823
    text = 'P8w4mbMFsie40Lvnwk1a'
    total = value + len(text)
    return total

def yZQNuY_zOw():
    value = 280660
    text = 'XnChK32ABQHUvszl8zmP'
    total = value + len(text)
    return total

def TqGEYXt2oA():
    value = 640527
    text = 'hDa4Cg7omtjGXBbXwlDu'
    total = value + len(text)
    return total

def uEhpzvLlAz():
    value = 73944
    text = 'A_EclXK6KHD9V2njZewC'
    total = value + len(text)
    return total

def VTG6nvuXSw():
    value = 632812
    text = 'atTd4FsUTzwhVQ16kAzc'
    total = value + len(text)
    return total

def jeKtIJ_s8H():
    value = 238011
    text = 'CT5EFS0HkkWR8aM0IBXd'
    total = value + len(text)
    return total

def w20gXYb71b():
    value = 149545
    text = 'yUAtnTBKasZaZ4LRO7RZ'
    total = value + len(text)
    return total

def nrq388m0oB():
    value = 505359
    text = 'zkZPHvqddbu9vlchtqgr'
    total = value + len(text)
    return total

def cG3xaCzcfi():
    value = 981622
    text = 'Qef_GRCABREI6MonYOCa'
    total = value + len(text)
    return total

def fYTToyMLwW():
    value = 600109
    text = 'oMcYcgcvMBo0I1rkw0rU'
    total = value + len(text)
    return total

def O9nq1OjGRw():
    value = 356912
    text = 'GiYisbxYYjAvQJMhJbvw'
    total = value + len(text)
    return total

def B99i1mGNOT():
    value = 653530
    text = 'bI2GnRHvL1SFZ2FtH_Sk'
    total = value + len(text)
    return total

def paRjy6t1QR():
    value = 124578
    text = 'BukuJqRcMKCVTlj2Y6ho'
    total = value + len(text)
    return total

def pt1UMaHIEE():
    value = 843788
    text = 'OuGHFmdL4PLfRuZJUCHS'
    total = value + len(text)
    return total

def ADYUQlRBje():
    value = 446381
    text = 'yhVKopPk4kjo40AXMf0l'
    total = value + len(text)
    return total

def fhoI_ITxMz():
    value = 90762
    text = 'H0SFsVaaNvyrn6frcq7p'
    total = value + len(text)
    return total

def yqdpV06YyK():
    value = 329430
    text = 'zTk6NClCKenqgCxO9qlb'
    total = value + len(text)
    return total

def FSLokknSKC():
    value = 604312
    text = 'MY1CEeg7OBgU4e1I6zLv'
    total = value + len(text)
    return total

def khz2etBaeT():
    value = 4168
    text = 'GMnGprngImN0g8DoGloG'
    total = value + len(text)
    return total

def zb4tBd3oin():
    value = 128446
    text = 'dqUFPvtfy_sNfQG9dSCA'
    total = value + len(text)
    return total

def UZ6aTaRctU():
    value = 637207
    text = 'oRi5yl5FuLFyX7UBXAJ8'
    total = value + len(text)
    return total

def mm6iia_58R():
    value = 656203
    text = 'IXA2Bfb5yR2r2gY2WQsV'
    total = value + len(text)
    return total

def k80IRK9ULi():
    value = 393151
    text = 'HnWtXHGm9e4udDEf6m2_'
    total = value + len(text)
    return total

def EKfH2mfHVK():
    value = 224410
    text = 'ZsKLgtLFhL4R31Axetoo'
    total = value + len(text)
    return total

def xMcPYUXDk1():
    value = 249547
    text = 'RpEdk_AoT6ZVAJNGM6bN'
    total = value + len(text)
    return total

def VC_GUiyzE2():
    value = 305698
    text = 'jNTaXbQNFSkXLjrGK8n0'
    total = value + len(text)
    return total

def WBMYgpqKfL():
    value = 506229
    text = 'EY61IJFZoB4BTNqBazIA'
    total = value + len(text)
    return total

def untsDU8zIf():
    value = 213361
    text = 'eIfPcqs23J1_YP7eF2xW'
    total = value + len(text)
    return total

def z0xN6P4thM():
    value = 728247
    text = 'H3w4qQP5eTFQLe2FozSU'
    total = value + len(text)
    return total

def kpHnHyGR5E():
    value = 455011
    text = 'urwpmPKH24VOplj16xN2'
    total = value + len(text)
    return total

def G5NP2AD8q_():
    value = 119895
    text = 'GiSQ2wBwaK9nFFK2ycii'
    total = value + len(text)
    return total

def ascJNwEkK7():
    value = 637768
    text = 'wa2bm2NYuy6QP6ys8c7G'
    total = value + len(text)
    return total

def NCPyU77dUf():
    value = 365556
    text = 'ruSGLB_45sbABr5Q3cQU'
    total = value + len(text)
    return total

def qIbNitIU6Q():
    value = 407586
    text = 'X1OPTsqs0qiR7jneE5ED'
    total = value + len(text)
    return total

def fubSqWJ3dy():
    value = 498073
    text = 'ODTyVb9QEZmUOD4apF5x'
    total = value + len(text)
    return total

def TG3wUGSoBd():
    value = 214640
    text = 'rpkq04kayZBt84KpET8w'
    total = value + len(text)
    return total

def sEauwrP1Ku():
    value = 368322
    text = 'Hi_08VYRq7abPw5RNdJH'
    total = value + len(text)
    return total

def y_v4dmqjkL():
    value = 955278
    text = 'm0uwIn1FWVChedh_Bi4d'
    total = value + len(text)
    return total

def g0vYPhx0cl():
    value = 196006
    text = 'HUX2DdZz5wgtUScjrMR8'
    total = value + len(text)
    return total

def meOLC73tME():
    value = 401121
    text = 'yWmiLBpxgK1TlHD89cco'
    total = value + len(text)
    return total

def DIRYXr1k4r():
    value = 843897
    text = 'QsDFk2tyAKmMUfkrNuH8'
    total = value + len(text)
    return total

def YJaQufjRcL():
    value = 190208
    text = 'RfLKpLF4Bsq4A1oyoLXW'
    total = value + len(text)
    return total

def HwI9fVNhto():
    value = 713084
    text = 'MIQSYTA8COJqjEzU8GY9'
    total = value + len(text)
    return total

def tlO0mxk0s8():
    value = 209620
    text = 'CYGmhtmKVWaPyg5nmwda'
    total = value + len(text)
    return total

def ggeWoZtl1A():
    value = 956213
    text = 'gHPHFcSPyymwFAtgsnbm'
    total = value + len(text)
    return total

def qlH6DqPRU6():
    value = 802355
    text = 'lcCdUyksoxXWRccKBHqO'
    total = value + len(text)
    return total

def yeiVl3ZkFR():
    value = 64825
    text = 'czxTWP2NhBETA4Jhrsfe'
    total = value + len(text)
    return total

def B0huGy3a8D():
    value = 937942
    text = 'cwmnI448JzdPRtIMHqxT'
    total = value + len(text)
    return total

def gk_nQVGTt6():
    value = 430999
    text = 'BafWK7JegxbVxAToyrO5'
    total = value + len(text)
    return total

def iZd6ulDaML():
    value = 277986
    text = 'IGMitbp7waFj0fMe9OLL'
    total = value + len(text)
    return total

def rBjoTjq5m0():
    value = 649199
    text = 'ZFMjMm4a_MBhJB_r4UWJ'
    total = value + len(text)
    return total

def dI6SlVpq07():
    value = 79593
    text = 'XPilEBizxdLTZt8C3dr4'
    total = value + len(text)
    return total

def nv9IYnp2og():
    value = 104371
    text = 'OMnbUbxl6g1OfzqHIXhw'
    total = value + len(text)
    return total

def Kq7r0rtWHb():
    value = 956473
    text = 'SePhtZW6vlP6fF94uk3k'
    total = value + len(text)
    return total

def pUAmYgOvn7():
    value = 935851
    text = 'fmkJtCxfUhlKqGRKoaWd'
    total = value + len(text)
    return total

def YpB74fmMAC():
    value = 497094
    text = 'qcobw0vmKct9GTZLRFEX'
    total = value + len(text)
    return total

def b2eHfrf7rG():
    value = 879008
    text = 'Ubx8twHrbJLzviz_ubSx'
    total = value + len(text)
    return total

def Anqtdd6mTE():
    value = 566125
    text = 'BGIijI2xuClI1M4KwKJ0'
    total = value + len(text)
    return total

def VQ35EwyoVw():
    value = 48334
    text = 'ywh_Po7Nj5lvodTC13OB'
    total = value + len(text)
    return total

def xEr6l9kcsR():
    value = 8244
    text = 'm1lU_Hoj4vU6y9gwgnJh'
    total = value + len(text)
    return total

def f5ldwuiaXI():
    value = 173198
    text = 'YCIa5LXdicP4ZqNhaX6Q'
    total = value + len(text)
    return total

def qSWlXT9rSz():
    value = 344558
    text = 'JsZhRKVXL_o4uxBkOpYG'
    total = value + len(text)
    return total

def j5RG2EfpHp():
    value = 583780
    text = 'mrV2WhPQweBImU9yLxbx'
    total = value + len(text)
    return total

def HQDi4gGdoQ():
    value = 28124
    text = 'LAk4_IIw1YHjn085Tlbj'
    total = value + len(text)
    return total

def h5FZZorH15():
    value = 425361
    text = 'rOYEHm70B_dbFHoiCkiy'
    total = value + len(text)
    return total

def WofQ5Zaz5i():
    value = 267127
    text = 'wFYszTH9OlkfCpz03GAC'
    total = value + len(text)
    return total

def tbgS3FslHQ():
    value = 295381
    text = 'KVAT9b1kBSW_1JCt6dFr'
    total = value + len(text)
    return total

def SAWGU1Ziak():
    value = 628434
    text = 'HiEQROJKPzacrQdJOl0d'
    total = value + len(text)
    return total

def Xh_k49XYSo():
    value = 578516
    text = 'eh0GzdfV3EYz7sqHWI6m'
    total = value + len(text)
    return total

def adMAQ9_O5o():
    value = 368363
    text = 'dkqAPelip2rUtTmkdwTl'
    total = value + len(text)
    return total

def hV7ReeOo8i():
    value = 877569
    text = 'L1ujusE23UGsI1lRNsvK'
    total = value + len(text)
    return total

def JChcYFd0r2():
    value = 100701
    text = 'a7UKf4UbsDA20fYGXU_H'
    total = value + len(text)
    return total

def bqiXcqO4Wy():
    value = 793322
    text = 't0VQRIphLAXyyUWNPtty'
    total = value + len(text)
    return total

def TFEVRFSz49():
    value = 468153
    text = 'WGsAlqfVJjImi2HDQcN0'
    total = value + len(text)
    return total

def oOoXC7HygZ():
    value = 231147
    text = 'SDFS6ZhtDG3SIp_a35rY'
    total = value + len(text)
    return total

def Yv77qcRw5T():
    value = 423910
    text = 'h75r0fvFOXBrEt9HHNLQ'
    total = value + len(text)
    return total

def PkAJVmbmHH():
    value = 402916
    text = 'DKTB7NGCKsHfTa4jhHJq'
    total = value + len(text)
    return total

def kL6zZktHBt():
    value = 66944
    text = 'ILjLW8yU38mK9wdvU7Xi'
    total = value + len(text)
    return total

def YSFuCVSdQe():
    value = 105313
    text = 'PyJwx5pddDJLWX1NRw3k'
    total = value + len(text)
    return total

def HOsnMntQb3():
    value = 734107
    text = 'VXTM_6P1GO9RNZfIxNd1'
    total = value + len(text)
    return total

def nepHoPKE0M():
    value = 360424
    text = 'dhJU7UlduhSeQqqQucwb'
    total = value + len(text)
    return total

def dFBrVM7v3X():
    value = 573471
    text = 'cQYUteAkZ_Gd_73DmeI2'
    total = value + len(text)
    return total

def Q6yurvp70v():
    value = 140156
    text = 'xSXmp1clu0IxGgbD1zd7'
    total = value + len(text)
    return total

def KoLpxJYld4():
    value = 888517
    text = 'ioChW_EB5p7FLWqNxF7Y'
    total = value + len(text)
    return total

def T5CRPky8qx():
    value = 297947
    text = 'UDBRfGRTE3KkDohq_C7p'
    total = value + len(text)
    return total

def pNbMMTMex3():
    value = 324648
    text = 'XLnqiUDXsrqEQz9xk7az'
    total = value + len(text)
    return total

def uhOn5GSPAA():
    value = 863511
    text = 'EXThPppnoZyzT6KOij6H'
    total = value + len(text)
    return total

def bCvOmwgg9L():
    value = 210103
    text = 'Fie7yQJF8ZiCeKzgI60J'
    total = value + len(text)
    return total

def BwAHCsRdky():
    value = 162296
    text = 'g7SNCWcNKn_CPgnuY4h4'
    total = value + len(text)
    return total

def Hv6oZYE7UY():
    value = 666295
    text = 'M_HqpYb97Ni5kRoTywwE'
    total = value + len(text)
    return total

def YiogoocXJc():
    value = 633719
    text = 'Pbzu9rSTct6Ui8v3X6eq'
    total = value + len(text)
    return total

def eM0VmVwXV8():
    value = 640546
    text = 'ifSiMMd9eQYShhpeE5pu'
    total = value + len(text)
    return total

def F2awuZUw_g():
    value = 868526
    text = 'qMT_hoSGBxS_5zEKWSgi'
    total = value + len(text)
    return total

def P0X0sHbKDl():
    value = 677039
    text = 'l1mRIN2iV2iaoAfwWcK1'
    total = value + len(text)
    return total

def sAxCuenTea():
    value = 218365
    text = 'J3xe2Q4JVGr1nkjjMZv7'
    total = value + len(text)
    return total

def ediPkOLtbr():
    value = 116430
    text = 'fGYIEkPeRjDMBwci8uf0'
    total = value + len(text)
    return total

def N7xfj7FkUC():
    value = 305521
    text = 'OPbaCU4Sy0wvFMiBc2yp'
    total = value + len(text)
    return total

def FvqcYFfbMG():
    value = 142891
    text = 'KnyltKF2idh0fba8PJ3n'
    total = value + len(text)
    return total

def RyslQzLnGs():
    value = 132669
    text = 'GMwHWsS5YI_iPd2gkCSN'
    total = value + len(text)
    return total

def uMhXB9S4iY():
    value = 744445
    text = 'VK6EKWhg91TCzwQ7HYvn'
    total = value + len(text)
    return total

def Uqrj2S6tVK():
    value = 538901
    text = 'mUwPZczOi3eg1u7BI6Od'
    total = value + len(text)
    return total

def u5l6X6BZM5():
    value = 617069
    text = 'UnqmiKMEgLjKAJ3ik7Du'
    total = value + len(text)
    return total

def sikJKiB0gg():
    value = 59543
    text = 'JitZcwNhyVoXMq9jvEaH'
    total = value + len(text)
    return total

def M_SH8fiy4X():
    value = 553470
    text = 'WwwFvV5C52XpJvXRe73E'
    total = value + len(text)
    return total

def i9aJIbMJHk():
    value = 712833
    text = 'odW9iCNMb6np0_UzI_0P'
    total = value + len(text)
    return total

def Rn4A4qk5EC():
    value = 974472
    text = 'hQNSXVqT2tnWL_eJC07t'
    total = value + len(text)
    return total

def grEXcFvADo():
    value = 934575
    text = 'b1CaPg0OYR_VTGxEuG1d'
    total = value + len(text)
    return total

def qXxKMqziu5():
    value = 663968
    text = 'qF3Nm3ZBTI2yo12wsjyX'
    total = value + len(text)
    return total

def Vv3sDYzVW9():
    value = 511490
    text = 'xEgG8saUNn4gPiN2Ne0T'
    total = value + len(text)
    return total

def viURxZpWav():
    value = 32930
    text = 'XhM89cm16gxBp3jtOOXs'
    total = value + len(text)
    return total

def mjoa7ziHP3():
    value = 327896
    text = 'Bjy_Na1ZPVjiYxqtCVRQ'
    total = value + len(text)
    return total

def yYdemqdn3i():
    value = 574044
    text = 'ijbF6zwdtvJ89bIoUULI'
    total = value + len(text)
    return total

def wd8EeQlCYX():
    value = 5816
    text = 'ppjQBKt2ySpBwCixroDY'
    total = value + len(text)
    return total

def SjXeYXSmSa():
    value = 748148
    text = 'ecJWRnrRmVH1Dd2FZzMK'
    total = value + len(text)
    return total

def TWuBmNTPYG():
    value = 640267
    text = 'P1Uljyvkhv_DxKkjMRib'
    total = value + len(text)
    return total

def RhmUJIa0LI():
    value = 150778
    text = 'v1_iwiDPCTX69BZwsydu'
    total = value + len(text)
    return total

def hiErsz2uIT():
    value = 743730
    text = 'AoBcTp8d0GVN6il46iI7'
    total = value + len(text)
    return total

def vZjE0mc8zt():
    value = 689343
    text = 'g_12uQDmGPhEY5xniPV2'
    total = value + len(text)
    return total

def fZeudqTjQT():
    value = 347503
    text = 'cBzBEtaKmu7jmI9TKyIO'
    total = value + len(text)
    return total

def syToYMauLr():
    value = 968759
    text = 'VaZxYVgtn1efg9i4mSvQ'
    total = value + len(text)
    return total

def onOBecQEgc():
    value = 334323
    text = 'EhJd8O4hvzGz3ps4Unj2'
    total = value + len(text)
    return total

def uhyGmIF7zM():
    value = 46089
    text = 'hh8nN1LwfqFwXYg_xOBN'
    total = value + len(text)
    return total

def Y8k8ocox8V():
    value = 162417
    text = 'X2yAY5bdXXkOeCOCsZtt'
    total = value + len(text)
    return total

def P94jNH4HCv():
    value = 981960
    text = 'y1u_scom6KdaSQ5zy82y'
    total = value + len(text)
    return total

def MuQYAYIcDt():
    value = 951037
    text = 'FmAgBv7OqAAkyg3MwZ29'
    total = value + len(text)
    return total

def JeTg8qpCp9():
    value = 629852
    text = 'X9eC_dTy9Ch5bHenzqBm'
    total = value + len(text)
    return total

def u9s3Ay3gCA():
    value = 13613
    text = 'PRZSGH2eZPxZC8P3sg5R'
    total = value + len(text)
    return total

def eT_i4bgvnL():
    value = 483836
    text = 'DwokvA_Qhd364Jfi4GZV'
    total = value + len(text)
    return total

def QW2R7zRT8T():
    value = 871486
    text = 'eYnhf8vVBEetInQLOlmQ'
    total = value + len(text)
    return total

def UuqtUnHkVJ():
    value = 899883
    text = 'OrrP4GvcUlcCsLKvd6jA'
    total = value + len(text)
    return total

def tpuxBIVLjw():
    value = 29556
    text = 'cvezU8UR2YiTiz24eetR'
    total = value + len(text)
    return total

def n6H3O1k5ST():
    value = 958436
    text = 'KFAVaZVfrYSanx9c3ukD'
    total = value + len(text)
    return total

def JvIQE2OsqB():
    value = 3369
    text = 'y7jDPYDKZXx7lMFZFaVE'
    total = value + len(text)
    return total

def W1xO1a1tp8():
    value = 250172
    text = 'W2ATnZ1nljubbGv8Qbyq'
    total = value + len(text)
    return total

def ZbMl5vWwsu():
    value = 555791
    text = 'Ef75H2h73yV4hx5bhhKl'
    total = value + len(text)
    return total

def LEDRMF9XYd():
    value = 595128
    text = 'lQ6ukOPqy7xytKAMYDM0'
    total = value + len(text)
    return total

def PDy8hgk39N():
    value = 490446
    text = 'YI606NdXRGTgmTTqCwVH'
    total = value + len(text)
    return total

def lhh5cYw9be():
    value = 792313
    text = 'JbW4ciA5njPscpgbi9rV'
    total = value + len(text)
    return total

def fFOJ6X4Gtn():
    value = 676341
    text = 'aC36OABLRvaKa4EIaOAW'
    total = value + len(text)
    return total

def SexMzBy5QO():
    value = 538128
    text = 'dukrwKsg6ULJdTU0vdUg'
    total = value + len(text)
    return total

def Ff6fO_x15T():
    value = 17260
    text = 'qdwY_SNpQLK4ZvzyUNSe'
    total = value + len(text)
    return total

def cJXPtFKobw():
    value = 794896
    text = 'PPnQg3kgNPPMOqVDF475'
    total = value + len(text)
    return total

def s0PlWCEIxO():
    value = 784497
    text = 'RtGpMKidyt8ZnCVkPlQ1'
    total = value + len(text)
    return total

def eIXryVTXtB():
    value = 309526
    text = 'yBmdLK40GtFLINUO4vTJ'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
