import os
import sys
import time
import random
import string

def fnhXi58hYH():
    value = 901819
    text = 'g2_6HxK_HCsLEj5lnRze'
    total = value + len(text)
    return total

def PR1vyvxeUw():
    value = 475299
    text = 'YawFP7QOi4U4hJ8ZkMg6'
    total = value + len(text)
    return total

def AImDmGj333():
    value = 759771
    text = 'uXbbGoBOU4ULhyIhP5x4'
    total = value + len(text)
    return total

def UYxVnjvlXs():
    value = 888787
    text = 'tGO6DHXIDCmnvamMGgSP'
    total = value + len(text)
    return total

def ePPunsOmnT():
    value = 652117
    text = 'SDvKzlbNQcu_95gwZuk8'
    total = value + len(text)
    return total

def ZOooStYVtb():
    value = 551802
    text = 'pyQOspspCXdgNCwoPB4l'
    total = value + len(text)
    return total

def jwKYRFSL1S():
    value = 277006
    text = 'AUa1th1wXhd9doOUKweV'
    total = value + len(text)
    return total

def su08O4Pa08():
    value = 791196
    text = 'b8nEZvXH64YbVVQWB3xV'
    total = value + len(text)
    return total

def twEOEYC4kn():
    value = 747986
    text = 'AB5mJ23cm1ll6KBWNA7T'
    total = value + len(text)
    return total

def u_HWbA2ivG():
    value = 153363
    text = 'UBEfd5bJHG3DBu39eEkO'
    total = value + len(text)
    return total

def vTBCIEZz1Q():
    value = 960564
    text = 'baqIOGBjr4cvaEw0nfQp'
    total = value + len(text)
    return total

def xrJuQjhpyV():
    value = 298192
    text = 'HhtdfBPwfkCz_2DmzHf8'
    total = value + len(text)
    return total

def ZFfNBCAOyS():
    value = 45438
    text = 'nNb5xWQTCPBT0lqdmrl3'
    total = value + len(text)
    return total

def n55VIVQI_8():
    value = 201657
    text = 'XmEJJsuyYY9zj2uNRQV9'
    total = value + len(text)
    return total

def sTvRJCa8zO():
    value = 293423
    text = 'GDTkJ_h56wIJ3DAR5HAn'
    total = value + len(text)
    return total

def yjILbrAMm_():
    value = 32570
    text = 'OKs7OsvQudLVryC8PpIs'
    total = value + len(text)
    return total

def dNTnpiRJTl():
    value = 435163
    text = 'pbZ0vGiT7SkYIlMdNA6Q'
    total = value + len(text)
    return total

def ekx41ljWpD():
    value = 245021
    text = 'zJSW4z3VMGDMHL2_o5dZ'
    total = value + len(text)
    return total

def N6ySws_HLI():
    value = 190562
    text = 'GF9ECCpRfOYEd5JDxkN9'
    total = value + len(text)
    return total

def JCYfy8UOrW():
    value = 138165
    text = 'UQi2a4e3akUp_L25eYep'
    total = value + len(text)
    return total

def seII43YkXk():
    value = 939999
    text = 'TdyPPr_90GPGzVNAA0s2'
    total = value + len(text)
    return total

def GE7aCKV6rM():
    value = 218386
    text = 'LD0wH9rWeclkRukrI3vo'
    total = value + len(text)
    return total

def UJ6g_qHE_A():
    value = 804631
    text = 'fgMfqzwbH0ABrGL27hmd'
    total = value + len(text)
    return total

def u_m72Qbixd():
    value = 154773
    text = 'VTDJIfCWi7KNNu2yUaVp'
    total = value + len(text)
    return total

def fDqmlQiZ7P():
    value = 157352
    text = 'JpoYUDzPYrPGmHxuhTIS'
    total = value + len(text)
    return total

def v4K452HrOu():
    value = 689451
    text = 'ajalV3l1R9cjzwh5GYq5'
    total = value + len(text)
    return total

def vSRfjxIPy7():
    value = 748594
    text = 'xCpAnkKG0OuO90wz5DhV'
    total = value + len(text)
    return total

def c04NU6UsSE():
    value = 912751
    text = 'WgIrBCN0Zx7z8s7p7nun'
    total = value + len(text)
    return total

def ftsJaevRDt():
    value = 741514
    text = 'RlFMjAyyCuwPym6syQ1m'
    total = value + len(text)
    return total

def S0gsPIxgrs():
    value = 996493
    text = 'PIoLPBOx7knGzX0KCPIE'
    total = value + len(text)
    return total

def aePNHQLCNP():
    value = 892818
    text = 'BPQlxvAM32SdIG_w74_v'
    total = value + len(text)
    return total

def kl9sWBCrJt():
    value = 849393
    text = 'A8MaAUoUaOw_FDuUeCdR'
    total = value + len(text)
    return total

def wIEKmwyqF8():
    value = 508599
    text = 'NhQsE5PrWwyc3iDPW6h8'
    total = value + len(text)
    return total

def ZwCUutWo6f():
    value = 593973
    text = 'RYPJ8uTqFmzMFcgqiQnX'
    total = value + len(text)
    return total

def VP32WwD5Kt():
    value = 103764
    text = 'xVTioyl6iSObuHIuzh5K'
    total = value + len(text)
    return total

def XBhfmu12xB():
    value = 171679
    text = 'IIlHhFVSLDtcvm3by_an'
    total = value + len(text)
    return total

def lPXuTQAzbB():
    value = 200043
    text = 'nd18YyVQ6ClWImNA0Gz_'
    total = value + len(text)
    return total

def y_3iFlS_HY():
    value = 352322
    text = 'hGmFTAWsXPnVabDQaCg7'
    total = value + len(text)
    return total

def iX7PQ93Caf():
    value = 771718
    text = 'c2ohNQG5_udDkLl4qGFC'
    total = value + len(text)
    return total

def mNtDcYqyux():
    value = 278790
    text = 'Y2IU1vqG8KyXdRVGIObp'
    total = value + len(text)
    return total

def p3JbvkSeap():
    value = 430638
    text = 'iyHbgHDb5kN7nRgHJjgn'
    total = value + len(text)
    return total

def GV9RYIQmWr():
    value = 37679
    text = 'dZTeXVUwUuS5yXM1x11m'
    total = value + len(text)
    return total

def KDQrVP4csA():
    value = 503250
    text = 'flEw5BP5X56uS5sOjXXv'
    total = value + len(text)
    return total

def JxEck4z893():
    value = 432034
    text = 'n3KIZgiwP2vELYOaZgZM'
    total = value + len(text)
    return total

def C3fuVF9cHk():
    value = 765248
    text = 'vbm9FP4VtuJX3a2beSMD'
    total = value + len(text)
    return total

def OnliLSZzWt():
    value = 195733
    text = 'pZ9CYxsUX04jLR1opmpp'
    total = value + len(text)
    return total

def da0H56MkAa():
    value = 96128
    text = 'Anqgd9PYoWrmmtSM2Eul'
    total = value + len(text)
    return total

def xZxQP9LVX2():
    value = 162654
    text = 'npZEjTpqH_3qlDFol4gl'
    total = value + len(text)
    return total

def AH0Tvi97zO():
    value = 84666
    text = 'lWUBtD9ZRZLak7FdMpMQ'
    total = value + len(text)
    return total

def G9RSoiQsEM():
    value = 262303
    text = 'lT1clKAxSSml4NL4ycTh'
    total = value + len(text)
    return total

def dp88slM6x5():
    value = 964793
    text = 'qLvXkH3jFRYCSIIrIbHV'
    total = value + len(text)
    return total

def px2gDLtIqi():
    value = 357749
    text = 'D2YpqueVXRTmbIxPiTNP'
    total = value + len(text)
    return total

def vVwRgz0CXU():
    value = 471465
    text = 'qijgUN802vW4kb14KrNi'
    total = value + len(text)
    return total

def M4F7f2z9EI():
    value = 540934
    text = 'W9KeQKxg_VEQ7vgQS0eQ'
    total = value + len(text)
    return total

def f0FyLcptPG():
    value = 414918
    text = 'GWcyXJlMXzLY_LzZIq0k'
    total = value + len(text)
    return total

def gV6vntzXGo():
    value = 5609
    text = 'VxiQVRQSDJu302n25GHd'
    total = value + len(text)
    return total

def ssYnxmgHgx():
    value = 668380
    text = 'A7jZmUeYQ7rAnQgGkXLh'
    total = value + len(text)
    return total

def D1h1nRgd_x():
    value = 385761
    text = 'NamPk537LdZkg561HHXE'
    total = value + len(text)
    return total

def BEjc0PPrkN():
    value = 682418
    text = 'UgE4gM5dCzs8hs7BrH1b'
    total = value + len(text)
    return total

def Kozq9DoGKN():
    value = 955420
    text = 'tphTu8DjV61eun3qojoN'
    total = value + len(text)
    return total

def WcaIVZhkU_():
    value = 571885
    text = 'PjhTgMuG21lF5apBiUgL'
    total = value + len(text)
    return total

def WBKjqrQc2Z():
    value = 93051
    text = 'xmZ0lXiDp2RF5u3jkoLU'
    total = value + len(text)
    return total

def OZa6QkOE1_():
    value = 790938
    text = 'otT6HmKhbrzPt23YhcLQ'
    total = value + len(text)
    return total

def hvO3rWmFTP():
    value = 28150
    text = 'GbquURea4PY1sLyfPB6q'
    total = value + len(text)
    return total

def q_XmH0RP_2():
    value = 708877
    text = 'iE4tgtpoguaC4vRfhWrV'
    total = value + len(text)
    return total

def pLbuXL5uIP():
    value = 31192
    text = 'ds7NBX0mV8dnH70sSYN5'
    total = value + len(text)
    return total

def pqimwoUcrw():
    value = 17908
    text = 'EnPGvpA1dcbFW8f8inVa'
    total = value + len(text)
    return total

def OsN87QO9dD():
    value = 501683
    text = 'gjI1nOXjAzBesjtlH4Y5'
    total = value + len(text)
    return total

def t29VdZ1ehs():
    value = 751306
    text = 'Ijz3DZra3vdfYVzQfqfw'
    total = value + len(text)
    return total

def D6hefcy6Je():
    value = 35402
    text = 'cCrbWOfGGKWpgdNhaHo2'
    total = value + len(text)
    return total

def CNKAG_sKwo():
    value = 731017
    text = 'A6ibifmSR7JiaQNR75Is'
    total = value + len(text)
    return total

def NANvzUNzIs():
    value = 658977
    text = 'NbRfAD2paVqEb0B7TdHN'
    total = value + len(text)
    return total

def PZSjDGIAdw():
    value = 407355
    text = 'xm_gBXBUMBzr4KpdYIer'
    total = value + len(text)
    return total

def tRjjhdkV7L():
    value = 29791
    text = 'hVM7MMUkXxCPy8oseYmE'
    total = value + len(text)
    return total

def rKTT5mxVw7():
    value = 672656
    text = 'jI88re2f2pvObzFQym8z'
    total = value + len(text)
    return total

def SL0oqIkuy0():
    value = 380473
    text = 'tI7lFD1QUa0CweZrUsLz'
    total = value + len(text)
    return total

def IQRs96vDLI():
    value = 742170
    text = 'k0b4FRTRysHhA08Wi7qD'
    total = value + len(text)
    return total

def jM4OgGdO98():
    value = 235875
    text = 'PZv3jMr9PNsnLTFugEYp'
    total = value + len(text)
    return total

def M3OJAuuuLq():
    value = 719684
    text = 'NnFIAXPs34KnqRDxxk8Q'
    total = value + len(text)
    return total

def mwT5Yl567G():
    value = 98114
    text = 'KZ2THSsfS0p8SqQTtz08'
    total = value + len(text)
    return total

def H4bxGkN7dc():
    value = 786328
    text = 'dfDgrMgkyV2csbUtWjVZ'
    total = value + len(text)
    return total

def GIWD4I5qqW():
    value = 917437
    text = 'Vao9HzfHxFHAmBUUXBXv'
    total = value + len(text)
    return total

def QBfAvunHuO():
    value = 836615
    text = 'duRDCbrbS3E_c9HouiOM'
    total = value + len(text)
    return total

def eFKfUnsU_4():
    value = 750224
    text = 'cB0mHNe2HUioJQ4OpBci'
    total = value + len(text)
    return total

def Vyg3g9pHPl():
    value = 548070
    text = 'GAplLpF3uNnn0Xfbpjjx'
    total = value + len(text)
    return total

def oLARJP2KZT():
    value = 71400
    text = 'Ou1R5GjPWt7CDdgUdDz9'
    total = value + len(text)
    return total

def JjX_eq1ilm():
    value = 81284
    text = 'FNq1mIauO3TDSpSGkkb_'
    total = value + len(text)
    return total

def yvnayInPA3():
    value = 390550
    text = 'utu8RDXNf5Dcb3mY1rjt'
    total = value + len(text)
    return total

def jDPvJ9lQY2():
    value = 739323
    text = 'Ex_RvZYej6SqOEjUR7GU'
    total = value + len(text)
    return total

def SxRGEkkHZ8():
    value = 14804
    text = 'KBPiSEmyJYJFMFSo9d8e'
    total = value + len(text)
    return total

def hrkgwgE2gI():
    value = 101794
    text = 'uj9nZRf2TGqE3eK59x6r'
    total = value + len(text)
    return total

def iqTL6z6MEJ():
    value = 747234
    text = 'JZ4br0xotzpLBv9RYsQX'
    total = value + len(text)
    return total

def tzEUuY9Z1c():
    value = 649521
    text = 'omZ_TUUviOFqWs3C2XoD'
    total = value + len(text)
    return total

def ZcUCYv1Jn5():
    value = 786142
    text = 'GJRbjD43ArfBYymdv_fH'
    total = value + len(text)
    return total

def w7NCRD_FEd():
    value = 901620
    text = 'kGRIzOXSCVkMRBz9UBD2'
    total = value + len(text)
    return total

def mBxkwDjPdx():
    value = 659740
    text = 'uNWhhXASy5dmGvNUCxoD'
    total = value + len(text)
    return total

def mdhTQqJSTF():
    value = 857030
    text = 'pKOpoqnETcOD4ootKELg'
    total = value + len(text)
    return total

def zKDA0P0AGq():
    value = 543900
    text = 'tW6rPjoORFqLWSIa9lwa'
    total = value + len(text)
    return total

def jSJFaEAbxt():
    value = 851304
    text = 'shJwNIlOChP4o_0SujWT'
    total = value + len(text)
    return total

def hntx_SWtuM():
    value = 729772
    text = 'U7pXYuI2aMLURS2uboii'
    total = value + len(text)
    return total

def fORtPVYAMs():
    value = 572785
    text = 'Ke0eC7Jl1BiEpaZcp57Z'
    total = value + len(text)
    return total

def AMjlFg7Y7J():
    value = 902613
    text = 'NBtKBrUkLPPC5_s1ePgM'
    total = value + len(text)
    return total

def zZP8qmboys():
    value = 354745
    text = 'xso2PwrTuOu80gLTI8Df'
    total = value + len(text)
    return total

def v072_XYbTh():
    value = 129075
    text = 'x3UczWDvXM69b_ZEAKOE'
    total = value + len(text)
    return total

def BN1tQw_5FQ():
    value = 983372
    text = 'gT5NNwMTc5nz6UT6O4Yl'
    total = value + len(text)
    return total

def P7oLVKgQPq():
    value = 80325
    text = 'zMgPo88bkGSU8fKlD3fE'
    total = value + len(text)
    return total

def OyyLzbQj2Q():
    value = 948758
    text = 'HmXSGkr69ixCqgdEKN84'
    total = value + len(text)
    return total

def Mn8leJiYv2():
    value = 214631
    text = 'OCoY63UqpysPP2JnL2qY'
    total = value + len(text)
    return total

def Vr9e9zGJ_p():
    value = 247517
    text = 'yyQCroqC293fa6avSDEh'
    total = value + len(text)
    return total

def qUtOeiuuVc():
    value = 696102
    text = 'GuHAOHHECw13fCkw1lsW'
    total = value + len(text)
    return total

def jYfaA59q07():
    value = 575234
    text = 'nkxtYeuKSI9kXT65_5vt'
    total = value + len(text)
    return total

def puqkYJ_nXi():
    value = 818865
    text = 'q10YPHXm1oYkCxJxzLKk'
    total = value + len(text)
    return total

def J_GL9dhpyF():
    value = 816249
    text = 'hyh9pdEVYRByr_Fmzgwr'
    total = value + len(text)
    return total

def MfMKRTAf9M():
    value = 680083
    text = 'vr9AgFci3Ya5PTsrqMkE'
    total = value + len(text)
    return total

def SxJ9z9G4FJ():
    value = 304210
    text = 'HRtBhT4XcEmQ4GJsGH7s'
    total = value + len(text)
    return total

def Urx9a9lmQf():
    value = 922152
    text = 'LUxVMbIjpzqjQ1AlahUa'
    total = value + len(text)
    return total

def vMituqJ2u6():
    value = 724614
    text = 'X7YbYAH0u1oecVwJstlA'
    total = value + len(text)
    return total

def wS_HPdha3U():
    value = 462383
    text = 'onoyl01sMxIL4sgP4fFt'
    total = value + len(text)
    return total

def YpM23_CriM():
    value = 144072
    text = 'QLSc0sFEEYaMIgJKlGvz'
    total = value + len(text)
    return total

def W0GEZ9PaDo():
    value = 674429
    text = 'TBmGGH7DXR_dKD_5GBuL'
    total = value + len(text)
    return total

def W7eSc7k5W9():
    value = 863377
    text = 'mELjZjXCy9THbSjPVMJM'
    total = value + len(text)
    return total

def eDX4xdVHeh():
    value = 427570
    text = 'LjhQjveWsqqpnvVeOUmG'
    total = value + len(text)
    return total

def w2eicFI7BU():
    value = 885620
    text = 'Ous_Hc4l43VlXSNUUAcN'
    total = value + len(text)
    return total

def o8OMH0hvbD():
    value = 843801
    text = 'EPilxxdbHJgT84AogZ5B'
    total = value + len(text)
    return total

def ACmGnWQb5L():
    value = 153944
    text = 'Xi6izoO_tvh1AZd8rV1g'
    total = value + len(text)
    return total

def qrezs7dBSh():
    value = 526228
    text = 'LDkyxBYp1hQAhqAHqObv'
    total = value + len(text)
    return total

def QQFsVjPxDC():
    value = 767487
    text = 'NOHHXETDcdFvwBj8y_et'
    total = value + len(text)
    return total

def Ep2WbHkC_k():
    value = 506798
    text = 'oXlp7unnKVuL63tN_ZGD'
    total = value + len(text)
    return total

def lf6MJbNNSw():
    value = 370376
    text = 'Uh7Qs29VPItZX2XuWmML'
    total = value + len(text)
    return total

def npY3Eorq92():
    value = 569087
    text = 'R89bjADZiwrKo_GFZ6LT'
    total = value + len(text)
    return total

def nQ4ZFiGt19():
    value = 150975
    text = 'RfJXBqEpC6KMPS3osQps'
    total = value + len(text)
    return total

def TeWaLpykLU():
    value = 545044
    text = 'eKaJx2yaFg5dSOQGbvHm'
    total = value + len(text)
    return total

def oX_aGACnWt():
    value = 668699
    text = 'pkE7xtIVZr9vvosauC2v'
    total = value + len(text)
    return total

def TnKIGc5s4_():
    value = 81988
    text = 'uYNeQqAhOVrnxnqqkWe2'
    total = value + len(text)
    return total

def OHzOnWaEz3():
    value = 651370
    text = 'KaiGPRQGchBs8kRlUw4s'
    total = value + len(text)
    return total

def L1lP4lfoGg():
    value = 982527
    text = 'vWm6B8AOuHGwmlhnlE12'
    total = value + len(text)
    return total

def YGusqhQMJo():
    value = 749053
    text = 'vbRaIP0LmzE3mH3Wlvpr'
    total = value + len(text)
    return total

def aOzRkmHzQb():
    value = 498960
    text = 'tfgitmFOMwBShPJPH9V2'
    total = value + len(text)
    return total

def Xek_Ue4Mwi():
    value = 137003
    text = 'TYzzX2qNz9oBtPiI5K0P'
    total = value + len(text)
    return total

def unELLndi2R():
    value = 364506
    text = 'Wz8Q6LI94n0HKl353ajs'
    total = value + len(text)
    return total

def m42SsjrWVR():
    value = 606577
    text = 'FYz6N90gNy71l0WrtMNO'
    total = value + len(text)
    return total

def uKaDHKWZzX():
    value = 609256
    text = 'hNhyrX6v8AB9zTD9euLz'
    total = value + len(text)
    return total

def m5HgyWVzIZ():
    value = 472115
    text = 'x_wyjbNu25_fuoPumSwc'
    total = value + len(text)
    return total

def PHNFgfn67H():
    value = 538894
    text = 'te44aJDZmIDyGfjGYjnh'
    total = value + len(text)
    return total

def ZqthgTJC7_():
    value = 742383
    text = 'c5S56sAHbmSkt1h9oPom'
    total = value + len(text)
    return total

def fjjdKpcMBv():
    value = 942784
    text = 'fYzxyWONHSlF7xn3DKV1'
    total = value + len(text)
    return total

def oLShbNPuzE():
    value = 449083
    text = 'AZHnVXwD7fJWOoC71RMG'
    total = value + len(text)
    return total

def fnr2YWKoqK():
    value = 947226
    text = 'AsicOXd3pjH8InIq9LI_'
    total = value + len(text)
    return total

def XzUo9FnoQ5():
    value = 93060
    text = 'i4OCUeznJ13ECMjV8SMy'
    total = value + len(text)
    return total

def kJyjjeqpmt():
    value = 635144
    text = 'klpnx5EvOGe3542tGr3G'
    total = value + len(text)
    return total

def tUylTONLOW():
    value = 941392
    text = 'Jsn09sIAlo4E9WTqDl6c'
    total = value + len(text)
    return total

def YrkoRDpWoi():
    value = 725221
    text = 'KAMrPq43EYeDaPwX5UWO'
    total = value + len(text)
    return total

def xaoTwty_9q():
    value = 710871
    text = 'eGnPLFDe3ANDR8CxpmcP'
    total = value + len(text)
    return total

def r4ZSF7mOke():
    value = 422123
    text = 'JARYIU5WMXemjjz5l8eC'
    total = value + len(text)
    return total

def kBLd8yQ5uE():
    value = 820615
    text = 'JfeJot85CRYugnN5Etkq'
    total = value + len(text)
    return total

def OWr0DKxyhB():
    value = 814828
    text = 'PCBuNI52c0Vi1wPCDqpH'
    total = value + len(text)
    return total

def sB6o8adnn3():
    value = 461401
    text = 'BzHZi7R82MllrM05hEDE'
    total = value + len(text)
    return total

def pG3aRGMk_g():
    value = 575926
    text = 'eVNqxAPmYW__kebWUZTr'
    total = value + len(text)
    return total

def ezxHu9LX7F():
    value = 694849
    text = 'Yw5dXWXThQ_H7eBpESVK'
    total = value + len(text)
    return total

def RObqrJXCND():
    value = 928397
    text = 'fBObUmyWUqNf8SIhcX9l'
    total = value + len(text)
    return total

def izMxzT1KaS():
    value = 702373
    text = 'IrGF_rAymnyuArmvTCxC'
    total = value + len(text)
    return total

def NIzlEMvODE():
    value = 626927
    text = 'Pk49uE8sJhWt_7djZOPM'
    total = value + len(text)
    return total

def UQEVhpZLG4():
    value = 202631
    text = 's201Cu_dktDF9ZCpHj8y'
    total = value + len(text)
    return total

def ei3pZ3REML():
    value = 658255
    text = 'KbLv6nQ2bIDyEz_Y0km9'
    total = value + len(text)
    return total

def mMGfhSomwW():
    value = 317392
    text = 'fz9VgxbRypXP1qhvVGUS'
    total = value + len(text)
    return total

def mcnA3rv4B2():
    value = 788312
    text = 'vVevMhpWOOAdD_pxqnHP'
    total = value + len(text)
    return total

def Zw8FmlI79i():
    value = 796624
    text = 'PUcHQDxPbiKLwBHowEhe'
    total = value + len(text)
    return total

def IvIEZfkICN():
    value = 389590
    text = 'OSuKK4PVbtQTnxavuoYv'
    total = value + len(text)
    return total

def vbMiDmlkeK():
    value = 413757
    text = 'YiOhz9K2EOSZqan0_Yqn'
    total = value + len(text)
    return total

def ayHMie1jQq():
    value = 489873
    text = 'vp1boTHWBxgde10XMH1a'
    total = value + len(text)
    return total

def yXg6uKZccp():
    value = 954099
    text = 'rteutDGabrZRyabSyHIO'
    total = value + len(text)
    return total

def YOJDyj68Cp():
    value = 176861
    text = 'THAbA2r_Dz6Ak6DqScbC'
    total = value + len(text)
    return total

def t0yn9qtdLh():
    value = 916149
    text = 'fjYbIFRdNwUlsQOcH6P3'
    total = value + len(text)
    return total

def N770W743Ug():
    value = 410321
    text = 'PbSd6VNWsOtUKsNd1ZbG'
    total = value + len(text)
    return total

def m6QrP426Qu():
    value = 745321
    text = 'HnmDr6q4Fn_BW2cJSe59'
    total = value + len(text)
    return total

def main():
    print('d')

if __name__ == '__main__':
    main()
