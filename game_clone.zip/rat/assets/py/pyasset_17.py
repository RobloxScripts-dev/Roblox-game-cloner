import os
import sys
import time
import random
import string

def PAjq7Sh2Tw():
    value = 805352
    text = 'roOEenhOGJdxapB32qFK'
    total = value + len(text)
    return total

def wdsBfAz5TG():
    value = 754547
    text = 'XzLesQqViAE_qkJG6VDO'
    total = value + len(text)
    return total

def RyY75Y4q3P():
    value = 814416
    text = 'BPVqnaSkkQOvbOyMY8LW'
    total = value + len(text)
    return total

def QqQ9D2WLEr():
    value = 180434
    text = 'WZdT5GCxZaia0UQJ67K9'
    total = value + len(text)
    return total

def SXfYmD2hVp():
    value = 3554
    text = 'hQaxCDYMCadnIudOdHeg'
    total = value + len(text)
    return total

def XhktJkLLLQ():
    value = 954952
    text = 'gMPhc230hnR5xVHHPtPP'
    total = value + len(text)
    return total

def SlzTSYWzYp():
    value = 828658
    text = 'cLWJp6hOjpIjWAAPioA6'
    total = value + len(text)
    return total

def oggl18L2sx():
    value = 207364
    text = 'OtLZMnvqq7ucjmgTFMKw'
    total = value + len(text)
    return total

def I0z_f2oluI():
    value = 35527
    text = 'jP8OQjOjZJfDWm5JcEVI'
    total = value + len(text)
    return total

def QH_FGzdaCO():
    value = 496834
    text = 'GuEAfCgtjbZuTk7J7bu4'
    total = value + len(text)
    return total

def cWkfx6ZT42():
    value = 317674
    text = 'VJ_4EB9DfZeO8EgKTlZw'
    total = value + len(text)
    return total

def yP0HystUjI():
    value = 249712
    text = 'hE2rYw7urqSKCFmRgSl6'
    total = value + len(text)
    return total

def NaRAsmuFxc():
    value = 105892
    text = 'VaPr5tVcl16NvrYjv6r4'
    total = value + len(text)
    return total

def iPBO8ZAwWy():
    value = 688140
    text = 'AnYUfAlnGxmW9CgKiSwU'
    total = value + len(text)
    return total

def GwnZyVwxXh():
    value = 613097
    text = 'cH4Kr6f63bbFmIPsNG69'
    total = value + len(text)
    return total

def QvsEEidhaI():
    value = 13104
    text = 'sZa1oMz8OgUoCMdG0jJD'
    total = value + len(text)
    return total

def e7QyJY3BlU():
    value = 372884
    text = 'BD1x3IBNKEoqcPydzUhL'
    total = value + len(text)
    return total

def ekNt_TmT85():
    value = 603649
    text = 'm6ikr9v3wUtfde5wVEjC'
    total = value + len(text)
    return total

def g1f_toesgH():
    value = 421243
    text = 'eEUOHmxtSY7Vmxjy9X7L'
    total = value + len(text)
    return total

def BbLFZaJtRi():
    value = 267743
    text = 'lwW8_eNxhmvUHhKfcz6t'
    total = value + len(text)
    return total

def SRHTMG7VGQ():
    value = 944822
    text = 'lrEO9bTU1CwsURGi4NVL'
    total = value + len(text)
    return total

def gaUyYO8J4i():
    value = 348643
    text = 'MhFA0VmQEQlO2kTsJvDh'
    total = value + len(text)
    return total

def lKltZ5d6gB():
    value = 502283
    text = 'udw2LOQwk3O0y5puCVPP'
    total = value + len(text)
    return total

def T_NuGbjlj6():
    value = 427305
    text = 'BUoMEJH73Ka7XXeBiqPt'
    total = value + len(text)
    return total

def wu7GGDR5Jj():
    value = 63066
    text = 'EeTmeH7UYaW5ggL21FOU'
    total = value + len(text)
    return total

def qoHyqgUOym():
    value = 168327
    text = 'br6zmoROOL8eyfwCAt3p'
    total = value + len(text)
    return total

def S_NUogo19j():
    value = 572365
    text = 'TYs8fNBZ0il7_Wvg93jQ'
    total = value + len(text)
    return total

def lEih7VGqNq():
    value = 163331
    text = 'gxlRZFTK_9yMbeq1uUx2'
    total = value + len(text)
    return total

def OT7HHRiXa1():
    value = 109095
    text = 'lNTspiRubqr7vPXExDEh'
    total = value + len(text)
    return total

def qfXvTe_Sqv():
    value = 141377
    text = 'vmRML0llO8a5mZhNVoeD'
    total = value + len(text)
    return total

def Rldoy4Tw0i():
    value = 916507
    text = 'LEa7yZYWQ9BW3m8sFNKi'
    total = value + len(text)
    return total

def xzmAhTf8hR():
    value = 983184
    text = 'FPvHfUaXdiMaOXOQluWG'
    total = value + len(text)
    return total

def TZJF_7Huxh():
    value = 244613
    text = 'TUcwILPuNFTp9pb6suJu'
    total = value + len(text)
    return total

def FrL4mlORew():
    value = 692040
    text = 'E5n3xOwpIuVGCr8UUA1Y'
    total = value + len(text)
    return total

def N7JCUvpcGA():
    value = 948625
    text = 'qOa7g_Ib96FLJjaqHs2O'
    total = value + len(text)
    return total

def WV5Re4HQSQ():
    value = 350673
    text = 'qYIRFar2Gn3iwRwY9Wyn'
    total = value + len(text)
    return total

def L8k0ygMOry():
    value = 53244
    text = 'zYPPehXBfM60u2koA6by'
    total = value + len(text)
    return total

def qK3X3Q42xX():
    value = 725664
    text = 'kx2txt2HpSh_Lw7Z0fbG'
    total = value + len(text)
    return total

def Qj68dWinPv():
    value = 741727
    text = 'JtVhnNHA5IcDrU3NZTHp'
    total = value + len(text)
    return total

def K5v8e8QWtt():
    value = 641179
    text = 'P_gFqirlm2FUL0C3Sv_M'
    total = value + len(text)
    return total

def xGtfRjZDvp():
    value = 712083
    text = 'HXr2JdSQ1_IDyqHmxEet'
    total = value + len(text)
    return total

def boPFVkV4tW():
    value = 494379
    text = 'az5OJjAQJM7LagSBeOkW'
    total = value + len(text)
    return total

def DyEy39bfeX():
    value = 964715
    text = 'f6KZbe4lh96rnumprjJU'
    total = value + len(text)
    return total

def jAO45GEdL_():
    value = 181529
    text = 'AjsovHd1sTpxmKkaTTXo'
    total = value + len(text)
    return total

def SEUpbSC5wf():
    value = 521774
    text = 'fCu6hg4sNQJjAkBoQpZP'
    total = value + len(text)
    return total

def XYb7u3NALc():
    value = 163611
    text = 'Y5EFNWjQiyoIEpnpdQMI'
    total = value + len(text)
    return total

def vjzFPdHo11():
    value = 27306
    text = 'OrY7QYbwo2vZ3iFS4XBq'
    total = value + len(text)
    return total

def fsehjisjBD():
    value = 720772
    text = 'yPh2FDjnfNUMGK3iZV6e'
    total = value + len(text)
    return total

def lvnOyZJaJw():
    value = 115176
    text = 'yyVbii9MjTnWB5EsDn3K'
    total = value + len(text)
    return total

def hjot2VcDwi():
    value = 971723
    text = 'BQznnsoRhvfM8UpEPIpG'
    total = value + len(text)
    return total

def wlbzqzZuF8():
    value = 12844
    text = 'sAkGlRV1CZKGg_540pym'
    total = value + len(text)
    return total

def fZYHZiZ0eL():
    value = 814816
    text = 'y7koamCOuTvaXJZJ6trQ'
    total = value + len(text)
    return total

def IY60k1CB6N():
    value = 44973
    text = 'MY4QZnGLwflntTRo8Chf'
    total = value + len(text)
    return total

def Y_2NRw5AP1():
    value = 914584
    text = 'rCgnhGf8OT7wyOHUuwNK'
    total = value + len(text)
    return total

def sa8pGPb10C():
    value = 216528
    text = 'AEEQ9wgs5t8VVCuK3BCz'
    total = value + len(text)
    return total

def iKNfWMNSba():
    value = 179160
    text = 'isZkNq6qD_Mlk2BgE6KP'
    total = value + len(text)
    return total

def OerpUg4MQe():
    value = 942635
    text = 'QV8WDeM4DMKYKVJsIg3K'
    total = value + len(text)
    return total

def IJjHAyH807():
    value = 797779
    text = 'eHoJ3WIakwojANDPkVcO'
    total = value + len(text)
    return total

def gek9mmtWgl():
    value = 511947
    text = 'I0IrKVCBjQHrGC1DjO3_'
    total = value + len(text)
    return total

def x9CVvxmS0H():
    value = 72473
    text = 'CUUVXfjggHhu8WC6uqpN'
    total = value + len(text)
    return total

def xqgdpVUe4l():
    value = 9835
    text = 'EvAXEuMPc5_v5hkJXn9N'
    total = value + len(text)
    return total

def bzEcymnXc5():
    value = 740172
    text = 'iKPIfU4OYOz0O4ECMPHl'
    total = value + len(text)
    return total

def w617NGgfG9():
    value = 903945
    text = 'hPM9E95Q6fOcOvoiejqx'
    total = value + len(text)
    return total

def rezLKr9l1d():
    value = 433412
    text = 'Bsr_CCvHq5jRtnnHPKII'
    total = value + len(text)
    return total

def agnOzMRnR3():
    value = 514824
    text = 'fxqi4g5najlgvFsSz5i1'
    total = value + len(text)
    return total

def M9MLd0uFqe():
    value = 873152
    text = 'hw8JbkTDCpo4hLPlhus7'
    total = value + len(text)
    return total

def Kei14Z4obY():
    value = 117058
    text = 'tRMsMApsUpuT1emH2IE3'
    total = value + len(text)
    return total

def E7Kla6POLG():
    value = 289295
    text = 'N7ZIIOKZftUwKRAg9b03'
    total = value + len(text)
    return total

def qWTepv6ZlM():
    value = 593884
    text = 'Ju3WWXc5XyFisID8DQhM'
    total = value + len(text)
    return total

def p5sHZw1zZ6():
    value = 507031
    text = 'n_ae2R5E9TfzdRTRO_MZ'
    total = value + len(text)
    return total

def LcdkpbiSzP():
    value = 180939
    text = 'sPuMgAmzk_OLTTjZAdIP'
    total = value + len(text)
    return total

def NGx_D7Awm0():
    value = 614876
    text = 'GNejHad4a65_JIN74JHG'
    total = value + len(text)
    return total

def Z8EO3nSRiJ():
    value = 117660
    text = 'ArdsRIbsUEBRbib5BJ2j'
    total = value + len(text)
    return total

def IFpBWA7xIA():
    value = 295548
    text = 'x4sJP2CyxHmfsMR9_qjq'
    total = value + len(text)
    return total

def ufm5UO0TGW():
    value = 923522
    text = 'HNqnvGLeeFTGmtFYmZ1I'
    total = value + len(text)
    return total

def ZD2XGqHTnQ():
    value = 848087
    text = 'xRdk5WQNFZyh8GNCJbzt'
    total = value + len(text)
    return total

def Kl5aiOz8ob():
    value = 772226
    text = 'EfFVcP5yLHR0uZ35PMCK'
    total = value + len(text)
    return total

def WWFWrH5tLA():
    value = 926059
    text = 'hK_i19CJFJdQ9cBATmXu'
    total = value + len(text)
    return total

def SSy8fMIAGb():
    value = 302252
    text = 'iNkQ7j3aC0WxjiX5WKbf'
    total = value + len(text)
    return total

def rKaeQBRKPS():
    value = 351389
    text = 'fUYdIegPenRZHBU_HsPm'
    total = value + len(text)
    return total

def TeyI4GyoVc():
    value = 691758
    text = 'YwSCbrGfHAivzn6ixJ42'
    total = value + len(text)
    return total

def dxIDTy13FW():
    value = 866240
    text = 'mdzffdXzkzVaS2C5vG1s'
    total = value + len(text)
    return total

def OR7tOBVlpe():
    value = 324506
    text = 'JPoLeQGrvAzmeMQZ1v4Q'
    total = value + len(text)
    return total

def U7gwkvK0wo():
    value = 609946
    text = 'lh34Px8PBpc9dpAIeZD1'
    total = value + len(text)
    return total

def svY0pB2ULg():
    value = 478541
    text = 'RD9vDGt9oZiQ5ee6ZbYZ'
    total = value + len(text)
    return total

def HWM2CFRqco():
    value = 313269
    text = 'eZ3JntNjedAHDJTChXmg'
    total = value + len(text)
    return total

def hpgbPZZvhe():
    value = 234321
    text = 'HCcyEgOPs35dPLU5qAlB'
    total = value + len(text)
    return total

def jJZKcEAiMU():
    value = 610557
    text = 'reNeNGh1BdhtnmQpVowb'
    total = value + len(text)
    return total

def JuSOUUPKWJ():
    value = 56633
    text = 'iv1IcEPn0ILGBWzsPTkP'
    total = value + len(text)
    return total

def m46jydNsXW():
    value = 344615
    text = 'sDydup8_w4DOgp3DB4XG'
    total = value + len(text)
    return total

def TWuouRJccc():
    value = 668119
    text = 'rRRvQuao1xgu9qLZnWvv'
    total = value + len(text)
    return total

def U5wros4Bo_():
    value = 607371
    text = 'pBYyV15nLHkXOjQzujk2'
    total = value + len(text)
    return total

def zp18BsUE35():
    value = 892901
    text = 'DwWLLVTeYzTY5QP0U9oY'
    total = value + len(text)
    return total

def ipj4tRUXCl():
    value = 93388
    text = 'LB9BxaGjvX5AdUtjh7Uo'
    total = value + len(text)
    return total

def sQtdYRD9bx():
    value = 335375
    text = 'FEqlcTpRYxe16tnFwDSD'
    total = value + len(text)
    return total

def jSvK1Y3nIg():
    value = 928656
    text = 'MGBvOsHj1Y61nZbAFWOQ'
    total = value + len(text)
    return total

def gAL04nmg1A():
    value = 931461
    text = 'bn1VFFrf8uyZvNtI4HpK'
    total = value + len(text)
    return total

def O1gN5EGDOD():
    value = 538933
    text = 'BPEihj4aZbog0MCi56yi'
    total = value + len(text)
    return total

def TdO2hd7aJO():
    value = 19030
    text = 'p9_yaczFuLHGx5Bj4jRC'
    total = value + len(text)
    return total

def JtcyFwBegK():
    value = 599704
    text = 'FGnlv7LVC31G930qB0WF'
    total = value + len(text)
    return total

def ifTbfXTmn9():
    value = 333275
    text = 'FjQQ8WFxVitabGeyR7fK'
    total = value + len(text)
    return total

def HpHxI0TrVr():
    value = 762147
    text = 'axEp0pWNiNYLcWOc4J80'
    total = value + len(text)
    return total

def main():
    print('r')

if __name__ == '__main__':
    main()
